#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2007-2008 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region ' Header

#Region "Namespaces"

Imports Microsoft.VisualBasic
Imports System
Imports System.IO
Imports System.Collections
Imports System.Collections.Generic
Imports WinForms = System.Windows.Forms
Imports Autodesk.Revit
Imports Autodesk.Revit.Elements
Imports Autodesk.Revit.Symbols
Imports Autodesk.Revit.Events
Imports System.Diagnostics

Imports RvtElement = Autodesk.Revit.Element ' to avoid ambiguity with Geometry.Element
#End Region ' Namespaces


Namespace Labs
#Region "Lab_6_event"
    'Subscribe to , handling, unsubscribe to document saving event.
    Public Class Lab_Event_PreventSave
        Implements IExternalApplication
        Public Function OnStartup(ByVal application As ControlledApplication) As IExternalApplication.Result _
              Implements Autodesk.Revit.IExternalApplication.OnStartup
            Try
                'use  += operator to subscribe to DocumentSaving event. It is the same for other events
                AddHandler application.DocumentSaving, AddressOf app_eventsHandlerMethod
            Catch ex As Exception
                WinForms.MessageBox.Show(ex.Message)
                Return IExternalApplication.Result.Failed
            End Try

            Return IExternalApplication.Result.Succeeded
        End Function
        Public Function OnShutdown(ByVal application As ControlledApplication) As IExternalApplication.Result _
             Implements Autodesk.Revit.IExternalApplication.OnShutdown
            'remove the event subscription using -= operateor.
            RemoveHandler application.DocumentSaving, AddressOf app_eventsHandlerMethod
            Return IExternalApplication.Result.Succeeded
        End Function

        ' Shows a message to decide if save the document.
        Private Sub app_eventsHandlerMethod(ByVal obj As Object, ByVal args As PreDocEventArgs)
            If args.Cancellable = True Then
                'Ask if prevent the from saving.
                Dim dr As WinForms.DialogResult = WinForms.MessageBox.Show("Saving events handler was triggered. Using the pre-event mechanism , we have a chance to prevent it happening." & Constants.vbCrLf & "  Continue to save the document?", "Event document saving", WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question)
                args.Cancel = (dr <> WinForms.DialogResult.Yes)
            End If

        End Sub
    End Class
#End Region '"Lab_6_event"
End Namespace
