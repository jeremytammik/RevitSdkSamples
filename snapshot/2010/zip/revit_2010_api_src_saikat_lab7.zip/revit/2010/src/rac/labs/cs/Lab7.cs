#region Header
// Revit API .NET Labs
//
// Copyright (C) 2007-2009 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;
using Autodesk.Revit.Geometry;
using Autodesk.Revit.Elements;
# endregion

namespace Labs
{
    #region Lab7_1_CreateForm
    public class Lab7_1_CreateForm: IExternalCommand
    {  
        IExternalCommand.Result IExternalCommand.Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.Application app = commandData.Application;
            app = commandData.Application;
            Document doc = app.ActiveDocument;

            // Create profiles array
            ReferenceArrayArray ref_ar_ar = new ReferenceArrayArray();

            // Create first profile
            ReferenceArray ref_ar = new ReferenceArray();

            int y = 100;
            int x = 50;
            XYZ ptA = new XYZ(-x, y, 0);
            XYZ ptB = new XYZ(x, y, 0);
            XYZ ptC = new XYZ(0, y + 10, 10);
            CurveByPoints curve = FormUtils.MakeCurve(app, ptA, ptB, ptC);
            ref_ar.Append(curve.GeometryCurve.Reference);
            ref_ar_ar.Append(ref_ar);


            // Create second profile
            ref_ar = new ReferenceArray();

            y = 40;
            ptA = new XYZ(-x, y, 5);
            ptB = new XYZ(x, y, 5);
            ptC = new XYZ(0, y, 25);
            curve = FormUtils.MakeCurve(app, ptA, ptB, ptC);
            ref_ar.Append(curve.GeometryCurve.Reference);
            ref_ar_ar.Append(ref_ar);

            // Create third profile
            ref_ar = new ReferenceArray();

            y = -20;
            ptA = new XYZ(-x, y, 0);
            ptB = new XYZ(x, y, 0);
            ptC = new XYZ(0, y, 15);
            curve = FormUtils.MakeCurve(app, ptA, ptB, ptC);
            ref_ar.Append(curve.GeometryCurve.Reference);
            ref_ar_ar.Append(ref_ar);

            // Create fourth profile
            ref_ar = new ReferenceArray();

            y = -60;
            ptA = new XYZ(-x, y, 0);
            ptB = new XYZ(x, y, 0);
            ptC = new XYZ(0, y + 10, 20);
            curve = FormUtils.MakeCurve(app, ptA, ptB, ptC);
            ref_ar.Append(curve.GeometryCurve.Reference);
            ref_ar_ar.Append(ref_ar);

            Autodesk.Revit.Elements.Form form = doc.FamilyCreate.NewLoftForm(true, ref_ar_ar);        
            
            return IExternalCommand.Result.Succeeded;
        }
    }
    #endregion
    
    # region Lab7_2_CreateDividedSurface
    public class Lab7_2_CreateDividedSurface : IExternalCommand
    {
        IExternalCommand.Result IExternalCommand.Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Application app = commandData.Application;
            Document doc = app.ActiveDocument;
            try
            {
                // find forms in the model by filter:
                Filter filterForm = app.Create.Filter.NewCategoryFilter(BuiltInCategory.OST_MassSurface);
                List<Autodesk.Revit.Element> forms = new List<Autodesk.Revit.Element>();
                doc.get_Elements(filterForm, forms);
                foreach (Form form in forms)
                {
                    // Now, lets create the Divided surface on the loft form
                    Autodesk.Revit.Creation.FamilyItemFactory fac = doc.FamilyCreate;
                    Options options = app.Create.NewGeometryOptions();
                    options.ComputeReferences = true;
                    options.View = doc.ActiveView;
                    Autodesk.Revit.Geometry.Element element = form.get_Geometry(options);

                    GeometryObjectArray geoObjectArray = element.Objects;
                    //enum the geometry element
                    for (int j = 0; j < geoObjectArray.Size; j++)
                    {
                        GeometryObject geoObject = geoObjectArray.get_Item(j);
                        Solid solid = geoObject as Solid;
                        foreach (Face face in solid.Faces)
                        {
                            if (face.Reference != null)
                            {
                                if (null != face)
                                {
                                    Autodesk.Revit.Elements.DividedSurface divSurface = fac.NewDividedSurface(face.Reference);
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                return IExternalCommand.Result.Failed;
            }
            return IExternalCommand.Result.Succeeded;

        }
    }
    #endregion

    # region Lab7_3_ChangeTilePattern
    public class Lab7_3_ChangeTilePattern : IExternalCommand
    {
        IExternalCommand.Result IExternalCommand.Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Application app = commandData.Application;
            Document doc = app.ActiveDocument;
            try
            {
                // find forms in the model by filter:
                Filter filterForm = app.Create.Filter.NewTypeFilter(typeof(Autodesk.Revit.Elements.Form));
                List<Autodesk.Revit.Element> forms = new List<Autodesk.Revit.Element>();
                doc.get_Elements(filterForm, forms);
                foreach (Form form in forms)
                {
                    // Get access to the divided surface data from the form
                    DividedSurfaceData dsData = form.GetDividedSurfaceData();
                    if (null != dsData)
                    {
                        // get the references associated with the divided surfaces
                        foreach (Reference reference in dsData.GetReferencesWithDividedSurfaces())
                        {
                            DividedSurface divSurface = dsData.GetDividedSurfaceForReference(reference);

                            int count = 0;
                            TilePatterns tilepatterns = doc.Settings.TilePatterns;
                            foreach (Autodesk.Revit.Enums.TilePatternsBuiltIn TilePatternEnum in Enum.GetValues(typeof(Autodesk.Revit.Enums.TilePatternsBuiltIn)))
                            {
                                if (count.Equals(3))
                                {
                                    divSurface.ObjectType = tilepatterns.GetTilePattern(TilePatternEnum);
                                    break;
                                }
                                count = count + 1;
                            }
                        }
                    }                    
                }
            }
            catch
            {
                return IExternalCommand.Result.Failed;
            }
            return IExternalCommand.Result.Succeeded;
        }
    }
    #endregion

    # region Utilities
        /// <summary>
        /// This class is utility class for form creation.
        /// </summary>
        public class FormUtils
        {
            #region Class Implementation
            /// <summary>
            /// Create curve by points element by three points
            /// </summary>
            /// <param name="app">revit application</param>
            /// <param name="ptA">point a</param>
            /// <param name="ptB">point b</param>
            /// <param name="ptC">point c</param>
            /// <returns></returns>
            public static CurveByPoints MakeCurve(Application app, XYZ ptA, XYZ ptB, XYZ ptC)
            {
                Document doc = app.ActiveDocument;
                Autodesk.Revit.Elements.ReferencePoint refPtA = doc.FamilyCreate.NewReferencePoint(ptA);
                Autodesk.Revit.Elements.ReferencePoint refPtB = doc.FamilyCreate.NewReferencePoint(ptB);
                Autodesk.Revit.Elements.ReferencePoint refPtC = doc.FamilyCreate.NewReferencePoint(ptC); 

                Autodesk.Revit.Elements.ReferencePointArray refPtsArray = new ReferencePointArray();
                refPtsArray.Append(refPtA);
                refPtsArray.Append(refPtB);
                refPtsArray.Append(refPtC);

                Autodesk.Revit.Elements.CurveByPoints curve = doc.FamilyCreate.NewCurveByPoints(refPtsArray);

                return curve;
            }
            #endregion
        }
    # endregion
}
