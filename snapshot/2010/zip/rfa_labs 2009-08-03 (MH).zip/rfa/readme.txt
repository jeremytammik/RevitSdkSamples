
ReadMe -- Revit Family API Labs

Last updated: AUg 3, 2009 


Contents:

- cs 	   	� C# source

- csdoc    	� labs instruction for C# version  

- vb 	   	� VB source

- vbdoc    	� labs instruction for VB.NET version 

- template 	� Family template file we use for the labs.
 
- rfa_labs.sln 		� C# + VB solution

- Revit.ini.cs.txt 	� Revit.ini for C# version of labs 

- Revit.ini.vb.txt 	� Revit.ini for VB.NET version of labs 

- AdnSamples.txt 	� C# RvtSamples.txt include file (this is just for your convenience
                          in case you are interested in.) 
