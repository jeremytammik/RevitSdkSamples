This sample is prepared by Bill Zhang, DevTech, Autodesk for use in AU.
========================================================================
    DYNAMIC LINK LIBRARY : RevitCodingTips_VC Project Overview
========================================================================

AppWizard has created this RevitCodingTips_VC DLL for you.

This file contains a summary of what you will find in each of the files that
make up your RevitCodingTips_VC application.

RevitCodingTips_VC.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

RevitCodingTips_VC.cpp
    This is the main DLL source file.

RevitCodingTips_VC.h
    This file contains a class declaration.

AssemblyInfo.cpp
	Contains custom attributes for modifying assembly metadata.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
