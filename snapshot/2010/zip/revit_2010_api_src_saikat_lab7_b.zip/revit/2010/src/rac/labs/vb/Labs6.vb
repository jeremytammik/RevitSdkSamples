#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2007-2009 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region

#Region "Namespaces"

Imports Microsoft.VisualBasic
Imports System
Imports WinForms = System.Windows.Forms
Imports Autodesk.Revit
Imports Autodesk.Revit.Events
Imports System.Diagnostics
#End Region

Namespace Labs
#Region "Lab_6_event"
    'Subscribe to , handling, unsubscribe to document saving event.
    Public Class Lab_Event_PreventSave
        Implements IExternalApplication
        Public Function OnStartup(ByVal application As ControlledApplication) As IExternalApplication.Result _
              Implements Autodesk.Revit.IExternalApplication.OnStartup
            Try
                AddHandler application.DocumentSaving, AddressOf app_eventsHandlerMethod
            Catch ex As Exception
                WinForms.MessageBox.Show(ex.Message)
                Return IExternalApplication.Result.Failed
            End Try

            Return IExternalApplication.Result.Succeeded
        End Function
        Public Function OnShutdown(ByVal application As ControlledApplication) As IExternalApplication.Result _
             Implements Autodesk.Revit.IExternalApplication.OnShutdown
            RemoveHandler application.DocumentSaving, AddressOf app_eventsHandlerMethod
            Return IExternalApplication.Result.Succeeded
        End Function

        ' Shows a message to decide if save the document.
        Private Sub app_eventsHandlerMethod(ByVal obj As Object, ByVal args As Autodesk.Revit.Events.DocumentSavingEventArgs)
            If args.Cancellable Then
                ' Ask whether to prevent the document from saving.
                Dim dr As WinForms.DialogResult = WinForms.MessageBox.Show("Saving events handler was triggered. Using the pre-event mechanism , we have a chance to prevent it happening." & vbCrLf & "  Continue to save the document?", "Event document saving", WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question)
                args.Cancel = (dr <> WinForms.DialogResult.Yes)
            End If

        End Sub
    End Class
#End Region
End Namespace
