#region Header
// RstLink
//
// Copyright (C) 2007-2008 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Soap;
using W = System.Windows.Forms;
using System.Xml.Serialization;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;
using RstLink;
#endregion // Namespaces

namespace RstLinkRevitClient
{
  class IntBic
  {
    public const int Columns = ( int ) BuiltInCategory.OST_StructuralColumns;
    public const int Framing = ( int ) BuiltInCategory.OST_StructuralFraming;
    public const int Foundation = ( int ) BuiltInCategory.OST_StructuralFoundation;
  }

  #region Import
  /// <summary>
  /// Import incremental changes from the RstLink intermediate XML file
  /// </summary>
  /// 
  [Transaction( TransactionMode.Automatic )]
  [Regeneration( RegenerationOption.Manual )]
  public class RSLinkImport : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string msg,
      ElementSet els )
    {
      UIApplication app = commandData.Application;
      Document doc = app.ActiveUIDocument.Document;

      //Hashtable rstElems = null; // todo: rewrite using Dictionary<>
      HashSet<RSMember> rstElems = null;

      // De-serialize the result file 
      W.OpenFileDialog dlg = new W.OpenFileDialog();

      try
      {
        // Select File to Open
        dlg.Filter = "RstLink xml files (*.xml)|*.xml";
        dlg.Title = "RstLink - Revit IMPORT from AutoCAD";
        if( dlg.ShowDialog() == W.DialogResult.OK )
        {
          FileStream fs = new FileStream( dlg.FileName, FileMode.Open );
          SoapFormatter sf = new SoapFormatter();
          sf.AssemblyFormat = FormatterAssemblyStyle.Simple;
          sf.Binder = new RsLinkBinder();
          rstElems = sf.Deserialize( fs ) as HashSet<RSMember>;
          fs.Close();
        }
        else
        {
          RstLink.Util.InfoMsg( "Command cancelled!" );
          return Result.Failed;
        }
      }
      catch( Exception ex )
      {
        RstLink.Util.InfoMsg( "Error while deserializing: " + ex.Message );
        return Result.Failed;
      }
      if( 0 == rstElems.Count )
      {
        RstLink.Util.InfoMsg( "No elements found in the result file!" );
        return Result.Cancelled;
      }

      Transaction documentTransaction = new Transaction( doc, "Document" );
      documentTransaction.Start();

      try
      {
        StreamWriter log = new StreamWriter( dlg.FileName + ".log" );
        int iModified = 0;

        foreach( RSMember m in rstElems )
        {
          //ADD NEW elements 
          //================
          if( 0 == m.revitId )
          {
            // In 8.1 API there are no ways to create new Families with Location as Curve, but Point only.
            // This has been addressed in 9.0 API - see eg CreateBeamsColumnsBraces sample in the SDK

            // Bonus: add new elements....

            //MODIFY NEW Sizes (Types)
            //=======================
          }
          else
          {
            ElementId id = new ElementId( m.revitId );
            FamilyInstance fi = doc.get_Element( id ) as FamilyInstance;

            // Check if the Type has changed (in theory we'd need to check Family as well)
            string newType = m._type;

            if( !fi.Symbol.Name.Equals( newType ) )
            {
              log.WriteLine( "Member Id=" + m.revitId + ": Type changed from " + fi.Symbol.Name + " to " + newType );

              BuiltInCategory bic = m._usage.Equals( "Column" )
                ? BuiltInCategory.OST_StructuralColumns
                : BuiltInCategory.OST_StructuralFraming;

              FamilySymbol newSymb = GetFamilySymbol( doc, bic, newType );

              if( newSymb == null )
              {
                log.WriteLine( "  ERROR: Could not find the new Symbol loaded in RVT!" );
              }
              else
              {
                try
                {
                  fi.Symbol = newSymb;
                  log.WriteLine( "  Symbol SUSSESSFULLY changed!" );
                  iModified += 1;
                }
                catch( Exception ex )
                {
                  log.WriteLine( "  ERROR: Could not change to the new Symbol ?!" );
                }
              }
            }
          }
        }
        RstLink.Util.InfoMsg( "Successfully MODIFIED Types for " + iModified + " structural members!" );
        log.Close();
        documentTransaction.Commit();
        return Result.Succeeded;
      }
      catch( Exception ex )
      {
        documentTransaction.RollBack();
        RstLink.Util.InfoMsg( "Error: " + ex.Message );
        return Result.Failed;
      }
    }

    /// <summary>
    /// Helper to get specified type for a given category.
    /// Return a FamilySymbol for a given category name and type.
    /// (in theory, we can have non-unique solution, i.e. the same 
    /// type name for more than one family from this category!)
    /// </summary>
    public static FamilySymbol GetFamilySymbol(
      Document doc,
      BuiltInCategory bic,
      string typeName )
    {
      FilteredElementCollector collector = new FilteredElementCollector( doc );
      collector.OfClass( typeof( FamilySymbol ) );
      collector.OfCategory( bic );

      // todo: probably the type name can also be checked using a filter ... 
      // using a parameter filter, and equality ... what parameter is that?
      // or rewrite using a LINQ query? benchmark different approaches?

      foreach( Element e in collector )
      {
        if( e.Name.Equals( typeName ) )
        {
          return e as FamilySymbol;
        }
      }
      return null;
    }
  }
  #endregion // Import

  #region Export
  /// <summary>
  /// Export all structural elements to the RstLink intermediate file.
  /// Currently, only columns and framing is implemented - skeleton code is in place for others.
  /// </summary>
  /// 
  [Transaction( TransactionMode.Automatic )]
  [Regeneration( RegenerationOption.Manual )]
  public class RSLinkExport : IExternalCommand
  {
    public Result Execute( ExternalCommandData commandData, ref string msg, ElementSet els )
    {
      UIApplication app = commandData.Application;
      Document doc = app.ActiveUIDocument.Document;

      //Categories categories = doc.Settings.Categories;
      //Category catStruColums = categories.get_Item( BuiltInCategory.OST_StructuralColumns );
      //Category catStruFraming = categories.get_Item( BuiltInCategory.OST_StructuralFraming );
      //Category catStruFoundation = categories.get_Item( BuiltInCategory.OST_StructuralFoundation );

      // No Dictionary was available in .NET 2003, so used untyped collection. If doing again in 2005 - better use Dictionary

      //Hashtable rstElems = new Hashtable();
      HashSet<RSMember> rstElems = new HashSet<RSMember>();

      // todo: remove unneccessary try-catch handlers
      // todo: rewrite using 2009 filtering

      // LOOP all elements and add to the collection
      //ElementIterator iter = doc.Elements;
      IList<ElementFilter> filters = new List<ElementFilter>();
      ElementClassFilter classFilter1 = new ElementClassFilter( typeof( Wall ) );
      ElementClassFilter classFilter2 = new ElementClassFilter( typeof( Floor ) );
      ElementClassFilter classFilter3 = new ElementClassFilter( typeof( ContFooting ) );
      ElementClassFilter classFilter4 = new ElementClassFilter( typeof( FamilyInstance ) );
      ElementClassFilter classFilter5 = new ElementClassFilter( typeof( PointLoad ) );
      ElementClassFilter classFilter6 = new ElementClassFilter( typeof( LineLoad ) );
      ElementClassFilter classFilter7 = new ElementClassFilter( typeof( AreaLoad ) );
      filters.Add( classFilter1 );
      filters.Add( classFilter2 );
      filters.Add( classFilter3 );
      filters.Add( classFilter4 );
      filters.Add( classFilter5 );
      filters.Add( classFilter6 );
      filters.Add( classFilter7 );
      LogicalOrFilter logOrFilter = new LogicalOrFilter( filters );

      FilteredElementCollector collector = new FilteredElementCollector( app.ActiveUIDocument.Document );
      FilteredElementIterator iter = collector.WherePasses( logOrFilter ).GetElementIterator();
      while( iter.MoveNext() )
      {
        Element elem = iter.Current as Element;

        if( elem is Wall ) // Strucural WALL
        {
          Wall w = elem as Wall;
          try
          {
            AnalyticalModel anaWall = w.GetAnalyticalModel();
            if( anaWall != null )
            {
              if( anaWall.GetCurves( AnalyticalCurveType.RawCurves ).Count > 0 )
              {
                //ToDo WALL
              }
            }
          }
          catch
          {
          }
        }
        else if( elem is Floor ) // Strucural FLOOR
        {
          Floor f = elem as Floor;
          try
          {
            AnalyticalModel anaFloor = f.GetAnalyticalModel();
            //AnalyticalModelFloor anaFloor = f.AnalyticalModel as AnalyticalModelFloor;
            if( anaFloor != null )
            {
              if( anaFloor.GetCurves( AnalyticalCurveType.RawCurves ).Count > 0 )
              {
                //ToDo FLOOR
              }
            }
          }
          catch
          {
          }
        }
        else if( elem is ContFooting ) // Strucural CONTINUOUS FOOTING
        {
          ContFooting cf = elem as ContFooting;
          try
          {
            //AnalyticalModel3D ana3D = cf.AnalyticalModel as AnalyticalModel3D;
            AnalyticalModel ana3D = cf.GetAnalyticalModel();
            if( ana3D != null )
            {
              if( ana3D.GetCurves( AnalyticalCurveType.RawCurves ).Count > 0 )
              {
                //ToDo CONT.FOOTING
              }
            }
          }
          catch
          {
          }
        }
        else if( elem is FamilyInstance ) // one of strucural standard families
        {
          try
          {
            FamilyInstance fi = elem as FamilyInstance;
            //INSTANT C# NOTE: The following VB 'Select Case' included range-type or non-constant 'Case' expressions and was converted to C# 'if-else' logic:
            //			  Select Case fi.Category.Name

            // From RS3, better use local-independent design
            // Case "Structural Columns", "Structural Framing"
            //ORIGINAL LINE: Case catStruColums.Name, catStruFraming.Name
            //if( ( fi.Category.Name == catStruColums.Name ) || ( fi.Category.Name == catStruFraming.Name ) )

            int iBic = fi.Category.Id.IntegerValue;

            if( ( iBic == IntBic.Columns ) || ( iBic == IntBic.Framing ) )
            {
              try
              {
                //AnalyticalModelFrame anaFrame = fi.AnalyticalModel as AnalyticalModelFrame;
                AnalyticalModel anaFrame = fi.GetAnalyticalModel();
                if( anaFrame != null )
                {
                  // Create MEMBER in neutral format and add it to the collection
                  RSMember member = CreateRSMember( fi, anaFrame );
                  if( member != null )
                  {
                    rstElems.Add( member );
                  }
                }
              }
              catch
              {
              }
            }
            else if( iBic == IntBic.Foundation ) // Case "Structural Foundations"
            {
              try
              {
                //AnalyticalModelLocation anaLoc = fi.AnalyticalModel as AnalyticalModelLocation;
                AnalyticalModel anaLoc = fi.GetAnalyticalModel();
                if( anaLoc != null )
                {
                  //ToDo FOUNDATION...also change hard-coded category name
                }
              }
              catch
              {
              }
            }
          }
          catch
          {
          }
        }
        else if( elem is PointLoad ) // ToDo: all LOADS!
        {
          //...
        }
        else if( elem is LineLoad )
        {
          //...
        }
        else if( elem is AreaLoad )
        {
          //...
        }
      }

      // Serialize the members to a file
      if( 0 < rstElems.Count )
      {
        // Select File to Save
        W.SaveFileDialog dlg = new W.SaveFileDialog();
        dlg.Filter = "RstLink xml files (*.xml)|*.xml";
        dlg.Title = "RstLink - Revit EXPORT to AutoCAD";
        dlg.FileName = "RstLinkRevitToAcad.xml";
        if( dlg.ShowDialog() == W.DialogResult.OK )
        {
          //SOAP (would be faster if BINARY, but just to make it readable)
          FileStream fs = new FileStream( dlg.FileName, FileMode.Create );
          SoapFormatter sf = new SoapFormatter();
          sf.AssemblyFormat = FormatterAssemblyStyle.Simple;
          sf.Binder = new RstLink.RsLinkBinder();
          sf.Serialize( fs, rstElems );
          fs.Close();
          RstLink.Util.InfoMsg( "Successfully exported " + rstElems.Count + " structural elements!" );
        }
        else
        {
          RstLink.Util.InfoMsg( "Command cancelled!" );
          return Result.Cancelled;
        }

        // NOTE: - (de)serialization works fine but all assemblies MUST be in the same folder as revit.EXE!
        // The same is true later when deserializing in AutoCAD - must put them in same folder with acad.EXE.
        // jeremy - i fixed this, no longer true
        //           SEE: Serialize the Collection to a file
        //           http://www.codeproject.com/soap/Serialization_Samples.asp
        //           Serialization(Headaches)
        //           http://www.dotnet4all.com/dotnet-code/2004/12/serialization-headaches.html
        //Try
        //    Dim fsTest As New FileStream("c:\temp\_RSLinkExport.xml", FileMode.Open)
        //    Dim sfTest As New SoapFormatter
        //    Dim elemsTest As Hashtable = sfTest.Deserialize(fsTest)
        //    fsTest.Close()
        //    MsgBox("Num.of DeSer = " & elemsTest.Count)
        //Catch ex As Exception
        //    MsgBox("Error in DeSer: " & ex.Message)
        //End Try
      }
      else
      {
        RstLink.Util.InfoMsg( "No Structural Elements found in this model!" );
      }
      return Result.Succeeded;
    }

    RSMember CreateRSMember( FamilyInstance fi, AnalyticalModel anaFrame )
    {
      try
      {
        int id = fi.Id.IntegerValue;
        Line line = anaFrame.GetCurve() as Line;
        string type = fi.Symbol.Name;
        string usage = null;
        if( fi.Category.Name == "Structural Columns" )
        {
          usage = "Column";
        }
        else
        {
          // This doesn't work any longer in structure 3! (was OK in 2?)
          //usage = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_TEXT_PARAM).AsString
          // Now must get the integer enumeration and map the name
          //124334  6	Other
          //124340  3	Girder
          //124349  5	Purlin
          //134865  6	Other
          //129463  7	Vertical Bracing
          //124337  3	Girder
          //124331  6	Other
          //124346  8	Horizontal Bracing
          //124343  4	Joist
          //129409  9	Kicker Bracing
          try
          {
            switch( fi.get_Parameter( BuiltInParameter.INSTANCE_STRUCT_USAGE_PARAM ).AsInteger() )
            {
              case 3:
                usage = "Girder";
                break;
              case 4:
                usage = "Joist";
                break;
              case 5:
                usage = "Purlin";
                break;
              case 6:
                usage = "Other";
                break;
              case 7:
                usage = "Vertical Bracing";
                break;
              case 8:
                usage = "Horizontal Bracing";
                break;
              case 9:
                usage = "Kicker Bracing";
                break;
              default:
                usage = "Unknown";
                break;
            }
          }
          catch( Exception ex )
          {
            usage = "Parameter Fails";
          }
          //Dim p1 As Parameter = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_TEXT_PARAM)
          //If Not p1 Is Nothing Then
          //    MsgBox(p1.StorageType.ToString)
          //End If

          //Dim p2 As Parameter = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_PARAM)
          //If Not p2 Is Nothing Then
          //    MsgBox(p2.StorageType.ToString)
          //End If
        }
        XYZ p1 = line.get_EndPoint( 0 );
        XYZ q1 = line.get_EndPoint( 1 );
        RSPoint p = new RSPoint( p1.X, p1.Y, p1.Z );
        RSPoint q = new RSPoint( q1.X, q1.Y, q1.Z );
        RSLine l = new RSLine( p, q );
        RSMember m = new RSMember( id, usage, type, l );
        return m;
      }
      catch( Exception ex )
      {
        return null;
      }
    }
  }
  #endregion // Export
}
