#Region "Namespaces"
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Reflection
Imports System.Text
#End Region

Namespace Labs
    ''' <summary> 
    ''' From http://www.timvw.be/presenting-the-sortablebindinglistt 
    ''' </summary> 
    Public Class SortableBindingList(Of T)
        Inherits BindingList(Of T)
        Private propertyDescriptor As PropertyDescriptor
        Private listSortDirection As ListSortDirection
        Private isSorted As Boolean

        Public Sub New()
        End Sub

        Public Sub New(ByVal enumerable As IEnumerable(Of T))
            If enumerable Is Nothing Then
                Throw New System.ArgumentNullException("enumerable")
            End If

            For Each t As T In enumerable
                Me.Add(t)
            Next
        End Sub

        Protected Overloads Overrides ReadOnly Property SupportsSortingCore() As Boolean
            Get
                Return True
            End Get
        End Property

        Protected Overloads Overrides ReadOnly Property IsSortedCore() As Boolean
            Get
                Return Me.isSorted
            End Get
        End Property

        Protected Overloads Overrides ReadOnly Property SortPropertyCore() As PropertyDescriptor
            Get
                Return Me.propertyDescriptor
            End Get
        End Property

        Protected Overloads Overrides ReadOnly Property SortDirectionCore() As ListSortDirection
            Get
                Return Me.listSortDirection
            End Get
        End Property

        Protected Overloads Overrides Sub ApplySortCore(ByVal prop As PropertyDescriptor, ByVal direction As ListSortDirection)
            Dim itemsList As List(Of T) = TryCast(Me.Items, List(Of T))
            itemsList.Sort(Function(ByVal t1 As T, ByVal t2 As T) Do 
            Me.propertyDescriptor = prop
            Me.listSortDirection = direction
            Me.isSorted = True

            Dim reverse As Integer = If((direction = ListSortDirection.Ascending), 1, -1)

            Dim value1 As T = DirectCast(prop.GetValue(t1), T)
            Dim value2 As T = DirectCast(prop.GetValue(t2), T)

            Return reverse * Comparer(Of T).[Default].Compare(value1, value2)
    End Function) 

    Me.OnListChanged(New ListChangedEventArgs(ListChangedType.Reset, -1)) 
End Sub 

        Protected Overloads Overrides Sub RemoveSortCore()
            Me.isSorted = False
            Me.propertyDescriptor = MyBase.SortPropertyCore
            Me.listSortDirection = MyBase.SortDirectionCore
        End Sub
    End Class
End Namespace

