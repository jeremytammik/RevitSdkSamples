﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.Constants

Namespace Labs
    Public Class BuiltInParamsCheckerForm

        Private _data As SortableBindingList(Of BuiltInParamsChecker.ParameterData)

        Public Sub New(ByVal description As String, ByVal data As SortableBindingList(Of BuiltInParamsChecker.ParameterData))
            _data = data
            InitializeComponent()
            Text = (description & " ") + Text
        End Sub

        Private Sub BuiltInParamsCheckerForm_Load(ByVal sender As Object, ByVal e As EventArgs)
            dataGridView1.DataSource = _data
            dataGridView1.Columns(0).HeaderText = "BuiltInParameter"
            dataGridView1.Columns(1).HeaderText = "Parameter Name"
            dataGridView1.Columns(2).HeaderText = "Type"
            dataGridView1.Columns(3).HeaderText = "Read/Write"
            dataGridView1.Columns(4).HeaderText = "String Value"
            dataGridView1.Columns(5).HeaderText = "Database Value"
            Dim w As Integer = dataGridView1.Width / 6
            For Each c As DataGridViewColumn In dataGridView1.Columns
                c.Width = w
            Next
        End Sub

        Private Sub CopyToClipboardToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim s As String = Text & vbCr & vbLf
            For Each a As BuiltInParamsChecker.ParameterData In _data
                s += (((((vbCr & vbLf & a.[Enum] & vbTab) + a.Name & vbTab) + a.Type & vbTab) + a.ReadWrite & vbTab) + a.ValueString & vbTab) + a.Value
            Next
            If 0 < s.Length Then
                Clipboard.SetDataObject(s)
            End If
        End Sub

    End Class
End Namespace
