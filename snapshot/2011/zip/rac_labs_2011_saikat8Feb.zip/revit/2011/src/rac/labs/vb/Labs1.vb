#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2006-2010 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region

#Region "Namespaces"
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
Imports Microsoft.VisualBasic.Constants
' please help remove these stupid workarounds:
'Imports Element2 = Autodesk.Revit.DB.Element
'Imports LanguageType2 = Autodesk.Revit.ApplicationServices.LanguageType
'Imports Selection2 = Autodesk.Revit.UI.Selection.Selection
#End Region

Namespace Labs

#Region "Lab1_1_HelloWorld"
    ''' <summary>
    ''' Say hello.
    ''' 
    ''' Explain the development environment and the addin manifest information defining
    ''' the link between Revit and the external command. Also, how the external command
    ''' can be hooked up with a custom user interface by an external application.
    '''
    ''' Also explain the TaskDialog class provided for Revit-style message boxes.
    ''' Please also refer to the HelloRevit SDK sample demonstrating more TaskDialog 
    ''' features.
    ''' </summary>
    <Transaction(TransactionMode.Automatic)> _
    <Regeneration(RegenerationOption.Manual)> _
    Public Class Lab1_1_HelloWorld
        Implements IExternalCommand

        Public Function Execute( _
            ByVal commandData As ExternalCommandData, _
            ByRef message As String, _
            ByVal elements As ElementSet) _
            As Result _
            Implements IExternalCommand.Execute

            LabUtils.InfoMsg("Hello World")
            Return Result.Succeeded

        End Function

    End Class
#End Region

#Region "Lab1_2_CommandArguments"
    ''' <summary>
    ''' Demonstrate contents and usage of the Execute() method's 
    ''' command data input argument and the meaning of the result
    ''' return code and the message and element set return arguments.
    ''' 
    ''' This is also a good place to explain the transaction and 
    ''' regeneration modes.
    ''' </summary>
    <Transaction(TransactionMode.Automatic)> _
    <Regeneration(RegenerationOption.Manual)> _
    Public Class Lab1_2_CommandArguments
        Implements IExternalCommand

        Public Function Execute( _
            ByVal commandData As ExternalCommandData, _
            ByRef message As String, _
            ByVal elements As ElementSet) _
            As Result _
            Implements IExternalCommand.Execute

            ' access application, document, and current view:

            Dim uiapp As UIApplication = commandData.Application
            Dim app As Application = uiapp.Application
            Dim uidoc As UIDocument = uiapp.ActiveUIDocument
            Dim doc As Document = uidoc.Document
            Dim view As View = commandData.View

            Dim lt As LanguageType = app.Language
            Dim pt As ProductType = app.Product

            Dim s As String = "Application = " + app.VersionName + vbCrLf
            s += "Language = " + lt.ToString() + vbCrLf
            s += "Product = " + pt.ToString() + vbCrLf
            s += "Version = " + app.VersionNumber + vbCrLf '
            s += "Document path = " + doc.PathName + vbCrLf ' Empty if not saved yet
            s += "Document title = " + doc.Title + vbCrLf
            s += "View name = " + view.Name
            LabUtils.InfoMsg(s)

            ' list the current selection set:

            Dim sel As Selection = uidoc.Selection

            s = "There are " + sel.Elements.Size.ToString() + " elements in the selection:"

            For Each elem As Element In sel.Elements
                s += vbCrLf + "  " + elem.Category.Name
                s += " Id=" + elem.Id.IntegerValue.ToString()
            Next

            LabUtils.InfoMsg(s)

            ' we pretend that something is wrong with the first element in the selection.
            ' pass a message back to the Revit user and indicate the error result:

            If Not sel.Elements.IsEmpty Then
                Dim iter As ElementSetIterator = sel.Elements.ForwardIterator
                iter.MoveNext()
                Dim errElem As Element = iter.Current
                elements.Clear()
                elements.Insert(errElem)
                message = "We pretend something is wrong with this element and pass back this message to user"
                Return Result.Failed
            Else
                ' we return failed here as well, actually.
                ' as long as the message string and element set are empty,
                ' it makes no difference to the user.
                ' it also aborts the automatic transaction, avoiding marking
                ' the database as dirty.

                Return Result.Failed
            End If

        End Function

    End Class
#End Region

End Namespace
