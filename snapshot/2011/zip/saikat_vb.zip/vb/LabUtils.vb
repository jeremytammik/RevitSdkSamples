#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2006-2010 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region

#Region "Namespaces"
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.IO
Imports System.Linq
Imports Autodesk.Revit
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
#End Region

Namespace Labs
    Public Class LabUtils

#Region "Formatting and message handlers"
        Public Const Caption As String = "Revit API Labs"

        ''' <summary> 
        ''' Return an English plural suffix 's' or 
        ''' nothing for the given number of items. 
        ''' </summary> 
        Public Shared Function PluralSuffix(ByVal n As Integer) As String
            Return If(1 = n, "", "s")
        End Function

        Public Shared Function DotOrColon(ByVal n As Integer) As String
            Return If(0 < n, ":", ".")
        End Function

        ''' <summary> 
        ''' Format a real number and return its string representation. 
        ''' </summary> 
        Public Shared Function RealString(ByVal a As Double) As String
            Return a.ToString("0.##")
        End Function

        ''' <summary> 
        ''' Format a point or vector and return its string representation. 
        ''' </summary> 
        Public Shared Function PointString(ByVal p As XYZ) As String
            Return String.Format("({0},{1},{2})", RealString(p.X), RealString(p.Y), RealString(p.Z))
        End Function

        ''' <summary> 
        ''' Return a description string for a given element. 
        ''' </summary> 
        Public Shared Function ElementDescription(ByVal e As Element) As String
            Dim description As String = If((e.Category Is Nothing), e.[GetType]().Name, e.Category.Name)

            If e.Name IsNot Nothing Then
                description += " '" + e.Name + "'"
            End If
            Return description
        End Function

        ''' <summary> 
        ''' Return a description string including element id for a given element. 
        ''' </summary> 
        Public Shared Function ElementDescription(ByVal e As Element, ByVal includeId As Boolean) As String
            Dim description As String = ElementDescription(e)
            If includeId Then
                description += " " + e.Id.IntegerValue.ToString()
            End If
            Return description
        End Function

        ''' <summary>
        ''' Revit TaskDialog wrapper for a short informational message.
        ''' </summary>
        Public Shared Sub InfoMsg(ByVal msg As String)
            Debug.WriteLine(msg)
            TaskDialog.Show(Caption, msg, UI.TaskDialogCommonButtons.Ok)
        End Sub

        ''' <summary>
        ''' Revit TaskDialog wrapper for a message
        ''' with separate main instruction and content.
        ''' </summary>
        Public Shared Sub InfoMsg(ByVal msg As String, ByVal content As String)
            Debug.WriteLine(msg)
            Debug.WriteLine(content)
            Dim d As New TaskDialog(Caption)
            d.MainInstruction = msg
            d.MainContent = content
            d.Show()
        End Sub

        ''' <summary>
        ''' Revit TaskDialog wrapper for a message with separate 
        ''' main instruction and list of lines of content.
        ''' The main instruction is expected to include count,
        ''' plural suffix and dot or end placeholders.
        ''' </summary>
        Public Shared Sub InfoMsg(ByVal msg As String, ByVal content As List(Of String))
            Dim n As Integer = content.Count

            InfoMsg(String.Format(msg, n, PluralSuffix(n), DotOrColon(n)), String.Join("\n", content.ToArray()))
        End Sub

        ''' <summary>
        ''' MessageBox wrapper for error message.
        ''' </summary>
        Public Shared Sub ErrorMsg(ByVal msg As String)
            Debug.WriteLine(msg)
            'WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Error ); 
            Dim d As New TaskDialog(Caption)
            d.MainIcon = UI.TaskDialogIcon.TaskDialogIconWarning
            d.MainInstruction = msg
            d.Show()
        End Sub

        ''' <summary> 
        ''' MessageBox wrapper for question message. 
        ''' </summary> 
        Public Shared Function QuestionMsg(ByVal msg As String) As Boolean
            Debug.WriteLine(msg)
            'bool rc = WinForms.DialogResult.Yes 
            ' == WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question ); 
            'Debug.WriteLine( rc ? "Yes" : "No" ); 
            'return rc; 
            Dim d As New TaskDialog(Caption)
            d.MainIcon = UI.TaskDialogIcon.TaskDialogIconNone
            d.MainInstruction = msg
            d.CommonButtons = UI.TaskDialogCommonButtons.Yes Or UI.TaskDialogCommonButtons.No
            d.DefaultButton = UI.TaskDialogResult.Yes
            Return UI.TaskDialogResult.Yes = d.Show()
        End Function

        ''' <summary> 
        ''' MessageBox wrapper for question and cancel message. 
        ''' </summary> 
        Public Shared Function QuestionCancelMsg(ByVal msg As String) As TaskDialogResult
            Debug.WriteLine(msg)
            'WinForms.DialogResult rc = WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.YesNoCancel, WinForms.MessageBoxIcon.Question ); 
            'Debug.WriteLine( rc.ToString() ); 
            'return rc; 
            Dim d As New TaskDialog(Caption)
            d.MainIcon = TaskDialogIcon.TaskDialogIconNone
            d.MainInstruction = msg
            d.CommonButtons = TaskDialogCommonButtons.Yes Or TaskDialogCommonButtons.No Or TaskDialogCommonButtons.Cancel
            d.DefaultButton = TaskDialogResult.Yes
            Return d.Show()
        End Function


#End Region

#Region "Geometry Utilities"

        ''' <summary>
        ''' Return the midpoint between two points.
        ''' </summary>
        Public Shared Function Midpoint(ByVal p As XYZ, ByVal q As XYZ) As XYZ
            Return p + 0.5 * (q - p)
        End Function

#End Region

#Region "Selection"

        Public Shared Function GetSingleSelectedElementOrPrompt(ByVal uidoc As UIDocument, ByVal type As Type) As Element
            Dim e As Element = Nothing

            Dim ss As ElementSet = uidoc.Selection.Elements

            If 1 = ss.Size Then
                Dim iter As ElementSetIterator = ss.ForwardIterator()
                iter.MoveNext()
                Dim t As Type = iter.Current.[GetType]()
                If t.Equals(type) OrElse t.IsSubclassOf(type) Then
                    e = TryCast(iter.Current, Element)
                End If
            End If
            If e Is Nothing Then
                Dim r As Reference = uidoc.Selection.PickObject(ObjectType.Element, New TypeSelectionFilter(type), String.Format("Please pick a {0} element", type.Name))

                e = r.Element
            End If
            Return e
        End Function

        ''' <summary> 
        ''' A selection filter for a specific System.Type. 
        ''' </summary> 
        Class TypeSelectionFilter
            Implements ISelectionFilter

            Private _type As Type

            Public Sub New(ByVal type As Type)
                _type = type
            End Sub

            ''' <summary> 
            ''' Allow an element of the specified System.Type to be selected. 
            ''' </summary> 
            ''' <param name="e">A candidate element in selection operation.</param> 
            ''' <returns>Return true for specified System.Type, false for all other elements.</returns> 
            Public Function AllowElement(ByVal e As Autodesk.Revit.DB.Element) As Boolean Implements Autodesk.Revit.UI.Selection.ISelectionFilter.AllowElement
                'return null != e.Category 
                ' && e.Category.Id.IntegerValue == ( int ) _bic; 

                Return e.[GetType]().Equals(_type)
            End Function

            ''' <summary> 
            ''' Allow all the reference to be selected 
            ''' </summary> 
            ''' <param name="reference">A candidate reference in selection operation.</param> 
            ''' <param name="position">The 3D position of the mouse on the candidate reference.</param> 
            ''' <returns>Return true to allow the user to select this candidate reference.</returns> 
            Public Function AllowReference(ByVal reference As Autodesk.Revit.DB.Reference, ByVal position As Autodesk.Revit.DB.XYZ) As Boolean Implements Autodesk.Revit.UI.Selection.ISelectionFilter.AllowReference
                Return True
            End Function

        End Class

        Public Shared Function GetSingleSelectedElementOrPrompt(ByVal uidoc As UIDocument) As Element
            Dim e As Element = Nothing
            Dim ss As ElementSet = uidoc.Selection.Elements
            If 1 = ss.Size Then
                Dim iter As ElementSetIterator = ss.ForwardIterator()
                iter.MoveNext()
                e = TryCast(iter.Current, Element)
            Else
                Dim r As Reference = uidoc.Selection.PickObject(ObjectType.Element, "Please pick an element")

                e = r.Element
            End If
            Return e
        End Function

#End Region

#Region "Helpers to get specific element collections"

        ''' <summary> 
        ''' Determine bottom and top levels for creating walls. 
        ''' In a default empty Revit Architecture project, 
        ''' 'Level 1' and 'Level 2' will be returned. 
        ''' </summary> 
        ''' <returns>True is the two levels are successfully determined.</returns> 
        Public Shared Function GetBottomAndTopLevels(ByVal doc As Document, ByRef levelBottom As Level, ByRef levelTop As Level) As Boolean
            Dim collector As New FilteredElementCollector(doc)
            collector.OfClass(GetType(Level))

            Dim levels As ICollection(Of Element) = collector.ToElements()

            For Each e As Element In levels
                If levelBottom Is Nothing Then
                    levelBottom = TryCast(e, Level)
                ElseIf levelTop Is Nothing Then
                    levelTop = TryCast(e, Level)
                Else
                    Exit For
                End If
            Next
            If levelTop.Elevation < levelBottom.Elevation Then
                Dim tmp As Level = levelTop
                levelTop = levelBottom
                levelBottom = tmp
            End If
            Return levelBottom IsNot Nothing AndAlso levelTop IsNot Nothing
        End Function

        ''' <summary> 
        ''' Return all elements of the requested class in the active document 
        ''' matching the given built-in category. 
        ''' </summary> 
        Public Shared Function GetElementsOfType(ByVal doc As Document, ByVal type As Type, ByVal bic As BuiltInCategory) As ICollection(Of Element)
            Dim collector As New FilteredElementCollector(doc)
            collector.OfCategory(bic)
            collector.OfClass(type)
            Return collector.ToElements()
        End Function

        ''' <summary> 
        ''' Return all family symbols in the active document 
        ''' matching the given built-in category. 
        ''' </summary> 
        Public Shared Function GetFamilySymbols(ByVal doc As Document, ByVal bic As BuiltInCategory) As ICollection(Of Element)
            Return GetElementsOfType(doc, GetType(FamilySymbol), bic)
        End Function

        ''' <summary> 
        ''' Return the first family symbol found in the active document 
        ''' matching the given built-in category or null if none is found. 
        ''' </summary> 
        Public Shared Function GetFirstFamilySymbol(ByVal doc As Document, ByVal bic As BuiltInCategory) As FamilySymbol
            For Each s As FamilySymbol In GetFamilySymbols(doc, bic)
                Return s
            Next

            Debug.Assert(False, String.Format("expected at least one {0} symbol in project", bic.ToString()))

            Return Nothing
        End Function

        ''' <summary>
        ''' Retrieve all standard family instances for a given category.
        ''' </summary>
        Shared Function GetFamilyInstances( _
            ByVal doc As Document, _
            ByVal bic As BuiltInCategory) _
        As ICollection(Of Element)

            ' 2009
            'Dim elements As New System.Collections.Generic.List(Of Element)
            'Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(FamilyInstance))
            'Dim filterCategory As Filter = app.Create.Filter.NewCategoryFilter(bic)
            'Dim filterCombination As Filter = app.Create.Filter.NewLogicAndFilter(filterCategory, filterType)
            'Dim nRetVal As Integer = app.ActiveDocument.Elements(filterCombination, elements)
            'Return elements

            Dim collector As FilteredElementCollector = New FilteredElementCollector(doc)
            collector.OfClass(GetType(FamilyInstance))
            collector.OfCategory(bic)
            Return collector.ToElements()
        End Function

        ''' <summary> 
        ''' Helper to get all instances for a given category, 
        ''' identified either by a built-in category or by a category name. 
        ''' </summary> 
        Public Shared Function GetTargetInstances(ByVal doc As Document, ByVal targetCategory As Object) As List(Of Element)
            Dim elements As List(Of Element)

            Dim isName As Boolean = targetCategory.[GetType]().Equals(GetType(String))

            If isName Then
                Dim cat As Category = doc.Settings.Categories.Item(TryCast(targetCategory, String))
                Dim collector As New FilteredElementCollector(doc)
                collector.OfCategoryId(cat.Id)
                elements = New List(Of Element)(collector)
            Else
                Dim collector As FilteredElementCollector = New FilteredElementCollector(doc).WhereElementIsNotElementType()

                collector.OfCategory(DirectCast(targetCategory, BuiltInCategory))

                Dim model_elements = From e In collector Where (e.Category IsNot Nothing AndAlso e.Category.HasMaterialQuantities) _
                    Select e

                elements = model_elements.ToList(Of Element)()
            End If
            Return elements
        End Function

        ''' <summary> 
        ''' Return the one and only project information element 
        ''' by searching for the "Project Information" category. 
        ''' Only one such element exists. 
        ''' </summary> 
        Public Shared Function GetProjectInfoElem(ByVal doc As Document) As Element
            Dim collector As New FilteredElementCollector(doc)
            collector.OfCategory(BuiltInCategory.OST_ProjectInformation)
            Return collector.FirstElement()
        End Function

#End Region

#Region "Helpers for parameters"
        ''' <summary> 
        ''' Helper to return parameter value as string. 
        ''' One can also use param.AsValueString() to 
        ''' get the user interface representation. 
        ''' </summary> 
        Public Shared Function GetParameterValue(ByVal param As Parameter) As String
            Dim s As String
            Select Case param.StorageType
                Case StorageType.[Double]
                    ' 
                    ' the internal database unit for all lengths is feet. 
                    ' for instance, if a given room perimeter is returned as 
                    ' 102.36 as a double and the display unit is millimeters, 
                    ' then the length will be displayed as 
                    ' peri = 102.36220472440 
                    ' peri * 12 * 25.4 
                    ' 31200 mm 
                    ' 
                    's = param.AsValueString(); // value seen by user, in display units 
                    's = param.AsDouble().ToString(); // if not using not using LabUtils.RealString() 
                    s = RealString(param.AsDouble())
                    ' raw database value in internal units, e.g. feet 
                    Exit Select

                Case StorageType.[Integer]
                    s = param.AsInteger().ToString()
                    Exit Select

                Case StorageType.[String]
                    s = param.AsString()
                    Exit Select

                Case StorageType.ElementId
                    s = param.AsElementId().IntegerValue.ToString()
                    Exit Select

                Case StorageType.None
                    s = "?NONE?"
                    Exit Select
                Case Else

                    s = "?ELSE?"
                    Exit Select
            End Select
            Return s
        End Function

        ''' <summary> 
        ''' Helper to return parameter value as string, with additional 
        ''' support for element id to display the element type referred to. 
        ''' </summary> 
        Public Shared Function GetParameterValue2(ByVal param As Parameter, ByVal doc As Document) As String
            Dim s As String
            If StorageType.ElementId = param.StorageType AndAlso doc IsNot Nothing Then
                Dim id As ElementId = param.AsElementId()
                Dim i As Integer = id.IntegerValue
                If 0 > i Then
                    s = i.ToString()
                Else
                    Dim e As Element = doc.Element(id)
                    s = ElementDescription(e, True)
                End If
            Else
                s = GetParameterValue(param)
            End If
            Return s
        End Function

#End Region

#Region "Helpers for shared parameters"
        ''' <summary> 
        ''' Helper to get shared parameters file. 
        ''' </summary> 
        Public Shared Function GetSharedParamsFile(ByVal app As Application) As DefinitionFile
            ' Get current shared params file name 
            Dim sharedParamsFileName As String
            Try
                sharedParamsFileName = app.SharedParametersFilename
            Catch ex As Exception
                ErrorMsg("No shared params file set:" + ex.Message)
                Return Nothing
            End Try
            If 0 = sharedParamsFileName.Length Then
                Dim path As String = LabConstants.SharedParamFilePath
                Dim stream As StreamWriter
                stream = New StreamWriter(path)
                stream.Close()
                app.SharedParametersFilename = path
                sharedParamsFileName = app.SharedParametersFilename
            End If
            ' Get the current file object and return it 
            Dim sharedParametersFile As DefinitionFile
            Try
                sharedParametersFile = app.OpenSharedParameterFile()
            Catch ex As Exception
                ErrorMsg("Cannnot open shared params file:" + ex.Message)
                sharedParametersFile = Nothing
            End Try
            Return sharedParametersFile
        End Function

        ''' <summary> 
        ''' Helper to get shared params group. 
        ''' </summary> 
        Public Shared Function GetOrCreateSharedParamsGroup(ByVal sharedParametersFile As DefinitionFile, ByVal groupName As String) As DefinitionGroup
            Dim g As DefinitionGroup = sharedParametersFile.Groups.Item(groupName)
            If g Is Nothing Then
                Try
                    g = sharedParametersFile.Groups.Create(groupName)
                Catch generatedExceptionName As Exception
                    g = Nothing
                End Try
            End If
            Return g
        End Function

        ''' <summary> 
        ''' Helper to get shared params definition. 
        ''' </summary> 
        Public Shared Function GetOrCreateSharedParamsDefinition(ByVal defGroup As DefinitionGroup, ByVal defType As ParameterType, ByVal defName As String, ByVal visible As Boolean) As Definition
            Dim definition As Definition = defGroup.Definitions.Item(defName)
            If definition Is Nothing Then
                Try
                    definition = defGroup.Definitions.Create(defName, defType, visible)
                Catch generatedExceptionName As Exception
                    definition = Nothing
                End Try
            End If
            Return definition
        End Function

        ''' <summary> 
        ''' Get GUID for a given shared param name. 
        ''' </summary> 
        ''' <param name="app">Revit application</param> 
        ''' <param name="defGroup">Definition group name</param> 
        ''' <param name="defName">Definition name</param> 
        ''' <returns>GUID</returns> 
        Public Shared Function SharedParamGUID(ByVal app As Application, ByVal defGroup As String, ByVal defName As String) As Guid
            Dim guid__1 As Guid = Guid.Empty
            Try
                Dim file As DefinitionFile = app.OpenSharedParameterFile()
                Dim group As DefinitionGroup = file.Groups.Item(defGroup)
                Dim definition As Definition = group.Definitions.Item(defName)
                Dim externalDefinition As ExternalDefinition = TryCast(definition, ExternalDefinition)
                guid__1 = externalDefinition.GUID
            Catch generatedExceptionName As Exception
            End Try
            Return guid__1
        End Function
#End Region

#Region "_2010"

        '''' <summary>
        '''' Helper to get all geometrical elements.
        '''' </summary>
        'Shared Function GetAllModelElements(ByVal app As Application) As ElementSet

        '    Dim elems As ElementSet = app.Create.NewElementSet
        '    Dim opt As Geometry.Options = app.Create.NewGeometryOptions
        '    opt.DetailLevel = Geometry.Options.DetailLevels.Fine

        '    'Dim iter As IEnumerator = app.ActiveDocument.Elements ' this would also be sufficient
        '    Dim iter As ElementIterator = app.ActiveDocument.Elements
        '    Do While (iter.MoveNext())
        '        Dim elem As Element = iter.Current

        '        ' This single line would probably work if all system families were exposed as HostObjects, but they are not yet
        '        'If TypeOf elem Is FamilyInstance Or TypeOf elem Is HostObject Then
        '        If Not (TypeOf elem Is Symbol OrElse TypeOf elem Is FamilyBase) Then
        '            If Not (elem.Category Is Nothing) Then
        '                Dim geo As Geometry.Element = elem.Geometry(opt)
        '                If Not (geo Is Nothing) Then
        '                    elems.Insert(elem)
        '                End If
        '            End If
        '        End If
        '    Loop
        '    Return elems
        'End Function


        '''' <summary>
        '''' Helper to get all walls in Revit 2008.
        '''' </summary>
        'Shared Function GetAllWalls_2008(ByVal app As Application) As ElementSet
        '    Dim elems As ElementSet = app.Create.NewElementSet
        '    Dim iter As IEnumerator = app.ActiveDocument.Elements
        '    'Iterate through the elements in the active document
        '    Do While (iter.MoveNext())
        '        Dim elem As Element = iter.Current
        '        ' For Wall (one of the Host objects), there is a specific class!
        '        If TypeOf elem Is Wall Then
        '            elems.Insert(elem)
        '        End If
        '    Loop
        '    Return elems
        'End Function

        '''' <summary>
        '''' Helper to get all walls using Revit 2009.
        '''' </summary>
        'Shared Function GetAllWalls(ByVal app As Application) As List(Of Element)
        '    Dim elements As New List(Of Element)
        '    Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(Wall))
        '    Dim n As Integer = app.ActiveDocument.Elements(filterType, elements)
        '    Return elements
        'End Function

        '''' <summary>
        '''' Helper to get all standard family instances for a given category name using Revit 2008 API.
        '''' </summary>
        'Shared Function GetAllStandardFamilyInstancesForACategoryName_2008( _
        '    ByVal app As Application, _
        '    ByVal catName As String) _
        'As ElementSet

        '    Dim elems As ElementSet = app.Create.NewElementSet

        '    Dim iter As IEnumerator = app.ActiveDocument.Elements
        '    Do While (iter.MoveNext())
        '        Dim elem As Element = iter.Current
        '        ' First check for the class, then for specific category name
        '        If TypeOf elem Is FamilyInstance Then
        '            Try
        '                If elem.Category.Name.Equals(catName) Then
        '                    elems.Insert(elem)
        '                End If
        '            Catch
        '            End Try
        '        End If
        '    Loop

        '    Return elems

        'End Function

        '''' <summary>
        '''' Helper to get all standard family instances for a given category
        '''' name using the filter features provided by the Revit 2009 API.
        '''' </summary>
        'Shared Function GetAllStandardFamilyInstancesForACategoryName( _
        '    ByVal app As Application, _
        '    ByVal catName As String) _
        'As List(Of Element)

        '    Dim elements As New System.Collections.Generic.List(Of Element)
        '    Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(FamilyInstance))
        '    Dim cat As Category = app.ActiveDocument.Settings.Categories.Item(catName)
        '    Dim filterCategory As Filter = app.Create.Filter.NewCategoryFilter(cat)
        '    Dim filterCombination As Filter = app.Create.Filter.NewLogicAndFilter(filterCategory, filterType)
        '    Dim nRetVal As Integer
        '    Try
        '        nRetVal = app.ActiveDocument.Elements(filterCombination, elements)
        '    Catch ex As Exception

        '    End Try

        '    Return elements

        'End Function

        '''' <summary>
        '''' Return all types of the requested class in the active document matching the given built-in category.
        '''' </summary>
        'Public Shared Function GetAllTypes( _
        '    ByVal app As Application, _
        '    ByVal type As Type, _
        '    ByVal bic As BuiltInCategory) _
        'As List(Of Element)
        '    Dim familySymbols As New List(Of Element)
        '    Dim filterCategory As Filter = app.Create.Filter.NewCategoryFilter(bic)
        '    Dim filterType As Filter = app.Create.Filter.NewTypeFilter(type)
        '    Dim filter As Filter = app.Create.Filter.NewLogicAndFilter(filterCategory, filterType)
        '    Dim rVal As Integer = app.ActiveDocument.Elements(filter, familySymbols)
        '    Return familySymbols
        'End Function

        '''' <summary>
        '''' Return all family symbols in the active document matching the given built-in category.
        '''' </summary>
        'Public Shared Function GetAllFamilySymbols( _
        '    ByVal app As Application, _
        '    ByVal bic As BuiltInCategory) _
        'As List(Of Element)
        '    Return GetAllTypes(app, GetType(FamilySymbol), bic)
        'End Function

        '''' <summary>
        '''' Helper to get all model instances for a given built-in category in Revit 2009.
        '''' </summary>
        'Public Shared Function GetAllModelInstancesForACategory(ByVal app As Application, ByVal bic As BuiltInCategory) As List(Of Element)

        '    Dim elements As New List(Of Element)
        '    Dim filterCategory As Filter = app.Create.Filter.NewCategoryFilter(bic)
        '    Dim rVal As Integer = app.ActiveDocument.Elements(filterCategory, elements)
        '    Dim opt As Geo.Options = app.Create.NewGeometryOptions()
        '    Dim elements2 As New List(Of Element)
        '    Dim e As Element
        '    For Each e In elements
        '        If Not (TypeOf e Is Autodesk.Revit.Symbol) And Not (TypeOf e Is FamilyBase) And Not (e.Geometry(opt) Is Nothing) Then
        '            elements2.Add(e)
        '        End If
        '    Next

        '    Return elements2

        'End Function

        '''' <summary>
        '''' Helper to get specified type for specified family as FamilySymbol object
        '''' (in theory, we should also check for the correct *Category Name*).
        '''' (note: this only works with component family.)
        '''' </summary>
        'Shared Function GetFamilySymbol_2008( _
        '    ByVal doc As Document, _
        '    ByVal familyName As String, _
        '    ByVal typeName As String) _
        'As FamilySymbol

        '    Dim iter As ElementIterator = doc.Elements
        '    Do While (iter.MoveNext())
        '        Dim elem As Element = iter.Current

        '        ' We got a Family
        '        If TypeOf elem Is Family Then
        '            Dim fam As Family = elem
        '            ' If we have a match on family name, loop all its types for the other match
        '            If fam.Name.Equals(familyName) Then
        '                Dim sym As FamilySymbol
        '                For Each sym In fam.Symbols
        '                    If sym.Name.Equals(typeName) Then
        '                        Return sym
        '                    End If
        '                Next
        '            End If
        '        End If
        '    Loop

        '    ' if here - haven't got it!
        '    Return Nothing

        'End Function

        '''' <summary>
        '''' Helper to get specified type for specified family as FamilySymbol object
        '''' (in theory, we should also check for the correct *Category Name*).
        '''' (note: this only works with component family.)
        '''' </summary>
        'Shared Function GetFamilySymbol( _
        '    ByVal app As Application, _
        '    ByVal familyName As String, _
        '    ByVal typeName As String) _
        'As FamilySymbol

        '    Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(FamilySymbol))
        '    Dim filterFamilyName As Filter = app.Create.Filter.NewFamilyFilter(familyName)
        '    Dim filter As Filter = app.Create.Filter.NewLogicAndFilter(filterType, filterFamilyName)
        '    Dim elementList As New List(Of Element)
        '    Dim num As Integer = app.ActiveDocument.Elements(filter, elementList)
        '    ' we have a list of symbols for a given family. 
        '    ' loop through the list and find a match 
        '    Dim elem As Element
        '    For Each elem In elementList
        '        Dim sym As FamilySymbol = elem
        '        If sym.Name.Equals(typeName) Then
        '            Return sym
        '        End If
        '    Next
        '    ' if here - haven't got it!
        '    Return Nothing
        'End Function




        '''' <summary>
        '''' Return the one and only project information element in Revit 2008.
        '''' </summary>
        'Public Shared Function GetProjectInfoElem_2008(ByVal doc As Document) As Element

        '    '"Project Information" category
        '    Dim catProjInfo As Category = doc.Settings.Categories.Item(BuiltInCategory.OST_ProjectInformation) '

        '    ' Loop all elements
        '    Dim elem As Element
        '    Dim elemIter As ElementIterator = doc.Elements
        '    Do While elemIter.MoveNext
        '        elem = elemIter.Current
        '        ' Return the first match (it's singleton!)
        '        Try
        '            If elem.Category.Id.Equals(catProjInfo.Id) Then
        '                Return elem
        '            End If
        '        Catch
        '        End Try
        '    Loop
        '    ' if here - couldn't find it !?
        '    Return Nothing

        'End Function

        '''' <summary>
        '''' Return the one and only project information element using Revit 2009 filtering
        '''' by searching for the "Project Information" category. Only one such element exists.
        '''' </summary>
        'Public Shared Function GetProjectInfoElem( _
        '    ByVal doc As Document, _
        '    ByRef app As Application) As Element

        '    Dim filterCategory As Filter = app.Create.Filter.NewCategoryFilter( _
        '      BuiltInCategory.OST_ProjectInformation)
        '    Dim elements As New List(Of Element)

        '    'it should return only one element in the collection.
        '    Dim nRetVal As Integer

        '    nRetVal = doc.Elements(filterCategory, elements)

        '    ' Loop all elements
        '    Dim elem As Element

        '    For Each elem In elements
        '        ' Return the first match (it's a singleton!)
        '        If (Not (elem Is Nothing)) Then
        '            Return elem
        '        End If
        '    Next

        '    Return Nothing

        'End Function

        '#Region "Helper for Parameters"

        '        ''' <summary>
        '        ''' Helper to return parameter value as string.
        '        ''' One can also use param.AsValueString() to 
        '        ''' get the user interface representation.
        '        ''' </summary>
        '        Public Shared Function GetParameterValue(ByVal param As Parameter) As String

        '            Dim str As String
        '            Select Case param.StorageType
        '                Case StorageType.Double
        '                    str = param.AsDouble.ToString
        '                Case StorageType.Integer
        '                    str = param.AsInteger.ToString
        '                Case StorageType.String
        '                    str = param.AsString
        '                Case StorageType.ElementId
        '                    str = param.AsElementId.Value.ToString
        '                Case StorageType.None
        '                    str = "?NONE?"
        '                Case Else
        '                    str = "?ELSE?"
        '            End Select
        '            Return str

        '        End Function

        '        ''' <summary>
        '        ''' Helper to return parameter value as string, with additional 
        '        ''' support for element id to display the element type referred to.
        '        ''' </summary>
        '        Public Shared Function GetParameterValue2( _
        '            ByVal param As Parameter, _
        '            ByVal doc As Document) _
        '        As String
        '            Dim str As String
        '            If StorageType.ElementId = param.StorageType Then
        '                Dim id As ElementId = param.AsElementId
        '                Dim i As Integer = id.Value
        '                If (0 <= i) Then : str = String.Format("{0}: {1}", i, doc.Element(id).Name)
        '                Else : str = i.ToString
        '                End If
        '            Else
        '                str = GetParameterValue(param)
        '            End If
        '            Return str
        '        End Function

        '        ''' <summary>
        '        ''' Helper to get *specific* parameter by name.
        '        ''' No longer required in 2009, because the element provides
        '        ''' direct look-up access by name as well in Revit 2009.
        '        ''' </summary>
        '        Shared Function GetElemParam_2008(ByVal elem As Element, ByVal name As String) As Parameter

        '            Dim parameters As Autodesk.Revit.ParameterSet = elem.Parameters
        '            Dim parameter As Autodesk.Revit.Parameter
        '            For Each parameter In parameters
        '                If (parameter.Definition.Name = name) Then
        '                    Return parameter
        '                End If
        '            Next

        '            Return Nothing

        '        End Function

        '#End Region

        '#Region "Helpers for shared parameters"

        '        ''' <summary>
        '        ''' Helper to get shared parameters file.
        '        ''' </summary>
        '        Public Shared Function GetSharedParamsFile(ByVal app As Application) _
        '            As Parameters.DefinitionFile

        '            ' Get current shared params file name
        '            Dim sharedParamsFileName As String
        '            Try
        '                sharedParamsFileName = app.Options.SharedParametersFilename
        '            Catch
        '                MsgBox("No Shared params file set !?")
        '                Return Nothing
        '            End Try

        '            If "" = sharedParamsFileName Then
        '                Dim path As String = LabConstants.SharedParamFilePath

        '                Dim stream As StreamWriter
        '                stream = New StreamWriter(path)
        '                stream.Close()

        '                app.Options.SharedParametersFilename = path
        '                sharedParamsFileName = app.Options.SharedParametersFilename
        '            End If

        '            ' Get the current file object and return it
        '            Dim sharedParametersFile As Autodesk.Revit.Parameters.DefinitionFile
        '            Try
        '                sharedParametersFile = app.OpenSharedParameterFile
        '            Catch
        '                MsgBox("Cannnot open Shared Params file !?")
        '                sharedParametersFile = Nothing
        '            End Try
        '            Return sharedParametersFile

        '        End Function

        '        ''' <summary>
        '        ''' Helper to get shared params group.
        '        ''' </summary>
        '        Public Shared Function GetOrCreateSharedParamsGroup( _
        '             ByVal sharedParametersFile As Parameters.DefinitionFile, _
        '             ByVal groupName As String) _
        '             As Parameters.DefinitionGroup

        '            Dim msProjectGroup As Autodesk.Revit.Parameters.DefinitionGroup
        '            'Get Shared Parameter group
        '            msProjectGroup = sharedParametersFile.Groups.Item(groupName)
        '            If (msProjectGroup Is Nothing) Then
        '                Try
        '                    'create shared paramteter group
        '                    msProjectGroup = sharedParametersFile.Groups.Create(groupName)
        '                Catch
        '                    msProjectGroup = Nothing
        '                End Try
        '            End If

        '            Return msProjectGroup

        '        End Function

        '        ''' <summary>
        '        ''' Helper to get shared params definition.
        '        ''' </summary>
        '        Public Shared Function GetOrCreateSharedParamsDefinition( _
        '         ByVal defGroup As Parameters.DefinitionGroup, _
        '         ByVal defType As Parameters.ParameterType, _
        '         ByVal defName As String, _
        '         ByVal visible As Boolean) As Parameters.Definition

        '            'Get parameter definition
        '            Dim definition As Parameters.Definition = defGroup.Definitions.Item(defName)
        '            If definition Is Nothing Then
        '                Try
        '                    'create parameter definition
        '                    definition = defGroup.Definitions.Create(defName, defType, visible)
        '                Catch
        '                    definition = Nothing
        '                End Try
        '            End If

        '            Return definition

        '        End Function

        '        ''' <summary>
        '        ''' Get GUID for a given shared param name.
        '        ''' </summary>
        '        Shared Function SharedParamGUID(ByVal app As Application, _
        '                                        ByVal defGroup As String, _
        '                                        ByVal defName As String) As Guid

        '            Dim guid As Guid = guid.Empty

        '            Try
        '                Dim file As Autodesk.Revit.Parameters.DefinitionFile = app.OpenSharedParameterFile
        '                Dim group As Autodesk.Revit.Parameters.DefinitionGroup = file.Groups.Item(defGroup)
        '                Dim definition As Autodesk.Revit.Parameters.Definition = group.Definitions.Item(defName)
        '                Dim externalDefinition As Autodesk.Revit.Parameters.ExternalDefinition = definition
        '                guid = externalDefinition.GUID
        '            Catch
        '            End Try

        '            Return guid

        '        End Function

        '#End Region

        '#Region "Group helpers"

        '        ''' <summary>
        '        ''' Helper to get all groups in Revit 2008.
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllGroups_2008(ByVal app As Application) As ElementSet

        '            Dim elems As ElementSet = app.Create.NewElementSet
        '            Dim iter As IEnumerator = app.ActiveDocument.Elements
        '            Do While (iter.MoveNext())
        '                Dim elem As Element = iter.Current
        '                If TypeOf elem Is Group Then
        '                    elems.Insert(elem)
        '                End If
        '            Loop
        '            Return elems

        '        End Function

        '        ''' <summary>
        '        ''' Helper to get all rooms using Revit 2009 filtering.
        '        ''' </summary>
        '        Shared Function GetAllRooms(ByVal app As Application) As List(Of Element)
        '            Dim elements As New List(Of Element)
        '            Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(Room))
        '            Dim iRetVal As Integer = app.ActiveDocument.Elements(filterType, elements)
        '            Return elements
        '        End Function

        '        ''' <summary>
        '        ''' Helper to get all groups using Revit 2009 filtering.
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllGroups(ByVal app As Application) As List(Of Element)
        '            Dim elements As New List(Of Element)
        '            Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(Group))
        '            Dim iRetVal As Integer = app.ActiveDocument.Elements(filterType, elements)
        '            Return elements
        '        End Function

        '        ''' <summary>
        '        ''' Helper to get all group types in Revit 2008
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllGroupTypes_2008(ByVal app As Application) As ElementSet

        '            Dim elems As ElementSet = app.Create.NewElementSet
        '            Dim iter As IEnumerator = app.ActiveDocument.Elements
        '            Do While (iter.MoveNext())
        '                Dim elem As Element = iter.Current
        '                If TypeOf elem Is GroupType Then
        '                    elems.Insert(elem)
        '                End If
        '            Loop
        '            Return elems

        '        End Function

        '        ''' <summary>
        '        ''' Helper to get all group types using Revit 2009 filtering
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllGroupTypes(ByVal app As Application) As List(Of Element)
        '            Dim elements As New List(Of Element)
        '            Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(GroupType))
        '            Dim iRetVal As Integer = app.ActiveDocument.Elements(filterType, elements)
        '            Return elements
        '        End Function


        '        ''' <summary>
        '        ''' Helper to get all *model* group types in Revit 2008.
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllModelGroupTypes_2008(ByVal app As Application) As ElementSet

        '            Dim elems As ElementSet = app.Create.NewElementSet
        '            Dim iter As IEnumerator = app.ActiveDocument.Elements
        '            Do While (iter.MoveNext())
        '                Dim elem As Element = iter.Current
        '                If TypeOf elem Is GroupType Then

        '                    ' Need additional check for the group type
        '                    Dim gt As GroupType = elem
        '                    Try
        '                        If gt.Parameter(Parameters.BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM).AsString.Equals(LabConstants.GroupTypeModel) Then
        '                            elems.Insert(elem)
        '                        End If
        '                    Catch
        '                    End Try

        '                End If
        '            Loop
        '            Return elems

        '        End Function


        '        ''' <summary>
        '        ''' Helper to get all *model* group types using Revit 2009 filtering.
        '        ''' </summary>
        '        ''' <param name="app"></param>
        '        ''' <returns></returns>
        '        ''' <remarks></remarks>
        '        Shared Function GetAllModelGroupTypes(ByVal app As Application) As List(Of Element)

        '            Dim elements As New List(Of Element)
        '            Dim filterType As Filter = app.Create.Filter.NewTypeFilter(GetType(GroupType))
        '            Dim filterParam = app.Create.Filter.NewParameterFilter(BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM, CriteriaFilterType.Equal, LabConstants.GroupTypeModel)
        '            Dim filter As Filter = app.Create.Filter.NewLogicAndFilter(filterType, filterParam)
        '            Dim n As Integer = app.ActiveDocument.Elements(filter, elements)
        '            Return elements

        '        End Function

        '#End Region

#End Region ' _2010

    End Class

End Namespace

