#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2007-2008 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region ' Header

#Region "Namespaces"
Imports System
Imports System.Collections.Generic
Imports db = Autodesk.Revit.DB
Imports dbst = Autodesk.Revit.DB.Structure
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.ApplicationServices
#End Region ' Namespaces

Namespace RstLabs
  ''' <summary>
  ''' Revit Structure utilities.
  ''' </summary>
  Friend NotInheritable Class RstUtils
#Region "Structural Element Description"
    Private Sub New()
    End Sub
    Public Shared Function StructuralElementDescription(ByVal e As db.FamilyInstance) As String
      Dim bic As db.BuiltInCategory = db.BuiltInCategory.OST_StructuralFraming
      Dim cat As db.Category = e.Document.Settings.Categories.Item(bic)
      Dim hasCat As Boolean = (Nothing IsNot e.Category)
      Dim hasUsage As Boolean = hasCat AndAlso e.Category.Id.Equals(cat.Id)
      Return e.Name & " Id=" & e.Id.IntegerValue.ToString() & (If(hasCat, ", Category=" & e.Category.Name, String.Empty)) & ", Type=" & e.Symbol.Name + (If(hasUsage, ", Struct.Usage=" & e.StructuralUsage.ToString(), String.Empty)) & ", Struct.Type=" & e.StructuralType.ToString()
    End Function

    Public Shared Function StructuralElementDescription(ByVal e As db.ContFooting) As String
      Return e.Name & " Id=" & e.Id.IntegerValue.ToString() & ", Category=" & e.Category.Name & ", Type=" & e.FootingType.Name
    End Function

    Public Shared Function StructuralElementDescription(ByVal e As db.Floor) As String
      Return e.Name & " Id=" & e.Id.IntegerValue.ToString() & ", Category=" & e.Category.Name & ", Type=" & e.FloorType.Name & ", Struct.Usage=" & e.StructuralUsage.ToString() ' can throw exception "only Beam and Brace support Structural Usage!"

    End Function

    Public Shared Function StructuralElementDescription(ByVal e As db.Wall) As String
      Return e.Name & " Id=" & e.Id.IntegerValue.ToString() & ", Category=" & e.Category.Name & ", Type=" & e.WallType.Name & ", Struct.Usage=" & e.StructuralUsage.ToString() ' can throw exception "only Beam and Brace support Structural Usage!"

    End Function
#End Region ' Structural Element Description

#Region "Retrieve specific element collections"
    ''' <summary>
    ''' Return all instances of the specified class..
    ''' </summary>
    Public Shared Function GetInstanceOfClass(ByVal doc As db.Document, ByVal type As Type) As List(Of db.Element)
      Dim list As New List(Of db.Element)()
      Dim collector As New db.FilteredElementCollector(doc)
      list = TryCast(collector.OfClass(type).ToElements(), List(Of db.Element))
      Return list
    End Function

    ''' <summary>
    ''' Return all instances of the specified class,including the derevided class instances.
    ''' </summary>
    Public Shared Function GetInstanceOfClass(ByVal doc As db.Document, ByVal type As Type, ByVal bInverted As Boolean) As List(Of db.Element)
      Dim list As New List(Of db.Element)()
      Dim collector As New db.FilteredElementCollector(doc)
      Dim classFilter As New db.ElementClassFilter(type, bInverted)
      Dim itor As db.FilteredElementIterator = collector.WherePasses(classFilter).GetElementIterator()
      list = TryCast(collector.ToElements(), List(Of db.Element))
      Return list
    End Function

    ''' <summary>
    ''' Return all loads in the current active document, 
    ''' i.e. any objects derived from LoadBase, sorted by load type.
    ''' </summary>
    Public Shared Sub GetAllSpecificLoads(ByVal doc As db.Document, ByRef pointLoads As db.ElementSet, ByRef lineLoads As db.ElementSet, ByRef areaLoads As db.ElementSet)
      ' More efficient if we loop only once and sort all in one go.
      ' This was more important in 2008 and earlier, before the filtering
      ' feature was introduced in Revit 2009.
      '      
      '      IEnumerator iter = app.ActiveDocument.Elements;
      '      while( iter.MoveNext() )
      '      {
      '        Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
      '        if( elem is PointLoad )
      '        {
      '          pointLoads.Insert( elem );
      '        }
      '        else if( elem is LineLoad )
      '        {
      '          lineLoads.Insert( elem );
      '        }
      '        else if( elem is AreaLoad )
      '        {
      '          areaLoads.Insert( elem );
      '        }
      '      }
      '      
      Dim a As New List(Of db.Element)()
      a = GetInstanceOfClass(doc, GetType(dbst.LoadBase), False)
      For Each elem As db.Element In a
        If TypeOf elem Is dbst.PointLoad Then
          pointLoads.Insert(elem)
        ElseIf TypeOf elem Is dbst.LineLoad Then
          lineLoads.Insert(elem)
        ElseIf TypeOf elem Is dbst.AreaLoad Then
          areaLoads.Insert(elem)
        End If
      Next elem
    End Sub


    ''' <summary>
    ''' Return all load symbols in active document.
    ''' </summary>
    Public Shared Function GetPointLoadSymbols(ByVal doc As db.Document) As List(Of db.Element)
      ' The following commented code is for Revit 2008 and previous version.
      ' It works in Revit 2009 too. However this method has a low performance.
      ' There is a new feature named Element filter in Revit 2009 API, which can improve the performance.
      '      
      '      ElementSet symbols = app.Create.NewElementSet();
      '
      '      ElementIterator iter = app.ActiveDocument.Elements(typeof(PointLoadType));
      '      while ((iter.MoveNext()))
      '      {
      '        Element elem = iter.Current as Element;
      '        if (elem is PointLoadType)
      '        {
      '          symbols.Insert(elem);
      '        }
      '      }
      '      return symbols;
      '            
      Dim a As New List(Of db.Element)()
      a = GetInstanceOfClass(doc, GetType(dbst.LoadTypeBase))
      Return a
    End Function

    ''' <summary>
    ''' Return all structural walls in active document.
    ''' </summary>
    Public Shared Function GetAllStructuralWalls(ByVal doc As db.Document) As List(Of db.Element)
      Dim walls As New List(Of db.Element)()
      walls = GetInstanceOfClass(doc, GetType(db.Wall))
      Dim elems As List(Of db.Element) = New List(Of db.Element)()
      For Each w As db.Wall In walls
        '
        ' We could check if the wall is anything but non-bearing in one of the two following ways:
        ' If Not w.Parameter(db.BuiltInParameter.WALL_STRUCTURAL_USAGE_TEXT_PARAM).AsString.Equals("Non-bearing") Then
        ' If Not w.Parameter(db.BuiltInParameter.WALL_STRUCTURAL_USAGE_PARAM).AsInteger = 0 Then
        ' ... but it is more generic and precise to make sure that analytical model exists
        ' (in theory, one can set the wall to bearing and still uncheck Analytical):
        '
        If Nothing IsNot w.GetAnalyticalModel() Then
          elems.add(w)
        End If
      Next w
      Return elems
    End Function

    ''' <summary>
    ''' Return all structural floors in active document.
    ''' </summary>
    Public Shared Function GetAllStructuralFloors(ByVal doc As db.Document) As List(Of db.Element)
      Dim floors As New List(Of db.Element)()
      'Filter filterFloors = app.Create.Filter.NewTypeFilter( typeof( Floor ) );
      'List<Element> floors = new List<Element>();
      'app.ActiveDocument.Elements( filterFloors, floors );
      floors = GetInstanceOfClass(doc, GetType(db.Floor))
      Dim elems As List(Of db.Element) = New List(Of db.Element)()
      For Each f As db.Floor In floors
        Dim anaMod As dbst.AnalyticalModel = f.GetAnalyticalModel()
        If Nothing IsNot anaMod Then
          '
          ' For floors, looks like we need to have additional check:
          ' for non-structural floors anaMod is NOT null, but it IS empty!
          '
          '          AnalyticalModelFloor floorAnaMod = anaMod as AnalyticalModelFloor;
          If 0 < anaMod.GetCurves(dbst.AnalyticalCurveType.RawCurves).Count Then
            elems.Add(f)
          End If
        End If
      Next f
      Return elems
    End Function

    ''' <summary>
    ''' Return all structural continuous footings in active document.
    ''' </summary>
    Public Shared Function GetAllStructuralContinuousFootings(ByVal doc As db.Document) As List(Of db.Element)
      Dim a As New List(Of db.Element)()
      'Filter filterFooting = app.Create.Filter.NewTypeFilter( typeof( ContFooting ) );
      'List<Element> a = new List<Element>();
      'app.ActiveDocument.Elements( filterFooting, a );
      a = GetInstanceOfClass(doc, GetType(db.ContFooting))
      Dim elems As List(Of db.Element) = New List(Of db.Element)()
      For Each cf As db.ContFooting In a
        If Nothing IsNot cf.GetAnalyticalModel() Then
          elems.Add(cf)
        End If
      Next cf
      Return elems
    End Function
#End Region ' Retrieve specific element collections
  End Class
End Namespace
