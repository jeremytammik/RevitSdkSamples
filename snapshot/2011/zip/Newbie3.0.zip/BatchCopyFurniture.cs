﻿using System;
using System.Collections.Generic;
using System.Linq;

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI.Selection;


/*
 * This command can copy the picked group in a room to any other picked rooms. Users only need several click 
 * Before runing this command, group is needed be created.  
 * The group can contain any kinds of Revit elements, for instance,furnitures,mep ducts and pipes, and the group should be in an existing room. 
 * The target room should also be created before running this command.
 * 
 * */


[TransactionAttribute(TransactionMode.Automatic)]
[RegenerationAttribute(RegenerationOption.Automatic)]
public class BatchCopyFurniture : IExternalCommand
{
    public Result Execute(ExternalCommandData commandData, ref string messages, ElementSet elements)
    {
        UIApplication uiApp = commandData.Application;
        Document doc = uiApp.ActiveUIDocument.Document;
        Application app = uiApp.Application;

        Reference refPicked = null;
        try
        {
            Selection sel = uiApp.ActiveUIDocument.Selection;
            GroupPickFilter groupFilter = new GroupPickFilter();
            refPicked = sel.PickObject(ObjectType.Element,groupFilter, "Please select a group in a room");  //need to add filter to restrict room only

            Element elem = refPicked.Element;
            Group group = elem as Group;
            if (group == null)
            {
                messages = "No group was selected.";
                return Result.Failed;
            }

            //Get the group's Origin point coordinates.
            XYZ ptOrigin = GetGroupOrigin(group, doc);

            //Get the room that the picked group is located in.
            Room room = GetRoomOfGroup(doc,ptOrigin);

            //pick rooms interactively by user
            RoomPickFilter roomPickFilter = new RoomPickFilter();
            IList<Reference> refRooms = sel.PickObjects(ObjectType.Element, roomPickFilter, "Please select rooms to duplicate furniture group");

            //place furniture to these rooms
            PlaceFurnitureInRoom(refRooms, room, group.GroupType, ptOrigin, doc);
        }
        //If user right click or press ESC key, handle the exception
        catch (Autodesk.Revit.Exceptions.OperationCanceledException ex)
        {            
            return Result.Cancelled;
        }
        //catch other errors.
        catch (Exception ex)
        {
            messages = ex.Message;
            return Result.Failed;
        }
        return Result.Succeeded;
    }
    
    //Get the room where the group is located in.
    //Argument ptGroup: the group we will find where it is located.
    //Argument doc:
    //Argument app:
    Room GetRoomOfGroup( Document doc,XYZ ptGroup)
    {
        FilteredElementCollector collector = new FilteredElementCollector(doc);
        collector.OfCategory(BuiltInCategory.OST_Rooms);
        Room room = null;
        foreach (Element elem in collector)
        {
            room = elem as Room;
            if (room != null)
            {
                //decide if this group's center is in the picked room                  
                if (room.IsPointInRoom(ptGroup))
                {
                    break;
                }
            }
        }
        return room;
    }

    //Return the center/origin point of a group 
    public XYZ GetGroupOrigin(Group group, Document doc)
    {
        XYZ pt = null;
        BoundingBoxXYZ bounding = group.get_BoundingBox(doc.ActiveView);
        pt = (bounding.Max + bounding.Min) * 0.5;
        return pt;
    }

    //Duplicate furniture group in picked rooms according to the room's center point.
    //The position where  group is placed is based on the target room's center point, the offset to the room's center point is the offset between the source group center to its owner room's center.
    //lists: all selected rooms' reference.
    //roomSource: the room that the source group is located in.
    //gt: group type of the source group
    //ptGroupOrigin: source group's center/origin point coordinates.
    //doc:
    public void PlaceFurnitureInRoom(IList<Reference> lists, Room roomSource, GroupType gt, XYZ ptGroupOrigin, Document doc)
    {
        foreach (Reference ref1 in lists)
        {
            Room roomTarget = ref1.Element as Room;
            if (roomTarget == null)
                continue;

            XYZ ptRoom = GetRoomCenter(roomTarget, doc);
            XYZ offsetXYZ = ptGroupOrigin - GetRoomCenter(roomSource, doc);
            XYZ offsetXY = new XYZ(offsetXYZ.X, offsetXYZ.Y, 0);

            Group g = doc.Create.PlaceGroup(ptRoom + offsetXY, gt);
        }
    }

    //Return a room's center point coordinates. 
    //Z value is equal to the bottom of the room
    public XYZ GetRoomCenter(Room room, Document doc)
    {
        LocationPoint ptLocation = room.Location as LocationPoint;
        //get the room center point.
        BoundingBoxXYZ bounding = room.get_BoundingBox(doc.ActiveView);
        XYZ xyzCenter = (bounding.Max + bounding.Min) * 0.5;
        XYZ ptRoom = new XYZ(xyzCenter.X, xyzCenter.Y, ptLocation.Point.Z);
        return ptRoom;
    }
}

//Filter to constraint only model groups are highlighted when cursor is hovering. And only model group can be selected.
public class GroupPickFilter : ISelectionFilter
{
    public bool AllowElement(Element element)
    {
        return (element.Category.Name == "Model Groups");
       
    }

    public bool AllowReference(Reference refer, XYZ point)
    {
        return false;
    }
}

//Filter to constraint only rooms are highlighted when cursor is hovering. And only room element can be selected.
public class RoomPickFilter : ISelectionFilter
{
    public bool AllowElement(Element element)
    {
        return (element.Category.Name == "Rooms");
    }

    public bool AllowReference(Reference refer, XYZ point)
    {
        return false;
    }
}

