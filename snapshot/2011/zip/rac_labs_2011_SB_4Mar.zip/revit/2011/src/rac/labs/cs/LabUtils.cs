#region Header
// Revit API .NET Labs
//
// Copyright (C) 2007-2010 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion // Namespaces

namespace Labs
{
  static class LabUtils
  {
    #region Formatting and message handlers
    public const string Caption = "Revit API Labs";

    /// <summary>
    /// Return an English plural suffix 's' or
    /// nothing for the given number of items.
    /// </summary>
    public static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    public static string DotOrColon( int n )
    {
      return 0 < n ? ":" : ".";
    }

    /// <summary>
    /// Format a real number and return its string representation.
    /// </summary>
    public static string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    /// <summary>
    /// Format a point or vector and return its string representation.
    /// </summary>
    public static string PointString( XYZ p )
    {
      return string.Format( "({0},{1},{2})", 
        RealString( p.X ), RealString( p.Y ), RealString( p.Z ) );
    }

    /// <summary>
    /// Return a description string for a given element.
    /// </summary>
    public static string ElementDescription( Element e )
    {
      string description = ( null == e.Category )
        ? e.GetType().Name
        : e.Category.Name;

      if( null != e.Name )
      {
        description += " '" + e.Name + "'";
      }
      return description;
    }

    /// <summary>
    /// Return a description string including element id for a given element.
    /// </summary>
    public static string ElementDescription( Element e, bool includeId )
    {
      string description = ElementDescription( e );
      if( includeId )
      {
        description += " " + e.Id.IntegerValue.ToString();
      }
      return description;
    }

    /// <summary>
    /// Revit TaskDialog wrapper for a short informational message.
    /// </summary>
    public static void InfoMsg( string msg )
    {
      Debug.WriteLine( msg );
      //WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information );
      TaskDialog.Show( Caption, msg, TaskDialogCommonButtons.Ok );
    }

    /// <summary>
    /// Revit TaskDialog wrapper for a message
    /// with separate main instruction and content.
    /// </summary>
    public static void InfoMsg( string msg, string content )
    {
      Debug.WriteLine( msg );
      Debug.WriteLine( content );
      TaskDialog d = new TaskDialog( Caption );
      d.MainInstruction = msg;
      d.MainContent = content;
      d.Show();
    }

    /// <summary>
    /// Revit TaskDialog wrapper for a message with separate 
    /// main instruction and list of lines of content.
    /// The main instruction is expected to include count,
    /// plural suffix and dot or end placeholders.
    /// </summary>
    public static void InfoMsg( string msg, List<string> content )
    {
      int n = content.Count;

      InfoMsg( string.Format( msg,
        n, PluralSuffix( n ), DotOrColon( n ) ),
        string.Join( "\n", content.ToArray() ) );
    }

    /// <summary>
    /// MessageBox wrapper for error message.
    /// </summary>
    public static void ErrorMsg( string msg )
    {
      Debug.WriteLine( msg );
      //WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Error );
      TaskDialog d = new TaskDialog( Caption );
      d.MainIcon = TaskDialogIcon.TaskDialogIconWarning;
      d.MainInstruction = msg;
      d.Show();
    }

    /// <summary>
    /// MessageBox wrapper for question message.
    /// </summary>
    public static bool QuestionMsg( string msg )
    {
      Debug.WriteLine( msg );
      //bool rc = WinForms.DialogResult.Yes
      //  == WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question );
      //Debug.WriteLine( rc ? "Yes" : "No" );
      //return rc;
      TaskDialog d = new TaskDialog( Caption );
      d.MainIcon = TaskDialogIcon.TaskDialogIconNone;
      d.MainInstruction = msg;
      d.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No;
      d.DefaultButton = TaskDialogResult.Yes;
      return TaskDialogResult.Yes == d.Show();
    }

    /// <summary>
    /// MessageBox wrapper for question and cancel message.
    /// </summary>
    public static TaskDialogResult QuestionCancelMsg( string msg )
    {
      Debug.WriteLine( msg );
      //WinForms.DialogResult rc = WinForms.MessageBox.Show( msg, Caption, WinForms.MessageBoxButtons.YesNoCancel, WinForms.MessageBoxIcon.Question );
      //Debug.WriteLine( rc.ToString() );
      //return rc;
      TaskDialog d = new TaskDialog( Caption );
      d.MainIcon = TaskDialogIcon.TaskDialogIconNone;
      d.MainInstruction = msg;
      d.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No | TaskDialogCommonButtons.Cancel;
      d.DefaultButton = TaskDialogResult.Yes;
      return d.Show();
    }
    #endregion // Formatting and message handlers

    #region Selection
    /*public static Element GetSingleSelectedElement( UIDocument doc )
    {
      Element e = null;
      ElementSet ss = doc.Selection.Elements;
      if( 1 != ss.Size )
      {
        ErrorMsg( "Please pre-select a single element." );
      }
      else
      {
        ElementSetIterator iter = ss.ForwardIterator();
        iter.MoveNext();
        e = iter.Current as Element;
      }
      return e;
    }*/

    public static Element GetSingleSelectedElementOrPrompt( UIDocument uidoc )
    {
      Element e = null;
      ElementSet ss = uidoc.Selection.Elements;
      if( 1 == ss.Size )
      {
        ElementSetIterator iter = ss.ForwardIterator();
        iter.MoveNext();
        e = iter.Current as Element;
      }
      else
      {
        Reference r = uidoc.Selection.PickObject( 
          ObjectType.Element, "Please pick an element" );

        e = r.Element;
      }
      return e;
    }

    /// <summary>
    /// A selection filter for a specific System.Type.
    /// </summary>
    class TypeSelectionFilter : ISelectionFilter
    {
      Type _type;

      public TypeSelectionFilter( Type type )
      {
        _type = type;
      }

      /// <summary>
      /// Allow an element of the specified System.Type to be selected.
      /// </summary>
      /// <param name="element">A candidate element in selection operation.</param>
      /// <returns>Return true for specified System.Type, false for all other elements.</returns>
      public bool AllowElement( Element e )
      {
        //return null != e.Category
        // && e.Category.Id.IntegerValue == ( int ) _bic;

        return e.GetType().Equals( _type );
      }

      /// <summary>
      /// Allow all the reference to be selected
      /// </summary>
      /// <param name="refer">A candidate reference in selection operation.</param>
      /// <param name="point">The 3D position of the mouse on the candidate reference.</param>
      /// <returns>Return true to allow the user to select this candidate reference.</returns>
      public bool AllowReference( Reference r, XYZ p )
      {
        return true;
      }
    }

    public static Element GetSingleSelectedElementOrPrompt( 
      UIDocument uidoc,
      Type type )
    {
      Element e = null;

      ElementSet ss = uidoc.Selection.Elements;

      if( 1 == ss.Size )
      {
        ElementSetIterator iter = ss.ForwardIterator();
        iter.MoveNext();
        Type t = iter.Current.GetType();
        if( t.Equals( type ) || t.IsSubclassOf( type ) )
        {
          e = iter.Current as Element;
        }
      }
      if( null == e )
      {
        Reference r = uidoc.Selection.PickObject(
          ObjectType.Element, 
          new TypeSelectionFilter( type ),
          string.Format( "Please pick a {0} element", type.Name ) );

        e = r.Element;
      }
      return e;
    }
    #endregion // Selection

    #region Geometry utilities
    /// <summary>
    /// Return the midpoint between two points.
    /// </summary>
    public static XYZ Midpoint( XYZ p, XYZ q )
    {
      return p + 0.5 * ( q - p );
    }
    #endregion // Geometry utilities

    #region Helpers to get specific element collections
    /// <summary>
    /// Determine bottom and top levels for creating walls.
    /// In a default empty Revit Architecture project,
    /// 'Level 1' and 'Level 2' will be returned.
    /// </summary>
    /// <returns>True is the two levels are successfully determined.</returns>
    public static bool GetBottomAndTopLevels(
      Document doc, 
      ref Level levelBottom, 
      ref Level levelTop )
    {
      FilteredElementCollector levels = new FilteredElementCollector( doc );
      levels.OfCategory( BuiltInCategory.OST_Levels );
      levels.OfClass( typeof( Level ) );

      //FilteredElementCollector levels = collector.ToElements();

      foreach( Element e in levels )
      {
        if( null == levelBottom )
        {
          levelBottom = e as Level;
        }
        else if( null == levelTop )
        {
          levelTop = e as Level;
        }
        else
        {
          break;
        }
      }
      if( levelTop.Elevation < levelBottom.Elevation )
      {
        Level tmp = levelTop;
        levelTop = levelBottom;
        levelBottom = tmp;
      }
      return null != levelBottom && null != levelTop;
    }

    /// <summary>
    /// Return all elements of the requested class in the active document 
    /// matching the given built-in category.
    /// </summary>
    public static FilteredElementCollector GetElementsOfType(
      Document doc, 
      Type type, 
      BuiltInCategory bic )
    {
      FilteredElementCollector collector = new FilteredElementCollector( doc );
      collector.OfCategory( bic );
      collector.OfClass( type );
      return collector;
    }

    /// <summary>
    /// Return all family symbols in the active document 
    /// matching the given built-in category.
    /// </summary>
    public static FilteredElementCollector GetFamilySymbols( 
      Document doc, 
      BuiltInCategory bic )
    {
      return GetElementsOfType( doc, typeof( FamilySymbol ), bic );
    }

    /// <summary>
    /// Return the first family symbol found in the active document 
    /// matching the given built-in category or null if none is found.
    /// </summary>
    public static FamilySymbol GetFirstFamilySymbol(
      Document doc,
      BuiltInCategory bic )
    {
      FamilySymbol s = GetFamilySymbols( doc, bic ).FirstElement() as FamilySymbol;

      Debug.Assert( null != s, string.Format( 
        "expected at least one {0} symbol in project",
        bic.ToString() ) );

      return s;
    }

    /// <summary>
    /// Retrieve all standard family instances for a given category.
    /// </summary>
    public static FilteredElementCollector GetFamilyInstances(
      Document doc,
      BuiltInCategory bic )
    {
      /* 2009:
      List<Element> elements = new List<Element>();
      Filter filterType = app.Create.Filter.NewTypeFilter( typeof( FamilyInstance ) );
      Filter filterCategory = app.Create.Filter.NewCategoryFilter( bic );
      Filter filterAnd = app.Create.Filter.NewLogicAndFilter( filterType, filterCategory );
      app.ActiveDocument.get_Elements( filterAnd, elements );
      return elements;
      */

      FilteredElementCollector collector = new FilteredElementCollector( doc );
      collector.OfClass( typeof( FamilyInstance ) );
      collector.OfCategory( bic );
      return collector; // .ToElements()
    }

    /// <summary>
    /// Helper to get all instances for a given category,
    /// identified either by a built-in category or by a category name.
    /// </summary>
    public static List<Element> GetTargetInstances(
      Document doc,
      object targetCategory )
    {
      List<Element> elements;

      bool isName = targetCategory.GetType().Equals( typeof( string ) );

      if( isName )
      {
        Category cat = doc.Settings.Categories.get_Item( targetCategory as string );
        FilteredElementCollector collector = new FilteredElementCollector( doc );
        collector.OfCategoryId( cat.Id );
        elements = new List<Element>( collector );
      }
      else
      {
        FilteredElementCollector collector
          = new FilteredElementCollector( doc )
            .WhereElementIsNotElementType();

        collector.OfCategory( ( BuiltInCategory ) targetCategory );

        var model_elements = from e in collector
          where ( null != e.Category && e.Category.HasMaterialQuantities )
          select e;

        elements = model_elements.ToList<Element>();
      }
      return elements;
    }

    /// <summary>
    /// Return the one and only project information element
    /// by searching for the "Project Information" category.
    /// Only one such element exists.
    /// </summary>
    public static Element GetProjectInfoElem( Document doc )
    {
      FilteredElementCollector collector = new FilteredElementCollector( doc );
      collector.OfCategory( BuiltInCategory.OST_ProjectInformation );
      return collector.FirstElement();
    }

#if _2010
    /// <summary>
    /// Helper to get specified type for specified family as FamilySymbol object
    /// (in theory, we should also check for the correct *Category Name*).
    /// (note: this only works with component family.)
    /// </summary>
    public static FamilySymbol GetFamilySymbol(
      Application app,
      string familyName,
      string typeName )
    {
      Filter filterType = app.Create.Filter.NewTypeFilter( typeof( FamilySymbol ) );
      Filter filterFamilyName = app.Create.Filter.NewFamilyFilter( familyName );
      Filter filter = app.Create.Filter.NewLogicAndFilter( filterType, filterFamilyName );
      List<Element> elementList = new List<Element>();
      int n = app.ActiveDocument.get_Elements( filter, elementList );
      // we have a list of symbols for a given family.
      // loop through the list and find a match
      // todo: can this loop be repalced by a third filter,
      // for instance using a specified parameter value 
      // to check for the given family name?
      foreach( Element e in elementList )
      {
        if( e.Name.Equals( typeName ) )
        {
          return e as FamilySymbol;
        }
      }
      return null;
    }

    /// <summary>
    /// Helper to get all instance elements with an IMPORT_INSTANCE_SCALE parameter.
    /// </summary>
    public static List<Element> GetAllImportScaleInstances_Crash( Application app )
    {
      List<Element> elements = new List<Element>();
      try
      {
        Filter fType = app.Create.Filter.NewTypeFilter( typeof( Instance ) );
        Filter fParam = app.Create.Filter.NewParameterFilter(
          BuiltInParameter.IMPORT_INSTANCE_SCALE,
          CriteriaFilterType.HasParam,
          0 );
        Filter f = app.Create.Filter.NewLogicAndFilter( fType, fParam );
        app.ActiveDocument.get_Elements( f, elements );
      }
      catch( Exception ex )
      {
        Debug.WriteLine( ex.Message );
      }
      return elements;
    }

    public static List<Element> GetAllImportScaleInstances( Application app )
    {
      List<Element> elements = new List<Element>();
      Filter fType = app.Create.Filter.NewTypeFilter( typeof( Instance ) );
      Filter fParam = app.Create.Filter.NewParameterFilter(
        BuiltInParameter.IMPORT_INSTANCE_SCALE, 
        CriteriaFilterType.GreaterThanOrEqual,
        0.0 );
      Filter f = app.Create.Filter.NewLogicAndFilter( fType, fParam );
      app.ActiveDocument.get_Elements( f, elements );
      return elements;
    }

    public static List<Element> GetFamiliesOfCategory(
      Application app, 
      BuiltInCategory bic )
    {
      Document doc = app.ActiveDocument;
      List<Element> famsInCat = new List<Element>();

#if MARTIN
      // why doesn't this work?
      // it does not work, because the Family class has not implemented the Category property.
      // you have to use other methods to check the category of a family. dor some family instances, you can use FamilyCategory instead of Category, but that does not always work either. the most reliable method is to check the Category property on any one (such as the first) symbol contained in the family.
      Autodesk.Revit.Creation.Filter cf 
        = app.Create.Filter;

      TypeFilter typeFilter 
        = cf.NewTypeFilter( typeof( Family ) );

      CategoryFilter catFilter 
        = cf.NewCategoryFilter( bic );

      LogicAndFilter andFilter 
        = cf.NewLogicAndFilter( typeFilter, catFilter );

      doc.get_Elements( andFilter, famsInCat );
      return famsInCat;
#endif // MARTIN

#if MARTIN
      Category categoryMechanicalEquipment 
        = doc.Settings.Categories.get_Item( bic );

      ElementId categoryId 
        = categoryMechanicalEquipment.Id;

      ElementIterator it 
        = doc.get_Elements( typeof( Family ) );

      while( it.MoveNext() )
      {
        Family family = it.Current as Family;
        bool categoryMatches 
          = family.FamilyCategory.Id.Equals( categoryId );

        if( categoryMatches )
        {
          famsInCat.Add( family );
        }
      }
      return famsInCat;
#endif // MARTIN

      Category categoryMechanicalEquipment 
        = doc.Settings.Categories.get_Item( bic );

      ElementId categoryId 
        = categoryMechanicalEquipment.Id;

      ElementIterator it 
        = doc.get_Elements( typeof( Family ) );

      while( it.MoveNext() )
      {
        Family family = it.Current as Family;
        foreach( Symbol s in family.Symbols )
        {
          if( s.Category.Id.Equals( categoryId ) )
          {
            famsInCat.Add( family );
          }
          break; // only need to look at first symbol
        }
      }
      return famsInCat;
    }
#endif // _2010
    #endregion // Helpers to get specific element collections

    #region Helpers for parameters
    /// <summary>
    /// Helper to return parameter value as string.
    /// One can also use param.AsValueString() to
    /// get the user interface representation.
    /// </summary>
    public static string GetParameterValue( Parameter param )
    {
      string s;
      switch( param.StorageType )
      {
        case StorageType.Double:
          //
          // the internal database unit for all lengths is feet.
          // for instance, if a given room perimeter is returned as
          // 102.36 as a double and the display unit is millimeters,
          // then the length will be displayed as
          // peri = 102.36220472440
          // peri * 12 * 25.4
          // 31200 mm
          //
          //s = param.AsValueString(); // value seen by user, in display units
          //s = param.AsDouble().ToString(); // if not using not using LabUtils.RealString()
          s = RealString( param.AsDouble() ); // raw database value in internal units, e.g. feet
          break;

        case StorageType.Integer:
          s = param.AsInteger().ToString();
          break;
        
        case StorageType.String:
          s = param.AsString();
          break;
        
        case StorageType.ElementId:
          s = param.AsElementId().IntegerValue.ToString();
          break;

        case StorageType.None:
          s = "?NONE?";
          break;
        
        default:
          s = "?ELSE?";
          break;
      }
      return s;
    }

    /// <summary>
    /// Helper to return parameter value as string, with additional
    /// support for element id to display the element type referred to.
    /// </summary>
    public static string GetParameterValue2( Parameter param, Document doc )
    {
      string s;
      if( StorageType.ElementId == param.StorageType && null != doc )
      {
        ElementId id = param.AsElementId();
        int i = id.IntegerValue;
        if( 0 > i )
        {
          s = i.ToString();
        }
        else
        {
          Element e = doc.get_Element( id );
          s = ElementDescription( e, true );
        }
      }
      else
      {
        s = GetParameterValue( param );
      }
      return s;
    }

    /*
    /// <summary>
    /// Helper to return either standard parameter string, 
    /// or element name in case of an element id.
    /// </summary>
    public static string GetParameterValueString2( Parameter param, Document doc )
    {
      string s;
      if( StorageType.ElementId == param.StorageType && null != doc )
      {
        ElementId id = param.AsElementId();
        int i = id.Value;
        s = ( 0 <= i )
          ? ElementDescription( doc.get_Element( ref id ) )
          : string.Empty; // i.ToString();
      }
      else
      {
        s = param.AsValueString();
      }
      return s;
    }*/
    #endregion // Helpers for parameters

    #region Helpers for shared parameters
    /// <summary>
    /// Helper to get shared parameters file.
    /// </summary>
    public static DefinitionFile GetSharedParamsFile( 
      Application app )
    {
      // Get current shared params file name
      string sharedParamsFileName;
      try
      {
        sharedParamsFileName = app.SharedParametersFilename;
      }
      catch( Exception ex )
      {
        ErrorMsg( "No shared params file set:" + ex.Message );
        return null;
      }
      if( 0 == sharedParamsFileName.Length )
      {
        string path = LabConstants.SharedParamFilePath;
        StreamWriter stream;
        stream = new StreamWriter( path );
        stream.Close();
        app.SharedParametersFilename = path;
        sharedParamsFileName = app.SharedParametersFilename;
      }
      // Get the current file object and return it
      DefinitionFile sharedParametersFile;
      try
      {
        sharedParametersFile = app.OpenSharedParameterFile();
      }
      catch( Exception ex )
      {
        ErrorMsg( "Cannnot open shared params file:" + ex.Message );
        sharedParametersFile = null;
      }
      return sharedParametersFile;
    }

    /// <summary>
    /// Helper to get shared params group.
    /// </summary>
    public static DefinitionGroup GetOrCreateSharedParamsGroup( 
     DefinitionFile sharedParametersFile, 
     string groupName )
    {
      DefinitionGroup g = sharedParametersFile.Groups.get_Item( groupName );
      if( null == g )
      {
        try
        {
          g = sharedParametersFile.Groups.Create( groupName );
        }
        catch( Exception )
        {
          g = null;
        }
      }
      return g;
    }

    /// <summary>
    /// Helper to get shared params definition.
    /// </summary>
    public static Definition GetOrCreateSharedParamsDefinition(
      DefinitionGroup defGroup,
      ParameterType defType,
      string defName,
      bool visible )
    {
      Definition definition = defGroup.Definitions.get_Item( defName );
      if( null == definition )
      {
        try
        {
          definition = defGroup.Definitions.Create( defName, defType, visible );
        }
        catch( Exception )
        {
          definition = null;
        }
      }
      return definition;
    }

    /// <summary>
    /// Get GUID for a given shared param name.
    /// </summary>
    /// <param name="app">Revit application</param>
    /// <param name="defGroup">Definition group name</param>
    /// <param name="defName">Definition name</param>
    /// <returns>GUID</returns>
    public static Guid SharedParamGUID( Application app, string defGroup, string defName )
    {
      Guid guid = Guid.Empty;
      try
      {
        DefinitionFile file = app.OpenSharedParameterFile();
        DefinitionGroup group = file.Groups.get_Item( defGroup );
        Definition definition = group.Definitions.get_Item( defName );
        ExternalDefinition externalDefinition = definition as ExternalDefinition;
        guid = externalDefinition.GUID;
      }
      catch( Exception )
      {
      }
      return guid;
    }
    #endregion // Helpers for shared parameters
  }
}
