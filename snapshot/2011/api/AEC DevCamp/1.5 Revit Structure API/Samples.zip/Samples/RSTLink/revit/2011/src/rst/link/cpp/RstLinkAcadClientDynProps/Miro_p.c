

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Wed May 26 14:45:18 2010
 */
/* Compiler settings for .\Miro.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/
#pragma warning( disable: 4152 )  /* function/data pointer conversion in expression */
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */

#pragma optimize("", off ) 

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 475
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "Miro.h"

#define TYPE_FORMAT_STRING_SIZE   3                                 
#define PROC_FORMAT_STRING_SIZE   1                                 
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   0            

typedef struct _Miro_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } Miro_MIDL_TYPE_FORMAT_STRING;

typedef struct _Miro_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } Miro_MIDL_PROC_FORMAT_STRING;

typedef struct _Miro_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } Miro_MIDL_EXPR_FORMAT_STRING;


static RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const Miro_MIDL_TYPE_FORMAT_STRING Miro__MIDL_TypeFormatString;
extern const Miro_MIDL_PROC_FORMAT_STRING Miro__MIDL_ProcFormatString;
extern const Miro_MIDL_EXPR_FORMAT_STRING Miro__MIDL_ExprFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IRevitID_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IRevitID_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IForce_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IForce_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISection_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISection_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IUsage_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IUsage_ProxyInfo;



#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT50_OR_LATER)
#error You need a Windows 2000 or later to run this stub because it uses these features:
#error   /robust command line switch.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will fail with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const Miro_MIDL_PROC_FORMAT_STRING Miro__MIDL_ProcFormatString =
    {
        0,
        {

			0x0
        }
    };

static const Miro_MIDL_TYPE_FORMAT_STRING Miro__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */

			0x0
        }
    };


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IRevitID, ver. 0.0,
   GUID={0xA534D69F,0x802A,0x40cb,{0xB6,0x2E,0x5D,0xAE,0x8C,0x70,0xFF,0x76}} */

#pragma code_seg(".orpc")
static const unsigned short IRevitID_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IRevitID_ProxyInfo =
    {
    &Object_StubDesc,
    Miro__MIDL_ProcFormatString.Format,
    &IRevitID_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IRevitID_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Miro__MIDL_ProcFormatString.Format,
    &IRevitID_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IRevitIDProxyVtbl = 
{
    0,
    &IID_IRevitID,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IRevitID_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IRevitIDStubVtbl =
{
    &IID_IRevitID,
    &IRevitID_ServerInfo,
    7,
    &IRevitID_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IForce, ver. 0.0,
   GUID={0xF648290E,0xEDB2,0x49aa,{0xA4,0x37,0x69,0xB1,0x28,0x0D,0x9A,0x96}} */

#pragma code_seg(".orpc")
static const unsigned short IForce_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IForce_ProxyInfo =
    {
    &Object_StubDesc,
    Miro__MIDL_ProcFormatString.Format,
    &IForce_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IForce_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Miro__MIDL_ProcFormatString.Format,
    &IForce_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IForceProxyVtbl = 
{
    0,
    &IID_IForce,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IForce_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IForceStubVtbl =
{
    &IID_IForce,
    &IForce_ServerInfo,
    7,
    &IForce_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISection, ver. 0.0,
   GUID={0x185408D6,0x1454,0x422f,{0xB6,0x5F,0x58,0x5E,0xBE,0x11,0xD4,0xC7}} */

#pragma code_seg(".orpc")
static const unsigned short ISection_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO ISection_ProxyInfo =
    {
    &Object_StubDesc,
    Miro__MIDL_ProcFormatString.Format,
    &ISection_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISection_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Miro__MIDL_ProcFormatString.Format,
    &ISection_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _ISectionProxyVtbl = 
{
    0,
    &IID_ISection,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION ISection_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _ISectionStubVtbl =
{
    &IID_ISection,
    &ISection_ServerInfo,
    7,
    &ISection_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IUsage, ver. 0.0,
   GUID={0x184F914F,0x6836,0x4b23,{0x85,0x84,0xC8,0xEF,0x57,0x97,0x44,0x8D}} */

#pragma code_seg(".orpc")
static const unsigned short IUsage_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IUsage_ProxyInfo =
    {
    &Object_StubDesc,
    Miro__MIDL_ProcFormatString.Format,
    &IUsage_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IUsage_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Miro__MIDL_ProcFormatString.Format,
    &IUsage_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IUsageProxyVtbl = 
{
    0,
    &IID_IUsage,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IUsage_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IUsageStubVtbl =
{
    &IID_IUsage,
    &IUsage_ServerInfo,
    7,
    &IUsage_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    Miro__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x50002, /* Ndr library version */
    0,
    0x70001f4, /* MIDL Version 7.0.500 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0
    };

const CInterfaceProxyVtbl * _Miro_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IForceProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IUsageProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IRevitIDProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISectionProxyVtbl,
    0
};

const CInterfaceStubVtbl * _Miro_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IForceStubVtbl,
    ( CInterfaceStubVtbl *) &_IUsageStubVtbl,
    ( CInterfaceStubVtbl *) &_IRevitIDStubVtbl,
    ( CInterfaceStubVtbl *) &_ISectionStubVtbl,
    0
};

PCInterfaceName const _Miro_InterfaceNamesList[] = 
{
    "IForce",
    "IUsage",
    "IRevitID",
    "ISection",
    0
};

const IID *  _Miro_BaseIIDList[] = 
{
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    0
};


#define _Miro_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _Miro, pIID, n)

int __stdcall _Miro_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _Miro, 4, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _Miro, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _Miro, 4, *pIndex )
    
}

const ExtendedProxyFileInfo Miro_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _Miro_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _Miro_StubVtblList,
    (const PCInterfaceName * ) & _Miro_InterfaceNamesList,
    (const IID ** ) & _Miro_BaseIIDList,
    & _Miro_IID_Lookup, 
    4,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#pragma optimize("", on )
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/

