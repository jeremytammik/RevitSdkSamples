﻿#region "Imports"

using System;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;

#endregion

namespace RSTLabsCS
{

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Automatic)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Automatic)]
    public class AlignRebar: IExternalApplication   
    {
        // Hard coded path for icons for UI buttons
        String m_imageFolder = "C:\\Saikat\\DevTech\\DevCamp2010\\RST\\Presentation\\Samples\\RST2011_PlatformAPI\\RSTLabs\\Images\\";
 
        #region IExternalApplication Members

        /// <summary>
        /// On Shutdown, unregister the updater
        /// </summary>
        /// <param name="application"></param>
        /// <returns></returns>
        Result IExternalApplication.OnShutdown(UIControlledApplication application)
        {
            RebarUpdater updater = new RebarUpdater(application.ActiveAddInId);
            UpdaterRegistry.UnregisterUpdater(updater.GetUpdaterId());

            return Result.Succeeded; 
        }

        /// <summary>
        /// On start up, add UI buttons, register the updater, add triggers
        /// </summary>
        /// <param name="application"></param>
        /// <returns></returns>
        Result IExternalApplication.OnStartup(UIControlledApplication application)
        {
            // Add the UI buttons on start up
            AddUILabsButtons(application);

            RebarUpdater updater = new RebarUpdater(application.ActiveAddInId);

            // Register the updater in the singleton UpdateRegistry class
            UpdaterRegistry.RegisterUpdater(updater);

            // Set the filter; in this case we shall work with beams specifically
            ElementCategoryFilter filter = new ElementCategoryFilter(BuiltInCategory.OST_StructuralFraming);

            // Add trigger 
            UpdaterRegistry.AddTrigger(updater.GetUpdaterId(), filter, Element.GetChangeTypeGeometry());

            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /// <summary>
        /// Add UI buttons
        /// </summary>
        /// <param name="app"></param>
        public void AddUILabsButtons(UIControlledApplication app)
        {
            // create a ribbon panel on the Analyze tab
            RibbonPanel panel = app.CreateRibbonPanel(Tab.Analyze, "RST Labs");
            AddDMUCommandButtons(panel);
        }

        
        /// <summary>
        /// Control buttons for the Dynamic Model Update 
        /// </summary>
        /// <param name="panel"></param>
        public void AddDMUCommandButtons(RibbonPanel panel)
        {
            // get the location of this dll. 
            string assembly = GetType().Assembly.Location;

            // create three toggle buttons for radio button group 
            // #1
            ToggleButtonData toggleButtonData3 = new ToggleButtonData("RSTLabsDMUOff", "Align Off", assembly, "RSTLabsCS.UIDynamicModelUpdateOff");
            toggleButtonData3.LargeImage = new BitmapImage(new Uri(m_imageFolder + "Families.ico"));

            // #2 
            ToggleButtonData toggleButtonData4 = new ToggleButtonData("RSTLabsDMUOn", "Align On", assembly, "RSTLabsCS.UIDynamicModelUpdateOn");
            toggleButtonData4.LargeImage = new BitmapImage(new Uri(m_imageFolder + "Families.ico"));

            // make dyn update on/off radio button group 
            RadioButtonGroupData radioBtnGroupData2 = new RadioButtonGroupData("RebarAlign");
            RadioButtonGroup radioBtnGroup2 = panel.AddItem(radioBtnGroupData2) as RadioButtonGroup;
            radioBtnGroup2.AddItem(toggleButtonData3);
            radioBtnGroup2.AddItem(toggleButtonData4);
        }
        
        #endregion
    }

    public class RebarUpdater : IUpdater
    {
        public static bool m_updateActive = false;
        AddInId addinID = null;
        UpdaterId updaterID = null;

        public RebarUpdater(AddInId id)
        {
            addinID = id;
            // UpdaterId that is used to register and 
            // unregister updaters and triggers
            updaterID = new UpdaterId(addinID, new Guid("63CDBB88-5CC4-4ac3-AD24-52DD435AAB25"));
        }

        /// <summary>
        /// Implement the logic to align the rebar based on new beam length
        /// </summary>
        /// <param name="data"></param>
        public void Execute(UpdaterData data)
        {
            if (m_updateActive == false) { return; }

            // Get access to document object
            Document doc = data.GetDocument();

            try
            {
                // Loop through all the modified elements
                foreach (ElementId modifiedElemId in data.GetModifiedElementIds())
                {
                    FamilyInstance beam = doc.get_Element(modifiedElemId) as FamilyInstance;

                    // Create a filter to access all the rebars in the model 
                    FilteredElementCollector rebars = new FilteredElementCollector(doc);
                    rebars.OfCategory(BuiltInCategory.OST_Rebar);
                    rebars.OfClass(typeof(Rebar));

                    foreach (Rebar rebar in rebars)
                    {
                        // Calculate the beam line
                        XYZ beamStartPoint = new XYZ();
                        XYZ beamEndPoint = new XYZ();
                        Line beamLine = CalculateBeamLine(beam);

                        // Get the start and end point 
                        if (null != beamLine)
                        {
                            beamStartPoint = beamLine.get_EndPoint(0);
                            beamEndPoint = beamLine.get_EndPoint(1);
                        }

                        // To align the rebar to the new beam's length, we split the tasks in two stages
                        // Step 1: Move the rebar to align with one of the end of the beam

                        // For this we first access the rebar line geometry
                        Line rebarLine = rebar.Curves.get_Item(0) as Line;
                        // Calculate the translation vector (the extent of the move)
                        XYZ transVec = new XYZ(beamStartPoint.X - rebarLine.get_EndPoint(0).X, 0.0, 0.0);
                        // Perform the move 
                        doc.Move(rebar, transVec);
                        
                        // This move causes the beam line to change and so recalculating the beam line
                        beamLine = CalculateBeamLine(beam);

                        // Step 2: Set the new length of the rebar based on new beam length
                        // For this, we can set the relevant parameter after checking at UI
                        rebar.get_Parameter("B").Set(GetLength(beamLine));
                    }
                }
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Exception", ex.Message);
            }
        }

        // Calculate the beam line 
        private Line CalculateBeamLine(FamilyInstance beam)
        {
            Autodesk.Revit.DB.GeometryElement geoElement = beam.get_Geometry(new Options());
            if (null == geoElement || 0 == geoElement.Objects.Size)
            {
                throw new Exception("Can't get the geometry of selected element.");
            }

            Line beamLine = null;

            //get the geometry object
            foreach (GeometryObject geoObject in geoElement.Objects)
            {
                // get the driving path and vector of the beam 
                beamLine = geoObject as Line;
                if (null != beamLine)
                {
                    return beamLine;
                }
            }
            return null;
        }

        /// <summary>
        /// get the length of the given line
        /// </summary>
        /// <param name="line"></param>
        /// <returns>length</returns>
        public static double GetLength(Line line)
        {
            Autodesk.Revit.DB.XYZ sub = SubXYZ(line.get_EndPoint(0), line.get_EndPoint(1));
            double length = Math.Sqrt(sub.X * sub.X + sub.Y * sub.Y + sub.Z * sub.Z);
            return length;
        }

        /// <summary>
        /// subtraction of two Autodesk.Revit.DB.XYZ as Matrix
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        private static Autodesk.Revit.DB.XYZ SubXYZ(Autodesk.Revit.DB.XYZ p1, Autodesk.Revit.DB.XYZ p2)
        {
            double x = p1.X - p2.X;
            double y = p1.Y - p2.Y;
            double z = p1.Z - p2.Z;

            Autodesk.Revit.DB.XYZ result = new Autodesk.Revit.DB.XYZ(x, y, z);
            return result;
        }
        
        /// <summary>
        /// Returns the auxiliary string
        /// </summary>
        /// <returns></returns>
        public string GetAdditionalInformation()
        {
            return "Automatically aligns the rebar to match that of the beam";
        }

        /// <summary>
        /// Set the priority
        /// </summary>
        /// <returns></returns>
        public ChangePriority GetChangePriority()
        {
            return ChangePriority.Rebar;
        }

        /// <summary>
        /// return the updater Id
        /// </summary>
        /// <returns></returns>
        public UpdaterId GetUpdaterId()
        {
            return updaterID;
        }

        /// <summary>
        /// return the updater name
        /// </summary>
        /// <returns></returns>
        public string GetUpdaterName()
        {
            return "Rebar alignment updater";
        }
    }


    [Transaction(TransactionMode.Automatic)]
    [Regeneration(RegenerationOption.Automatic)]
    public class UIDynamicModelUpdateOff : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            RSTLabsCS.RebarUpdater.m_updateActive = false;
            return Result.Succeeded;
        }
    }

    [Transaction(TransactionMode.Automatic)]
    [Regeneration(RegenerationOption.Automatic)]
    public class UIDynamicModelUpdateOn : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            RSTLabsCS.RebarUpdater.m_updateActive = true;
            return Result.Succeeded;
        }
    }
}
