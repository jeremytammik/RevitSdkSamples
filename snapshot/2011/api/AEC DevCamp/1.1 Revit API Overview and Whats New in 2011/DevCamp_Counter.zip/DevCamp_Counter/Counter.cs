﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Autodesk.Revit;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Events;
using Autodesk.Revit.DB.Events;

namespace DevCamp_Counter
{

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class LevelMatcher : IExternalCommand
    {
        static AddInId m_appId = new AddInId(new Guid("C2181371-E65B-4a35-BF7F-2959CA87A42D"));
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.ApplicationServices.Application app = commandData.Application.Application;
            Document doc = commandData.Application.ActiveUIDocument.Document;
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document famDoc = app.NewFamilyDocument(@"C:\Revit\r2011\Data\Platform\Imperial\Templates\Conceptual Mass\Mass.rft");
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            IList<Element> elementList = new List<Element>();
            elementList = collector.OfClass(typeof(Level)).OfCategory(BuiltInCategory.OST_Levels).ToElements();
            Transaction transaction = new Transaction(famDoc);
            transaction.SetName("Level creation");
            transaction.Start();
            foreach (Element e in elementList)
            {
                Level l = e as Level;
                Level famLevel = famDoc.FamilyCreate.NewLevel(l.Elevation);
                try // Revit will throw exception if level name would be a duplicate
                {
                    famLevel.Name = l.Name;
                }
                catch (System.Exception)
                {
                }
                ViewPlan viewPlan = famDoc.FamilyCreate.NewViewPlan(famLevel.Name, famLevel, ViewPlanType.FloorPlan);
            }
            transaction.Commit();

            transaction.SetName("Geometry creation");
            transaction.Start();
            IList<Reference>faceRefs = new List<Reference>();
            faceRefs = uidoc.Selection.PickObjects(Autodesk.Revit.UI.Selection.ObjectType.Face,"Select faces for referencing in the family");
            foreach (Reference r in faceRefs)
            {
                Face f = r.GeometryObject as Face;
                foreach (EdgeArrayArray edgeLoop in f.EdgeLoops)
                {
                    foreach (EdgeArray edgeArray in edgeLoop)
                    {
                        foreach (Edge edge in edgeArray)
                        {
                            ReferencePointArray array = new ReferencePointArray();
                            XYZ end1 = edge.get_EndPointReference(0).GlobalPoint;
                            XYZ end2 = edge.get_EndPointReference(1).GlobalPoint;
                            ReferencePoint rp1 = famDoc.FamilyCreate.NewReferencePoint(end1);
                            ReferencePoint rp2 = famDoc.FamilyCreate.NewReferencePoint(end2);
                            array.Append(rp1);
                            array.Append(rp2);
                            CurveByPoints cbp = famDoc.FamilyCreate.NewCurveByPoints(array);
                        }
                    }
                }
            }
            transaction.Commit();
            
            famDoc.SaveAs(@"C:\MassWithLevels.rfa");
            doc.Close();
            famDoc.Close();
            return Result.Succeeded;
        }
    }

    
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class ParameterRandomizer_Basic : IExternalCommand
    {
        static AddInId m_appId = new AddInId(new Guid("CF184391-E65B-4a35-BF7F-2959CA87A42D"));
        FamilyInstance instance = null;
        StreamWriter writer = null;
        Transaction t = null;
        ImageExportOptions imageOptions = null;
        Document doc = null;
        UIDocument uidoc = null;
        UIApplication uiApp = null;
        List<KeyValuePair<string, double>> paramValueList = null;
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.ApplicationServices.Application app = commandData.Application.Application;
            uiApp = new UIApplication(app);
            doc = commandData.Application.ActiveUIDocument.Document;
            uidoc = commandData.Application.ActiveUIDocument;
            imageOptions = new ImageExportOptions();
            imageOptions.PixelSize = 175;

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            try
            {
                instance = collector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Mass).ToElements().First() as FamilyInstance;
            }
            catch (System.Exception)
            {
                TaskDialog.Show("Error", "No mass instance found.");
                return Result.Cancelled;            	
            }

            paramValueList = new List<KeyValuePair<string,double>>();
            List<string> paramList = new List<string>();
            foreach (Parameter p in instance.Parameters)
            {
                if (p.Definition.ParameterGroup == BuiltInParameterGroup.PG_DATA)
                {
                    paramList.Add(p.Definition.Name);
                    paramValueList.Add(new KeyValuePair<string,double>(p.Definition.Name, p.AsDouble()));
                }
            }
            if (paramList.Count == 0)
            {
                TaskDialog.Show("Error", "The mass instance has no parameters in the 'Data' parameter group.");
                return Result.Cancelled;
            }

            t = new Transaction(doc);
            t.SetName("transaction");
            t.Start();
            doc.ActiveView.setVisibility(doc.Settings.Categories.get_Item("Mass"), true);
            t.Commit();
              
            string htmlFile = "C:\\images.html";
            writer = new StreamWriter(htmlFile);
            writer.WriteLine("<html><body><table>");

            for (int ctr = 0; ctr < 20; ctr++ )
            {
                FailureHandlingOptions failOpt = t.GetFailureHandlingOptions();
                failOpt.SetFailuresPreprocessor(new RollbackErrors());

                if (ctr % 6 == 0) writer.WriteLine("<tr>");
                imageOptions.FilePath = "c:\\img_" + ctr + ".jpg";
                writer.WriteLine("<td valign='bottom'><img src='" + imageOptions.FilePath + "' border=1><br><font size=-1>");
                t.Start();
                t.SetName("Randomizer Iteration " + ctr);
                foreach (KeyValuePair<string, double> thisPair in paramValueList)
                {
                    string s = thisPair.Key;
                    Parameter pp = instance.get_Parameter(s);
                    pp.Set(thisPair.Value);
                    SetParam(thisPair);
                    writer.WriteLine(s + "=" + SetParam(thisPair) + "<br>");
                }
                t.SetFailureHandlingOptions(failOpt);
                t.Commit();
                uidoc.RefreshActiveView();
                doc.ExportImage(imageOptions);
            }
            writer.WriteLine("</body></html>");
            writer.Close();
            System.Diagnostics.Process.Start(htmlFile);
            return Result.Succeeded;
        }

        public double SetParam(KeyValuePair<string, double> thisPair)
        {
            Parameter p = instance.get_Parameter(thisPair.Key);
            double valOld = thisPair.Value;
            Random random = new Random((int)valOld * DateTime.Now.Millisecond);
            double newVal = Math.Round(valOld * (random.NextDouble() + 0.5), 3);
            bool result = p.Set(newVal);
            return newVal;
        }
        public class RollbackErrors : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                IList<FailureMessageAccessor> failList = failuresAccessor.GetFailureMessages();
                if (failuresAccessor.GetFailureMessages(FailureSeverity.Error).Count > 0)
                {
 //                   failuresAccessor.RollBackPendingTransaction();
                    return FailureProcessingResult.ProceedWithRollBack;
                }
                else
                {
                    return FailureProcessingResult.Continue;
                }
            }
        }
    }


    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class ParameterRandomizer_with_Solar : IExternalCommand
    {
        static AddInId m_appId = new AddInId(new Guid("CF184291-E65B-4a35-BF7F-2959CA87A42D"));
        FamilyInstance instance = null;
        int ctr = 0;
        int idleSolarCnt = 0;
        UpdateState updateState = UpdateState.UpdateParams;
        StreamWriter writer = null;
        Transaction t = null;
        ImageExportOptions imageOptions = null;
        Document doc = null;
        UIDocument uidoc = null;
        UIApplication uiApp = null;
        List<KeyValuePair<string, double>> paramValueList = null;

        public enum UpdateState
        {
            UpdateParams,
            UpdateImage,
            SolarAnalysis,
        }

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.ApplicationServices.Application app = commandData.Application.Application;
            uiApp = new UIApplication(app);
            doc = commandData.Application.ActiveUIDocument.Document;
            uidoc = commandData.Application.ActiveUIDocument;
            imageOptions = new ImageExportOptions();
            imageOptions.PixelSize = 175;

            FilteredElementCollector collector = new FilteredElementCollector(doc);
            try
            {
                instance = collector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Mass).ToElements().First() as FamilyInstance;
            }
            catch (System.Exception)
            {
                TaskDialog.Show("Error", "No mass instance found.");
                return Result.Cancelled;
            }

            paramValueList = new List<KeyValuePair<string, double>>();
            List<string> paramList = new List<string>();
            foreach (Parameter p in instance.Parameters)
            {
                if (p.Definition.ParameterGroup == BuiltInParameterGroup.PG_DATA)
                {
                    paramList.Add(p.Definition.Name);
                    paramValueList.Add(new KeyValuePair<string, double>(p.Definition.Name, p.AsDouble()));
                }
            }
            if (paramList.Count == 0)
            {
                TaskDialog.Show("Error", "The mass instance has no parameters in the 'Data' parameter group.");
                return Result.Cancelled;
            }

            t = new Transaction(doc);
            t.SetName("transaction");
            t.Start();
            doc.ActiveView.setVisibility(doc.Settings.Categories.get_Item("Mass"), true);
            t.Commit();

            string htmlFile = Path.GetTempPath() + "\\images.html";
            writer = new StreamWriter(htmlFile);

            uiApp.Idling += new EventHandler<IdlingEventArgs>(idleUpdate);
            uiApp.Application.DocumentChanged += new EventHandler<DocumentChangedEventArgs>(documentChanged);

            return Result.Succeeded;
        }

        public void idleUpdate(object sender, IdlingEventArgs e)
        {
            if (ctr < 5)
            {
                if (ctr == 0)
                {
                    writer.WriteLine("<html><body><table>");
                }
                switch (updateState)
                {
                    case UpdateState.UpdateParams:
                        FailureHandlingOptions failOpt = t.GetFailureHandlingOptions();
                        failOpt.SetFailuresPreprocessor(new RollbackErrors());

                        if (ctr % 8 == 0) writer.WriteLine("<tr>");
                        imageOptions.FilePath = Path.GetTempPath() + "\\img_" + ctr + ".jpg";
                        writer.WriteLine("<td valign='bottom'><img src='" + imageOptions.FilePath + "' border=1><br><font size=-1>");
                        t.Start();
                        t.SetName("Randomizer Iteration " + ctr);
                        foreach (KeyValuePair<string, double> thisPair in paramValueList)
                        {
                            string s = thisPair.Key;
                            Parameter pp = instance.get_Parameter(s);
                            pp.Set(thisPair.Value);
                            SetParam(thisPair);
                            writer.WriteLine(s + "=" + SetParam(thisPair) + "<br>");
                        }
                        t.SetFailureHandlingOptions(failOpt);
                        t.Commit();

                        updateState = UpdateState.SolarAnalysis;
                        break;
                    case UpdateState.SolarAnalysis:
                        idleSolarCnt++;
                        if (idleSolarCnt > 10)
                        {
                            Thread.Sleep(5000);
                            ctr++;
                            updateState = UpdateState.UpdateImage;
                            idleSolarCnt = 0;
                        }
                        break;

                    case UpdateState.UpdateImage:
                        uidoc.RefreshActiveView();
                        doc.ExportImage(imageOptions);
                        updateState = UpdateState.UpdateParams;
                        break;

                }
            }
            else
            {
                writer.WriteLine("</body></html>");
                writer.Close();
                //    System.Diagnostics.Process.Start(htmlFile);
                uiApp.Idling -= idleUpdate;
            }

        }

        private void documentChanged(object sender, DocumentChangedEventArgs e)
        {
            List<ElementId> elementIds = new List<ElementId>();

            foreach (ElementId id in e.GetAddedElementIds())
            {
                elementIds.Add(id);
            }

            foreach (ElementId id in e.GetModifiedElementIds())
                elementIds.Add(id);

            foreach (ElementId id in elementIds)
            {
                Element elem = doc.get_Element(id);
                if (null == elem)
                    continue;

                if (elem is Autodesk.Revit.DB.Analysis.SpatialFieldManager)
                //   elem.Category.Id.IntegerValue == (int)Autodesk.Revit.DB.BuiltInCategory.OST_AnalysisDisplayStyle)
                {
                    updateState = UpdateState.UpdateImage;
                    break;
                }

            }
        }

        public double SetParam(KeyValuePair<string, double> thisPair)
        {
            Parameter p = instance.get_Parameter(thisPair.Key);
            double valOld = thisPair.Value;
            Random random = new Random((int)valOld * DateTime.Now.Millisecond);
            double newVal = Math.Round(valOld * (random.NextDouble() + 0.5), 3);
            bool result = p.Set(newVal);
            return newVal;
        }
        public class RollbackErrors : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
            {
                IList<FailureMessageAccessor> failList = failuresAccessor.GetFailureMessages();
                if (failuresAccessor.GetFailureMessages(FailureSeverity.Error).Count > 0)
                {
                    //                   failuresAccessor.RollBackPendingTransaction();
                    return FailureProcessingResult.ProceedWithRollBack;
                }
                else
                {
                    return FailureProcessingResult.Continue;
                }
            }
        }

    }

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class IdleTimeStamp : IExternalCommand
    {
        static AddInId m_appId = new AddInId(new Guid("CF184671-E65B-4a35-BF7F-2959CA87A42D"));
        TextNote textNote = null;
        String oldDateTime = null;
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication uiApp = new UIApplication(commandData.Application.Application);
            Document doc = commandData.Application.ActiveUIDocument.Document;
            Transaction t = new Transaction(doc);
            t.SetName("Text Note");
            t.Start();
            textNote = doc.Create.NewTextNote(doc.ActiveView, XYZ.Zero, XYZ.BasisX, XYZ.BasisY, 0, TextAlignFlags.TEF_ALIGN_LEFT, DateTime.Now.ToString());
            t.Commit();
            oldDateTime = DateTime.Now.ToString();
            uiApp.Idling += new EventHandler<IdlingEventArgs>(idleUpdate);
            return Result.Succeeded;
        }
        public void idleUpdate(object sender, IdlingEventArgs e)
        {
            Autodesk.Revit.ApplicationServices.Application app = sender as Autodesk.Revit.ApplicationServices.Application;
            UIApplication uiApp = new UIApplication(app);
            Document doc = uiApp.ActiveUIDocument.Document;
            if (oldDateTime != DateTime.Now.ToString())
            {
                Transaction t2 = new Transaction(doc);
                t2.SetName("Text Note Update");
                t2.Start();
                textNote.Text = DateTime.Now.ToString();
                t2.Commit();
                oldDateTime = DateTime.Now.ToString();
            }
        }
    }


    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class a : IExternalCommand
    {
        static AddInId m_appId = new AddInId(new Guid("CF184371-E65B-4a35-BF7F-2959CA87A42D"));
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.ApplicationServices.Application app = commandData.Application.Application;
            Document doc = commandData.Application.ActiveUIDocument.Document;
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            return Result.Succeeded;
        }
    }

}
