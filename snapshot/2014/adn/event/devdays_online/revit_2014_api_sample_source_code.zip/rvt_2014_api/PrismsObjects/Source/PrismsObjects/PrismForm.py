﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from Prism import *

class PrismForm(Prism):
        
    def ExtrudeProfiles(self):
        """
        Overrides the ExtrudeProfiles function of the Prism superclass.
        
        Extrudes an array of model curves in a conceptual mass template.
        The extrusion occurs along the Z direction. If the input value for the
        height is negative the extrusion occurs along the -Z direction. 
        This is a helper function called by the higher level functions intended
        to generate prisms for various profiles.   
        
        Returns a reference to the generated Form object.
        """            
        
        #create an array of model curves out of the array of curves composing 
        #the profile to be extruded
        modelCurveArr = self.FromCurvesToModelCurves()
        
        #convert the array of model curves to a reference array
        profile = self.FromModelCurveToReferenceArray(modelCurveArr)
        
        transactionExtrusion = Transaction(self.doc, "CreateExtrusion")
        transactionExtrusion.Start()        
        prism = self.doc.FamilyCreate.NewExtrusionForm(True, profile, self.upVector.Multiply(self.height))
        transactionExtrusion.Commit()
        return prism.Id
        
    def FromCurvesToModelCurves(self):
    	"""
        Converts an array curves to an array of model curves and returns the array of model 
        curves. This is a helper function called by the higher level ExtrudeProfiles function.
        """
        
    	bottomSketchPlane = self.CreateBottomSketchPlane()
    	modelCurveArr = ModelCurveArray()
        
        transactionSketch = Transaction(self.doc, "CreateSketch")
        transactionSketch.Start()                        
        for curve in self.extrusionProfile:
            modelCurve = self.doc.FamilyCreate.NewModelCurve(curve, bottomSketchPlane)
            modelCurveArr.Append(modelCurve)        
        transactionSketch.Commit()
    	return modelCurveArr
  
    
    def FromModelCurveToReferenceArray(self, modelCurveArr):
    	"""
        Converts an array of model curves to a reference array and returns the reference 
        array. This is a helper function called by the higher level ExtrudeProfiles function.
               
        Keyword arguments:
        modelCurveArr -- an array of model curves   
        """
        referenceArr = ReferenceArray()
        for modelCurve in modelCurveArr:
            referenceArr.Append(modelCurve.GeometryCurve.Reference)
        return referenceArr


    
    


