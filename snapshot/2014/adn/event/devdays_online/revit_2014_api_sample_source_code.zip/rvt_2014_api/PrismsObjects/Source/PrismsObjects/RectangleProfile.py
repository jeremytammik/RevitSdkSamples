﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from ShapeProfile import *

class RectangleProfile(ShapeProfile):
	
    def __init__(self, sideLength, sideWidth):
    	#NOTE: Negative input values for sideLenth and sideWidth will
    	#create a profile line in the -Y and -X direction respectively.
    	
    	if sideLength == 0 : raise ValueError, 'sideLength cannot be zero'
        if sideWidth == 0 : raise ValueError, 'sideWidth cannot be zero'       
        self.sideLength = sideLength
        self.sideWidth = sideWidth
        
        ShapeProfile.__init__(self)
        
        self.DrawShapeProfileOnXYPlane()
    
    
    def DrawShapeProfileOnXYPlane(self):
        """
        Generates the curves that compose a rectangle and adds them to a curve array.
        The profile is placed by default on the XY plane.
        """
        
    	#define the four corners of the rectangle
        ptLeft = XYZ.Zero
        ptTop = XYZ(0, self.sideLength,0)
        ptRight = XYZ(self.sideWidth, self.sideLength, 0)
        ptBottom = XYZ(self.sideWidth, 0, 0)
        
        #GSenerate all lines connecting the 3 points        
        leftSide = Line.CreateBound(ptLeft, ptTop)
        topSide = Line.CreateBound(ptTop, ptRight)
        rightSide = Line.CreateBound(ptRight, ptBottom)
        bottomSide = Line.CreateBound(ptBottom, ptLeft)
        self.crvArray.Append(leftSide)
        self.crvArray.Append(topSide)
        self.crvArray.Append(rightSide)
        self.crvArray.Append(bottomSide)

               

    


