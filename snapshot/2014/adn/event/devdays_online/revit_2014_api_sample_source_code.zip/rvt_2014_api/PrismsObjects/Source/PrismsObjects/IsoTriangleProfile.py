﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from ShapeProfile import *

class IsoTriangleProfile(ShapeProfile):
	
    def __init__(self, legLength):
    	#NOTE: Negative input values for legLenth will create a profile 
        #line in the -X and -Y direction.
    	if legLength == 0 : raise ValueError, 'legLength cannot be zero'
    	self.legLength = legLength
    	
        ShapeProfile.__init__(self)
              
        self.DrawShapeProfileOnXYPlane()
   
   
    def DrawShapeProfileOnXYPlane(self):
        """
        Generates the curves that compose an iso triangle and adds them to a curve array.
        The profile is placed by default on the XY plane.
        """
       
        #define the three points that define the triangle profile
        p0 = XYZ.Zero
        p1 = XYZ(0, self.legLength, 0)
        p2 = XYZ(self.legLength, 0, 0)
        
        # Generate the lines between every two points of the triangle
        # and add them to an array 
        self.crvArray.Append(Line.CreateBound(p0,p1))  
        self.crvArray.Append(Line.CreateBound(p1,p2))
        self.crvArray.Append(Line.CreateBound(p2,p0))    
    
    

    

