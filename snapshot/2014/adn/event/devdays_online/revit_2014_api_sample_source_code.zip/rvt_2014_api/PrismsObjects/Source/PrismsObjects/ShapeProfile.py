﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *

class ShapeProfile():
	
    def __init__(self):  	 
        self.crvArray = CurveArray()
        #unit vector along the Z direction to be used as plane normal
        self.upVector = XYZ(0,0,1)
        #creates a default reference to the origin point of the XY plane
        #XY plane will be used as the default sketch plane for the shape profile
        self.origin = XYZ(0,0,0)

        
    def DrawShapeProfileOnXYPlane():
    	"""
        Generates the curves that compose a shape profile and adds them to a curve 
        array. The profile is placed by default on the XY plane.
        """      
    	raise NotImplementedError()
    
    
    def GetProfile(self):
    	"""
        Returns the array of curves that compose the shape profile
        """
     	return self.crvArray
     
     
   