﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from math import *
from ShapeProfile import *

class CircleProfile(ShapeProfile):
	
    def __init__(self, radius):
    	if radius <= 0 : raise ValueError, 'radius must be a positive number'
    	self.radius = radius
    	
        ShapeProfile.__init__(self)
                
        self.DrawShapeProfileOnXYPlane()
    
    def DrawShapeProfileOnXYPlane(self):
        """
        Generates the curves that compose a circle and adds them to a curve array.
        The profile is placed by default on the XY plane.
        """
       
        #define the circle profile given a plane on XY
        circlePlane = Plane(self.upVector, self.origin)
        circle = Arc.Create(circlePlane, self.radius, 0, 2*pi) 
        
        #add the profile curves to an array
        self.crvArray.Append(circle)
        
       


