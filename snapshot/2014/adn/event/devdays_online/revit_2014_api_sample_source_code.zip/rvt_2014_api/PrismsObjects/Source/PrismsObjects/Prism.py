﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *

class Prism():
      
    def __init__(self, activeDoc, height, shapeProfile): 
    	#NOTE: Negative input value for height will create a profile line 
    	#in the -Z direction.
    	if height == 0 : raise ValueError, 'height cannot be zero'
    	
    	self.height = height
        self.doc = activeDoc       
        self.extrusionProfile = shapeProfile.GetProfile()
        #creates a default extrusion direction along the z axis
        self.upVector = XYZ(0,0,1)
        #creates a default reference to the origin point of the XY plane
        #XY plane will be used as the default sketch plane
        self.origin = XYZ(0,0,0)

    def ExtrudeProfiles(self):
        """
        Extrudes an array of profiles given a default sketch plane (XY plane).
        The extrusion occurs along the Z direction. If the input value for the
        height is negative the extrusion occurs along the -Z direction.  

        Returns a reference to the generated Extrusion object.        
        """
              
        #Define a plane to place the circular profile
        bottomSketchPlane = self.CreateBottomSketchPlane()
        
        #Extrude triangle transaction
        transactionExtrusion = Transaction(self.doc, "CreateExtrusion")
        transactionExtrusion.Start()        
        extrusionProfiles = CurveArrArray()  
        extrusionProfiles.Append(self.extrusionProfile)
        prism = self.doc.FamilyCreate.NewExtrusion(True, extrusionProfiles, bottomSketchPlane, self.height)
        transactionExtrusion.Commit()
        return prism.Id
        
    def CreateBottomSketchPlane(self):
        """
        A utility function that creates a default sketch plane. It returns a plane
        object with normal along the Z direction and origin the point at (0,0,0). This 
        function is called by the higher-level function ExtrudeProfiles  to define a 
        sketch plane for the extrusion.  
        """
        
        #Create plane transaction
        transactionPlane = Transaction(self.doc, "CreateSketchPlane")
        transactionPlane.Start() 
        bottomPlane = Plane(self.upVector, self.origin)
        bottomSketchPlane = self.doc.FamilyCreate.NewSketchPlane(bottomPlane)
        transactionPlane.Commit()
        return bottomSketchPlane
       



    
    

