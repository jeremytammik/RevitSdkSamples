﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from System.Collections.Generic import List
from math import *
from ShapeProfile import *

class RegularPolygonProfile(ShapeProfile):
	
    def __init__(self, numSides, sideLength):
    	if numSides <= 0 : raise ValueError, 'numSides must be a positive number'
        if numSides > 20 : raise ValueError, 'numSides must be less than 20'
        if sideLength <= 0 : raise ValueError, 'sideLength must be a positive number'     
        self.numSides = numSides
        self.sideLength = sideLength
        
        ShapeProfile.__init__(self)
        
        self.DrawShapeProfileOnXYPlane()
    
    
    def DrawShapeProfileOnXYPlane(self):
        """
        Generates the curves that compose a regular polygon and adds them to a curve array.
        The profile is placed by default on the XY plane.
        """
       
        # compute the inradius of the polygon (distance from the center of the polygon 
        # to the midpoint of any side)
        inradious = self.sideLength/(2*tan(2*pi/self.numSides))   
        # use the inradius to compute the radius of the circle that circumscribes the polygon  
        radius = sqrt(pow(inradious,2)+pow(self.sideLength/2,2))
        
        circlePlane = Plane(self.upVector, self.origin)
        circle = Arc.Create(circlePlane, radius, 0, 2*pi) 
        
        thetaIncrement = (2*pi)/self.numSides
        
        polyCorners = []

        # the coordinates of the corners of the polygon are computed by computing first
        # the polar coordinates using the angle increment theta and then converting to cartesian
        for i in range(self.numSides):
            if i == 0:
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
            elif i == (self.numSides-1):
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
                self.crvArray.Append(Line.CreateBound(polyCorners[i-1], polyCorners[i]))
                self.crvArray.Append(Line.CreateBound(polyCorners[i], polyCorners[0]))
            else:
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
                self.crvArray.Append(Line.CreateBound(polyCorners[i-1], polyCorners[i]))
                
    
    def GetCartesianPoint(self, radius, theta):
        """
        A utility function that converts polar to cartesian coordinates. 
        Returns an XYZ point. 
               
        Keyword arguments:
        radius -- the radius of the circle
        theta -- angle in radians
        """
        x = radius * cos(theta)
        y = radius * sin(theta)
        return XYZ(x, y, 0)
    
    
    

    

