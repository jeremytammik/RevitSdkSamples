﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *

from CircleProfile import *
from IsoTriangleProfile import *
from RegularPolygonProfile import *
from RectangleProfile import *
from Prism import *
from PrismForm import *

class ThisApplication (ApplicationEntryPoint):
	#region Revit Macros generated code
    def FinishInitialization(self):
    	ApplicationEntryPoint.FinishInitialization(self)
    	self.InternalStartup()
    
    def OnShutdown(self):
    	self.InternalShutdown()
    	ApplicationEntryPoint.OnShutdown(self)
    
    def InternalStartup(self):
    	self.Startup()
    
    def InternalShutdown(self):
    	self.Shutdown()
    #endregion
    
    def Startup(self):
    	self
    	
    def Shutdown(self):
    	self

    #------------------------DEMO FUNCTIONS    
    #The following functions are returning extrusions for a given shape profile.
    #They require a family document to work.  
    def NewIsoTrianglePrismDemo(self):
        isoTriangle = IsoTriangleProfile(2) 
        isoTrianglularPrism = Prism(self.ActiveUIDocument.Document, 3, isoTriangle)
        prismId = isoTrianglularPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))


    def NewRegularPolygonPrismDemo(self):
        regularPolygon = RegularPolygonProfile(8, 4)
        regularPolygonPrism = Prism(self.ActiveUIDocument.Document, 3, regularPolygon)
        prismId = regularPolygonPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
               
    def NewCylindricalPrismDemo(self):
        circle = CircleProfile(2) 
        circularPrism = Prism(self.ActiveUIDocument.Document, 3, circle)
        prismId = circularPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    def NewRectanglePrismDemo(self):
        rectangle = RectangleProfile(2,5) 
        rectanglePrism = Prism(self.ActiveUIDocument.Document, 3, rectangle)
        prismId = rectanglePrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    #The following functions are returning extrusion forms for a given shape profile.
    #They require a conceptua mass family document to work
    
    def NewIsoTrianglePrismFormDemo(self):
        isoTriangle = IsoTriangleProfile(2) 
        isoTrianglularPrism = PrismForm(self.ActiveUIDocument.Document, 3, isoTriangle)
        prismId = isoTrianglularPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    def NewRegularPolygonPrismFormDemo(self):
        regularPolygon = RegularPolygonProfile(8, 4) 
        regularPolygonPrism = PrismForm(self.ActiveUIDocument.Document, 3, regularPolygon)
        prismId = regularPolygonPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    def NewCylindricalPrismFormDemo(self):
        circle = CircleProfile(2) 
        circularPrism = PrismForm(self.ActiveUIDocument.Document, 3, circle)
        prismId = circularPrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    def NewRectanglePrismFormDemo(self):
        rectangle = RectangleProfile(-2,-5) 
        rectanglePrism = PrismForm(self.ActiveUIDocument.Document, 3, rectangle)
        prismId = rectanglePrism.ExtrudeProfiles()
        TaskDialog.Show("Prism generation", ("prism Id: " + prismId.ToString()))
        
    #--------------------------------------
        
       
    # Transaction mode
    def GetTransactionMode(self):
        return Attributes.TransactionMode.Manual
	
	# Addin Id
    def GetAddInId(self):
        return 'EAAE00FD-4F99-4D57-892E-4827FE89DFBA'
