﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;

namespace Revit.SDK.Samples.Site.CS
{
    /// <summary>
    /// Raised all points contained in a subregion by 3 feet.
    /// </summary>
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    class SiteRaiseTerrainInRegionCommand : IExternalCommand
    {
        #region IExternalCommand Members

        /// <summary>
        /// Implementation of the external command.
        /// </summary>
        /// <param name="commandData"></param>
        /// <param name="message"></param>
        /// <param name="elements"></param>
        /// <returns></returns>
        public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {
            SiteUIUtils.ChangeSubregionAndPointsElevation(commandData.Application.ActiveUIDocument, 3);

            return Result.Succeeded;
        }

        #endregion
    }
}
