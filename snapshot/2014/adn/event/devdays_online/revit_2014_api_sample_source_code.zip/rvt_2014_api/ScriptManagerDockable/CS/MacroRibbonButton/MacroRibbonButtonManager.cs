﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using System.Xml.Linq;
namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
   public class MacroRibbonButtonManager
   {
      public MacroRibbonButtonManager(RibbonPanel panel)
      {
         m_ribbonPanel = panel;
         m_nameInfoMap  = new Dictionary<string, ButtonInfo>();
      }
      public void Initialize()
      {
        string classNameNamespace = "Revit.SDK.Samples.ScriptManagerDockable.CS.";
   
        int buttonIndex;
        for (buttonIndex = 1; buttonIndex <= Constants.MaximumRibbonIcons; buttonIndex++)
        {
           string buttonName = "button" +  buttonIndex.ToString();
           PushButtonData buttonData = new PushButtonData(buttonName, Constants.ButtonNameNone, FileUtility.GetAssemblyFullName(), classNameNamespace + buttonName);
           buttonData.AvailabilityClassName = classNameNamespace + buttonName;
           PushButton button = m_ribbonPanel.AddItem(buttonData) as PushButton;
           button.Visible = false;
           m_nameInfoMap.Add(buttonName, new ButtonInfo(button, Constants.DefaultScriptIconFilename, "", ""));
        }

        XDocument buttonConfig = FileUtility.GetButtonConfigXDocument();
        if (buttonConfig != null)
        {
           if (buttonConfig.Root.Elements(Constants.xnButton).Count() > Constants.MaximumRibbonIcons)
              throw new InvalidOperationException("Ribbon configuration file has unsupported number of button configurations.");
           int index = 0;
           foreach (XElement element in buttonConfig.Root.Elements(Constants.xnButton))
           {
              string buttonName, macroName, moduleName, icon;
              buttonName = element.Attribute(Constants.xnName).Value;
              macroName = element.Attribute(Constants.xnMacroName).Value;
              moduleName = element.Attribute(Constants.xnModuleName).Value;
              icon = element.Attribute(Constants.xnIcon).Value;
              if ( (!string.IsNullOrEmpty(macroName)) && (!(string.IsNullOrEmpty(moduleName))))
                   ThisApplication.thisApp.GetMacroAPIUtility().AssignSpecificButton(buttonName, macroName, moduleName, icon);
              index++;
           }
        }
     }
      public string GetFirstAvailableButton()
     {
        foreach (string key in m_nameInfoMap.Keys)
         {
            if (!IsButtonMapped(key))
               return key;
         }
         return null;
     }
      public bool IsScriptMapped(Script script)
      {
         foreach (ButtonInfo info in m_nameInfoMap.Values)
         {

            if (info.MacroName == "")
               continue;
            if ((script.ScriptName == info.MacroName) && (script.Collection.ScriptCollectionName == info.ModuleName))
               return true;
         }
         return false;
      }
      public void AssignButton(string buttonName, string macroName, string macroModule)
      {
         m_nameInfoMap[buttonName].MacroName = macroName;
         m_nameInfoMap[buttonName].ModuleName = macroModule;
      }
      public Tuple<string, string> GetMappedScript(string buttonName)
      {
         if (!IsButtonMapped(buttonName))
            return new Tuple<string, string>("", "");
         else
            return new Tuple<string, string>(m_nameInfoMap[buttonName].MacroName, m_nameInfoMap[buttonName].ModuleName);
      }
      public string GetButtonName(string macroName, string moduleName)
      {
         foreach (string name in m_nameInfoMap.Keys)
         {
            string tempMacroName = m_nameInfoMap[name].MacroName;
            string tempMacroModule = m_nameInfoMap[name].ModuleName;

            if (tempMacroName != null)
            {
               if ((tempMacroName == macroName) && (tempMacroModule == moduleName))
                  return name;
            }
         }
         return null;
      }
      public void SetVisibility(string buttonName, bool visible)
      {
         CheckButtonName(buttonName);
         PushButton button = m_nameInfoMap[buttonName].Button;
         
         button.Visible = visible;
      }
      public void SetButtonText(string buttonName, string text)
      {
         CheckButtonName(buttonName);
         PushButton button = m_nameInfoMap[buttonName].Button;

         button.ItemText = text;
      }
      public void SetButtonIcon(string buttonName, string path)
      {
         CheckButtonName(buttonName);
         m_nameInfoMap[buttonName].IconPath = path;

             Uri uriImage = new Uri(FileUtility.GetUserIconPath()  + path);
             m_nameInfoMap[buttonName].Button.LargeImage = new System.Windows.Media.Imaging.BitmapImage(uriImage);
      }
      public string GetButtonIcon(string buttonName)
      {
         CheckButtonName(buttonName);

         return m_nameInfoMap[buttonName].IconPath;
      }
      public List<string> GetButtonNames()
      {
         return m_nameInfoMap.Keys.ToList();
      }

      private bool IsButtonMapped(string name)
      {
         if (m_nameInfoMap[name].MacroName != "")
            return true;
         else
            return false;
      }
      private void CheckButtonName(string buttonName)
      {
         if (!IsValidButtonName(buttonName))
            throw new InvalidOperationException("Invalid button macroName.");
      }
      private bool IsValidButtonName(string buttonName)
      {
         if (string.IsNullOrEmpty(buttonName))
            return false;
         ButtonInfo value;
         return m_nameInfoMap.TryGetValue(buttonName, out value);
      }
      #region Data
      RibbonPanel m_ribbonPanel;
      Dictionary<string, ButtonInfo> m_nameInfoMap;
      #endregion
   }

   public class ButtonInfo
   {
      public ButtonInfo(PushButton button, string iconPath, string macroName, string moduleName)
      {
         Button = button;
         IconPath = iconPath;
         MacroName = macroName;
         ModuleName = moduleName;
      }

      #region Data
      public string MacroName;
      public string ModuleName;
      public PushButton Button;
      public string IconPath;
      public Script Script;
      #endregion
   }
}
