﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Navigation;
using System.Windows.Controls.Primitives;
using System.Reflection;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;
using Autodesk.Revit.DB.Macros;
using Autodesk.Revit.UI.Macros;
using System.Collections.Specialized;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    class SuffixBuilder
    {
        public static void Reset()
        {
            sm_letterIndex = 0;
            sm_numberIndex = 1;
        }
        public static string Next()
        {
            if (sm_letterIndex == 4)
            {
                sm_letterIndex = 0;
                sm_numberIndex++;
            }
            string suffix = sm_letters[sm_letterIndex].ToString() + sm_numberIndex.ToString();
            sm_letterIndex++;
            return suffix;
        }

        #region Data
        private static char[] sm_letters = { 'a', 'b', 'c', 'd' };
        private static int sm_letterIndex = 0;
        private static int sm_numberIndex = 1;
        #endregion

    }


   class MacroAPIUtilityInternal
   {
      public static bool DoesModuleExist(string moduleName, MacroManager mgr)
      {
         if (string.IsNullOrEmpty(moduleName))
            return false;

         bool exists = false;
         foreach (MacroModule module in mgr)
         {
            if (module.Name == moduleName)
               exists = true;
         }
         return exists;
      }
      public static bool DoesMacroExist(string macroName, MacroModule module)
      {
         if (string.IsNullOrEmpty(macroName))
            return false;

         bool exists = false;
         foreach (Macro macro in module)
         {
            if (macro.Name == macroName)
               exists = true;
         }
         return exists;
      }
      public static string CreateNextNewModuleName(MacroLanguageType languageType, MacroManager mgr)
      {
         string newName = "NewModule_" + languageType.ToString() + "_" + GetNumberOfModules(mgr, languageType).ToString();
         if (MacroAPIUtilityInternal.DoesModuleExist(newName, mgr))
         {
             int maximumAttempts = 15;
             for (int attemptIndex = 0; attemptIndex != maximumAttempts; attemptIndex++)
             {
                 string newNameSuffixed = newName + SuffixBuilder.Next();
                 if (MacroAPIUtilityInternal.DoesModuleExist(newNameSuffixed, mgr))
                     continue;
                 else
                     return newNameSuffixed;
             }
         }
         else
         {
             return newName;
         }

         throw new ArgumentException(Constants.ExceptionScriptCollectionAlreadyExists, newName);
         
      }
      public static string CreateNextNewMacroName(MacroModule module, MacroLanguageType languageType)
      {
          string newName = "NewMacro_" + (GetNumberOfMacros(module) + 1).ToString();
          if (MacroAPIUtilityInternal.DoesMacroExist(newName, module))
          {
              int maximumAttempts = 15;
              for (int attemptIndex = 0; attemptIndex != maximumAttempts; attemptIndex++)
              {
                  string newNameSuffixed = newName + SuffixBuilder.Next();
                  if (MacroAPIUtilityInternal.DoesMacroExist(newNameSuffixed, module))
                      continue;
                  else
                      return newNameSuffixed;
              }
          }
          else
          {
              return newName;
          }
          throw new ArgumentException(Constants.ExceptionScriptAlreadyExistsMessage, newName);
      }
      public static int GetNumberOfMacros(MacroModule module)
      {
         int count = 0;
         foreach (Macro macro in module)
         {
            count++;
         }
         return count;
      }
      public static int GetNumberOfModules(MacroManager macroManager, MacroLanguageType languageType)
      {
         int count = 0;
         foreach (MacroModule module in macroManager)
         {
            if (module.MacroLanguageType == languageType)
               count++;
         }
         return count;
      }
      public static MacroModule GetMacroModule(string moduleName, MacroManager mgr)
      {
         if (!MacroAPIUtilityInternal.DoesModuleExist(moduleName, mgr))
            throw new ArgumentException(Constants.ExceptionScriptCollectionNotFoundMessage, moduleName);
         MacroModule toReturn = null;
         foreach (MacroModule macroModule in mgr)
         {
            if (macroModule.Name.Equals(moduleName))
            {
               toReturn = macroModule;
            }
         }


         return toReturn;
      }

      public static MacroModule AddModule(string moduleName, string moduleDescription, Autodesk.Revit.UI.Macros.UIMacroManager mgr, MacroLanguageType languageType)
      {
         ModuleSettings moduleSettings = new ModuleSettings(moduleName, languageType);
         moduleSettings.Description = moduleDescription;
         MacroModule newModule = mgr.AddModule(moduleSettings, MacroEnvironment.UI);
         return newModule;
      }
      public static bool RemoveModule(string moduleName, Autodesk.Revit.UI.Macros.UIMacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr.MacroManager);
         mgr.RemoveModule(module);
         return true;
      }
      public static string AddMacro(string macroName, string macroDescription, string moduleName, string macroText, Autodesk.Revit.DB.Macros.MacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr);
         module.AddMacro(macroName, macroDescription, macroText);
         return macroName;
      }
      public static bool RemoveMacro(string macroName, string moduleName, Autodesk.Revit.DB.Macros.MacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr);
         Macro macro = MacroAPIUtilityInternal.GetMacro(macroName, module);
         module.RemoveMacro(macro);
         return true;
      }
      public static bool EditMacro(string macroName, string moduleName, Autodesk.Revit.UI.Macros.UIMacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr.MacroManager);
         Macro macro = MacroAPIUtilityInternal.GetMacro(macroName, module);
         mgr.EditMacro(macro);
         return true;
      }
      public static bool EditModule(string moduleName, Autodesk.Revit.UI.Macros.UIMacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr.MacroManager);
         mgr.EditModule(module);
         return true;

      }
      public static string RunMacro(string macroName, string moduleName, Autodesk.Revit.DB.Macros.MacroManager mgr)
      {
         MacroModule module = MacroAPIUtilityInternal.GetMacroModule(moduleName, mgr);
         Macro macro = MacroAPIUtilityInternal.GetMacro(macroName, module);
         string retval = "";
         try
         {
             macro.Execute();
         }
         catch (Exception ex)
         {
             retval = ex.Message;
         }
         return retval;
      }

      private static Macro GetMacro(string macroName, MacroModule module)
      {
         Macro toReturn = null;
         foreach (Macro macro in module)
         {
            if (macro.Name.Equals(macroName))
            {
               toReturn = macro;
            }
         }
         return toReturn;
      }

   }
}
