﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Navigation;
using System.Windows.Controls.Primitives;
using System.Reflection;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    public partial class MainWindow : Page
    {
      #region Request Builders

      private void MakeRunRequest(Script script)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.RunMacro;
         commandData.MacroName = script.ScriptName;
         commandData.ModuleName = script.Collection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeEditRequest(Script script)
      {
         ModelessCommandData commandDataEditScript = new ModelessCommandData();
         commandDataEditScript.CommandType = ModelessCommandType.EditMacro;
         commandDataEditScript.MacroName = script.ScriptName;
         commandDataEditScript.ModuleName = script.Collection.ScriptCollectionName;
         MakeRequest(commandDataEditScript);
      }
      private void MakeAddToRibbonRequest(Script script)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.AddMacroToRibbon;
         commandData.MacroName = script.ScriptName;
         commandData.IconFilename = script.IconName;
         commandData.ModuleName = script.Collection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeRemoveFromRibbonRequest(Script script)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.RemoveMacroFromRibbon;
         commandData.MacroName = script.ScriptName;
         commandData.ModuleName = script.Collection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeDeleteRequest(Script script)
      {
         ModelessCommandData commandData= new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.RemoveMacro;
         commandData.MacroName = script.ScriptName;
         commandData.ModuleName = script.Collection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeDeleteRequest(ScriptCollection scriptCollection)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.RemoveModule;
         commandData.ModuleName = scriptCollection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeEditRequest(ScriptCollection scriptCollection)
      {
         ModelessCommandData commandDataEditModule = new ModelessCommandData();
         commandDataEditModule.CommandType = ModelessCommandType.EditModule;
         commandDataEditModule.ModuleName = scriptCollection.ScriptCollectionName;
         MakeRequest(commandDataEditModule);
      }
      public void MakeAddScriptRequest(Autodesk.Revit.DB.Macros.MacroLanguageType languageType, bool showUI = false)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.AddMacroToDefaultCollection;
         commandData.LanguageType = languageType;
         commandData.ShowUI = showUI;
         MakeRequest(commandData);
      }
      private void MakeAddScriptRequest(Autodesk.Revit.DB.Macros.MacroLanguageType languageType, ScriptCollection scriptCollection)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.AddMacroToNamedCollection;
         commandData.LanguageType = languageType;
         commandData.ModuleName = scriptCollection.ScriptCollectionName;
         MakeRequest(commandData);
      }
      private void MakeAddScriptCollectionRequest(Autodesk.Revit.DB.Macros.MacroLanguageType languageType)
      {
         ModelessCommandData commandData = new ModelessCommandData();
         commandData.CommandType = ModelessCommandType.AddNamedModule;
         commandData.LanguageType = languageType;
         MakeRequest(commandData);
      }
      #endregion
    }
}

