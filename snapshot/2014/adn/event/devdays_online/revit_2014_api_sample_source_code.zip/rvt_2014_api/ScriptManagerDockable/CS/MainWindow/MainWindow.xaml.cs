﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Navigation;
using System.Windows.Controls.Primitives;
using System.Reflection;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{

   public partial class MainWindow : Page, Autodesk.Revit.UI.IDockablePaneProvider
    {
        public MainWindow(ScriptData scriptData)
        {
           this.Resources.Add("data", scriptData);
           DataContext = this;
           InitializeComponent();
           RestoreDialogState(ThisApplication.thisApp.DialogState);
         //  this.Closing += new CancelEventHandler(MainWindow_Closing);
           m_exEvent  = Autodesk.Revit.UI.ExternalEvent.Create(m_handler);
        }

        public ScriptData GetScriptData() { return this.Resources["data"] as ScriptData; }

        public Autodesk.Revit.DB.Macros.MacroLanguageType SelectedLanguage
        {
           set
           {
              m_languageType = value;
              switch (value)
              {
                 case Autodesk.Revit.DB.Macros.MacroLanguageType.CSharp:
                    this.cBtn.IsChecked = true;
                    break;

                 case Autodesk.Revit.DB.Macros.MacroLanguageType.Python:
                    this.pythonBtn.IsChecked = true;
                    break;

                 case Autodesk.Revit.DB.Macros.MacroLanguageType.Ruby:
                    this.rubyBtn.IsChecked = true;
                    break;

                 case Autodesk.Revit.DB.Macros.MacroLanguageType.VBNet:
                    this.vbBtn.IsChecked = true;
                    break;
              }

           }
           get { return m_languageType; }
        }

        #region Button handlers
        private void BlockMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
           if (e.ClickCount == 2 && !m_isEditable)
           {
              //NOTE: When m_IsTreeView is true, i.e. we are in the TreeView display
              //the function call to MakeTreeBoxItemEditable() does not work. My assumption is
              //that the control of the expander is more powerful and does not register the
              //double click (wherever we click it will result to expanding the button). 
              //A solution would be to make a custom implementation of TreeView
              //and instead of an expander have a toggle button so that the the area of the
              //textbox can receive the double click.

              if (m_IsTreeView) MakeTreeBoxItemEditable();

              else MakeListBoxItemEditable();
           }
        }
        private void CommitButtonClick(object sender, RoutedEventArgs e)
        {
           return; //Disable until we support rename.
           /*
            //Get the ContentPresenter of the currently selected ListBoxItem
            ContentPresenter thisContentPresenter = FindVisualChild<ContentPresenter>(m_itemUnderEdit);
            //Finding the textBlock from the DataTemplate that is set on that ContentPresenter
            DataTemplate thisDataTemplate = thisContentPresenter.ContentTemplate;

            //convert the textblocks to editable textboxes
            SwitchTextBlockStates(thisDataTemplate, thisContentPresenter);

            SwitchDynamicButtonStates(thisDataTemplate, thisContentPresenter);
            m_isEditable = false;
            */
        }
        private void GraftFlattenButtonClicked(object sender, RoutedEventArgs e)
        {
           CollectionViewSource temp = (CollectionViewSource)this.FindResource("cvs");
           if (m_IsTreeView)
           {
              Tree.Visibility = Visibility.Collapsed;
              FlattenedListBox.Visibility = Visibility.Visible;
              m_IsTreeView = false;
           }
           else
           {
              FlattenedListBox.Visibility = Visibility.Collapsed;
              Tree.Visibility = Visibility.Visible;
              m_IsTreeView = true;
           }
        }
        private void DescendAscendButtonClicked(object sender, RoutedEventArgs e)
        {
           //NOTE: ALPHABETICAL SORTING DOES NOT WORK FOR THE GROUP DESCRIPTION
           //NEEDS TO BE FIXED
           CollectionViewSource temp = (CollectionViewSource)this.FindResource("cvs");
           if ((sender as ToggleButton).IsChecked.Value)
           {
              temp.SortDescriptions.Clear();
              temp.SortDescriptions.Add(new SortDescription("ScriptName", ListSortDirection.Ascending));
           }
           else
           {
              temp.SortDescriptions.Clear();
              temp.SortDescriptions.Add(new SortDescription("ScriptName", ListSortDirection.Descending));
           }
        }
        private void RadioButtonChecked(object sender, RoutedEventArgs e)
        {
           CollectionViewSource cvs = (CollectionViewSource)(this.Resources["cvs"]);
           if (pythonBtn.IsChecked == true)
           {
              m_languageType = Autodesk.Revit.DB.Macros.MacroLanguageType.Python;
              cvs.Filter += new FilterEventHandler(FilterByLanguage);
           }
           else if (rubyBtn.IsChecked == true)
           {
              m_languageType = Autodesk.Revit.DB.Macros.MacroLanguageType.Ruby;
              cvs.Filter += new FilterEventHandler(FilterByLanguage);
           }
           else if (cBtn.IsChecked == true)
           {
              m_languageType = Autodesk.Revit.DB.Macros.MacroLanguageType.CSharp;
              cvs.Filter += new FilterEventHandler(FilterByLanguage);
           }
           else if (vbBtn.IsChecked == true)
           {
              m_languageType = Autodesk.Revit.DB.Macros.MacroLanguageType.VBNet;
              cvs.Filter += new FilterEventHandler(FilterByLanguage);
           }
           else
           {
              cvs.Filter += new FilterEventHandler(RemoveFilter);
           }
        }
        #endregion

        #region UI State
        private void SelItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {

        }
        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
           TreeView t = sender as TreeView;
           Script s = (sender as TreeView).SelectedItem as Script;
        }
        private void ListBoxSelectionChanged(object sender, SelectionChangedEventArgs args)
        {
           if (!m_IsTreeView)
           {
              Script thisScript = (Script)FlattenedListBox.SelectedItem;
              if (thisScript != null)
              {
                 /*  Disable until we have a better handle on script import/export to ribbon
                  if (thisScript.HasButton)
                  {
                      export.IsEnabled = false; export.Opacity = 0.2;
                      invertExport.IsEnabled = true; invertExport.Opacity = 1;
                  }
                  else
                  {
                      export.IsEnabled = true; export.Opacity = 1;
                      invertExport.IsEnabled = false; invertExport.Opacity = 0.2;
                  }
                  * */
              }
           }
        }
        private void MakeListBoxItemEditable()
        {
           return;  //disable until we support renaming macros/modules
           /*
            //GET THE CURRENTLY SELECTED LISTBOX ITEM
                m_itemUnderEdit = (ListBoxItem)FlattenedListBox.
                    ItemContainerGenerator.ContainerFromItem(FlattenedListBox.Items.CurrentItem);
                //Get the ContentPresenter of the currently selected ListBoxItem
                ContentPresenter thisContentPresenter = FindVisualChild<ContentPresenter>(m_itemUnderEdit);
                //Finding the textBlock from the DataTemplate that is set on that ContentPresenter
                DataTemplate thisDataTemplate = thisContentPresenter.ContentTemplate;

                //CONVERT THE TEXTBLOCKS TO EDITABLE TEXTBOXES
                SwitchTextBlockStates(thisDataTemplate, thisContentPresenter);

                SwitchDynamicButtonStates(thisDataTemplate, thisContentPresenter);
                m_isEditable = true;
             */
        }
        private void MakeTreeBoxItemEditable()
        {
           return; //disable until we support renaming macros/modules
           /*
            //if the selected index returns -1 then a child item is currently selected, otherwise a parent
            int index = Tree.Items.IndexOf(Tree.SelectedItem);

            if (index != -1)  //PARENT CURRENTLY SELECTED
            {
                TreeViewItem item = (TreeViewItem)(Tree.ItemContainerGenerator.ContainerFromIndex(index));
                ContentPresenter thisContentPresenter = FindVisualChild<ContentPresenter>(item);
                DataTemplate thisDataTemplate = thisContentPresenter.ContentTemplate;

                //CONVERT THE TEXTBLOCKS TO EDITABLE TEXTBOXES
                SwitchTextBlockStates(thisDataTemplate, thisContentPresenter);

                SwitchDynamicButtonStates(thisDataTemplate, thisContentPresenter);
                m_isEditable = true;
            }
            * */
        }
        private void GetSelectedParentTreeItem()
        {
           //if the selected index returns -1 then a child item is currently selected, otherwise a parent
           int index = Tree.Items.IndexOf(Tree.SelectedItem);

           if (index != -1)  //PARENT CURRENTLY SELECTED
           {
              TreeViewItem item = (TreeViewItem)(Tree.ItemContainerGenerator.ContainerFromIndex(index));
              ContentPresenter thisContentPresenter = FindVisualChild<ContentPresenter>(item);
              DataTemplate thisDataTemplate = thisContentPresenter.ContentTemplate;

              //CONVERT THE TEXTBLOCKS TO EDITABLE TEXTBOXES
              SwitchTextBlockStates(thisDataTemplate, thisContentPresenter);

              SwitchDynamicButtonStates(thisDataTemplate, thisContentPresenter);
              m_isEditable = true;
           }
        }
        private void SwitchDynamicButtonStates(DataTemplate thisDataTemplate, ContentPresenter thisContentPresenter)
        {
           Button tempEdit = (Button)thisDataTemplate.FindName("edit", thisContentPresenter);
           Button tempCommit = (Button)thisDataTemplate.FindName("commit", thisContentPresenter);
           Button tempRun = (Button)thisDataTemplate.FindName("run", thisContentPresenter);
           Button tempRemove = (Button)thisDataTemplate.FindName("remove", thisContentPresenter);
           if (m_isEditable)
           {
              if (tempEdit != null) tempEdit.Visibility = Visibility.Hidden;
              if (tempCommit != null) tempCommit.Visibility = Visibility.Hidden;
              if (tempRun != null) tempRun.Visibility = Visibility.Visible;
              if (tempRemove != null) tempRemove.Visibility = Visibility.Visible;
           }
           else
           {
              if (tempEdit != null) tempEdit.Visibility = Visibility.Hidden;
              if (tempEdit != null) tempCommit.Visibility = Visibility.Hidden;
              if (tempEdit != null) tempRun.Visibility = Visibility.Visible;
              if (tempEdit != null) tempRemove.Visibility = Visibility.Visible;
           }
        }
        private void SwitchTextBlockStates(DataTemplate thisDataTemplate, ContentPresenter thisContentPresenter)
        {
           TextBlock nameTextBlock = (TextBlock)thisDataTemplate.FindName("ThisListBlock", thisContentPresenter);
           TextBox nameTextBox = (TextBox)thisDataTemplate.FindName("ThisListBox", thisContentPresenter);
           TextBlock descriptionTextBlock = (TextBlock)thisDataTemplate.FindName("OtherListBlock", thisContentPresenter);
           TextBox descriptionTextBox = (TextBox)thisDataTemplate.FindName("OtherListBox", thisContentPresenter);

           if (m_isEditable)
           {
              nameTextBlock.Visibility = Visibility.Visible;
              nameTextBox.Visibility = Visibility.Collapsed;
              descriptionTextBlock.Visibility = Visibility.Visible;
              descriptionTextBox.Visibility = Visibility.Collapsed;
           }
           else
           {
              nameTextBlock.Visibility = Visibility.Collapsed;
              nameTextBox.Visibility = Visibility.Visible;
              descriptionTextBlock.Visibility = Visibility.Collapsed;
              descriptionTextBox.Visibility = Visibility.Visible;
           }
        }
        private childItem FindVisualChild<childItem>(DependencyObject obj) where childItem : DependencyObject
        {
           for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
           {
              DependencyObject child = VisualTreeHelper.GetChild(obj, i);
              if (child != null && child is childItem) return (childItem)child;
              else
              {
                 childItem childOfChild = FindVisualChild<childItem>(child);
                 if (childOfChild != null) return childOfChild;
              }
           }
           return null;
        }
        #endregion

        #region UI Support
        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
           SaveDialogState();
        }
        private void SaveDialogState()
        {
           ThisApplication.thisApp.DialogState.LastSelectedLanguage = m_languageType;
           ThisApplication.thisApp.DialogState.IsTreeView = m_IsTreeView;
        }
        private void RestoreDialogState(DialogState state)
        {
           this.SelectedLanguage = state.LastSelectedLanguage;
           IsTreeView = state.IsTreeView;
        }
        private bool IsTreeView
        {
           set
           {
              if (value == true)
              {
                 Tree.Visibility = Visibility.Visible;
                 FlattenedListBox.Visibility = Visibility.Collapsed;
                 m_IsTreeView = true;
              }
              else
              {
                 Tree.Visibility = Visibility.Collapsed;
                 FlattenedListBox.Visibility = Visibility.Visible;
                 m_IsTreeView = false;
              }
           }
        }
        private void FilterByLanguage(object sender, FilterEventArgs e)
        {
            Script temp = e.Item as Script;
            if ((temp == null) || temp.Collection.ScriptCollectionType.Equals(m_languageType))
            {
                e.Accepted = true;
            }
            else
            {
                e.Accepted = false;
            }
        }
        private void RemoveFilter(object sender, FilterEventArgs e)
        {
            Script temp = e.Item as Script;
            if ((temp == null) || (allBtn.IsChecked==true))
            {
                e.Accepted = false;
            }
            else
            {
                e.Accepted = true;
            }
        }

  
        #endregion

        #region Data
        private bool m_IsTreeView = true;
        private bool m_isEditable = false;
        private Autodesk.Revit.DB.Macros.MacroLanguageType m_languageType = Autodesk.Revit.DB.Macros.MacroLanguageType.Python;
        #endregion


        public void SetupDockablePane(Autodesk.Revit.UI.DockablePaneProviderData data)
        {
            
            data.FrameworkElement = this as FrameworkElement;
            data.InitialState.DockPosition = Autodesk.Revit.UI.DockPosition.Right;
      
        }
    }
}

