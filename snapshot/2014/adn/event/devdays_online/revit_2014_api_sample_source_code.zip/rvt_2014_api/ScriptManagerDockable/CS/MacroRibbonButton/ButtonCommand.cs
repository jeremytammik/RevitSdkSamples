﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB.Macros;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
   /// <summary> 
   /// An abstract class for creating a script command; it implements the Revit 
   /// add-in interface IExternalCommand.
   /// The classes - generated dynamically in runtime - that contain the command  
   /// implementation for each script ribbon button are derived from this class.
   /// </summary>


   //Note -- each macro button needs a pre-defined ButtonCommand subclass.
   //If you increase Constants.MaximumRibbonIcons, add additional subclasses with the name format 'button<buttonNumber>, 
   //e.g. button7 : ButtonCommand, button8 : ButtonCommand...


   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button1 : ButtonCommand 
   {

   }

   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button2 : ButtonCommand
   {

   }

   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button3 : ButtonCommand
   {

   }

   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button4 : ButtonCommand
   {

   }

   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button5 : ButtonCommand
   {

   }


   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public class button6 : ButtonCommand
   {

   }

 
   [Regeneration(RegenerationOption.Manual)]
   [Transaction(TransactionMode.Manual)]
   public abstract class ButtonCommand : IExternalCommand, IExternalCommandAvailability
   {
      public bool IsCommandAvailable(UIApplication applicationData, CategorySet selectedCategories)
      {
         return true;
      }

      public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
      {
        ThisApplication.thisApp.GetMacroAPIUtility().Initialize(commandData.Application);
        Tuple<string, string> macro = ThisApplication.thisApp.GetMacroRibbonButtonManager().GetMappedScript(this.GetType().Name);
        ThisApplication.thisApp.GetMacroAPIUtility().RunMacro(macro.Item1, macro.Item2);
         return Result.Succeeded;
      }
   }
}


