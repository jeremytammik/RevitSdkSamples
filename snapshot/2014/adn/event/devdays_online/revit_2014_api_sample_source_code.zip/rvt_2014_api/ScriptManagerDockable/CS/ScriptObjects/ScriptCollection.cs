﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Windows.Data;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    /// <summary>
    ///A wrapper class for maintaining the information of a RevitAPI MacroModule object 
    ///This class is necessary for handling the functionalities of the Script Manager UI.
    /// </summary>
    public class ScriptCollection
    {

        /// <summary>
        /// Constructs a ScriptCollection object.
        /// </summary>
        /// <param macroName="macroName">A string denoting the macroName of the ScriptCollection object.</param>
        /// <param macroName="type">A string denoting the type of the ScriptCollection object.</param>
        /// <param macroName="moduleDescription">A string denoting what the ScriptCollection is doing.</param>
        public ScriptCollection(string name, Autodesk.Revit.DB.Macros.MacroLanguageType type, string description)
        {
            this.m_name = name;
            this.m_type = type;
            this.m_description = description;
            this.m_iconName = "Resources/" + type + ".png";
        }
        /// <summary>
        /// The macroName of the moduleName.
        /// </summary>
        public string ScriptCollectionName
        {
            get { return m_name; }
        }
        /// <summary>
        /// The macroName of the moduleName.
        /// </summary>
        public string ScriptCollectionIconName
        {
            get { return m_iconName; }
        }
        /// <summary>
        /// The moduleDescription of the moduleName.
        /// </summary>
        public string ScriptCollectionDescription
        {
            get { return m_description; }
            set { m_description = value; }
        }
        /// <summary>
        /// The Macro language type. 
        /// </summary>
        public Autodesk.Revit.DB.Macros.MacroLanguageType ScriptCollectionType
        {
            get { return m_type; }
        }

       #region Data
        private string m_name;
        private Autodesk.Revit.DB.Macros.MacroLanguageType m_type;
        private string m_description;
        private string m_iconName;
       #endregion
    }

    /// <summary>
    /// A class that converts a ScriptCollection object to a string containing the 
    /// ScriptCollection's macroName and moduleDescription. This class is used by the MainWindow
    /// class to bind the sm_ScriptData presented on the parent items of the TreeView to the
    /// aforementioned properties of the ScriptCollection.
    /// </summary>
    [ValueConversion(typeof(ScriptCollection), typeof(string))]
    public class CollectionPropertiesMixer : IValueConverter
    {
        /// <summary>
        /// Converts a ScriptCollection to a string containing the macroName and the
        /// moduleDescription of the ScriptCollection.
        /// </summary>
        /// <param macroName="value">The value produced by the binding source.</param>
        /// <param macroName="targetType">The type of the binding target property.</param>
        /// <param macroName="parameter">The converter parameter to use.</param>
        /// <param macroName="culture">The culture to use in the converter.</param>
        /// <returns>A converted value. If the method returns null, the valid null value is used.</returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is ScriptCollection)
            {
                return (value as ScriptCollection).ScriptCollectionName
                    + "\n" + (value as ScriptCollection).ScriptCollectionDescription;
            }
            return null;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    } 
}
