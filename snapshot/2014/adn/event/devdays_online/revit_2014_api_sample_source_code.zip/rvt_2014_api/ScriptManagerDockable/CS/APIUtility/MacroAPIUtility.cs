﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Navigation;
using System.Windows.Controls.Primitives;
using System.Reflection;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;
using Autodesk.Revit.DB.Macros;
using Autodesk.Revit.UI.Macros;
using System.Collections.Specialized;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{

   public partial class MacroAPIUtility
   {

      public void Initialize(UIApplication uiApplication)
      {
         m_uiApplication = uiApplication;
      }
      public  ModelessCommand ModelessCommand { get { return m_ModelessCommand; } }
      public string AddMacro(MacroLanguageType languageType, out string moduleName, out bool isNewModule, out string macroDescription, out  string moduleDescription)
      {

         isNewModule = false;

         moduleName = languageType.ToString() + Constants.DefaultScriptCollectionName;
         moduleDescription = CreateModuleDescription(moduleName, languageType);
         if (!DoesModuleExist(moduleName))
         {
            AddModule(moduleName, moduleDescription, languageType);
            isNewModule = true;
         }
         else
         {
            moduleDescription = GetAPIModuleDescription(moduleName);
         }

         string defaultMacro = CreateNextNewMacroName(moduleName, languageType, out macroDescription);

         CheckMacroNameDoesNotExist(defaultMacro, moduleName);

         return MacroAPIUtilityInternal.AddMacro(defaultMacro, macroDescription, moduleName, GetSampleMacroText(defaultMacro, languageType), GetMacroManager());

      }
      public bool EditMacro(string macroName, string moduleName)
      {
         CheckMacroNameExists(macroName, moduleName);

         return MacroAPIUtilityInternal.EditMacro(macroName, moduleName, GetUIMacroManager());
      }
      public string RunMacro(string macroName, string moduleName)
      {
         CheckMacroNameExists(macroName, moduleName);

         return MacroAPIUtilityInternal.RunMacro(macroName, moduleName, GetMacroManager());
      }
      public MacroManagerData BuildMacroManagerData()
      {
         MacroManager mgr = GetMacroManager();
         MacroManagerData data = new MacroManagerData();
         List<MacroModuleData> dataList = data.GetModuleDataList();

         foreach (MacroModule module in mgr)
         {
            MacroModuleData moduleData = new MacroModuleData(module.Name, module.Description, module.MacroLanguageType);
            foreach (Macro macro in module)
            {
               moduleData.AddMacro(new MacroData(macro.Name, macro.Description));
            }
            dataList.Add(moduleData);
         }

         return data;
      }

      private bool EditModule(string moduleName)
      {
         CheckModuleNameExists(moduleName);

         return MacroAPIUtilityInternal.EditModule(moduleName, GetUIMacroManager());
      }
      private void RemoveButton(string macroName, string moduleName)
      {

         CheckMacroNameExists(macroName, moduleName);

         string buttonToRemove = ThisApplication.thisApp.GetMacroRibbonButtonManager().GetButtonName(macroName, moduleName);
         if (string.IsNullOrEmpty(buttonToRemove))
         {

            Log.Message("Cannot find button.", 1);
            return;
         }

         ThisApplication.thisApp.GetMacroRibbonButtonManager().AssignButton(buttonToRemove, "", "");
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetButtonText(buttonToRemove, Constants.ButtonNameNone);
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetButtonIcon(buttonToRemove, Constants.DefaultScriptIconFilename);
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetVisibility(buttonToRemove, false);

      }
      public  void AssignSpecificButton(string buttonName,  string macroName, string moduleName, string iconFile)
      {
         if (string.IsNullOrEmpty(buttonName))
         {
            Log.Message("No more buttons available.", 1);
            return;
         }

         //CheckMacroNameExists(macroName, moduleName);

         ThisApplication.thisApp.GetMacroRibbonButtonManager().AssignButton(buttonName, macroName, moduleName);
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetButtonText(buttonName, macroName);
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetVisibility(buttonName, true);
         ThisApplication.thisApp.GetMacroRibbonButtonManager().SetButtonIcon(buttonName, iconFile);
      }
      private  void AssignButton(string macroName, string moduleName, string iconFile)
      {
         string buttonToAssign = ThisApplication.thisApp.GetMacroRibbonButtonManager().GetFirstAvailableButton();
         AssignSpecificButton(buttonToAssign, macroName, moduleName, iconFile);
      }
      private  MacroManager GetMacroManager()
      {
         return MacroManager.GetMacroManager(m_uiApplication.Application);
      }
      private UIMacroManager GetUIMacroManager()
      {
         return UIMacroManager.GetMacroManager(m_uiApplication);
      }
      private  bool DoesModuleExist(string moduleName)
      {
         return MacroAPIUtilityInternal.DoesModuleExist(moduleName, GetMacroManager());
      }
      private bool DoesMacroExist(string macroName, string moduleName)
      {
         CheckModuleNameExists(moduleName);
         return MacroAPIUtilityInternal.DoesMacroExist(macroName, MacroAPIUtilityInternal.GetMacroModule(moduleName, GetMacroManager()));
        
      }
      private int GetNumberOfModules(MacroLanguageType languageType)
      {
         return MacroAPIUtilityInternal.GetNumberOfModules(GetMacroManager(), languageType);
      }
      private int GetNumberOfMacros(string moduleName)
      {
         CheckModuleNameExists(moduleName);
       
            return MacroAPIUtilityInternal.GetNumberOfMacros(MacroAPIUtilityInternal.GetMacroModule(moduleName, GetMacroManager()));

      }
      private string CreateNextNewModuleName(MacroLanguageType langaugeType, out string moduleDescription)
      {
         string moduleName = MacroAPIUtilityInternal.CreateNextNewModuleName(langaugeType, GetMacroManager());
         moduleDescription = CreateModuleDescription(moduleName, langaugeType);
         return moduleName;
      }
      private string CreateNextNewMacroName(string moduleName, MacroLanguageType languageType, out string macroDescription)
      {
         CheckModuleNameExists(moduleName);

         string macroName =  MacroAPIUtilityInternal.CreateNextNewMacroName(MacroAPIUtilityInternal.GetMacroModule(moduleName, GetMacroManager()), languageType);
         macroDescription = CreateMacroDescription(macroName, languageType, moduleName);
         return macroName;
      }
      private  string AddModule(MacroLanguageType macroLanguageType, out string moduleDescription)
      {
         string name = CreateNextNewModuleName(macroLanguageType, out moduleDescription);


         AddModule(name, moduleDescription, macroLanguageType);
         return name;
      }
      private  string AddModule(string moduleName, string moduleDescription, MacroLanguageType languageType)
      {
         CheckModuleNameDoesNotExist(moduleName);

         return  MacroAPIUtilityInternal.AddModule(moduleName, moduleDescription, GetUIMacroManager(), languageType).Name;
       
      }
      private  bool RemoveModule(string moduleName)
      {
         CheckModuleNameExists(moduleName);

         return MacroAPIUtilityInternal.RemoveModule(moduleName, GetUIMacroManager());
      }
      private bool RemoveMacro(string macroName, string moduleName)
      {
         CheckMacroNameExists(macroName, moduleName);

         return MacroAPIUtilityInternal.RemoveMacro(macroName, moduleName, GetMacroManager());
      }
      private  string AddMacro(string moduleName, out string macroDescription)
      {
         MacroLanguageType languageType = GetModuleLanguageType(moduleName);
         string defaultMacro = CreateNextNewMacroName(moduleName, languageType, out macroDescription);

         CheckMacroNameDoesNotExist(defaultMacro, moduleName);


         
         return MacroAPIUtilityInternal.AddMacro(defaultMacro, macroDescription, moduleName, GetSampleMacroText(defaultMacro, languageType), GetMacroManager());
      }
      private string GetAPIModuleDescription(string moduleName)
      {
         CheckModuleNameExists(moduleName);
         return MacroAPIUtilityInternal.GetMacroModule(moduleName, GetMacroManager()).Description;
      }


      #region Text building helpers
      private static string GetSampleMacroText(string macroName, MacroLanguageType languageType)
      {
         switch (languageType)
         {
            case MacroLanguageType.CSharp:
               return string.Format(Constants.DefaultCSharpMacroText, languageType.ToString(), macroName);
            case MacroLanguageType.Python:
               return string.Format(Constants.DefaultPythonMacroText, languageType.ToString(), macroName);
            case MacroLanguageType.Ruby:
               return string.Format(Constants.DefaultRubyMacroText, languageType.ToString(), macroName);
            case MacroLanguageType.VBNet:
               return string.Format(Constants.DefaultVbMacroText, languageType.ToString(), macroName);
            default:
               return "";
         }
      }
      private MacroLanguageType GetModuleLanguageType(string moduleName)
      {

         CheckModuleNameExists(moduleName);

         return MacroAPIUtilityInternal.GetMacroModule(moduleName, GetMacroManager()).MacroLanguageType;
      }

      private static string CreateMacroDescription(string macroName, MacroLanguageType languageType, string moduleName)
      {
         return "Script " + macroName + " of collection " + moduleName;
      }
      private static string CreateModuleDescription(string moduleName, MacroLanguageType languageType)
      {
         return "Module " + moduleName + " (" + languageType.ToString() + ")";
      }
      #endregion

      #region Exception helpers
      private void CheckMacroNameExists(string macroName, string moduleName)
      {
         if (!DoesMacroExist(macroName, moduleName))
            throw new ArgumentException(Constants.ExceptionScriptNotFoundMessage, macroName + ", " + moduleName);
      }

      private void CheckModuleNameExists(string moduleName)
      {
         if (!DoesModuleExist(moduleName))
            throw new ArgumentException(Constants.ExceptionScriptCollectionNotFoundMessage, moduleName);
      }


      private void CheckMacroNameDoesNotExist(string macroName, string moduleName)
      {
         if (DoesMacroExist(macroName, moduleName))
            throw new ArgumentException(Constants.ExceptionScriptAlreadyExistsMessage, macroName + ", " + moduleName);
      }

      private void CheckModuleNameDoesNotExist(string moduleName)
      {
         if (DoesModuleExist(moduleName))
            throw new ArgumentException(Constants.ExceptionScriptCollectionAlreadyExists, moduleName);
      }


      #endregion

      #region Data
      private Autodesk.Revit.UI.UIApplication m_uiApplication;
      private ModelessCommand m_ModelessCommand = new ModelessCommand();
      #endregion

   }
}
