﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Configuration;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    /// <summary>
    /// A class that implements the ObservableCollection interface 
    /// and creates a collection of scripts. This is the main dataSource to 
    /// which the user interface components (BoxList and TreeView) bind to.
    /// </summary>
    public class ScriptData : ObservableCollection<Script>
    {
        public ScriptData() 
        {
        }
        public Script GetScript(string macroName, string moduleName)
        {
           foreach (Script script in this)
           {
              if ((script.ScriptName == macroName)  && (script.Collection.ScriptCollectionName == moduleName))
                 return script;
           }
           return null;
        }
        public bool DoesCollectionExist(string collectionName) 
        {
            return m_nameToCollection.ContainsKey(collectionName);
        }
        public ScriptCollection GetCollection(string collectionName) 
        {
           if (!DoesCollectionExist(collectionName))
              throw new ArgumentException(Constants.ExceptionScriptCollectionNotFoundMessage, collectionName);

           return m_nameToCollection[collectionName];
        }
        public void AddCollection(ScriptCollection collection)
        {
           if (DoesCollectionExist(collection.ScriptCollectionName))
              throw new ArgumentException(Constants.ExceptionScriptCollectionAlreadyExists, collection.ScriptCollectionName);
          m_nameToCollection.Add(collection.ScriptCollectionName, collection);

        }
        public void RemoveCollection(string collectionName)
        {
           if (!DoesCollectionExist(collectionName))
              throw new ArgumentException(Constants.ExceptionScriptCollectionNotFoundMessage, collectionName);
           m_nameToCollection.Remove(collectionName);
        }
        public void InitializeData(MacroManagerData macroManagerData)
        {
            // NOTE: 
            // ScriptData is an ObservableCollection of Scripts; each Script maintains a series of
            // among which the ScriptCollection it belongs to. Grouping ScriptData for the TreeView 
            // display is handled by wrapping ScriptData with a CollectionViewSource 
            // (instantiated in MainWindow.xaml) and setting the ScriptCollection as the grouping 
            // property.That means however that if a Module contains no Macros then it will have no 
            // presence in the ObservableCollection of Scripts. To work around that when we initialize
            // ScriptData, we add a dummy Script that is set be invisible.

            bool isLoaded = true;
     
            isLoaded = false;
            

            foreach (MacroModuleData macroModuleData in macroManagerData.GetModuleDataList())
            {
                int macrosCounter = 0;
                // we wrap each MacroModule with a ScriptCollection object
                ScriptCollection scriptCollection = new ScriptCollection(macroModuleData.Name,
                    macroModuleData.LanguageType, macroModuleData.Description);

                this.AddCollection(scriptCollection);

                foreach (MacroData  macroData in macroModuleData.GetMacroDataList())
                {
                    macrosCounter++;
                    Script tempScript;
                    //if is the first time the user launches the manager, the config is not loaded
                    if (!isLoaded) 
                    {
                       tempScript = new Script(macroData.Name, macroData.Description,
                            scriptCollection, null, true, false, macroModuleData.LanguageType.ToString());
                    }
                    else
                    {
                        // the iconName and the hasButton property are only stored in the config file
                       string tempIconName = "";
                        bool hasButton = true;
                        // we wrap each Macro with a Script object
                        tempScript = new Script(macroData.Name, macroData.Description,
                            scriptCollection, tempIconName, true, hasButton, macroModuleData.LanguageType.ToString());
                    }
                    this.Add(tempScript);
                }
  

                // if no macros are contained in the Module we add a dummy Script
                if (macrosCounter == 0)
                {
                    this.Add(new Script("VirtualScript", "This is a virtual script",
                        scriptCollection, null, false, false, ""));
                }
         
            }
        }

       #region Data
        // a dictionary to map the collection macroName to the default ScriptCollection
        // object for each programming language type.
        private Dictionary<string, ScriptCollection> m_nameToCollection = new Dictionary<string, ScriptCollection>();

       #endregion
    }
}
