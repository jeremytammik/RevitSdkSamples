﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    class Constants
    {
        public const string DefaultIcon = "Resources/new.ico";
        public const string DefaultDescription = "Double-click to add moduleDescription";
        public const string DefaultScriptCollectionName = "Default";
        public const string VirtualScriptName = "VirtualScript";
        public const string ApplicationName = "ScriptManagerDockable";
        public const string ScriptingTabName = "Scripting";
        public const string ScriptingPanelName = "Revit Scripts";
        public const string DefaultCSharpMacroText = "TaskDialog.Show(\"ScriptManager\", \"{0} Macro, Hello from {1}.\");";
        public const string DefaultPythonMacroText = "TaskDialog.Show(\"ScriptManager\", \"{0} Macro, Hello from {1}.\")";
        public const string DefaultRubyMacroText = "TaskDialog.Show(\"ScriptManager\", \"{0} Macro, Hello from {1}.\")";
        public const string DefaultVbMacroText = "TaskDialog.Show(\"ScriptManager\", \"{0} Macro, Hello from {1}.\")";
        public const string DefaultScriptIconFilename = "default.png";
        public const string ExceptionScriptNotFoundMessage = "Script not found.";
        public const string ExceptionScriptAlreadyExistsMessage = "Script already exists.";
        public const string ButtonNameNone = "<none>";
        public const string ExceptionScriptCollectionNotFoundMessage = "ScriptCollection not found.";
        public const string ExceptionScriptCollectionAlreadyExists = "ScriptCollection already exists.";
        public const int MaximumRibbonIcons = 6;  //Note, if you change this value, you must also add additional command subclasses in ButtonCommand.cs
        public static XName xnButton = "button";
        public static XName xnName = "buttonName";
        public static XName xnMacroName = "macroName";
        public static XName xnModuleName = "moduleName";
        public static XName xnIcon = "icon";
        public static XName xnConfiguration = "configuration";
    }
}
