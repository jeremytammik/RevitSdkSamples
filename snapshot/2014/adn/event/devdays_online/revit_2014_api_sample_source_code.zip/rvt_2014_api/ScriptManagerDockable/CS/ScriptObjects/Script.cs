﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    /// <summary>
    /// A wrapper class for maintaining the information of a RevitAPI Macro object.
    /// This class is necessary for handling the functionalities of the Script Manager UI.
    /// </summary>
    public class Script
    {
        /// <summary>
        /// Constructs a Script object.
        /// </summary>
        /// <param macroName="scriptName">A string denoting the macroName of the script.</param>
        /// <param macroName="moduleDescription">A string denoting the moduleDescription of what the script is doing.</param>
        /// <param macroName="collection">A ScriptCollection object denoting to which collection the script
        /// belongs to.</param>
        /// <param macroName="iconName">A string denoting the macroName of the icon to be placed on the script 
        /// tab/button in the MacroManager UI.</param>
        /// <param macroName="isVisible">A boolean value indicating whether the specific script should be visible
        /// or not in the MacroManager UI.</param>
        /// <param macroName="hasButton"></param>
        /// <param macroName="language"></param>
        public Script(string scriptName, string description, ScriptCollection collection, 
            string iconName, bool isVisible, bool hasButton, string language)
        {
            this.m_name = scriptName;
            this.m_collection = collection;

            if (description == null || description == "") this.m_description = Constants.DefaultDescription;
            else this.m_description = description;

         //   if (iconName == null) this.m_iconName = Constants.DefaultIcon;
         //   else this.m_iconName = iconName;

            this.m_isVisible = isVisible;
            this.m_hasButton = hasButton;
            this.m_language = collection.ScriptCollectionType;
            this.m_languageIconName = "Resources/" + m_language.ToString() + ".png";
        }
        /// <summary>
        /// The macroName of the script.
        /// </summary>
        public string ScriptName
        {
            get { return m_name; }
            set { m_name = value; }
        }
        /// <summary>
        /// The moduleDescription of what the script is doing.
        /// </summary>
        public string Description
        {
            get { return m_description; }
            set { m_description = value; }
        }
        /// <summary>
        /// The ScriptCollection object the script belongs to.
        /// </summary>
        public ScriptCollection Collection
        {
            get { return m_collection; }
        }
        /// <summary>
        /// The macroName of the ScriptCollection object the script belongs to.
        /// </summary>
        public Autodesk.Revit.DB.Macros.MacroLanguageType Language
        {
            get { return m_language; }
        }
        /// <summary>
        /// The macroName of the icon that represents the script's programming language.
        /// </summary>
        public string LanguageIconName
        {
            get { return m_languageIconName; }
        }
        public bool HasButton
        {
            get { return m_hasButton; }
            set { m_hasButton = value; }
        }
        /// <summary>
        /// Visibility of the script in the MacroManager UI.
        /// </summary>
        public bool isVisible
        {
            get { return m_isVisible; }
            set { m_isVisible = value; }
        }
        /// <summary>
        /// The macroName of the icon that represents the script.
        /// </summary>
        public string IconName
        {
            get { return m_iconName; }
            set { m_iconName = value; }
        }

        #region Data
        private string m_name;
        private string m_description;
        private ScriptCollection m_collection;
        private string m_iconName;
        private bool m_isVisible;
        private bool m_hasButton;
        private Autodesk.Revit.DB.Macros.MacroLanguageType m_language;
        private string m_languageIconName;
        #endregion
    }
}
