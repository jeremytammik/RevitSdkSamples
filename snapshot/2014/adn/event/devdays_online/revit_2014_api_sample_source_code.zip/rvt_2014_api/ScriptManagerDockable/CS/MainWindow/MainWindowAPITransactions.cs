﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//


using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Navigation;
using System.Windows.Controls.Primitives;
using System.Reflection;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
   public partial class MainWindow : Page
   {
      #region Modeless command handling
      /// <summary>
      /// Set command data in the UI, and set the dialog to Wait/Disabled until the IExternalApplication Idle()
      /// handler can process the command and re-enable the dialog.
      /// </summary>
      private void MakeRequest(ModelessCommandData commandData)
      {
         ThisApplication.thisApp.GetMacroAPIUtility().ModelessCommand.Make(commandData);
         m_exEvent.Raise();
         DozeOff();
      }
      private void EnableCommands(bool status)
      {
         if (status == false)
            this.Cursor = Cursors.Wait;
         else
            this.Cursor = Cursors.Arrow;
      }
      /// <summary>
      ///   DozeOff -> disable all controls (but the Exit button)
      /// </summary>
      private void DozeOff()
      {
         EnableCommands(false);
      }
      /// <summary>
      ///   WakeUp -> enable all controls -- called by the Idle() handler of the IExternalApplication after a command is complete.
      /// </summary>
      public void WakeUp()
      {
         EnableCommands(true);
      }
      #endregion

      #region UI Support
      public void UpdateUI(ModelessCommandData data)
      {
         switch (data.CommandType)
         {
            case ModelessCommandType.ReturnRemoveMacro:
               this.GetScriptData().Remove(this.GetScriptData().GetScript(data.MacroName, data.ModuleName));
               break;

            case ModelessCommandType.ReturnRemoveModule:
               {
                  List<Script> scriptsToRemove = new List<Script>();
                  foreach (Script script in this.GetScriptData())
                  {
                     if (script.Collection.ScriptCollectionName == data.ModuleName)
                     {
                        scriptsToRemove.Add(script);
                     }
                  }
                  foreach (Script script in scriptsToRemove)
                  {
                     this.GetScriptData().Remove(script);
                  }
                  this.GetScriptData().RemoveCollection(data.ModuleName);

                  break;
               }

            case ModelessCommandType.ReturnAddModule:
               {
                  MainWindow.AddScriptCollection(data.ModuleName, data.ModuleDescription, data.LanguageType, this.GetScriptData());
                  break;
               }

            case ModelessCommandType.ReturnAddMacro:
               {
                  if ((data.IsNewModule))
                     MainWindow.AddScriptCollection(data.ModuleName, data.ModuleDescription, data.LanguageType, this.GetScriptData());

                  Script tempScript = new Script(data.MacroName, data.MacroDescription, this.GetScriptData().GetCollection(data.ModuleName), null, true, false, data.LanguageType.ToString());
                  this.GetScriptData().Add(tempScript);

                  break;
               }
            case ModelessCommandType.ReturnRunMacro:
               {
                   if (!(string.IsNullOrEmpty(data.MacroReturnException)))
                       Log.Message(data.MacroReturnException, 1);
                   break;
               }
            default:
               break;
         }
      }
      private static string AddScriptCollection(string name, string description, Autodesk.Revit.DB.Macros.MacroLanguageType languageType, ScriptData scriptData)
      {
         ScriptCollection scriptCollection = new ScriptCollection(name, languageType, description);
         scriptData.AddCollection(scriptCollection);
         //UNLESS THE MODULE TEMPLATE HAS ITS SAMPLE METHODS UNCOMMENTED WE NEED TO
         //CREATE A DUMMY SCRIPT SO THAT IT CAN BE STORED IN THE SCRIPTDATA COLLECTION
     
            Script dummyScript = new Script(Constants.VirtualScriptName, "This is a virtual script",
                        scriptCollection, null, false, false, "");
            scriptData.Add(dummyScript);
         
         return name;
      }
      #endregion

      #region Button handlers
      private void AddScriptButtonClick(object sender, RoutedEventArgs e)
      {
         //WHEN THE TREE IS DISPLAYED
         if (m_IsTreeView)
         {

            int index = Tree.Items.IndexOf(Tree.SelectedItem);
            if (index != -1)  //PARENT CURRENTLY SELECTED
            {
               CollectionViewGroup groupObject = (CollectionViewGroup)Tree.SelectedItem;
               ScriptCollection selectedCollection = (ScriptCollection)groupObject.Name;
               MakeAddScriptRequest(this.SelectedLanguage, selectedCollection);
            }
            else
            {
              MakeAddScriptRequest(this.SelectedLanguage);
            }
         }
         else
         {
            if (allBtn.IsChecked == true)
               Log.Message("You need to have a programming language selected.", 1);
            else
            {
               MakeAddScriptRequest(this.SelectedLanguage);
            }
         }
      }
      private void AddFolderButtonClick(object sender, RoutedEventArgs e)
      {
         if (this.allBtn.IsChecked == true)
         {
            Log.Message("Select Language.", 1);
         }
         MakeAddScriptCollectionRequest(this.SelectedLanguage);
      }
      private void RemoveButtonClick(object sender, RoutedEventArgs e)
      {
         try
         {
            if (m_IsTreeView)
            {
               // the index of the selected item shows if the parent or the child 
               // of the TreeView is selected
               int index = Tree.Items.IndexOf(Tree.SelectedItem);
               if (index != -1)  //PARENT CURRENTLY SELECTED
               {
                  CollectionViewGroup groupObject = (CollectionViewGroup)Tree.SelectedItem;
                  ScriptCollection selectedCollection = (ScriptCollection)groupObject.Name;
                  MakeDeleteRequest(selectedCollection);

               }
               else //CHILD CURRENTLY SELECTED
               {
                  Script script = Tree.SelectedValue as Script;
                  if (script == null)
                  {
                     Log.Message("Null selection", 1);
                     return;
                  }
                  MakeDeleteRequest(script);
               }
            }
            else
            {
               Script thisScript = (Script)FlattenedListBox.SelectedItem;
               MakeDeleteRequest(thisScript);
            }
         }
         catch (Exception ex)
         {
            Log.Message("Error removing macro or moduleName: " + ex.Message, 1);
         }
      }
      private void RunButtonClick(object sender, RoutedEventArgs e)
      {
         try
         {
            Script script; 
            if (m_IsTreeView)
            {
               script = Tree.SelectedValue as Script;
               if (script == null)
               {
                  Log.Message("Null selection", 1);
                  return;
               }
            }
            else
            {
               script = (Script)FlattenedListBox.SelectedItem;
            }
            MakeRunRequest(script);
         }
         catch (Exception ex)
         {
            Log.Message("Error running macro: " + ex.Message, 1);
         }
      }
      private void EditButtonClick(object sender, RoutedEventArgs e)
      {
         try
         {
            Script script; 
            if (m_IsTreeView)
            {
               // the index of the selected item shows if the parent or the child 
               // of the TreeView is selected
               int index = Tree.Items.IndexOf(Tree.SelectedItem);
               if (index != -1)  //PARENT CURRENTLY SELECTED
               {
                  CollectionViewGroup groupObject = (CollectionViewGroup)Tree.SelectedItem;
                  ScriptCollection selectedCollection = (ScriptCollection)groupObject.Name;
                  MakeEditRequest(selectedCollection);
               }
               else //CHILD CURRENTLY SELECTED
               {
                  script = Tree.SelectedValue as Script;
                  if (script == null)
                  {
                     Log.Message("Null selection", 1);
                     return;
                  }
                  MakeEditRequest(script);
               }
            }
            else
            {
               Script thisScript = (Script)FlattenedListBox.SelectedItem;
               MakeEditRequest(thisScript);
            }
         }
         catch (Exception ex)
         {
            Log.Message("Error editing macro: " + ex.Message, 1);
         }
      }
      private void ExportButtonClick(object sender, RoutedEventArgs e)
      {
         try
         {
            if (m_IsTreeView)
            {
               object selectedValue = Tree.SelectedValue;
               if (selectedValue == null)
               {
                  Log.Message("Null selection", 1);
                  return;
               }
               Script script = selectedValue as Script;
               if (script == null)
               {
                  Log.Message("You can only promote individual scripts to the ribbon, not entire script collections.", 1);
                  return;
               }
               if (ThisApplication.thisApp.GetMacroRibbonButtonManager().IsScriptMapped(script))
               {
                  Log.Message("Script already assigned to button.", 1);
                  return;
               }
               script.IconName = FileUtility.GetSelectedIconFile();
               MakeAddToRibbonRequest(script);

            }
            else
            {
               Script thisScript = (Script)FlattenedListBox.SelectedItem;
               if (ThisApplication.thisApp.GetMacroRibbonButtonManager().IsScriptMapped(thisScript))
               {
                  Log.Message("Script already assigned to button.", 1);
                  return;
               }
               thisScript.IconName = FileUtility.GetSelectedIconFile();
               MakeAddToRibbonRequest(thisScript);
            }
         }
         catch (Exception ex)
         {
            Log.Message("Error adding macro to ribbon: " + ex.Message, 1);
         }
      }
      private void RemoveFromRibbonButtonClick(object sender, RoutedEventArgs e)
      {
         try
         {
            if (m_IsTreeView)
            {
               object selectedValue = Tree.SelectedValue;
               if (selectedValue == null)
               {
                  Log.Message("Null selection", 1);
                  return;
               }
               Script script = selectedValue as Script;

               if (script == null)
               {
                  Log.Message("You can only remove individual scripts from the ribbon, not entire script collections.", 1);
                  return;
               }

               MakeRemoveFromRibbonRequest(script);
            }
            else
            {
               Script thisScript = (Script)FlattenedListBox.SelectedItem;
               try
               {
                  MakeRemoveFromRibbonRequest(thisScript);
               }
               catch (Exception ex)
               {
                  Log.Message(ex.Message, 1);
               }
            }
         }
         catch (Exception ex)
         {
            Log.Message("Error removing macro from ribbon: " + ex.Message, 1);
         }
      }
      #endregion Button handlers

      #region Data
      // A new handler to handle request posting by the dialog
      private MacroAPIExternalEventHandler m_handler = new MacroAPIExternalEventHandler();

      // External Event for the dialog to use (to post requests)
      private Autodesk.Revit.UI.ExternalEvent m_exEvent;
      #endregion
   }
}