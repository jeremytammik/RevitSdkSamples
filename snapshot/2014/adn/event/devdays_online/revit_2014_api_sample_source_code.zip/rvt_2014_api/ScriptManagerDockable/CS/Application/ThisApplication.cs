﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Windows.Media.Imaging;
using System.Configuration;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.Attributes;
using System.Text;
using System.Collections.Generic;
using System.Xml.Linq;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
    /// <summary>
    /// Implements the Revit add-in interface IExternalApplication
    /// </summary>
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class ThisApplication : IExternalApplication
    {
       public Result OnShutdown(UIControlledApplication application)
       {
          SaveButtonConfiguration();
          return Result.Succeeded;
       }

       public void CreateAndRegisterDockableWindow(UIApplication application)
       {
          m_dockablePaneId = new DockablePaneId(new Guid("{9CF2E804-CE56-4657-9FE7-43BCE73522C5}"));
          InitializeWindow(application);
          application.RegisterDockablePane(m_dockablePaneId, "ScriptManagerDockable", m_mainWindow as IDockablePaneProvider);
       }

       public void ShowPage()
       {
          m_uiControlledApp.GetDockablePane(m_dockablePaneId).Show();
       }
       public Result OnStartup(UIControlledApplication application)
       {

          thisApp = this;
          m_macroAPIUtility = new MacroAPIUtility();
          m_uiControlledApp = application;
          application.Idling += new EventHandler<Autodesk.Revit.UI.Events.IdlingEventArgs>(application_Idling);
           // Create a custom ribbon tab  
          String tabName = Constants.ScriptingTabName;
          application.CreateRibbonTab(tabName);

          RibbonPanel panel = application.CreateRibbonPanel(tabName, Constants.ScriptingPanelName);
          // add the button that launches the Script Manager window
          AddRunButton(panel);
          panel.AddSeparator();


          m_macroRibbonButtonManager = new MacroRibbonButtonManager(panel);
          m_macroRibbonButtonManager.Initialize();

          return Result.Succeeded;
       }

    

       void application_Idling(object sender, Autodesk.Revit.UI.Events.IdlingEventArgs e)
       {
          UIApplication app = sender as UIApplication;
          if (m_Initialized)
          {
             m_uiControlledApp.Idling -= new EventHandler<Autodesk.Revit.UI.Events.IdlingEventArgs>(application_Idling);
             return;
          }
          CreateAndRegisterDockableWindow(app);
          m_Initialized = true;
       }

 
       public MacroRibbonButtonManager GetMacroRibbonButtonManager()
       {
          return m_macroRibbonButtonManager;
       }

       public MainWindow GetMainWindow()
       {
          return m_mainWindow;
       }
       public DialogState DialogState
       {
          get { return m_DialogState; }
       }
       public MacroAPIUtility GetMacroAPIUtility() { return m_macroAPIUtility; }
       private void SaveButtonConfiguration()
       {
          XDocument doc = new XDocument();

          XElement element = new XElement(Constants.xnConfiguration);
          doc.Add(element);
          foreach (string buttonName in thisApp.GetMacroRibbonButtonManager().GetButtonNames())
          {
             XElement xButton = new XElement(Constants.xnButton);
             xButton.SetAttributeValue(Constants.xnName, buttonName);
             Tuple<string, string> macroFromButton = thisApp.GetMacroRibbonButtonManager().GetMappedScript(buttonName);
             xButton.SetAttributeValue(Constants.xnMacroName, macroFromButton.Item1);
             xButton.SetAttributeValue(Constants.xnModuleName, macroFromButton.Item2);
             xButton.SetAttributeValue(Constants.xnIcon, thisApp.GetMacroRibbonButtonManager().GetButtonIcon(buttonName));
             element.Add(new XElement(xButton));
          }
           FileUtility.WriteButtonConfigXDocument(doc);

          
       }
       private void InitializeWindow(Autodesk.Revit.UI.UIApplication application)
        {
           ThisApplication.thisApp.GetMacroAPIUtility().Initialize(application);
           //CREATE THE DATA SOURCE WHERE THE UI WILL BE BOUND TO
           ScriptData scriptData = new ScriptData();
           scriptData.InitializeData(ThisApplication.thisApp.GetMacroAPIUtility().BuildMacroManagerData());
           m_mainWindow = new MainWindow(scriptData);
        }
       private static Type LoadsScriptCommand(string className, string scriptInfo,
            string dllFolder, string dllname, ModuleBuilder moduleBuilder)
        {
            TypeBuilder newCommandMacroClass = moduleBuilder.DefineType(className,
                                                        TypeAttributes.Class | TypeAttributes.Public,
                                                        typeof(ButtonCommand));

            // add RegenerationAttribute to type
            var regenerationConstrutorInfo = typeof(RegenerationAttribute).GetConstructor(new Type[] { typeof(RegenerationOption) });
            var regenerationAttributeBuilder = new CustomAttributeBuilder(regenerationConstrutorInfo, new object[] { RegenerationOption.Manual });
            newCommandMacroClass.SetCustomAttribute(regenerationAttributeBuilder);

            // add TransactionAttribute to type
            var transactionConstructorInfo = typeof(TransactionAttribute).GetConstructor(new Type[] { typeof(TransactionMode) });
            var transactionAttributeBuilder = new CustomAttributeBuilder(transactionConstructorInfo, new object[] { TransactionMode.Manual });
            newCommandMacroClass.SetCustomAttribute(transactionAttributeBuilder);

            // call base constructor with script path
            var ci = typeof(ButtonCommand).GetConstructor(new[] { typeof(string) });

            var constructorBuilder = newCommandMacroClass.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, new Type[0]);
            var gen = constructorBuilder.GetILGenerator();
            gen.Emit(OpCodes.Ldarg_0);
            gen.Emit(OpCodes.Ldstr, scriptInfo);
            gen.Emit(OpCodes.Call, ci);
            gen.Emit(OpCodes.Nop);
            gen.Emit(OpCodes.Ret);
            return newCommandMacroClass.CreateType();
        }
       private string FormatName(String name)
        {
            int maxSpaces = 12;
            if (name.Length < maxSpaces) return name.PadLeft(maxSpaces - name.Length) + "...";
            else return name.Substring(0, maxSpaces) + "...";
        }
       private bool IsAButton(AppSettingsSection scriptSettings, string key)
        {
            //the substring up to the first "," position indicates if the  
            //script is present as a button on the ribbon
            string value = scriptSettings.Settings[key].Value;
            string[] valueArray = value.Split(',');
            if (valueArray[0].Equals("True")) return true;
            return false;
        }
       private void AddRunButton(RibbonPanel panel)
        {
            PushButtonData pushButtonData = new PushButtonData("Scripts", "Show ScriptManager",
                FileUtility.GetAssemblyFullName(), "Revit.SDK.Samples.ScriptManagerDockable.CS.ExternalCommandScriptManager");
            pushButtonData.LargeImage = new BitmapImage(new Uri(FileUtility.GetApplicationResourcePath() + "macros_manage.png"));
           
            PushButton pushButton = panel.AddItem(pushButtonData) as PushButton;

            pushButton.AvailabilityClassName = "Revit.SDK.Samples.ScriptManagerDockable.CS.ExternalCommandScriptManager";


            PushButtonData pushButtonDataNewScript = new PushButtonData("NewScript", "Create New Script",
     FileUtility.GetAssemblyFullName(), "Revit.SDK.Samples.ScriptManagerDockable.CS.ExternalCommandNewScript");
            pushButtonDataNewScript.LargeImage = new BitmapImage(new Uri(FileUtility.GetApplicationResourcePath() + "macros_new.png"));

            PushButton pushButtonNewScript = panel.AddItem(pushButtonDataNewScript) as PushButton;

            pushButtonNewScript.AvailabilityClassName = "Revit.SDK.Samples.ScriptManagerDockable.CS.ExternalCommandNewScript";

        }
       #region Data
       private bool m_Initialized = false;
       private UIControlledApplication m_uiControlledApp;
        private  DialogState m_DialogState = new DialogState(Autodesk.Revit.DB.Macros.MacroLanguageType.Python, true);
        MainWindow m_mainWindow;
        internal static ThisApplication thisApp = null;
        private MacroAPIUtility m_macroAPIUtility;
        private MacroRibbonButtonManager m_macroRibbonButtonManager;
        Autodesk.Revit.UI.DockablePaneId m_dockablePaneId;
       #endregion

    }
}

