﻿//
// (C) Copyright 2003-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Revit.SDK.Samples.ScriptManagerDockable.CS
{
   public class MacroManagerData
   {
      public MacroManagerData()
      {
         m_ModuleDataList = new List<MacroModuleData>();
      }
      public List<MacroModuleData> GetModuleDataList() { return m_ModuleDataList; }

      #region Data
      private List<MacroModuleData> m_ModuleDataList;
      #endregion
   }

   public class MacroModuleData
   {
      public MacroModuleData(string moduleName, string moduleDescription, Autodesk.Revit.DB.Macros.MacroLanguageType languageType)
      {
         m_Name = moduleName;
         m_Description = moduleDescription;
         m_languageType = languageType;
         m_MacroDataList = new List<MacroData>();
      }
      public void AddMacro(MacroData data)
      {

         m_MacroDataList.Add(data);
      }

      public List<MacroData> GetMacroDataList() { return m_MacroDataList; }

      public string Name
      {
         get { return m_Name; }
      }

      public string Description
      {
         get { return m_Description; }
      }

      public Autodesk.Revit.DB.Macros.MacroLanguageType LanguageType
      {
         get { return m_languageType; }
      }

      #region Data
      private string m_Name;
      private string m_Description;
      private Autodesk.Revit.DB.Macros.MacroLanguageType m_languageType;
      private List<MacroData> m_MacroDataList;
      #endregion
   }

   public class MacroData
   {
      public MacroData(string macroName, string macroDescription)
      {

         m_Name = macroName;
         m_Description = macroDescription;
      }

      public string Name
      {
         get { return m_Name; }
      }

      public string Description
      {
         get { return m_Description; }
      }

      #region Data
      private string m_Name;
      private string m_Description;
      #endregion
   }
}
