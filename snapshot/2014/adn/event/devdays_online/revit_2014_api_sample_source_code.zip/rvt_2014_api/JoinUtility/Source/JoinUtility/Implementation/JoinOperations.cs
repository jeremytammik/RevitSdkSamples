﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 10/29/2012
 * Time: 11:57 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI.Macros;
using System.Diagnostics;

namespace JoinUtility
{
	/// <summary>
	/// A class to hold an instance of the current UIApplication
	///            get the current UIDocument and DB.Document
	///            perform view creation, query, and manipulation operations
	/// </summary>
	public class JoinOperations
	{
	
		#region Constructor
		/// <summary>
		/// Store the ApplicationEntryPoint, which has the same interface as UIApplication
		/// </summary>
		/// <param name="uiApplication"></param>
		public JoinOperations(ApplicationEntryPoint  uiApplication)
			{
				if (uiApplication == null)
					throw new ArgumentNullException("uiApplication");
				m_uiApplication = uiApplication;
			}
		#endregion
		  

    public void JoinTwoColumns(Element c1, Element c2)
		{
			Transaction t = new Transaction(ThisApplication.DocumentUtility.Doc(), "Join");
			t.Start();
			try 
			{
			JoinGeometryUtils.JoinGeometry(ThisApplication.DocumentUtility.Doc(), c1, c2);
			t.Commit();
			}
			catch (Exception ex)
			{
				t.RollBack();
				throw ex;
			}
	
		}
		
		public void UnJoinTwoColumns(Element c1, Element c2)
		{
			Transaction t = new Transaction(ThisApplication.DocumentUtility.Doc(), "UnJoin");
			t.Start();
			try 
			{
				JoinGeometryUtils.UnjoinGeometry(ThisApplication.DocumentUtility.Doc(), c1, c2);
				t.Commit();
			}
			catch (Exception ex)
			{
				t.RollBack();
				throw ex;
			}
		}
		

		public void DoesElementCutTarget(Element c1, Element c2)
		{
			bool retval = JoinGeometryUtils.DoesElementCutTarget(ThisApplication.DocumentUtility.Doc(), c1, c2);
			DebugUtility.Message("Does Element Cut Target? " + retval.ToString());
		}
		
		
		public void AreElementsJoined(Element c1, Element c2)
		{
			bool retval = JoinGeometryUtils.AreElementsJoined(ThisApplication.DocumentUtility.Doc(), c1, c2);
			DebugUtility.Message("Are Elements Joined? " + retval.ToString());
		}
		
		public void SwitchJoinOrder(Element c1, Element c2)
		{
			Transaction t = new Transaction(ThisApplication.DocumentUtility.Doc(), "Switch");
			t.Start();
			try 
			{
			 	JoinGeometryUtils.SwitchJoinOrder(ThisApplication.DocumentUtility.Doc(), c1, c2);
			 	t.Commit();
			}
			catch (Exception ex)
			{
				t.RollBack();
				throw ex;
			}
		}
		
		public void GetJoinedElements(Element c1)
		{

			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			sb.Append("Ids: ");
			ICollection<ElementId> ids = JoinGeometryUtils.GetJoinedElements(ThisApplication.DocumentUtility.Doc(), c1);
			foreach (ElementId id in ids)
			 	sb.Append(id.ToString() + ", ");
			 
			DebugUtility.Message(sb.ToString());
		}

    #region Data
		/// <summary>
		/// Store the ApplicationEntryPoint object for quick access to UIDocument, DB.Document, etc...
		/// </summary>
		private ApplicationEntryPoint  m_uiApplication;
		#endregion
	}
}
