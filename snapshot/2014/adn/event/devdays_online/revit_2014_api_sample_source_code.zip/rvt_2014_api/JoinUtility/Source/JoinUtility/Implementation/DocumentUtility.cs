﻿using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI.Macros;
using System.Diagnostics;

namespace JoinUtility
{
  /// <summary>
  /// A Utility class for managing the active document and getting elements and selections from it.
  /// </summary>
  public class DocumentUtility
  {
    public DocumentUtility( ApplicationEntryPoint uiApplication )
    {
      if( uiApplication == null )
        throw new ArgumentNullException( "uiApplication" );
      m_uiApplication = uiApplication;
    }

    //Document access:  Create high-level wrapper functions like these to avoid updating dozens of instances of:
    //'This.ActiveUIDocument.Document' if underlying code to get your document changes.

    //Tip - DocumentUtility

    /// <summary>
    /// A convenient method to get the active UIDocument
    /// </summary>
    /// <returns></returns>
    public UIDocument UiDoc()
    {
      return m_uiApplication.ActiveUIDocument;
    }

    //Tip - DocumentUtility

    /// <summary>
    /// A convenient method to get the active DB.Document
    /// </summary>
    /// <returns></returns>
    public Document Doc()
    {
      if( UiDoc() == null )
        return null;
      else
        return UiDoc().Document;
    }

    /// <summary>
    /// Gets an element of any Element-derived class by name.
    /// </summary>
    public RevitElement GetElementByName<RevitElement>( string name ) where RevitElement : Element
    {
      if( string.IsNullOrEmpty( name ) )
        return null;
      FilteredElementCollector fec = new FilteredElementCollector( Doc() );
      fec.OfClass( typeof( RevitElement ) );
      IList<Element> elements = fec.ToElements();
      Element result = null;
      result = GetElementByName( elements, name );
      return result as RevitElement;
    }

    public Element GetPreSelected()
    {
      if( ( UiDoc().Selection == null ) || ( UiDoc().Selection.GetElementIds().Count == 0 ) )
        return null;
      else
        return Doc().GetElement( UiDoc().Selection.GetElementIds().First() );
    }

    public void GetTwoPreSelected( out Element e1, out Element e2 )
    {
      e1 = null;
      e2 = null;
      if( ( UiDoc().Selection == null ) || ( UiDoc().Selection.GetElementIds().Count != 2 ) )
        return;
      else
      {
        e1 = Doc().GetElement( UiDoc().Selection.GetElementIds().First() );
        e2 = Doc().GetElement( UiDoc().Selection.GetElementIds().Last() );
      }
    }

    /// <summary>
    /// Checks to see if a name of a new Element-derived type already exists in the Revit document.
    /// If it does, make ten attempts to add a suffix to the name (using the SuffixBuilder class)
    /// to generate a unique name.
    /// </summary>


    /// <summary>
    /// A quick helper method to check if two double values are nearly equal.
    /// </summary>
    public static bool DoubleEqual( double value1, double value2 )
    {
      double difference = Math.Abs( value1 * .00001 );
      if( Math.Abs( value1 - value2 ) > difference )
        return false;
      else
        return true;
    }

    /// <summary>
    /// Find an element by name from a list of elements.
    /// </summary>
    private Element GetElementByName( IList<Element> elements, string name )
    {
      foreach( Element e in elements )
      {
        System.Diagnostics.Debug.WriteLine( e.Name );
      }
      Element result = null;
      try
      {
        result = elements.First( element => element.Name == name );
      }
      catch( Exception )
      {
        return null;
      }
      return result;
    }

    /// <summary>
    /// Returns true of an element of a given type of a given name exists in the active document, false otherwise.
    /// </summary>
    private bool DoesElementExist<RevitElement>( string name ) where RevitElement : Element
    {
      if( string.IsNullOrEmpty( name ) )
        return false;

      FilteredElementCollector fec = new FilteredElementCollector( Doc() );
      fec.OfClass( typeof( RevitElement ) );
      IList<Element> elements = fec.ToElements();
      Element result = null;
      result = GetElementByName( elements, name );
      if( result == null )
        return false;
      else
        return true;
    }

    #region Data
    /// <summary>
    /// Store the ApplicationEntryPoint object for quick access to UIDocument, DB.Document, etc...
    /// </summary>
    private ApplicationEntryPoint m_uiApplication;
    #endregion
  }
}
