﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 11/14/2012
 * Time: 10:05 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace JoinUtility
{
	/// <summary>
	/// A simple utility class to route all user messages.  If you change your message box style, implementation, or options,
	/// all your code to change is in one place.
	/// </summary>
	public class DebugUtility
	{
		public static void Message(string message)
		{
			Message(message, true, true, true);
		}
		
		public static void Message(string message, bool console, bool debug, bool messageBox)
		{
			if (console)
				Console.WriteLine(Title + " : " + message);
			if (debug)
				System.Diagnostics.Debug.WriteLine(Title  + " : "  + message);
			if (messageBox)
				System.Windows.MessageBox.Show(message, Title);
		}

    public static string Title = "JoinUtility";
	}
}
