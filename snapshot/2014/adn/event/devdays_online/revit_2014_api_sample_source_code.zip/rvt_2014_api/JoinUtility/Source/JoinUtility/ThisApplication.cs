using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace JoinUtility
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.DB.Macros.AddInId("CC4383B1-BC1A-4A1C-A817-D625F30F96CB")]
	/// <summary>
	/// ApplicationEntryPoint derived class containing the top-level entrypoint functions callable from the macro manager.
	/// </summary>
    public partial class ThisApplication
	{		
		public void JoinTwoColumns()
		{
			Element e1, e2;
			ThisApplication.DocumentUtility.GetTwoPreSelected(out e1, out e2);
			try 
			{
				ThisApplication.JoinOperations.JoinTwoColumns(e1, e2);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}
		
		public void AreElementsJoined()
		{
			Element e1, e2;
			ThisApplication.DocumentUtility.GetTwoPreSelected(out e1, out e2);
			try 
			{
				ThisApplication.JoinOperations.AreElementsJoined(e1, e2);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}
		
		public void UnJoinTwoColumns()
		{
			Element e1, e2;
			ThisApplication.DocumentUtility.GetTwoPreSelected(out e1, out e2);
			try 
			{
				ThisApplication.JoinOperations.UnJoinTwoColumns(e1, e2);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}
		
		public void DoesElementCutTarget()
		{
			Element e1, e2;
			ThisApplication.DocumentUtility.GetTwoPreSelected(out e1, out e2);
			try 
			{
				ThisApplication.JoinOperations.DoesElementCutTarget(e1, e2);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}
		
		public void SwitchJoinOrder()
		{
			Element e1, e2;
			ThisApplication.DocumentUtility.GetTwoPreSelected(out e1, out e2);
			try 
			{
				ThisApplication.JoinOperations.SwitchJoinOrder(e1, e2);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}

		public void GetJoinedElements()
		{
			Element e1 = ThisApplication.DocumentUtility.GetPreSelected();
			try 
			{
				ThisApplication.JoinOperations.GetJoinedElements(e1);
			}
			catch (Exception ex)
			{
				DebugUtility.Message( ex.Message);
			}
		}
	
		public static DocumentUtility DocumentUtility
		{
			get 
			{
				if (theApp.ActiveUIDocument == null)
					throw new InvalidOperationException("Document must be active.");
				return sm_documentUtility;
			}
		}
		
		public static JoinOperations JoinOperations
		{
			get 
			{
				return sm_joinOperations;
			}
		}
				
		#region Data
			private  static ThisApplication theApp;
			private  static JoinOperations sm_joinOperations;
			private  static DocumentUtility sm_documentUtility;
		#endregion
		
		#region Startup
		private void Module_Startup(object sender, EventArgs e)
		{
			theApp = this;
			sm_joinOperations = new JoinOperations(this);
			sm_documentUtility = new DocumentUtility(this);
		}

		private void Module_Shutdown(object sender, EventArgs e)
		{
		}
		#endregion
		
		#region Revit Macros generated code
		private void InternalStartup()
		{
			this.Startup += new System.EventHandler(Module_Startup);
			this.Shutdown += new System.EventHandler(Module_Shutdown);
		}
		#endregion	
	}
}