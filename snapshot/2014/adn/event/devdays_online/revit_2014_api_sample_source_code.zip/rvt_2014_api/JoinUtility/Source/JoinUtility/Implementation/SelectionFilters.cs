﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 11/14/2012
 * Time: 9:43 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace ViewLab
{

	/// <summary>
	/// A simple selection filter that can allow any element type.
	/// </summary>
	public class ElementSelectionFilter<RevitElementType> : ISelectionFilter 
	{
		//Tip
		public bool AllowElement(Element element)
    	{
	 		return (element is RevitElementType);
    	}

   	 public bool AllowReference(Reference refer, XYZ point)
    	{
        	return false;
    	} 	 

	}
}
