﻿import clr
clr.AddReferenceByName("RevitAPI.dll");
clr.AddReferenceByName("RevitAPIUI.dll");

from Autodesk.Revit import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Macros import *
from Autodesk.Revit.DB import *
from System.Collections.Generic import List
from math import *

class ThisApplication (ApplicationEntryPoint):
	#creates a default extrusion direction along the z axis
    upVector = XYZ(0,0,1)
    #creates a default reference to the origin point of the XY plane
    #XY plane will be used as the default sketch plane
    origin = XYZ(0,0,0)
    
	#region Revit Macros generated code
    def FinishInitialization(self):
    	ApplicationEntryPoint.FinishInitialization(self)
    	self.InternalStartup()
   
   
    def OnShutdown(self):
    	self.InternalShutdown()
    	ApplicationEntryPoint.OnShutdown(self)
    
    
    def InternalStartup(self):
    	self.Startup()
    
    
    def InternalShutdown(self):
    	self.Shutdown()
    #endregion
    
    
    def Startup(self):
    	self
    	
    	
    def Shutdown(self):
    	self


    def NewRightIsoTrianglePrismFormDemo(self):
        self.NewRightIsoTrianglePrismForm(self.ActiveUIDocument.Document, 1, 3)
    
    def NewRightIsoTrianglePrismDemo(self):
        self.NewRightIsoTrianglePrism(self.ActiveUIDocument.Document, -1, -1)
        
    def NewCylindricalPrismDemo(self):
        self.NewCylindricalPrism(self.ActiveUIDocument.Document, 1, 3)
        
    def NewRectangularPrismDemo(self):
        self.NewRectangularPrism(self.ActiveUIDocument.Document, 2, 4, 3)

    def NewRegularPolygonPrismDemo(self):
        self.NewRegularPolygonPrism(self.ActiveUIDocument.Document, 8, 4, 3)


    def NewRightIsoTrianglePrism(self, doc, legLength, height):
    	"""
    	Creates a prism from an isosceles triangle profile. The prism 
    	profile is created on the xy plane and the extrusion along the 
    	z axis. Negative input values for legLenth will create a profile 
    	line in the -X and -Y direction and negative height will create a 
    	profile line in the -Z direction.
    	
    	Precondition:
    	The input values for legLength and height must not be zero.	
    	
    	Keyword arguments:
    	doc -- the currently active project
        legLength -- the length of the side 
        height -- the height of the prism      
        """
        
        if legLength == 0 : raise ValueError, 'leglength cannot be zero'
        if height == 0 : raise ValueError, 'height cannot be zero'
        
        #define the three points that define the triangle profile
        p0 = XYZ.Zero
        p1 = XYZ(0,legLength,0)
        p2 = XYZ(legLength,0,0)
        
        #Generate lines connecting the 3 points        
        leg1 = Line.CreateBound(p0,p1)
        leg2 = Line.CreateBound(p1,p2)
        hypotenuse = Line.CreateBound(p2,p0)
        
        #add all profile curves to a profile list
        extrusionProfile = CurveArray()
        extrusionProfile.Append(leg1)
        extrusionProfile.Append(leg2)
        extrusionProfile.Append(hypotenuse)
        
        self.ExtrudeProfiles( doc, extrusionProfile, height)
        

    def NewCylindricalPrism(self, doc , radius, height):
    	"""
    	Creates a prism from a cylindrical profile. The prism profile 
    	is created on the xy plane and the extrusion along the z axis. 
    	Negative input value for height will create a profile line in
    	the -Z direction.
    	
    	Precondition:
    	The input value for height must not be zero and the input value
        for radius must be a positive number.   	
    	
    	Keyword arguments:
    	doc -- the currently active project
        radius -- the radius of the circle profile
        height -- the height of the prism      
        """
        
        if radius <= 0 : raise ValueError, 'radius must be a positive number'
        if height == 0 : raise ValueError, 'height cannot be zero'

        #define the circle profile of the prism
        circlePlane = Plane(self.upVector, self.origin)
        circle = Arc.Create(circlePlane, radius, 0, 2*pi) 
        
        #add the circle profile to the profile list
        extrusionProfile = CurveArray()
        extrusionProfile.Append(circle)        
        
        self.ExtrudeProfiles( doc, extrusionProfile, height)


    def NewRegularPolygonPrism(self, doc, numSides, sideLength, height):
    	"""
    	Creates a prism from a regular polygon profile. The prism profile is
    	created on the xy plane and the extrusion along the z axis. Negative 
    	input value for height will create a profile line in the -Z direction.
    	
    	Precondition:
    	The input value for height must not be zero and the value for sideLength 
    	must be a positive number. The input value for numSides must be a positive 
    	number but less than 20.
    	
    	Keyword arguments:
    	doc -- the currently active project
        numSides -- the number of sides of the polygon
        sideLength -- the length of each side
        height -- the height of the prism      
        """
        
        if numSides <= 0 : raise ValueError, 'numSides must be a positive number'
        if numSides > 20 : raise ValueError, 'numSides must be less than 20'
        if sideLength <= 0 : raise ValueError, 'sideLength must be a positive number'
        if height == 0 : raise ValueError, 'height cannot be zero'
        
        # compute the inradius of the polygon (distance from the center of the polygon 
        # to the midpoint of any side)
        inradious = sideLength/(2*tan(2*pi/numSides))   
        # use the inradius to compute the radius of the circle that circumscribes the polygon  
        radius = sqrt(pow(inradious,2)+pow(sideLength/2,2))
        
        circlePlane = Plane(self.upVector, self.origin)
        circle = Arc.Create(circlePlane, radius, 0, 2*pi) 
        
        thetaIncrement = (2*pi)/numSides
        
        polyCorners = []
        extrusionProfile = CurveArray()
        
        # the coordinates of the corners of the polygon are computed by computing first
        # the polar coordinates using the angle increment theta and then converting to cartesian
        for i in range(numSides):
            if i == 0:
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
            elif i == (numSides-1):
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
                extrusionProfile.Append(Line.CreateBound(polyCorners[i-1], polyCorners[i]))
                extrusionProfile.Append(Line.CreateBound(polyCorners[i], polyCorners[0]))
            else:
                polyCorners.append(self.GetCartesianPoint(radius, i*thetaIncrement))
                extrusionProfile.Append(Line.CreateBound(polyCorners[i-1], polyCorners[i]))
        
        self.ExtrudeProfiles( doc, extrusionProfile, height)
      
    
    def NewRectangularPrism(self, doc, sideLength, sideWidth, height):
    	"""
    	Creates a prism from a rectangular profile. The prism profile is created
    	on the xy plane and the extrusion along the z axis. Negative input values 
    	for sideLenth, sideWidth and height will create a profile line in the -Y, 
    	-X and -Z direction respectively.
    	
    	Precondition:
    	The input values for sideLength, sideWidth and height must not be zero.
    	
    	Keyword arguments:
    	doc -- the currently active project
        sideLength -- the length of the rectangle
        sideWidth -- the width of the rectangle
        height -- the height of the prism      
        """
        
        if sideLength == 0 : raise ValueError, 'sideLength cannot be zero'
        if sideWidth == 0 : raise ValueError, 'sideWidth cannot be zero'
        if height == 0 : raise ValueError, 'height cannot be zero.'
        
    	#define the four corners of the rectangle
        ptLeft = XYZ.Zero
        ptTop = XYZ(0,sideLength,0)
        ptRight = XYZ(sideWidth, sideLength,0)
        ptBottom = XYZ(sideWidth,0,0)
        
        extrusionProfile = CurveArray()
        
    	#GSenerate all lines connecting the 3 points        
        leftSide = Line.CreateBound(ptLeft, ptTop)
        topSide = Line.CreateBound(ptTop, ptRight)
        rightSide = Line.CreateBound(ptRight, ptBottom)
        bottomSide = Line.CreateBound(ptBottom, ptLeft)
        extrusionProfile.Append(leftSide)
        extrusionProfile.Append(topSide)
        extrusionProfile.Append(rightSide)
        extrusionProfile.Append(bottomSide)
               
        self.ExtrudeProfiles( doc, extrusionProfile, height)


    def NewRightIsoTrianglePrismForm(self, doc, legLength, height):
    	"""
    	Creates a prism from an isosceles triangle profile for a conceptual mass
    	template. The prism profile is created on the xy plane and the extrusion 
    	along the z axis. Negative input values for legLenth will create a profile 
    	line in the -X and -Y direction and negative height will create a profile
    	line in the -Z direction.
    	
    	Precondition:
    	The input values for legLength and height must not be zero.	
    	
    	Keyword arguments:
    	doc -- the currently active project
        legLength -- the length of the side 
        height -- the height of the prism      
        """
        
        if legLength == 0 : raise ValueError, 'leglength cannot be zero'
        if height == 0 : raise ValueError, 'height cannot be zero'
        
        p0 = XYZ.Zero
        p1 = XYZ(0,legLength,0)
        p2 = XYZ(legLength,0,0)
     
        leg1 = Line.CreateBound(p0,p1)
        leg2 = Line.CreateBound(p1,p2)
        hypotenuse = Line.CreateBound(p2,p0)
        
        bottomSketchPlane = self.CreateBottomSketchPlane(doc)
        
        transactionSketch = Transaction(doc, "CreateSketch")
        transactionSketch.Start()
        sleg1 = doc.FamilyCreate.NewModelCurve(leg1, bottomSketchPlane)
        sleg2 = doc.FamilyCreate.NewModelCurve(leg2, bottomSketchPlane)
        shypotenuse = doc.FamilyCreate.NewModelCurve(hypotenuse, bottomSketchPlane)
                        
        transactionSketch.Commit()
        
        transactionExtrusion = Transaction(doc, "CreateExtrusion")
        transactionExtrusion.Start()        
        profile = ReferenceArray()
        profile.Append(sleg1.GeometryCurve.Reference)
        profile.Append(sleg2.GeometryCurve.Reference)
        profile.Append(shypotenuse.GeometryCurve.Reference)

        doc.FamilyCreate.NewExtrusionForm(True, profile, self.upVector.Multiply(height))
        transactionExtrusion.Commit()    
        
        
    def ExtrudeProfiles(self, doc, extrusionProfile, height):
    	"""
    	Extrudes an array of profiles given a default sketch plane (XY plane).
    	The extrusion occurs along the Z direction. If the input value for the
    	height is negative the extrusion occurs along the -Z direction. 
    	This is a helper function called by the higher level functions intended
    	to generate prisms for various profiles.
    	   	
    	Keyword arguments:
    	doc -- the currently active project
        extrusionProfile -- a CurveArray containing the curves that define the profile
        height -- the height of the prism      
        """
        
        #Define a plane to place the circular profile
        bottomSketchPlane = self.CreateBottomSketchPlane(doc)
        
        #Extrude triangle transaction
        transactionExtrusion = Transaction(doc, "CreateExtrusion")
        transactionExtrusion.Start()        
        extrusionProfiles = CurveArrArray()  
        extrusionProfiles.Append(extrusionProfile)
        doc.FamilyCreate.NewExtrusion(True, extrusionProfiles, bottomSketchPlane, height)
        transactionExtrusion.Commit()
   

    def CreateBottomSketchPlane(self, doc):
    	"""
    	A utility function that creates a default sketch plane. It returns a plane
    	object with normal along the Z direction and origin the point at (0,0,0). This 
    	function is called by the higher-level function ExtrudeProfiles  to define a 
    	sketch plane for the extrusion. 
    	   	
    	Keyword arguments:
    	doc -- the currently active project   
        """
        
    	#Create plane transaction
        transactionPlane = Transaction(doc, "CreateSketchPlane")
        transactionPlane.Start() 
        bottomPlane = Plane(self.upVector, self.origin)
        bottomSketchPlane = doc.FamilyCreate.NewSketchPlane(bottomPlane)
        transactionPlane.Commit()
        return bottomSketchPlane    
       
       
    def GetCartesianPoint(self, radius, theta):
    	"""
    	A utility function that converts polar to cartesian coordinates. 
    	Returns an XYZ point. 
    	   	
    	Keyword arguments:
    	radius -- the radius of the circle
        theta -- angle in radians
        """
    	x = radius * cos(theta)
        y = radius * sin(theta)
        return XYZ(x, y, 0)
    
    
    # Transaction mode
    def GetTransactionMode(self):
        return Attributes.TransactionMode.Manual
	
	# Addin Id
    def GetAddInId(self):
        return '77C85659-44BC-4190-ABE4-C6AD4EE14AD7'
