﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.CodeChecking.Engineering;

namespace $safeprojectname$.Concrete
{
   /// <summary>
   /// Class for internal forces in linear elements
   /// </summary>
   class InternalForcesLinear : InternalForcesBase
   {
      /// <summary>
      /// Creates default 
      /// </summary>
      public InternalForcesLinear()
      {
         Forces = new InternalForcesContainer();
      }

      /// <summary>
      /// Gets or sets forces container
      /// </summary>
      public InternalForcesContainer Forces { get; set; }
   }
}
