﻿using System.Collections.Generic;

namespace $safeprojectname$
{
   namespace ConcreteTypes // todo: move this class to a new project file
   {
      /// <summary>
      /// Classification of available forces
      /// </summary>
      public enum EnabledInternalForces      
      { 
         /// <summary>
         /// Axial force. The force acting along the element.
         /// </summary>
         FX=0x01, 
         /// <summary>
         /// Shear force. The force acting perpendicular to the element, along Y axia.
         /// </summary>
         FY=0x02, 
         /// <summary>
         /// Shear force. The force acting perpendicular to the element along Z axis.
         /// </summary>
         FZ=0x04, 
         /// <summary>
         /// Torsional moment.
         /// </summary>
         MX=0x08,
         /// <summary>
         /// Bending moment. Bending around the Y axis.
         /// </summary>
         MY=0x10, 
         /// <summary>
         /// Bending moment. Bending around the Z axis.
         /// </summary>
         MZ=0x20,
      }

      /// <summary>
      /// Type of beam section
      /// </summary>
      public enum BeamSectionType 
      { 
         /// <summary>
         /// Section with slab interaction
         /// </summary>
         WithSlabBeamInteraction, 
         /// <summary>
         /// Section without slab interaction
         /// </summary>
         WithoutSlabBeamInteraction
      }

      /// <summary>
      /// Type of column structure type
      /// </summary>
      public enum ColumnStructureType
      {
         /// <summary>
         /// Sway structure 
         /// </summary>
         Sway,
         /// <summary>
         /// Non-sway structure
         /// </summary>
         NonSway
      }

      /// <summary>
      /// Converter class 
      /// </summary>
      public static class CalculationTypeHelper
      {

         /// <summary>
         /// Convertion into ForceType
         /// </summary>
         /// <param name="enabledForce">EnabledForce to be converted</param>
         /// <returns></returns>
         public static Autodesk.Revit.DB.CodeChecking.Engineering.ForceType GetForceType(this EnabledInternalForces enabledForce)
         {
            switch (enabledForce)
            {
               default: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Unknown;
               case EnabledInternalForces.FX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fx;
               case EnabledInternalForces.FY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fy;
               case EnabledInternalForces.FZ: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Fz;
               case EnabledInternalForces.MX: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Mx;
               case EnabledInternalForces.MY: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.My;
               case EnabledInternalForces.MZ: return Autodesk.Revit.DB.CodeChecking.Engineering.ForceType.Mz;
            }
         }
      }

   }
}
