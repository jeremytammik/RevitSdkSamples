﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;

namespace $safeprojectname$.Main
{
   /// <summary>
   /// Represents updater which main task is to invalidate results when any geometry change is done.
   /// </summary>
   class Updater : IUpdater
   {
      #region IUpdater Members

      public static Guid UpdaterId = new Guid("$guid14$");
      public static Guid AddinId = new Guid("$guid15$");

      public Updater()
      {
      }

      public void Execute(UpdaterData data)
      {
         Autodesk.Revit.DB.CodeChecking.Storage.StorageService service = Autodesk.Revit.DB.CodeChecking.Storage.StorageService.GetStorageService();
         Autodesk.Revit.DB.CodeChecking.Storage.StorageDocument storageDocument = service.GetStorageDocument(data.GetDocument());

         foreach (ElementId elId in data.GetModifiedElementIds())
         {
            Element el = data.GetDocument().GetElement(elId);
            storageDocument.ResultsManager.OutDateResults(Server.Server.ID, el);
         }
      }

      public string GetAdditionalInformation()
      {
         return "$updaterdescription$";
      }

      public ChangePriority GetChangePriority()
      {
         return ChangePriority.Structure;
      }

      public UpdaterId GetUpdaterId()
      {
         return new UpdaterId(new AddInId(AddinId), UpdaterId);
      }

      public string GetUpdaterName()
      {
         return "$updatername$";
      }

      #endregion
   }
}
