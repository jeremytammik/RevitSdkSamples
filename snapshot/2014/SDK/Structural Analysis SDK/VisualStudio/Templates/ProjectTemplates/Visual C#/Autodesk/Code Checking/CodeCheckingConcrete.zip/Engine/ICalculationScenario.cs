﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.Engine
{
   /// <summary>
   /// Base interface for calculation scenario.
   /// </summary>
   public interface ICalculationScenario
   {
      /// <summary>
      /// Gets list of calculation objects cref="ICalculationObject".
      /// </summary>
      /// <returns>List of calculation objects.</returns>
      List<ICalculationObject> CalculationScenarioList();
   }
}
