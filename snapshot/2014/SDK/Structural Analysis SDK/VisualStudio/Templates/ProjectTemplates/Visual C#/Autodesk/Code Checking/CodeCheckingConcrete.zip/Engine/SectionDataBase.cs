﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Engineering;

namespace $safeprojectname$.Engine
{
   /// <summary>
   /// Represents a base of section data.
   /// </summary>
   public class SectionDataBase : ObjectDataBase
   {
      /// <summary>
      /// Initializes a new instance of the SectionDataBase object with list of parameters.  
      /// </summary>
      /// <param name="point">Calculation point.</param>
      /// <param name="data">Object with base parameters for the section.</param>
      public SectionDataBase(CalcPoint point, ObjectDataBase data)
         : base(data)
      {
         calcPoint = point;
      }

      /// <summary>
      /// Initializes a new instance of the SectionDataBase from an existing one.  
      /// </summary>
      /// <param name="sectionDataBase">Section data to copy.</param>
      public SectionDataBase(SectionDataBase sectionDataBase) : base(sectionDataBase as ObjectDataBase)
      {
         calcPoint = sectionDataBase.CalcPoint;
      }

      private SectionDataBase() { }

      /// <summary>
      /// Gets a calculation point cref="CalcPoint".
      /// </summary>
      public CalcPoint CalcPoint
      {
         get { return calcPoint; }
      }

      private CalcPoint calcPoint;
   }
}
