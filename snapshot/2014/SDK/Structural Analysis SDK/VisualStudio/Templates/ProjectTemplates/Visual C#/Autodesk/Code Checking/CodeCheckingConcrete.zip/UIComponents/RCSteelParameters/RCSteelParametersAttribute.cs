﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.UIComponents.RCSteelParameters
{
#pragma warning disable 1591
   public class RCSteelParametersAttribute : Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.SubSchemaEmbeddedControlAttribute
   {
      public RCSteelParametersAttribute()
      {
         ServerUI = typeof(RCSteelParametersServerUI);
      }
   }
}
