﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.CodeChecking.Engineering;
using Autodesk.CodeChecking.Concrete;

namespace $safeprojectname$.Concrete
{
   /// <summary>
   /// This class provides the example for a simple design of RC cross-section .
   /// </summary>
   public class ConcreteSectionDesign
   {
      // Internal Forces 
      private List<InternalForcesContainer> internalForces;
      // Section
      private Geometry sectionGeometry;
      private double sectionWidth;
      private double sectionHeight;
      private SectionShapeType sectionType;
      // Concrete
      private double concreteFc;
      private double concreteYoungModulus;
      private double concreteCreepCoefficient;
      //Transversal reinforcement bars
      private double transReinforcementArea;
      private double transReinforcementDiameter;
      private double transReinforcementFy;
      private const int transReinforcementNumberOfLegs = 2;
      //Longitudinal reinforcement bars
      private double longReinforcementArea;
      private double longReinforcementDiameter;
      private double longReinforcementFy;
      private double longReinforcementTopCover;
      private double longReinforcementBottomCover;
      private double longReinforcementTopClearCover;
      private double longReinforcementBottomClearCover;
      private bool symmetricalReinforcementPreferable;
      //Element
      private Autodesk.Revit.DB.BuiltInCategory elementType;
      // internal parameters
      private Autodesk.CodeChecking.Concrete.Concrete concreteParameters;
      private RcVerificationHelperUtility verificationHelper;
      private Reinforcement longitudinalReinforcement;
      private Reinforcement transversalReinforcement;
      private double minStiffness;
      private List<string> designInfo;
      private List<string> designError;
      private List<string> designWarning;

      /// <summary>
      /// Sets the list of <see cref="InternalForcesContainer"/> associated with combinations or cases.
      /// </summary>
      public List<InternalForcesContainer> ListInternalForces
      {
         set { internalForces = value; }
      }
      /// <summary>
      /// Sets the cross section <see cref="Geometry"/> associated with combinations or cases.
      /// </summary>
      public Geometry Geometry
      {
         set { sectionGeometry = value; }
      }

      /// <summary>
      /// Sets the cross section width.
      /// </summary>
      public double Width
      {
         set { sectionWidth = value; }
      }

      /// <summary>
      /// Sets the cross section height.
      /// </summary>
      public double Height
      {
         set { sectionHeight = value; }
      }

      /// <summary>
      /// Sets type of cross section geometry.
      /// </summary>
      public SectionShapeType Type
      {
         set { sectionType = value; }
      }

      /// <summary>
      /// Sets the longitudinal reinforcement top cover.
      /// </summary>
      public double CoverTop
      {
         set { longReinforcementTopClearCover = value; }
      }

      /// <summary>
      /// Sets the longitudinal reinforcement bottom cover.
      /// </summary>
      public double CoverBottom
      {
         set { longReinforcementBottomClearCover = value; }
      }

      /// <summary>
      /// Sets the concrete Young modulus (modulus of elasticyty).
      /// </summary>
      public double YoungModulus
      {
         set { concreteYoungModulus = value; }
      }

      /// <summary>
      /// Sets the concrete stress limit for compresion.
      /// </summary>
      public double Compression
      {
         set { concreteFc = value; }
      }

      /// <summary>
      /// Sets the concrete creep coefficient.
      /// </summary>
      public double CreepCoefficient
      {
         set { concreteCreepCoefficient = value; }
      }


      /// <summary>
      /// Sets the minimum longitudinal reinforcement yeld stress (steel strenght).
      /// </summary>
      public double LongitudinalReinforcementMinimumYieldStress
      {
         set { longReinforcementFy = value; }
      }

      /// <summary>
      /// Sets the minimum transversal reinforcement yeld stress (steel strenght).
      /// </summary>
      public double TransversalReinforcementMinimumYieldStress
      {
         set { transReinforcementFy = value; }
      }

      /// <summary>
      /// Sets the minimum longitudinal reinforcement rebar area.
      /// </summary>
      public double LongitudinalReinforcementArea
      {
         set { longReinforcementArea = value; }
      }

      /// <summary>
      /// Sets the minimum transversal reinforcement rebar area.
      /// </summary>
      public double TransversalReinforcementArea
      {
         set { transReinforcementArea = value; }
      }

      /// <summary>
      /// Sets the minimum longitudinal reinforcement rebar diameter.
      /// </summary>
      public double LongitudinalReinforcementDiameter
      {
         set { longReinforcementDiameter = value; }
      }

      /// <summary>
      /// Sets the minimum transversal reinforcement rebar diameter.
      /// </summary>
      public double TransversalReinforcementDiameter
      {
         set { transReinforcementDiameter = value; }
      }
      /// <summary>
      /// Sets the type of element.
      /// </summary>
      public Autodesk.Revit.DB.BuiltInCategory ElementType
      {
         set { elementType = value; }
      }

      // Calculation/design resualts:

      /// <summary>
      /// Getsbottom reinforcement
      /// </summary>
      public double AsBottom {         
         get
         {
            return longitudinalReinforcement.AsBottom + transversalReinforcement.AsBottom;
         } 
      }

      /// <summary>
      /// Gets top reinforcement
      /// </summary>
      public double AsTop {
         get
         {
            return longitudinalReinforcement.AsTop + transversalReinforcement.AsTop;
         }
      }

      /// <summary>
      /// Gets left reinforcement
      /// </summary>
      public double AsLeft
      {
         get
         {
            return longitudinalReinforcement.AsLeft + transversalReinforcement.AsLeft;
         }
      }

      /// <summary>
      /// Gets right reinforcement
      /// </summary>
      public double AsRight
      {
         get
         {
            return longitudinalReinforcement.AsRight + transversalReinforcement.AsRight;
         }
      }

      /// <summary>
      /// Gets stirrup spacing
      /// </summary>
      public double Spacing
      {
         get
         {
            return transversalReinforcement.Spacing;
         }
      }

      /// <summary>
      /// Gets transversal reinforcement density
      /// </summary>
      public double TransversalDensity
      {
         get
         {
            return transversalReinforcement.TransversalDensity;
         }
      }

      /// <summary>
      /// Gets the list of design remarks
      /// </summary>
      public List<string> DesignInfo
      {
         get { return designInfo; }
      }

      /// <summary>
      /// Gets the list of design erros
      /// </summary>
      public List<string> DesignError
      {
         get { return designError; }
      }
      /// <summary>
      /// Gets the list of design erros
      /// </summary>
      public List<string> DesignWarning
      {
         get { return designWarning; }
      }
      /// <summary>
      /// Gets the minimum of section stiffness
      /// </summary>
      public double MinStiffness
      {
         get { return minStiffness; }
      }

      /// <summary>
      /// Initializes a new instance of user's section design object. 
      /// </summary>
      public ConcreteSectionDesign()
      {
         internalForces = new List<InternalForcesContainer>();
         sectionGeometry =new Geometry();
         sectionWidth = 0.0;
         sectionHeight = 0.0;
         sectionType = SectionShapeType.RectangularBar;
         concreteFc = 0.0;
         concreteYoungModulus = 0.0;
         concreteCreepCoefficient = 1.0;
         transReinforcementArea = 0.0;
         transReinforcementDiameter = 0.0;
         transReinforcementFy = 0.0;
         longReinforcementArea = 0.0;
         longReinforcementDiameter = 0.0;
         longReinforcementFy = 0.0;
         longReinforcementTopCover = 0.0;
         longReinforcementBottomCover = 0.0;
         longReinforcementTopClearCover = 0.0;
         longReinforcementBottomClearCover = 0.0;
         symmetricalReinforcementPreferable = false;
         elementType = Autodesk.Revit.DB.BuiltInCategory.INVALID;
         concreteParameters = new Autodesk.CodeChecking.Concrete.Concrete();
         minStiffness = 0.0;
         designInfo = new List<string>();
         designError = new List<string>();
         designWarning = new List<string>();
      }

      /// <summary>
      /// Main calculation method for cross section.
      /// </summary>
      /// <remarks>
      /// Overview:
      /// - preparing necessary data for cross section design </br>
      /// - longitudinal reinforcement design for ultimate limit state  </br>
      /// - longitudinal reinforcement design for serviceability limit state  </br>
      /// - sets minimum reinforcement </br>
      /// - calculation of stiffness for serviceability limit state - necessary for deflection  (only for beam)</br>
      /// - transversal reinforcement design for ultimate limit state  </br>
      /// - storing of information about calculation errors </br>
      /// - sets maximum stirrupas spacing </br>
      /// </remarks>
      public void Calculate()
      {
         try
         {
            PreparationOfCalculationData();                    // preparation of calculation results objects
            DataVeryfication();                                // verification of input data
            ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
            // After your implementation remove code below!
            // This is only example
            string warning = "This is only a sample code. It should be edited or replaced by a 3rd party implementation.";
            designWarning.Add(warning);
            longitudinalReinforcement.CurrentAsTop = 0.05;
            longitudinalReinforcement.CurrentToFinial();
            if (designWarning.First() != warning)
               throw new Exception(warning);
            // After your implementation remove code above!
            ///</WIZARD>

         }
         catch (Exception e)     // catching and storing exceptions (calculation errors)
         {
            OnError(e);
         }
      }
      

      /// <summary>
      /// Preparate the result objects.
      /// </summary>
      public void PreparationOfCalculationData()
      {
         // preparing necessary data for cross section design
         longitudinalReinforcement = new Reinforcement(longReinforcementFy);
         transversalReinforcement = new Reinforcement(transReinforcementFy);
         minStiffness = 0.0;
         longReinforcementTopCover = longReinforcementTopClearCover + transReinforcementDiameter + 0.5 * longReinforcementDiameter;
         longReinforcementBottomCover = longReinforcementBottomClearCover + transReinforcementDiameter + 0.5 * longReinforcementDiameter;
      }
      /// <summary>
      /// Input data veryfication. 
      /// </summary>
      public void DataVeryfication()
      {
         if (Math.Min(longReinforcementTopCover, longReinforcementBottomCover) < 1e-4)
         {
            throw new Exception(Properties.Resources.ResourceManager.GetString("ErrCover"));
         }
         if (Autodesk.Revit.DB.BuiltInCategory.OST_ColumnAnalytical == elementType)
         {
            if (Math.Max(longReinforcementTopCover, longReinforcementBottomCover) > 0.5 * Math.Min(sectionHeight, sectionWidth))
            {
               throw new Exception(Properties.Resources.ResourceManager.GetString("ErrCover"));
            }
         }
         else
         {
            if (longReinforcementTopCover + longReinforcementBottomCover > sectionHeight - 2e-4)
            {
               throw new Exception(Properties.Resources.ResourceManager.GetString("ErrCover"));
            }

         }
         switch(sectionType)
         {
            default:
               throw new Exception(Properties.Resources.ResourceManager.GetString("ErrSectionNotSupported"));
            case SectionShapeType.T:
               break;
            case SectionShapeType.RectangularBar:
               break;
         }
      }
      /// <summary>
      /// Handles exception
      /// </summary>
      /// <param name="e">Exception</param>
      public void OnError(Exception e)
      {
         // reset all of results
         longitudinalReinforcement.Reset();
         transversalReinforcement.Reset(); 
         minStiffness = 0.0;
         designError.Add(e.Message); // storing of information about calculation errors
         if (e is IRCException)      // storing debug information for RcuapiNet component
         {
            CalculationUtility.SerializeIRCException(e as IRCException);
         }
      }
   }
}
