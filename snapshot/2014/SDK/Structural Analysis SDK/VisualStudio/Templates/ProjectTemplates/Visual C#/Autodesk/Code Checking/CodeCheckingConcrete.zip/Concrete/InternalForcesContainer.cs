﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.CodeChecking.Engineering;

namespace $safeprojectname$.Concrete
{
   /// <summary>
   /// Simple container class for all possible internal forces in section
   /// </summary>
   public class InternalForcesContainer
   {
      /// <summary>
      /// Initializes a new instance of InternalForcesContainer object with default 0.0 values.
      /// </summary>
      public InternalForcesContainer()
      {
         ForceFx = 0.0; ForceFy = 0.0; ForceFz = 0.0; MomentMx = 0.0; MomentMy = 0.0; MomentMz = 0.0; DeflectionUx = 0.0; DeflectionUy = 0.0; DeflectionUz = 0.0;
         LimitState = ForceLimitState.Unknown;
         CaseName = "";
      }
      /// <summary>
      /// Gets or sets the force Fx (axial force).
      /// </summary>
      public double ForceFx { get; set; }

      /// <summary>
      /// Gets or sets the force Fy.
      /// </summary>
      public double ForceFy { get; set; }

      /// <summary>
      /// Gets or sets the force Fz (main shear force).
      /// </summary>
      public double ForceFz { get; set; }

      /// <summary>
      /// Gets or sets the moment Mz (torsion moment).
      /// </summary>
      public double MomentMx { get; set; }

      /// <summary>
      /// Gets or sets the moment My (main bending moment).
      /// </summary>
      public double MomentMy { get; set; }

      /// <summary>
      /// Gets or sets the moment My (main bending moment).
      /// </summary>
      public double MomentMz { get; set; }

      /// <summary>
      /// Gets or sets deflection Ux
      /// </summary>
      public double DeflectionUx { get; set; }

      /// <summary>
      /// Gets or sets deflection Uy
      /// </summary>
      public double DeflectionUy { get; set; }

      /// <summary>
      /// Gets or sets deflection Uz
      /// </summary>
      public double DeflectionUz { get; set; }


      /// <summary>
      /// Gets or sets the limit state.
      /// </summary>
      public ForceLimitState LimitState { get; set; }

      /// <summary>
      /// Gets or sets description of combination or case.
      /// </summary>
      public string CaseName { get; set; }
   }
}
