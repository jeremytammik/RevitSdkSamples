﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("CalculationParam", "$guid1$")]
    public class CalculationParameter : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public CalculationParameter()
        {
        }
		
		public CalculationParameter(Document document)
        {
        }

        public CalculationParameter(Entity entity,Document document)
            : base(entity,document)
        {
        }
    }
}
