﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $safeprojectname$.Engine;
using Autodesk.Revit.DB;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's calculation scenario.
   /// </summary>
   public class CalculationScenario : ICalculationScenario
   {

      #region ICalculationScenario Members

      /// <summary>
      /// Creates list of cref="ICalculationObject".
      /// </summary>
      /// <returns>List of cref="ICalculationObject".</returns>
      public List<ICalculationObject> CalculationScenarioList()
      {
         List<ICalculationObject> scenario = new List<ICalculationObject>();

         {
            PrepareSectionData calcObj = new PrepareSectionData();
            calcObj.Type = CalculationObjectType.Section;
            calcObj.ErrorResponse = ErrorResponse.SkipOnError;
            calcObj.Categories = new List<BuiltInCategory>() { BuiltInCategory.OST_BeamAnalytical, BuiltInCategory.OST_ColumnAnalytical };
            scenario.Add(calcObj);
         }

         ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
         {
            ModifyElementForces calcObj = new ModifyElementForces();
            calcObj.Type = CalculationObjectType.Element;
            calcObj.ErrorResponse = ErrorResponse.SkipOnError;
            calcObj.Categories = new List<BuiltInCategory>() { BuiltInCategory.OST_BeamAnalytical, BuiltInCategory.OST_ColumnAnalytical };
            scenario.Add(calcObj);
         }
         ///</WIZARD>

         {
            CalculateSection calcObj = new CalculateSection();
            calcObj.Type = CalculationObjectType.Section;
            calcObj.ErrorResponse = ErrorResponse.SkipOnError;
            calcObj.Categories = new List<BuiltInCategory>() { BuiltInCategory.OST_BeamAnalytical, BuiltInCategory.OST_ColumnAnalytical };
            scenario.Add(calcObj);
         }



         {
            FillResultData calcObj = new FillResultData();
            calcObj.Type = CalculationObjectType.Element;
            calcObj.ErrorResponse = ErrorResponse.RunOnError;
            calcObj.Categories = new List<BuiltInCategory>() { BuiltInCategory.OST_BeamAnalytical, BuiltInCategory.OST_ColumnAnalytical };
            scenario.Add(calcObj);
         }

         return scenario;
      }

      #endregion
   }
}
