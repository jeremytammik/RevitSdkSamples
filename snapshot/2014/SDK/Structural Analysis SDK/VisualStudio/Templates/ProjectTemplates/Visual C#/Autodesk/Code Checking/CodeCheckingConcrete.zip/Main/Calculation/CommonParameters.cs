﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using $safeprojectname$.Engine;
using Autodesk.Revit.DB.CodeChecking.Engineering.Tools;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's object with common parameters.
   /// </summary>
   public class CommonParameters : CommonParametersBase
   {
      /// <summary>
      /// Initializes a new instance of user's object with common parameters.  
      /// </summary>
      /// <param name="data">Acces to cref="ServiceData"</param>
      /// <param name="param">Instance of base common parameters object with predefined parameters to copy.</param>
      public CommonParameters(Autodesk.Revit.DB.CodeChecking.ServiceData data, CommonParametersBase param) : base(param)
      {

      }
      /// <summary>
      /// Gets and sets cref="ForceResultsCache" object.
      /// </summary>
      public ForceResultsCache ResultCache { get; set; }
   }
}
