﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Engineering;

namespace $safeprojectname$.Engine
{
   /// <summary>
   /// Represents a base of cref"ElementDataBase" or cref="SectionDataBase".
   /// </summary>
   public class ObjectDataBase
   {
      /// <summary>
      /// Initializes a new instance of the ObjectDataBase object with list of parameters.  
      /// </summary>
      /// <param name="elementId">Element identificator.</param>
      /// <param name="elementCategory">Element category.</param>
      /// <param name="elementMaterial">Element material.</param>
      /// <param name="elementLabel">Element label.</param>
      public ObjectDataBase( ElementId elementId,
                             Autodesk.Revit.DB.BuiltInCategory elementCategory,
                             StructuralAssetClass elementMaterial,
                             Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass elementLabel)
      {
         category = elementCategory;
         material = elementMaterial;
         elemId = new ElementId(elementId.IntegerValue); ;
         label = elementLabel;
      }

      /// <summary>
      /// Initializes a new instance of the ObjectDataBase from an existing one.  
      /// </summary>
      /// <param name="data">Object data to copy</param>
      public ObjectDataBase(ObjectDataBase data)
      {
         category = data.Category;
         material = data.Material;
         elemId = data.ElementId;
         label = data.Label;
      }

      /// <summary>
      /// Initializes a new instance of the ObjectDataBase. 
      /// </summary>
      public ObjectDataBase() { }

      /// <summary>
      /// Gets the element's category.
      /// </summary>
      public Autodesk.Revit.DB.BuiltInCategory Category
      {
         get { return category; }
      }

      /// <summary>
      /// Gets the element's material.
      /// </summary>
      public StructuralAssetClass Material
      {
         get { return material; }
      }

      /// <summary>
      /// Gets the element's identificator.
      /// </summary>
      public ElementId ElementId
      {
         get { return elemId; }
      }

      /// <summary>
      /// Gets the element's label schema.
      /// </summary>
      public Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass Label
      {
         get { return label; }
      }

      private Autodesk.Revit.DB.BuiltInCategory category;
      private StructuralAssetClass material;
      private ElementId elemId;
      private Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass label;
   }
}
