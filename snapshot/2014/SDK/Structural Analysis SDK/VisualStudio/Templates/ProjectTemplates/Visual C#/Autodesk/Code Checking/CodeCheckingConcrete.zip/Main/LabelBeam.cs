﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.ConcreteTypes;
using CT=$safeprojectname$.ConcreteTypes;
using Autodesk.Revit.DB.CodeChecking.Engineering.Concrete.ConcreteTypes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework;

namespace $safeprojectname$.Main
{
   /// <summary>
   /// Values validator for beam label.
   /// </summary>
   public class ValueValidatorBeam : IFieldValidator 
   {
      /// <summary>
      /// Validates the value.
      /// </summary>
      /// <param name="entity">The entity.</param>
      /// <param name="field">The field.</param>
      /// <param name="value">The value.</param>
      /// <param name="unit">The unit.</param>
      /// <returns></returns>
      public bool ValidateValue(object entity, string field, object value, DisplayUnitType unit)
      {
         ///<WIZARD OPTION="$RC_BEAM_CREEP">
         if (field == "CreepCoefficient")
         {
             return (double)value > 0;
         }
         ///</WIZARD>
         return true;
      }
   }

   /// <summary>
   /// Container for RC beam element material and calculation options
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("LabelBeam", "$guid9$")]
   public class LabelBeam : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
   {
      
      ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
      /// <summary>
      /// Collection of simple calculation type objects
      /// representing calculation options chosen by the user
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "BeamCalculationType")]
      [EnumControl(Description = "EnabledInternalForces", Category = "CalculationOptions", EnumType = typeof(ConcreteTypes.EnabledInternalForces), Presentation = PresentationMode.OptionList, Item = PresentationItem.ImageWithText, ImageSize = ImageSize.Medium, Context = "BeamLabel")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ListValue(Name = "EnabledInternalForces", Localizable = true, LocalizableValue = true)]
      public List<ConcreteTypes.EnabledInternalForces> EnabledInternalForces{ get; set; }
      ///</WIZARD>
      
      ///<WIZARD OPTION="$RC_BEAM_CREEP">
      /// <summary>
      /// Creep coefficient
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "CreepCoefficient", Unit = Autodesk.Revit.DB.UnitType.UT_Number, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_GENERAL)]
      [Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.TextBox(Description = "CreepCoefficient", Category = "CalculationOptions", IsVisible = true, IsEnabled = true, Index = -1, Localizable = true, FieldValidator = typeof(ValueValidatorBeam))]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "CreepCoefficient", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public Double CreepCoefficient { get; set; }
      ///</WIZARD>

      ///<WIZARD OPTION="$RC_BEAM_GEOMETRY_T_SECTION">
      /// <summary>
      /// Section type object(flanges/no flanges) representing
      /// option chosen by the user
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty]
      [EnumControl(Description = "SlabBeamInteraction", Category = "CalculationOptions", Index = -1, EnumType = typeof(ConcreteTypes.BeamSectionType), Presentation = PresentationMode.ToggleButton, Item = PresentationItem.Image, ImageSize = ImageSize.Medium, Context = "BeamLabel")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ValueWithName(LocalizableValue = true, Name = "SlabBeamInteraction", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public ConcreteTypes.BeamSectionType SlabBeamInteraction { get; set; }
      ///</WIZARD>

      /// <summary>
      /// Rebar parameters component for longitudinal reinforcement
      ///</summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "LongitudinalReinforcement")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "LongitudinalReinforcement")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.SubSchemaElement(LocalizableValue = true, Name = "LongitudinalReinforcement", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema LongitudinalReinforcement { get; set; }

      /// <summary>
      /// Rebar parameters component for transversal reinforcement
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "TransversalReinforcement")]
      [$safeprojectname$.UIComponents.RCSteelParameters.RCSteelParameters(Category = "TransversalReinforcement")]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.SubSchemaElement(LocalizableValue = true, Name = "TransversalReinforcement", Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = true)]
      public $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema TransversalReinforcement { get; set; }

      /// <summary>
      /// Creates default LabelBeam
      /// </summary>
      public LabelBeam()
      {
		 LongitudinalReinforcement = new $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
		 ///<WIZARD OPTION="$RC_BEAM_CREEP">
         CreepCoefficient = 2.0;
         ///</WIZARD>
         TransversalReinforcement = new  $safeprojectname$.UIComponents.RCSteelParameters.RCSteelParametersSchema();
         ///<WIZARD OPTION="$RC_TEMPLATE_ONLY">
         EnabledInternalForces = new List<ConcreteTypes.EnabledInternalForces>();
         EnabledInternalForces.Add(ConcreteTypes.EnabledInternalForces.MY);
         EnabledInternalForces.Add(ConcreteTypes.EnabledInternalForces.FZ);
         ///</WIZARD>
         ///<WIZARD OPTION="$RC_BEAM_GEOMETRY_T_SECTION">
         SlabBeamInteraction = ConcreteTypes.BeamSectionType.WithSlabBeamInteraction;
         ///</WIZARD>
      }

   }
}
