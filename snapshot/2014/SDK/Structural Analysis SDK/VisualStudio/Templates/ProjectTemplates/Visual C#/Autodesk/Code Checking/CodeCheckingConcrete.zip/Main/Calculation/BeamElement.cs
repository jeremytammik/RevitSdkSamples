﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Engineering;
using $safeprojectname$.Engine;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's beam element.
   /// </summary>
   public class BeamElement : ElementDataBase
   {
      /// <summary>
      /// Initializes a new instance of user's beam object.  
      /// </summary>
      /// <param name="elementDataBase">Instance of base element object with predefined parameters to copy.</param>
      public BeamElement(ElementDataBase elementDataBase) : base(elementDataBase) 
      {
      }

      /// <summary>
      /// Gets and sets cref="ElementInfo" object.
      /// </summary>
      public ElementInfo Info { get; set; }
   }
}
