Autodesk Revit API application: NewViewSection

This sample uses Visual Studio .NET 2005 C# code and provides a command that given a linear element, such as a wall, flooror beam generates a section view across the mid point of the element.