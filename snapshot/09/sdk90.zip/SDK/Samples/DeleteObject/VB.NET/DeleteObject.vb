'
' (C) Copyright 1994-2005 by Autodesk, Inc. All rights reserved.
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.

'
' AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable. 
Imports System
Imports System.Windows.Forms
Imports System.Collections

Imports Autodesk.Revit
Imports Autodesk.Revit.Elements
Imports Autodesk.Revit.Structural.Enums

'Delete the elements that were selected
Public Class DeleteObject
    Implements Autodesk.Revit.IExternalCommand

    'Implements Execute for IExternalCommand
   Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

      Dim revit As Autodesk.Revit.Application = commandData.Application

      Dim collection As ElementSet = revit.ActiveDocument.Selection.Elements
      'check user selection
      If collection.Size < 1 Then
         message = "Please select an object to delete."
         Return IExternalCommand.Result.Cancelled
      End If

      Dim isError As Boolean = True
      Try
         'delete selection
         Dim e As IEnumerator = collection.GetEnumerator()
         Dim MoreValue As Boolean = e.MoveNext()

         While MoreValue
            If TypeOf e.Current Is Autodesk.Revit.Element Then
               Dim component As Autodesk.Revit.Element = e.Current
               revit.ActiveDocument.Delete(component)
               MoreValue = e.MoveNext()
            End If
         End While

         isError = False

      Catch
         'if revit threw an exception, try to catch it
         For Each c As Autodesk.Revit.Element In collection
            elements.Insert(c)
         Next

         message = "Element(s) can't be deleted."
         Return IExternalCommand.Result.Failed
      Finally
         ' if revit threw an exception, display error and return failed
         If isError Then
            MessageBox.Show("Deletion failed.")
         End If

      End Try
      Return IExternalCommand.Result.Succeeded
   End Function
End Class
