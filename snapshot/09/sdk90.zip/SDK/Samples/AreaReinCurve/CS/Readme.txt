Autodesk Revit API application: AreaReinforcementCurve

This sample uses Visual studio .NET 2005 C#. Turn off all layers but one.  User get some parallel bars. 

Remove the hooks from one boundary curve so that the bars have hooks only at the other end. 