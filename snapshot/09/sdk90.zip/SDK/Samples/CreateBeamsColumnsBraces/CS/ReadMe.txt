Autodesk Revit API application: Create Beams, Columns & Braces

The function of the program is to create Columns Beams and Braces automatically, according to the user input.

1) Open the CreateBeamsColumnsBraces project. Make sure the added RevitAPI under the References have a righet file path. And modify the Revit.ini file in your Revit installation directory. You may refer to the supplied  Revit.ini file.

2) If you launch your Revit.exe, you will see the Create Beams Columns and Braces command in the External Commands item under the Tools menu.

3) When you select the Create Beams Columns and Braces command, you will see the Create Beams Columns and Braces Form dialog. The dialog will ask user to input some datum. Click OK, the program will create a truss model.