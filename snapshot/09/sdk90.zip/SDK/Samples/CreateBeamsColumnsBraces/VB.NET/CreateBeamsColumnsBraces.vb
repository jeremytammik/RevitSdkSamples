'
' (C) Copyright 1994-2005 by Autodesk, Inc. All rights reserved.
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable. 

Imports System
Imports System.IO
Imports System.Collections
Imports System.Windows.Forms

Imports Autodesk.Revit
Imports Autodesk.Revit.Parameters
Imports Autodesk.Revit.Elements
Imports Autodesk.Revit.Collections
Imports Autodesk.Revit.Events
Imports Autodesk.Revit.Symbols
Imports Autodesk.Revit.Structural
Imports Autodesk.Revit.Structural.Enums
Imports Autodesk.Revit.Creation
Imports Autodesk.Revit.Geometry

' Create Beams, Columns & Braces according to user's input information
Public Class CreateBeamsColumnsBraces
    Implements IExternalCommand 'ToDo: Add Implements Clauses for implementation methods of these interface(s)
    Private m_revit As Autodesk.Revit.Application = Nothing

    Private m_columnMaps As New ArrayList                'list of columns' type
    Private m_beamMaps As New ArrayList                  'list of beams' type
    Private m_braceMaps As New ArrayList                 'list of braces' type
    Private levels As New SortedList                     'list of list sorted by their elevations
    Private m_matrixUV(,) As Autodesk.Revit.Geometry.UV  '2D coordinates of matrix

    ' list of all type of columns
    Public ReadOnly Property ColumnMaps() As ArrayList
        Get
            Return m_columnMaps
        End Get
    End Property

    ' list of all type of beams
    Public ReadOnly Property BeamMaps() As ArrayList
        Get
            Return m_beamMaps
        End Get
    End Property

    'list of all type of braces
    Public ReadOnly Property BraceMaps() As ArrayList
        Get
            Return m_braceMaps
        End Get
    End Property

    'Application entry point implements IExternalCommand's method Execute
    'param name="revit" : The revit object for the active instance of Autodesk Revit.
    'param name="message" : A message that can be set by the external command and displayed in case of error.
    'param name="elements" : A set of elements that can be displayed if an error occurs.
    'returns : A value that signifies if your command was successful, failed or the user wishes to cancel.
    Public Function Execute1(ByVal revit As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As ElementSet) As IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute
        m_revit = revit.Application

        'if initialize failed return Result.Failed
        Dim initializeOK As Boolean = Initialize()
        If Not initializeOK Then
            Return Autodesk.Revit.IExternalCommand.Result.Failed
        End If

        Dim displayForm As New CreateBeamsColumnsBracesForm(Me)
        If displayForm.ShowDialog() <> DialogResult.OK Then
            Return Autodesk.Revit.IExternalCommand.Result.Cancelled
        End If

        Return Autodesk.Revit.IExternalCommand.Result.Succeeded
    End Function

    'check the number of floors is less than the number of levels
    'create beams, columns & braces according to selected types
    'param name="objColumn" : type of column
    'param name="objBeam" : type of beam
    'param name="objBrace" : type of brace
    'param name="floorNumber" : number of floor<
    'returns : number of floors is less than the number of levels and create successfully then return true
    Public Function AddInstance(ByVal columnObject As Object, ByVal beamObject As Object, ByVal braceObject As Object, ByVal floorNumber As Integer) As Boolean
        'whether floor number less than levels number
        If floorNumber >= levels.Count Then
            MessageBox.Show("The number of levels must be added.", "Revit")
            Return False
        End If

      Dim columnSymbol As Autodesk.Revit.Symbols.FamilySymbol = Nothing

        If TypeOf columnObject Is Autodesk.Revit.Symbols.FamilySymbol Then
            columnSymbol = columnObject
        End If

      Dim beamSymbol As Autodesk.Revit.Symbols.FamilySymbol = Nothing
        If TypeOf beamObject Is Autodesk.Revit.Symbols.FamilySymbol Then
            beamSymbol = beamObject
        End If

      Dim braceSymbol As Autodesk.Revit.Symbols.FamilySymbol = Nothing
        If TypeOf braceObject Is Autodesk.Revit.Symbols.FamilySymbol Then
            braceSymbol = braceObject
        End If

        'any symbol is null then the command failed
        If columnSymbol Is Nothing OrElse beamSymbol Is Nothing OrElse braceSymbol Is Nothing Then
            Return False
        End If

        Try

            For k As Integer = 0 To floorNumber - 1 'iterate levels from lower one to higher
                Dim baseLevel As Autodesk.Revit.Elements.Level = levels.GetByIndex(k)
                Dim topLevel As Autodesk.Revit.Elements.Level = levels.GetByIndex((k + 1))

                'place column of this level
                Dim point2D As Autodesk.Revit.Geometry.UV
                For Each point2D In m_matrixUV
                    PlaceColumn(point2D, columnSymbol, baseLevel, topLevel)
                Next point2D

                Dim matrixXSize As Integer = m_matrixUV.GetLength(0) 'length of matrix's x range
                Dim matrixYSize As Integer = m_matrixUV.GetLength(1) 'length of matrix's y range
                'iterate coordinate both in x direction and y direction and create beams and braces
                For j As Integer = 0 To matrixYSize - 1

                    For i As Integer = 0 To matrixXSize - 1
                        'create beams and braces in x direction
                        If i <> matrixXSize - 1 Then
                            PlaceBrace(m_matrixUV(i, j), m_matrixUV(i + 1, j), baseLevel, topLevel, beamSymbol, True)
                        End If
                        'create beams and braces in y direction
                        If j <> matrixYSize - 1 Then
                            PlaceBrace(m_matrixUV(i, j), m_matrixUV(i, j + 1), baseLevel, topLevel, beamSymbol, False)
                        End If
                    Next i
                Next j

                For j As Integer = 0 To matrixYSize - 1

                    For i As Integer = 0 To matrixXSize - 1
                        'create beams and braces in x direction
                        If i <> matrixXSize - 1 Then
                            PlaceBeam(m_matrixUV(i, j), m_matrixUV(i + 1, j), baseLevel, topLevel, beamSymbol)
                        End If
                        'create beams and braces in y direction
                        If j <> matrixYSize - 1 Then
                            PlaceBeam(m_matrixUV(i, j), m_matrixUV(i, j + 1), baseLevel, topLevel, beamSymbol)
                        End If
                    Next i
                Next j
            Next k
        Catch
            Return False
        End Try

        Return True
    End Function

    'generate 2D coordinates of matrix according to parameters
    'param name="xNumber" : Number of Columns in the X direction
    'param name="yNumber" : Number of Columns in the Y direction
    'param name="distance" : Distance between columns
    Public Sub CreateMatrix(ByVal xNumber As Integer, ByVal yNumber As Integer, ByVal distance As Double)
        m_matrixUV = New Autodesk.Revit.Geometry.UV(xNumber - 1, yNumber - 1) {}

        Dim i As Integer
        For i = 0 To xNumber - 1
            Dim j As Integer
            For j = 0 To yNumber - 1
                m_matrixUV(i, j) = New Autodesk.Revit.Geometry.UV(i * distance, j * distance)
            Next j
        Next i
    End Sub

    'iterate all the symbols of levels, columns, beams & braces
    'returns : A value that signifies if the initialization was successful for true or failed for false
    Private Function Initialize() As Boolean
        Try
            Dim i As ElementIterator = m_revit.ActiveDocument.Elements
            i.Reset()
            Dim moreElement As Boolean = i.MoveNext()
            While moreElement
                Dim o As Object = i.Current

                'add level to list
                Dim level As Autodesk.Revit.Elements.Level
                level = Nothing
                If TypeOf o Is Autodesk.Revit.Elements.Level Then
                    level = CType(o, Autodesk.Revit.Elements.Level)
                End If '

                If Not (level Is Nothing) Then
                    levels.Add(level.Elevation, level)
                    GoTo nextLoop
                End If

                Dim f As Autodesk.Revit.Elements.Family = Nothing
                If TypeOf o Is Autodesk.Revit.Elements.Family Then
                    f = o
                End If

                If f Is Nothing Then
                    GoTo nextLoop
                End If

                Dim symbol As Object
                For Each symbol In f.Symbols
                    Dim familyType As Autodesk.Revit.Symbols.FamilySymbol = symbol '

                    If familyType Is Nothing Then
                        GoTo nextLoop
                    End If
                    If familyType.Category Is Nothing Then
                        GoTo nextLoop
                    End If

                    'add symbols of beams and braces to lists 
                    Dim categoryName As String = familyType.Category.Name
                    If "Structural Framing" = categoryName Then
                        m_beamMaps.Add(New SymbolMap(familyType))
                        m_braceMaps.Add(New SymbolMap(familyType))
                    ElseIf "Structural Columns" = categoryName Then
                        m_columnMaps.Add(New SymbolMap(familyType))
                    End If
                Next symbol
nextLoop:
                moreElement = i.MoveNext()
            End While
        Catch
            Return False
        End Try
        Return True
    End Function

    'create column of certain type in certain position
    'param name="point2D" : 2D coordinate of the col umn
    'param name="columnType" : type of column
    'param name="baseLevel" : the base level of the column
    'param name="topLevel" : the top level of the column
    Private Sub PlaceColumn(ByVal point2D As Autodesk.Revit.Geometry.UV, ByVal columnType As Autodesk.Revit.Symbols.FamilySymbol, ByVal baseLevel As Autodesk.Revit.Elements.Level, ByVal topLevel As Autodesk.Revit.Elements.Level)
        'create column of certain type in certain level and start point 
        Dim point As New Autodesk.Revit.Geometry.XYZ(point2D.U, point2D.V, baseLevel.Elevation)
      Dim structuralType As Autodesk.Revit.Structural.Enums.StructuralType
      structuralType = Autodesk.Revit.Structural.Enums.StructuralType.Column
        Dim column As Autodesk.Revit.Elements.FamilyInstance = m_revit.ActiveDocument.Create.NewFamilyInstance(point, columnType, topLevel, structuralType)

        'set baselevel & toplevel of the column
        If Not (column Is Nothing) Then
            Dim baseLevelParameter As Parameter = column.Parameter(Autodesk.Revit.Parameters.BuiltInParameter.FAMILY_BASE_LEVEL_PARAM)
            Dim topLevelParameter As Parameter = column.Parameter(Autodesk.Revit.Parameters.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)
            Dim topOffsetParameter As Parameter = column.Parameter(BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM)
            Dim baseOffsetParameter As Parameter = column.Parameter(BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM)

            If Not (baseLevelParameter Is Nothing) Then
                Dim baseLevelId As Autodesk.Revit.ElementId
                baseLevelId = baseLevel.Id
                baseLevelParameter.Set(baseLevelId)
            End If

            If Not (topLevelParameter Is Nothing) Then
                Dim topLevelId As Autodesk.Revit.ElementId
                topLevelId = topLevel.Id
                topLevelParameter.Set(topLevelId)
            End If

            If Not (topOffsetParameter Is Nothing) Then
                topOffsetParameter.Set(0.0)
            End If

            If Not (baseOffsetParameter Is Nothing) Then
                baseOffsetParameter.Set(0.0)
            End If
        End If
    End Sub

    'create beam of certain type in certain position
    'param name="point2D1" : one point of the location line in 2D
    'param name="point2D2" : another point of the location line in 2D
    'param name="baseLevel" : the base level of the beam
    'param name="topLevel" : the top level of the beam
    'param name="beamType" : type of beam
    Private Sub PlaceBeam(ByVal point2D1 As Autodesk.Revit.Geometry.UV, ByVal point2D2 As Autodesk.Revit.Geometry.UV, ByVal baseLevel As Autodesk.Revit.Elements.Level, ByVal topLevel As Autodesk.Revit.Elements.Level, ByVal beamType As Autodesk.Revit.Symbols.FamilySymbol)
        Dim height As Double = topLevel.Elevation
        Dim startPoint As New Autodesk.Revit.Geometry.XYZ(point2D1.U, point2D1.V, height)
        Dim endPoint As New Autodesk.Revit.Geometry.XYZ(point2D2.U, point2D2.V, height)

      Dim structuralType As Autodesk.Revit.Structural.Enums.StructuralType = Autodesk.Revit.Structural.Enums.StructuralType.Beam
        Dim beam As Autodesk.Revit.Elements.FamilyInstance = m_revit.ActiveDocument.Create.NewFamilyInstance(startPoint, beamType, topLevel, structuralType)

        Dim beamCurve As LocationCurve = beam.Location '

        If Not (beamCurve Is Nothing) Then
            Dim line As line = m_revit.Create.NewLineBound(startPoint, endPoint)
            beamCurve.Curve = line
        End If
    End Sub

    'create brace of certain type in certain position between two adjacent columns
    'param name="point2D1" : one point of the location line in 2D
    'param name="point2D2" : another point of the location line in 2D
    'param name="baseLevel" : the base level of the brace
    'param name="topLevel" : the top level of the brace
    'param name="beamType" : type of beam
    'param name="isXDirection" : whether the location line is in x direction
    Private Sub PlaceBrace(ByVal point2D1 As Autodesk.Revit.Geometry.UV, ByVal point2D2 As Autodesk.Revit.Geometry.UV, ByVal baseLevel As Autodesk.Revit.Elements.Level, ByVal topLevel As Autodesk.Revit.Elements.Level, ByVal braceType As Autodesk.Revit.Symbols.FamilySymbol, ByVal isXDirection As Boolean)
        'get the start points and end points of location lines of two braces
        Dim topHeight As Double = topLevel.Elevation
        Dim baseHeight As Double = baseLevel.Elevation
        Dim middleElevation As Double = (topHeight + baseHeight) / 2
        Dim middleHeight As Double = (topHeight + baseHeight) / 2
        Dim startPoint As New Autodesk.Revit.Geometry.XYZ(point2D1.U, point2D1.V, middleElevation)
        Dim endPoint As New Autodesk.Revit.Geometry.XYZ(point2D2.U, point2D2.V, middleElevation)
        Dim middlePoint As Autodesk.Revit.Geometry.XYZ
        If isXDirection Then
            middlePoint = New Autodesk.Revit.Geometry.XYZ((point2D1.U + point2D2.U) / 2, point2D2.V, topHeight)
        Else
            middlePoint = New Autodesk.Revit.Geometry.XYZ(point2D2.U, (point2D1.V + point2D2.V) / 2, topHeight)
        End If

        'create two brace and set their location line
      Dim structuralType As Autodesk.Revit.Structural.Enums.StructuralType = Autodesk.Revit.Structural.Enums.StructuralType.Brace
        Dim levelId As Autodesk.Revit.ElementId = topLevel.Id
        Dim startLevelId As Autodesk.Revit.ElementId = baseLevel.Id
        Dim endLevelId As Autodesk.Revit.ElementId = topLevel.Id

        Dim firstBrace As Autodesk.Revit.Elements.FamilyInstance = m_revit.ActiveDocument.Create.NewFamilyInstance(startPoint, braceType, structuralType)
        Dim braceCurve1 As LocationCurve = firstBrace.Location '

        If Not (braceCurve1 Is Nothing) Then
            Dim line As Line = m_revit.Create.NewLineBound(startPoint, middlePoint)
            braceCurve1.Curve = line
        End If

        Dim referenceLevel1 As Parameter = firstBrace.Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
        If Not (referenceLevel1 Is Nothing) Then
            referenceLevel1.Set(levelId)
        End If

        Dim secondBrace As Autodesk.Revit.Elements.FamilyInstance = m_revit.ActiveDocument.Create.NewFamilyInstance(endPoint, braceType, baseLevel, structuralType)
        Dim braceCurve2 As LocationCurve = secondBrace.Location '

        If Not (braceCurve2 Is Nothing) Then
            Dim line As Line = m_revit.Create.NewLineBound(endPoint, middlePoint)
            braceCurve2.Curve = line
        End If

        Dim referenceLevel2 As Parameter = secondBrace.Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
        If Not (referenceLevel2 Is Nothing) Then
            referenceLevel2.Set(levelId)
        End If
    End Sub
End Class

'assistant class contains symbol and it's name
Public Class SymbolMap
    Private m_symbolName As String = ""
    Private m_symbol As Autodesk.Revit.Symbols.FamilySymbol = Nothing

    'constructor without parameter is forbidden
    Private Sub New()
    End Sub

    'constructor
    'param name="symbol" : family symbol
    Public Sub New(ByVal symbol As Autodesk.Revit.Symbols.FamilySymbol)
        m_symbol = symbol
        Dim familyName As String = ""
        If Not (symbol.Family Is Nothing) Then
            familyName = symbol.Family.Name
        End If
        m_symbolName = familyName + " : " + symbol.Name
    End Sub


    Public ReadOnly Property SymbolName() As String
        Get
            Return m_symbolName
        End Get
    End Property

    Public ReadOnly Property ElementType() As Autodesk.Revit.Symbols.FamilySymbol
        Get
            Return m_symbol
        End Get
    End Property
End Class
