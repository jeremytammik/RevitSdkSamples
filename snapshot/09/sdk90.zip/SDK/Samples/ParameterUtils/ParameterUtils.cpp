// ParameterUtils.cpp : Implementation of DLL Exports.


#include "stdafx.h"
#include "resource.h"
#include "ParameterUtils.h"

// ADDED BY AUTODESK
// Since the RevitAPI.tlb is imported into pre compiled header without any implementation, it must
// be added somewhere else. Do that here with the same options as in the precompiled headed except
// for implementation_only here so link time failures do not occur.
#import <RevitAPI.tlb> named_guids, auto_search, auto_rename, implementation_only
#import <MSCORLIB.tlb> auto_rename implementation_only
// END ADDED BY AUTODESK

class CParameterUtilsModule : public CAtlDllModuleT< CParameterUtilsModule >
{
public :
	DECLARE_LIBID(LIBID_ParameterUtilsLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_PARAMETERUTILS, "{72F7CE43-D107-489B-A4FA-138883760AB0}")
};

CParameterUtilsModule _AtlModule;

class CParameterUtilsApp : public CWinApp
{
public:

// Overrides
    virtual BOOL InitInstance();
    virtual int ExitInstance();

    DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CParameterUtilsApp, CWinApp)
END_MESSAGE_MAP()

CParameterUtilsApp theApp;

BOOL CParameterUtilsApp::InitInstance()
{
    return CWinApp::InitInstance();
}

int CParameterUtilsApp::ExitInstance()
{
    return CWinApp::ExitInstance();
}


// Used to determine whether the DLL can be unloaded by OLE
STDAPI DllCanUnloadNow(void)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    return (AfxDllCanUnloadNow()==S_OK && _AtlModule.GetLockCount()==0) ? S_OK : S_FALSE;
}


// Returns a class factory to create an object of the requested type
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _AtlModule.DllGetClassObject(rclsid, riid, ppv);
}


// DllRegisterServer - Adds entries to the system registry
STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    HRESULT hr = _AtlModule.DllRegisterServer();
	return hr;
}


// DllUnregisterServer - Removes entries from the system registry
STDAPI DllUnregisterServer(void)
{
	HRESULT hr = _AtlModule.DllUnregisterServer();
	return hr;
}

