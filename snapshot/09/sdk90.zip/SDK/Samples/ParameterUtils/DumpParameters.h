// ADDED BY AUTODESK
// DumpParameters.h : Declaration of the CDumpParameters

#pragma once
#include "resource.h"       // main symbols

#include "ParameterUtils.h"


// CDumpParameters
// CDumpParameters is an object that implements the Revit API's command interface, enabling a new
// command to be added to Revit. This class was generated in the following manner:
// From Class View the Add Class wizard was invoked.
// ATL Simple object was chosen.
// The Short Name was set to DumpParameters and the defaults for all the options was selected.
// This then generates header files and object files containing the shell of the object.
// Next the Revit command interface needs to be added to the object. This is done by:
// Select the class in Class View and right click, select Add followed by Implement Interface...
// Change the Implement interface from option to file and browse to the RevitAPI.tlb file
// In the Interfaces list select Autodesk_Revit_IExternalCommand and then > to add
// it to the implemented interfaces list.
// Click Finish
// The interface will now be added to the class. A few changes need to be made to make it functional.
// RevitAPI:: needs to be appended to the start of each Revit related definition since namespaces are
// being used to prevent possible conflicts.
// Lastly STDMETHOD(execute) needs to be changes to STDMETHOD(raw_execute) as we are using raw interfaces


// This class implements the Revit IExternalCommand interface
class ATL_NO_VTABLE CDumpParameters : 
   public CComObjectRootEx<CComSingleThreadModel>,
   public CComCoClass<CDumpParameters, &CLSID_DumpParameters>,
   public IDispatchImpl<IDumpParameters, &IID_IDumpParameters, &LIBID_ParameterUtilsLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
   public IDispatchImpl<RevitAPI::Autodesk_Revit_IExternalCommand, &__uuidof(RevitAPI::Autodesk_Revit_IExternalCommand), &RevitAPI::LIBID_RevitAPI, /* wMajor = */ 7, /* wMinor = */ 0>
{
public:
   CDumpParameters()
   {
   }

   DECLARE_REGISTRY_RESOURCEID(IDR_DUMPPARAMETERS)

   BEGIN_COM_MAP(CDumpParameters)
      COM_INTERFACE_ENTRY(IDumpParameters)
      COM_INTERFACE_ENTRY2(IDispatch, RevitAPI::Autodesk_Revit_IExternalCommand)
      COM_INTERFACE_ENTRY(RevitAPI::Autodesk_Revit_IExternalCommand)
   END_COM_MAP()

   DECLARE_PROTECT_FINAL_CONSTRUCT()

   HRESULT FinalConstruct()
   {
      return S_OK;
   }

   void FinalRelease() 
   {
   }

public:


   // Autodesk_Revit_IExternalCommand Methods
public:
   STDMETHOD(raw_Execute)(RevitAPI::_Autodesk_Revit_ExternalCommandData * commandData, BSTR * message, RevitAPI::_Autodesk_Revit_ElementSet * Elements, RevitAPI::Result * pRetVal);
};

OBJECT_ENTRY_AUTO(__uuidof(DumpParameters), CDumpParameters)

//END ADDED BY AUTODESK