// ADDED BY AUTODESK

#pragma once
#include "afxwin.h"

// CPropertiesDialog dialog
// This dialog is used to display the properties that exist upon an element. It consists of a list
// box and the ok, cancel buttons.

class CPropertiesDialog : public CDialog
{
	DECLARE_DYNAMIC(CPropertiesDialog)

public:
   CPropertiesDialog(CWnd* pParent = NULL);   // standard constructor

   // overloaded constructor that takes an array of strings which will be loaded into the list box
	CPropertiesDialog(const CStringArray& properties,CWnd* pParent = NULL);
	virtual ~CPropertiesDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
   // m_propertiesList is a class that represents the list box. It is used to display the properties
   CListBox m_propertiesList;

   // m_properties is a copy of the array of strings that is passed to the constructor of this class.
   // This array is used so that the strings can be stored up until the point the list box has actually
   // been created.
   CStringArray m_properties;

   // m_bFirstClass is a mechanism of ensuring that the list box contents only gets set once. This
   // boolean is initially set to false and then once the list box has been set it is changed to true.
   bool m_bFirstCall;
};

// END OF ADDED BY AUTODESK