// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef STRICT
#define STRICT
#endif

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows XP or later.
#define WINVER 0x0501		// Change this to the appropriate value to target other versions of Windows.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0410 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 6.0 or later.
#define _WIN32_IE 0x0600	// Change this to the appropriate value to target other versions of IE.
#endif

#define _ATL_APARTMENT_THREADED
#define _ATL_NO_AUTOMATIC_NAMESPACE

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit


#include <afxwin.h>
#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdisp.h>        // MFC Automation classes
#endif // _AFX_NO_OLE_SUPPORT

#include "resource.h"
#include <atlbase.h>
#include <atlcom.h>

using namespace ATL;

// ADDED BY AUTODESK
// This #import line adds the contents of the Autodesk Revit API Type Library to the project.
// It is included in stdafx.h so that it is available from all files. There are several things to
// note:
// The name of the type library is surrounded by <> meaning that the type library must be on the
// search path. This can be set in the Projects Additional Include directories.
// Named Guids are requested as ATL macros likes to use such things as LIBID_XXX.
// By default all Autodesk Revit definitions will be contained in a namespace. This will be RevitAPI.
// auto_search is specified because the Revit API uses other managed code components and this
// automatically locates these components and imports them.
// auto_rename is used because there are some name clashes with MSCORLIB. This option renames the clashing
// methods automatically.
// no_implementation is specified since this is added to a precompiled header and would result in
// duplication of data in all files.
#import <RevitAPI.tlb> named_guids, auto_search, auto_rename, no_implementation
// END OF ADDED BY AUTODESK
