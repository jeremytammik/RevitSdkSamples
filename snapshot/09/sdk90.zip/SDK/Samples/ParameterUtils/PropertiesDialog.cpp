// ADDED BY AUTODESK
// PropertiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "ParameterUtils.h"
#include "PropertiesDialog.h"


// CPropertiesDialog dialog

IMPLEMENT_DYNAMIC(CPropertiesDialog, CDialog)

// During the default constructors initialise the first call boolean.
CPropertiesDialog::CPropertiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPropertiesDialog::IDD, pParent)
   , m_bFirstCall(false)
{
}

// During the default constructors initialise the first call.
CPropertiesDialog::CPropertiesDialog(const CStringArray& properties,CWnd* pParent /*=NULL*/)
: CDialog(CPropertiesDialog::IDD, pParent)
, m_bFirstCall(false)
{
   // Take a copy of the string array that was passed to the constructor and store it with this class
   // for later use.
   m_properties.Copy(properties);
}

CPropertiesDialog::~CPropertiesDialog()
{
}

void CPropertiesDialog::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_LIST1, m_propertiesList);

   // if this is the first time that this method is called then we need to populate the list box
   // with the strings passed to the constructor.
   if (!m_bFirstCall)
   {
      // loop through all of the strings and added them to the list box.
      for (int i = 0; i < m_properties.GetCount(); i++)
         m_propertiesList.AddString(m_properties.GetAt(i));


      // The following code is used to set the tab widths within the list so that
      // the data can be viewed better. The tab stops are set to 1.33 times the length
      // of the longest string in the table.

      // Find the pixel width of the largest first substring.
      CString str;
      CSize   sz;
      int     nIndex, dx=0;
      CDC*    pDC = m_propertiesList.GetDC();
      for (int i=0;i < m_propertiesList.GetCount();i++)
      {
         m_propertiesList.GetText( i, str );

         if ((nIndex=str.Find('\t')) != -1)
            str = str.Right(nIndex);

         sz = pDC->GetTextExtent(str);

         if (sz.cx > dx)
            dx = sz.cx;
      }
      m_propertiesList.ReleaseDC(pDC);

      // Set tab stops at every one and 1/3 units
      // of the largest string. 
      // NOTE: Convert pixels to dialog units.
      m_propertiesList.SetTabStops((dx*4/3 * 4) / LOWORD(::GetDialogBaseUnits()));

      // Set the first call flag so that the list cannot be added again.
      m_bFirstCall = true;
   }
}

BEGIN_MESSAGE_MAP(CPropertiesDialog, CDialog)
END_MESSAGE_MAP()

// CPropertiesDialog message handlers
// END ADDED BY AUTODESK