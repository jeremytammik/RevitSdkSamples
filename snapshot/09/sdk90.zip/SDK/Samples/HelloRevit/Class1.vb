'      .NET Sample
'
'      Copyright (c) 2005-2006 by Autodesk, Inc.
'
'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.
'

Imports System

Imports Autodesk
Imports Autodesk.Revit

'
'  HelloRevit - defines *the* minimum Revit external command.
'
'  Please see README_HelloRevit.txt for the instruction on 
'  how to add this command to Revit. 
'  
'
Public Class Command

    Implements Autodesk.Revit.IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

        MsgBox("Hello Revit!")

        Return Autodesk.Revit.IExternalCommand.Result.Succeeded

    End Function

End Class


'
'  HelloRevit with a Form - defines *the* minimum Revit external command.
' 
'  Note: notice the workaround for using Form here. 
'  There is a problem .NET Framework 1.1:  http://support.microsoft.com/default.aspx?scid=kb;en-us;326219
'  The protection system is built into every Revit API method and property.  To workaround the problem, 
'  please call any harmless Revit API method like shown below. 
'  
'
Public Class Command_Form

    Implements Autodesk.Revit.IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

        ' The following line is a workaround:  http://support.microsoft.com/default.aspx?scid=kb;en-us;326219
        ' 
        Dim doc As Autodesk.Revit.Document = commandData.Application.ActiveDocument

        Try
            Dim myForm As Form1 = New Form1()
            myForm.ShowDialog()
        Catch e As Exception
            MsgBox(e.Message)
        End Try

        Return Autodesk.Revit.IExternalCommand.Result.Succeeded

    End Function

End Class
