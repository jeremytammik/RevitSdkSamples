[Enable Word Wrap to view this document correctly]

Contained in these sub folders are some of the Autodesk Revit 8.0 API samples. For more samples and support questions please contact the Autodesk Developer Network (ADN). The Autodesk Revit API enables external applications to add new commands to Autodesk Revit. These commands appear in the Autodesk Revit user interface under the Tools menu. When external commands are availble a menu item named "External Tools" will appear. From this menu item a fly-out menu will appear listing all the commands that are currently available.

External commands can be written in any programming lanuage that supports Microsoft COM or Microsoft .NET Framework, such as Visual Basic, Visual C#, Visual C++ etc.

The manner by which Autodesk Revit knows about the existance of external commands is via the Revit.ini file that is located in the Autodesk Revit Program directory, usually C:\Program Files\Autodesk Revit 8.0\Program. To use each of the samples some data must be added to this Revit.ini file to make the commands appear. Each sample contains a Revit.ini file, the contents of which should be copied into the existing Revit.ini file in the Autodesk Revit Program directory. Some of the data copied may contain file path names to components which must be corrected by you to point to the location into which you built the samples. Once Autodesk Revit is started the external commands will become visible if the sample has been correctly built and the Revit.ini file correctly modified.

[Samples]

ArchSample1 - Exports the contents of an entire project to Microsoft Excel 2003. You must have Microsoft Excel 2003 for this sample to function. Each category in the Revit project will be translated to a worksheet in Excel. Each sheet will contain a column for each parameter that is shared amongst the elements within that category, such as wall area.

BrowseBindings � This sample reads all the shared parameter bindings from the active project. The bindings link a shared parameter to a specified category, enabling user defined parameters to be added to new and existing elements within the project. For more details on shared parameters please see the Revit help files.

CreateShared � This sample adds two commands to Revit. The first shows how a shared parameter can be created via the API. Note that a shared parameter file named RevitParameters.txt must exist before this sample will function. For details on how to create a shared parameter file please see the Revit help files. The second command shows how a shared parameter can be modified via the API.

DumpParameters � An MFC/ATL based application written in C++ that displays the parameters that are present on the selected element in a dialog box, very much like, but much simpler than the Element Properties dialog box within Revit.

HelloWorld � A base sample that can be used to kick start your development. The sample just displays a dialog with the words �Hello World� within it when the command is executed.

InvisibleParam � Shared parameters added via the API can be set to invisible so that the Revit user does not know of their existence. This is useful as these parameters cannot be modified by the user and so can contain data that is specific to and whose consistency is important to the external application.

LibraryPaths � Shows how the Revit search paths for families and other libraries can be read or changed.

LoadFamily � Loads a named family symbol from a family file via the API.

ModifyIniFile � A C++ sample that can be modified or added to you installer code to modify the Revit.ini file programmatically.

MoveLinear � Shows how a linear element, such as a wall, can be moved by setting its base curve instead of using the Move method. Setting the base curve can be used for changing the length of the wall etc.

PhysicalProp � A sample that shows how to retrieve the detailed data from an element that has physical properties.

RotateElement � This sample shows the procedure for modifying a parameter that is present on an element. In this case the parameter is the rotation of the element. It shows how to locate a parameter by the name used in the element properties dialog and then change its value.

SpanDirection � For structural floors. Shows how the span direction can be retrieved from a floor.

StructSample1 � A sample that takes a wall and then applies basic timber framing to it at a specified distance apart.

TypeSelector � This sample shows how the type of a selected element, such as a wall can be changed using the API.

