Option Explicit On 
Imports System
Imports Autodesk.Revit

Public Class Command2
    Implements Autodesk.Revit.IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute
        Dim sharedParameterDefinition As Autodesk.Revit.Parameters.Definition
        sharedParameterDefinition = commandData.Application.OpenSharedParameterFile.Groups.Item("RevitParameters").Definitions.Item("APIParameter")

        Dim mParameterName As String = "APIParameter"
        Dim mNewParamValue As String = "Hello Revit"

        Dim iter As IEnumerator
        iter = commandData.Application.ActiveDocument.Elements
        Do While (iter.MoveNext)
            Dim element As Autodesk.Revit.Element
            element = iter.Current
            If Not (TypeOf element Is Autodesk.Revit.Symbol) Then
                If Not (element.Category Is Nothing) Then
                    If (element.Category.Name = "Walls") Then

                        Dim param As Autodesk.Revit.Parameter
                        Dim parameters As Autodesk.Revit.ParameterSet = element.Parameters
                        For Each param In parameters
                            If (param.Definition.Name = mParameterName) Then
                                param.Set(mNewParamValue)
                                Exit For
                            End If
                        Next
                    End If
                End If
            End If
        Loop

        Return IExternalCommand.Result.Succeeded

    End Function
End Class
