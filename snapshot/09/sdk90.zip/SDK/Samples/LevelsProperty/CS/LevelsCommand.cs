//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;
using Autodesk.Revit.Elements;

namespace Revit.SDK.Samples.LevelsProperty.CS
{
	public class LevelsCommand : IExternalCommand
	{
		#region GetDatum

		public IExternalCommand.Result Execute(ExternalCommandData revit, ref String message, ElementSet elements)
		{
			m_revit = revit;

			//Get every level by iterating through all elements
			systemLevelsDatum = new List<LevelsDataSource>();

			ElementIterator systemElementIterator = m_revit.Application.ActiveDocument.Elements;
			systemElementIterator.Reset();
			while (systemElementIterator.MoveNext())
			{
				Level systemLevel = systemElementIterator.Current as Level;
				if (null != systemLevel)
				{
					LevelsDataSource levelsDataSourceRow = new LevelsDataSource();

					levelsDataSourceRow.LevelIDValue = systemLevel.Id.Value;
					levelsDataSourceRow.Name = systemLevel.Name;

					double temValue = systemLevel.Elevation * 304.8;
					double temValue2 = double.Parse(temValue.ToString("#.0"));
					levelsDataSourceRow.Elevation = temValue2;

					systemLevelsDatum.Add(levelsDataSourceRow);
				}
			}

			LevelsForm displayForm = new LevelsForm(this);
			displayForm.ShowDialog();

			return IExternalCommand.Result.Succeeded;
		}

		ExternalCommandData m_revit;

		//Store all levels's datum in system
		System.Collections.Generic.List<LevelsDataSource> systemLevelsDatum;
		public System.Collections.Generic.List<LevelsDataSource> SystemLevelsDatum
		{
			get
			{
				return systemLevelsDatum;
			}
			set
			{
				systemLevelsDatum = value;
			}
		}
		#endregion

		#region SetData
		/// <summary>
		/// Set Level
		/// </summary>
		/// <param name="levelIDValue">Pass a Level's ID value</param>
		/// <param name="levelName">Pass a Level's Name</param>
		/// <param name="levelElevation">Pass a Level's Elevation</param>
		public void SetLevel(int levelIDValue, String levelName, double levelElevation)
		{
			ElementIterator systemElementIterator = m_revit.Application.ActiveDocument.Elements;
			systemElementIterator.Reset();
			while (systemElementIterator.MoveNext())
			{
				Level systemLevel = systemElementIterator.Current as Autodesk.Revit.Elements.Level;
				if (null != systemLevel)
				{
					if (systemLevel.Id.Value == levelIDValue)
					{
						systemLevel.Name = levelName;
						systemLevel.Elevation = levelElevation / 304.8;
					}
				}
			}
		}
		#endregion

		#region CreateLevel
		/// <summary>
		/// Create a level
		/// </summary>
		/// <param name="levelName">Pass a Level's Name</param>
		/// <param name="levelElevation">Pass a Level's Elevation</param>
		public void CreateLevel(String levelName, double levelElevation)
		{
			Level newLevel = m_revit.Application.ActiveDocument.Create.NewLevel(levelElevation / 304.8);

			newLevel.Name = levelName;
		}
		#endregion

		#region DeleteLevel
		/// <summary>
		/// Delete a Level.
		/// </summary>
		/// <param name="IDValueOfLevel">A Level's ID value</param>
		public void DeleteLevel(int IDValueOfLevel)
		{
			ElementId IDOfLevel;
			IDOfLevel.Value = IDValueOfLevel;

			m_revit.Application.ActiveDocument.Delete(ref IDOfLevel);
		}
		#endregion
	}
}
