Autodesk Revit API application: BeamAndSlabNewParameter

This sample uses Visual Studio .NET 2005 C# code and provides three commands. 
The first command add a shared parameter, named Unique ID, to beams and slabs and 
set a GUID to the parameter. 
The second command display Unique ID parameter's value in a list box if present for all the selected elements. 
The third command high light the element according the Unique ID's value which is selected in the list box.
In addition, when implement the first command use the category id instead of the string name for the category to retrieve the category.

