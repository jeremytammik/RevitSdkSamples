'
'	Revit API Sample Program: StructSample1CS
'
'	Migrated by mh. March, 2005 
'
'	Last modified: Feb. 18, 2006 by mh. 
' 
'

Subject: column creation.   

Description: This command places a set of coulmns in the selected wall.

Note that Revit uses Feet as an internal length unit. The sample assumes that you are using a metric template. 

Usage: 

(1) load the column family type of "M_Wood Timber Column", "191 x 292mm" (It is hard-coded in the program.) 
(2) Draw a couple of walls, and constrain their top and bottom to the levels in the properties dialog. 
(3) Run the command. 
It will then place columns along each wall with the interval of 5 feet. (the interval is also hard coded.) 