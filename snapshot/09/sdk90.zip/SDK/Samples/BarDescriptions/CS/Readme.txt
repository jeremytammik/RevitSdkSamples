Autodesk Revit API application:BarDescriptions

This sample uses Visual studio .NET 2005 C# to Iterates through the BarDescriptions in the project and displays the properties in a table. And allow the properties information of BarDescriptions to be saved in an Excel .CSV file.

The BarDescription is the the Bar Table property of an Area Reinforcement element, so first some Area Reinforcement elements should be drawn.