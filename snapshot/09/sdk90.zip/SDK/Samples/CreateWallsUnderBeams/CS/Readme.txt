This command will take a selection of beams and draw simple rectangular walls along and under the path of the beams.

When the command is executed a dialog should appear that contains the following:
	A drop down list for all types of wall.
	A check box for whether the walls are structural. Default should be checked.
