using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Revit.SDK.Samples.Loads.CS
{
    /// <summary>
    /// mainly deal with the operation on load case page on the form
    /// </summary>
    public partial class LoadsForm
    {
        int m_loadCaseDataGridViewSelectedIndex;
        int m_loadNatureDataGridViewSelectedIndex;
        System.Windows.Forms.DataGridViewTextBoxColumn LoadCasesName;
        System.Windows.Forms.DataGridViewTextBoxColumn LoadCasesNumber;
        System.Windows.Forms.DataGridViewComboBoxColumn LoadCasesNature;
        System.Windows.Forms.DataGridViewComboBoxColumn LoadCasesCategory;
        System.Windows.Forms.DataGridViewTextBoxColumn LoadNatureName;


        // Methods
        /// <summary>
        /// Initialize the data on this page.
        /// </summary>
        void InitializeLoadCasePage()
        {
            InitializeLoadCasesDataGridView();
            InitializeLoadNaturesDataGridView();


            if (0 == m_dataBuffer.LoadCases.Count)
            {
                this.duplicateLoadCasesButton.Enabled = false;
            }
            if (0 == m_dataBuffer.LoadNatures.Count)
            {
                this.addLoadNaturesButton.Enabled = false;
            }
            this.addLoadNaturesButton.Enabled = false;
        }

        /// <summary>
        /// Initialize the loadCasesDataGridView
        /// </summary>
        private void InitializeLoadCasesDataGridView()
        {
            this.LoadCasesName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoadCasesNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoadCasesNature = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.LoadCasesCategory = new System.Windows.Forms.DataGridViewComboBoxColumn();
            loadCasesDataGridView.AutoGenerateColumns = false;
            this.loadCasesDataGridView.Columns.AddRange(new DataGridViewColumn[] { this.LoadCasesName, this.LoadCasesNumber, this.LoadCasesNature, this.LoadCasesCategory });
            loadCasesDataGridView.DataSource = m_dataBuffer.LoadCasesMap;

            this.LoadCasesName.DataPropertyName = "LoadCasesName";
            this.LoadCasesName.HeaderText = "Name";
            this.LoadCasesName.Name = "LoadCasesName";
            this.LoadCasesName.ReadOnly = false;
            this.LoadCasesName.Width = loadCasesDataGridView.Width / 6;

            this.LoadCasesNumber.DataPropertyName = "LoadCasesNumber";
            this.LoadCasesNumber.HeaderText = "Case Number";
            this.LoadCasesNumber.Name = "LoadCasesNumber";
            this.LoadCasesNumber.ReadOnly = true;
            this.LoadCasesNumber.Width = loadCasesDataGridView.Width / 4;

            this.LoadCasesNature.DataPropertyName = "LoadCasesNatureId";
            this.LoadCasesNature.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.LoadCasesNature.HeaderText = "Nature";
            this.LoadCasesNature.Name = "LoadCasesNature";
            this.LoadCasesNature.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.LoadCasesNature.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.LoadCasesNature.Width = loadCasesDataGridView.Width / 4;

            LoadCasesNature.DataSource = m_dataBuffer.LoadNatures;
            LoadCasesNature.DisplayMember = "Name";
            LoadCasesNature.ValueMember = "Id";

            this.LoadCasesCategory.DataPropertyName = "LoadCasesCategoryId";
            this.LoadCasesCategory.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.LoadCasesCategory.HeaderText = "Category";
            this.LoadCasesCategory.Name = "LoadCasesCategory";
            this.LoadCasesCategory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.LoadCasesCategory.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.LoadCasesCategory.Width = loadCasesDataGridView.Width / 4;

            LoadCasesCategory.DataSource = m_dataBuffer.LoadCasesCategory;
            LoadCasesCategory.DisplayMember = "Name";
            LoadCasesCategory.ValueMember = "Id";
            this.loadCasesDataGridView.MultiSelect = false;
            this.loadCasesDataGridView.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void InitializeLoadNaturesDataGridView()
        {
            this.LoadNatureName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            loadNaturesDataGridView.AutoGenerateColumns = false;
            this.loadNaturesDataGridView.Columns.AddRange(new DataGridViewColumn[] { this.LoadNatureName });
            loadNaturesDataGridView.DataSource = m_dataBuffer.LoadNaturesMap;
            this.LoadNatureName.DataPropertyName = "LoadNaturesName";
            this.LoadNatureName.HeaderText = "Name";
            this.LoadNatureName.Name = "LoadNaturesName";
            this.LoadNatureName.ReadOnly = false;
            this.LoadNatureName.Width = loadCasesDataGridView.Width - 100;
            this.loadNaturesDataGridView.MultiSelect = false;
            this.loadNaturesDataGridView.SelectionMode = DataGridViewSelectionMode.CellSelect;
            
        }

        private void loadCasesDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Initilize();
            m_loadCaseDataGridViewSelectedIndex = e.RowIndex;
        }

        private void loadNaturesDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Initilize();
            m_loadNatureDataGridViewSelectedIndex = e.RowIndex;
        }

        private void loadCasesDataGridView_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            m_loadCaseDataGridViewSelectedIndex = e.RowIndex;
        }

        private void loadNaturesDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            m_loadNatureDataGridViewSelectedIndex = e.RowIndex;
        }

        private void loadNaturesDataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            object objectTemp = this.loadNaturesDataGridView.CurrentCell.Value;
            string nameTemp = objectTemp as string;

            object changeValue = e.FormattedValue;
            string changeValueTemp = changeValue as string;

            if (nameTemp == changeValueTemp)
            {
                return;
            }

            if (null == changeValueTemp)
            {
                MessageBox.Show("Name can not be null", "Revit");
                e.Cancel = true;
                return;
            }

            if ("" == changeValueTemp)
            {
                MessageBox.Show("Name can not be null", "Revit");
                e.Cancel = true;
                return;
            }

            if (!m_dataBuffer.LoadCasesDeal.IsNatureNameUnique(changeValueTemp))
            {
                MessageBox.Show("Name can not be same", "Revit");
                e.Cancel = true;
                return;
            }
        }

        private void loadCasesDataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex != 0)
            {
                return;
            }
            
            DataGridViewCell cellTemp = this.loadCasesDataGridView.CurrentCell;
            if (null == cellTemp)
            {
                return;
            }
            string nameTemp = cellTemp.Value as string;
            if (null == nameTemp)
            {
                e.Cancel = false;
                return;
            }

            object changeValue = e.FormattedValue;
            string changeValueTemp = changeValue as string;

            if (nameTemp == changeValueTemp)
            {
                return;
            }

            if (null == changeValueTemp)
            {
                MessageBox.Show("Name can not be null", "Revit");
                e.Cancel = true;
                return;
            }

            if ("" == changeValueTemp)
            {
                MessageBox.Show("Name can not be null", "Revit");
                e.Cancel = true;
                return;
            }

            if (!m_dataBuffer.LoadCasesDeal.IsCaseNameUnique(changeValueTemp))
            {
                MessageBox.Show("Name can not be same", "Revit");
                e.Cancel = true;
                return;
            }
        }

        private void duplicateLoadCasesButton_Click(object sender, EventArgs e)
        {
            m_loadCaseDataGridViewSelectedIndex = this.loadCasesDataGridView.CurrentCell.RowIndex; 
            if (!m_dataBuffer.LoadCasesDeal.DuplicateLoadCase(m_loadCaseDataGridViewSelectedIndex))
            {
                MessageBox.Show("Duplicate failed", "Revit");
                return;
            }
            this.ReLoad();
        }

        private void addLoadNaturesButton_Click(object sender, EventArgs e)
        {
            if (!m_dataBuffer.LoadCasesDeal.AddLoadNature(m_loadNatureDataGridViewSelectedIndex))
            {
                MessageBox.Show("Add Nature Failed", "Revit");
                return;
            }
            this.ReLoad();
        }

       
        /// <summary>
        /// Reload the data of the cases and natures
        /// </summary>
        private void ReLoad()
        {
            this.loadNaturesDataGridView.DataSource = null;
            this.loadCasesDataGridView.DataSource = null;
            this.LoadCasesNature.SortMode = DataGridViewColumnSortMode.Automatic;
            this.loadNaturesDataGridView.DataSource = m_dataBuffer.LoadNaturesMap;
            this.loadCasesDataGridView.DataSource = m_dataBuffer.LoadCasesMap;
            this.Refresh();
            return;
        }

        /// <summary>
        /// enable button
        /// </summary>
        private void Initilize()
        {
            if (this.loadCasesDataGridView.Focused)
            {
                this.addLoadNaturesButton.Enabled = false;
                this.duplicateLoadCasesButton.Enabled = true;
                
            }
            else if (this.loadNaturesDataGridView.Focused)
            {
                this.addLoadNaturesButton.Enabled = true;
                this.duplicateLoadCasesButton.Enabled = false;
               
            }
            this.Refresh();
            return;
        } 
    }
}
