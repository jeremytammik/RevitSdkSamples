namespace Revit.SDK.Samples.ObjectViewer.CS
{
    partial class ObjectViewerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.parametersDataGridView = new System.Windows.Forms.DataGridView();
            this.physicalModelradioButton = new System.Windows.Forms.RadioButton();
            this.analyticalModelradioButton = new System.Windows.Forms.RadioButton();
            this.previewPictureBox3D = new Revit.SDK.Samples.ObjectViewer.CS.PictureBox3D();
            ((System.ComponentModel.ISupportInitialize)(this.parametersDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // parametersDataGridView
            // 
            this.parametersDataGridView.AllowUserToAddRows = false;
            this.parametersDataGridView.AllowUserToDeleteRows = false;
            this.parametersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.parametersDataGridView.Location = new System.Drawing.Point(559, 15);
            this.parametersDataGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.parametersDataGridView.Name = "parametersDataGridView";
            this.parametersDataGridView.ReadOnly = true;
            this.parametersDataGridView.RowTemplate.Height = 24;
            this.parametersDataGridView.Size = new System.Drawing.Size(335, 460);
            this.parametersDataGridView.TabIndex = 4;
            this.parametersDataGridView.TabStop = false;
            // 
            // physicalModelradioButton
            // 
            this.physicalModelradioButton.AutoSize = true;
            this.physicalModelradioButton.Checked = true;
            this.physicalModelradioButton.Location = new System.Drawing.Point(92, 496);
            this.physicalModelradioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.physicalModelradioButton.Name = "physicalModelradioButton";
            this.physicalModelradioButton.Size = new System.Drawing.Size(123, 21);
            this.physicalModelradioButton.TabIndex = 2;
            this.physicalModelradioButton.TabStop = true;
            this.physicalModelradioButton.Text = "Physical Model";
            this.physicalModelradioButton.UseVisualStyleBackColor = true;
            this.physicalModelradioButton.Click += new System.EventHandler(this.physicalModelradioButton_Click);
            // 
            // analyticalModelradioButton
            // 
            this.analyticalModelradioButton.AutoSize = true;
            this.analyticalModelradioButton.Location = new System.Drawing.Point(291, 496);
            this.analyticalModelradioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.analyticalModelradioButton.Name = "analyticalModelradioButton";
            this.analyticalModelradioButton.Size = new System.Drawing.Size(131, 21);
            this.analyticalModelradioButton.TabIndex = 3;
            this.analyticalModelradioButton.TabStop = true;
            this.analyticalModelradioButton.Text = "Analytical Model";
            this.analyticalModelradioButton.UseVisualStyleBackColor = true;
            this.analyticalModelradioButton.Click += new System.EventHandler(this.analyticalModelradioButton_Click);
            // 
            // previewPictureBox3D
            // 
            this.previewPictureBox3D.DataSource = null;
            this.previewPictureBox3D.Location = new System.Drawing.Point(16, 15);
            this.previewPictureBox3D.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.previewPictureBox3D.Name = "previewPictureBox3D";
            this.previewPictureBox3D.Size = new System.Drawing.Size(521, 460);
            this.previewPictureBox3D.TabIndex = 1;
            this.previewPictureBox3D.Text = "pictureBox3D";
            this.previewPictureBox3D.UseVisualStyleBackColor = true;
            // 
            // ObjectViewerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 532);
            this.Controls.Add(this.analyticalModelradioButton);
            this.Controls.Add(this.physicalModelradioButton);
            this.Controls.Add(this.previewPictureBox3D);
            this.Controls.Add(this.parametersDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ObjectViewerForm";
            this.ShowInTaskbar = false;
            this.Text = "Object Viewer";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ObjectViewerForm_FormClosed);
            this.Load += new System.EventHandler(this.ObjectViewerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.parametersDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView parametersDataGridView;
        private PictureBox3D previewPictureBox3D;
		private System.Windows.Forms.RadioButton physicalModelradioButton;
		private System.Windows.Forms.RadioButton analyticalModelradioButton;
    }
}