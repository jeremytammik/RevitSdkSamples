//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


namespace Revit.SDK.Samples.ObjectViewer.CS
{
	using System;
	using System.Collections.Generic;
	using System.Text;
	using System.Drawing;
	using System.Drawing.Drawing2D;

	using Autodesk.Revit.Structural;
	using Autodesk.Revit.Geometry;


	/// <summary>
	/// utility class provide arithmetic of matrix
	/// </summary>
	public class MathUtil
	{
		/// <summary>
		/// multiply cross two matrix
		/// </summary>
		/// <param name="m1">left matrix</param>
		/// <param name="m2">right matrix</param>
		/// <returns>result matrix</returns>
		public static double[,] MultiCross(double[,] m1, double[,] m2)
		{
			double[,] result = new double[3, 3];

			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					for (int k = 0; k < 3; k++)
					{
						result[i, j] += m1[i, k] * m2[k, j];
					}
				}
			}

			return result;
		}

		/// <summary>
		/// multiply cross two matrix
		/// </summary>
		/// <param name="m1">left matrix</param>
		/// <param name="m2">right matrix</param>
		/// <returns>result matrix</returns>
		public static XYZ[] MultiCross(XYZ[] m1, XYZ[] m2)
		{
			XYZ[] result = new XYZ[3];

			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					for (int k = 0; k < 3; k++)
					{
						switch (j)
						{
							case 0:
								(result[i]).X += (m1[i])[k] * (m2[k])[j];
								break;
							case 1:
								(result[i]).Y += (m1[i])[k] * (m2[k])[j];
								break;
							case 2:
								(result[i]).Z += (m1[i])[k] * (m2[k])[j];
								break;
							default:
								break;
						}
					}
				}
			}

			return result;
		}

		/// <summary>
		/// subtraction of two XYZ as Matrix
		/// </summary>
		/// <param name="p1"></param>
		/// <param name="p2"></param>
		/// <returns></returns>
		public static XYZ SubXYZ(XYZ p1, XYZ p2)
		{
			double x = p1.X - p2.X;
			double y = p1.Y - p2.Y;
			double z = p1.Z - p2.Z;

			XYZ result = new XYZ(x, y, z);
			return result;
		}

		/// <summary>
		/// subtraction of two XYZ as Matrix
		/// </summary>
		/// <param name="p1"></param>
		/// <param name="p2"></param>
		/// <returns></returns>
		public static XYZ AddXYZ(XYZ p1, XYZ p2)
		{
			double x = p1.X + p2.X;
			double y = p1.Y + p2.Y;
			double z = p1.Z + p2.Z;

			XYZ result = new XYZ(x, y, z);
			return result;
		}
	}
}
