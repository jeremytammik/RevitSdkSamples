//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


namespace Revit.SDK.Samples.ObjectViewer.CS
{
	using System;
	using System.Collections.Generic;
	using System.Text;
	using System.Drawing;
	using System.Drawing.Drawing2D;

    using Autodesk.Revit;
    using Autodesk.Revit.Elements;
	using Autodesk.Revit.Structural;
	using Autodesk.Revit.Geometry;

    using Element = Autodesk.Revit.Element;
    using GeoElement = Autodesk.Revit.Geometry.Element;

	/// <summary>
	/// generate GraphicsData by give geometry object
	/// </summary>
	public class ModelDataFactory
	{

        private GraphicsData m_graphicsData = null;

        /// <summary>
        /// Graphics data for GDI
        /// </summary>
        public GraphicsData GraphicsData
        {
            get
            {
                return m_graphicsData;
            }
        }

        /// <summary>
        /// Generate appropriate format graphics data for GDI.
        /// </summary>
        /// <param name="element">The selected element maybe has analytical model lines</param>
        public void GenerateGraphicsData(Element element)
        {
            try
            {
                m_graphicsData = PreGraphicsDataForAnalyticalModel(element);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get the analytical model object from an element.
        /// </summary>
        /// <param name="element">The selected element maybe has analytical model lines</param>
        /// <returns>Return analytical model object, or else return null.</returns>
        private AnalyticalModel PreAnalyticalModel(Element element)
        {
            AnalyticalModel analyticalModel = null;
            //find out the type of the element 
            switch (element.GetType().Name.ToString())
            {
                //it is a family instance
                case "FamilyInstance":
                    FamilyInstance familyComponet = element as FamilyInstance;
                    if (null != element as FamilyInstance)
                    {
                        // get the familyinstance's analytical model
                        analyticalModel = familyComponet.AnalyticalModel;
                    }
                    break;
                //it is a wall
                case "Wall":
                    Wall wall = element as Wall;
                    if (null != wall)
                    {
                        // get the wall's analytical model
                        analyticalModel = wall.AnalyticalModel;
                    }
                    break;
                //it is a cont footing
                case "ContFooting":
                    ContFooting contFooting = element as ContFooting;
                    if (null != contFooting)
                    {
                        // get the contfoot's analytical model
                        analyticalModel = contFooting.AnalyticalModel;
                    }
                    break;
                //it is a floor
                case "Floor":
                    Floor floor = element as Floor;
                    if (null != floor)
                    {
                        // get the floor's analytical model
                        analyticalModel = floor.AnalyticalModel;
                    }
                    break;
                //else break
                default:
                    analyticalModel = null;
                    break;
            }

            return analyticalModel;
        }

        /// <summary>
        /// Generate appropriate graphics data object from exact analytical model type.
        /// </summary>
        /// <param name="element">The selected element maybe has analytical model lines</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData PreGraphicsDataForAnalyticalModel(Element element)
        {
            AnalyticalModel analyticalMode = PreAnalyticalModel(element);
            GraphicsData graphics = null;
            if (null == analyticalMode)
                return null;
            

            switch (analyticalMode.GetType().Name)
            {
                case "AnalyticalModel3D":
                    AnalyticalModel3D ThreeDimension = analyticalMode as AnalyticalModel3D;
                    graphics = CreateGraphicsData(ThreeDimension);
                    break;
                case "AnalyticalModelFloor":
                    AnalyticalModelFloor floor = analyticalMode as AnalyticalModelFloor;
                    graphics = CreateGraphicsData(floor);
                    break;
                case "AnalyticalModelWall":
                    AnalyticalModelWall wall = analyticalMode as AnalyticalModelWall;
                    graphics = CreateGraphicsData(wall);
                    break;
                case "AnalyticalModelFrame":
                    AnalyticalModelFrame frame = analyticalMode as AnalyticalModelFrame;
                    graphics = CreateGraphicsData(frame);
                    break;
                case "AnalyticalModelLocation":
                    AnalyticalModelLocation location = analyticalMode as AnalyticalModelLocation;
                    graphics = CreateGraphicsData(location);
                    break;
                case "AnalyticalModelProfile":
                    AnalyticalModelProfile profiel = analyticalMode as AnalyticalModelProfile;
                    graphics = CreateGraphicsData(profiel);
                    break;
            }

            return graphics;
        }

		/// <summary>
		/// create GraphicsData of give AnalyticalModel3D
		/// </summary>
		/// <param name="model">AnalyticalModel3D contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModel3D model)
        {
            GraphicsData data = new GraphicsData();

            CurveArrayIterator curves = model.Curves.ForwardIterator();
            curves.Reset();
            while (curves.MoveNext())
            {
                Curve curve = curves.Current as Curve;

                try
                {
                    XYZArray points = curve.Tessellate();
                    data.InsertCurve(points);
                }
                catch
                {
                }
            }
            data.UpdataData();

            return data;
        }

        /// <summary>
        /// create GraphicsData of give AnalyticalModelFloor
        /// </summary>
        /// <param name="model">AnalyticalModelFloor contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModelFloor model)
        {
            GraphicsData data = new GraphicsData();

            CurveArrayIterator curves = model.Curves.ForwardIterator();
            curves.Reset();
            while (curves.MoveNext())
            {
                Curve curve = curves.Current as Curve;

                try
                {
                    XYZArray points = curve.Tessellate();
                    data.InsertCurve(points);
                }
                catch
                {
                }
            }
            data.UpdataData();

            return data;
        }

        /// <summary>
        /// create GraphicsData of give AnalyticalModelWall
        /// </summary>
        /// <param name="model">AnalyticalModelWall contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModelWall model)
        {
            GraphicsData data = new GraphicsData();

            CurveArrayIterator curves = model.Curves.ForwardIterator();
            curves.Reset();
            while (curves.MoveNext())
            {
                Curve curve = curves.Current as Curve;

                try
                {
                    XYZArray points = curve.Tessellate();
                    data.InsertCurve(points);
                }
                catch
                {
                }
            }
            data.UpdataData();

            return data;
        }

        /// <summary>
        /// create GraphicsData of give AnalyticalModelFrame
        /// </summary>
        /// <param name="model">AnalyticalModelFrame contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModelFrame model)
        {
            GraphicsData data = new GraphicsData();

            Curve curve = model.Curve;

            try
            {
                XYZArray points = curve.Tessellate();
                data.InsertCurve(points);
            }
            catch
            {
            }
            data.UpdataData();

            return data;
        }

        /// <summary>
        /// create GraphicsData of give AnalyticalModelLocation
        /// </summary>
        /// <param name="model">AnalyticalModelLocation contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModelLocation model)
        {
            GraphicsData data = new GraphicsData();

            try
            {
                XYZArray points = new XYZArray();
                XYZ point = model.Point;
                points.Append(ref point);
                data.InsertCurve(points);
            }
            catch
            {
            }
            data.UpdataData();

            return data;
        }

        /// <summary>
        /// create GraphicsData of give AnalyticalModelProfile
        /// </summary>
        /// <param name="model">AnalyticalModelProfile contains geometry data</param>
        /// <returns>A graphics data object appropriate for GDI.</returns>
        private GraphicsData CreateGraphicsData(AnalyticalModelProfile model)
        {
            GraphicsData data = new GraphicsData();

            CurveArrayIterator curves = model.SweptProfile.Curves.ForwardIterator();
            curves.Reset();
            while (curves.MoveNext())
            {
                Curve curve = curves.Current as Curve;

                try
                {
                    XYZArray points = curve.Tessellate();
                    data.InsertCurve(points);
                }
                catch
                {
                }
            }
            data.UpdataData();

            return data;
        }
	}
}
