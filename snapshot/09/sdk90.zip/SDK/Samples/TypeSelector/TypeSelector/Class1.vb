'      Copyright (c) 2006 by Autodesk, Inc.

'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.
'
' TypeSelector - This sample shows how the type of a selected element, 
' such as a wall can be changed using the API.
'

Option Explicit On
Imports System
Imports Autodesk.Revit

Public Class Command

    Implements Autodesk.Revit.IExternalCommand

        Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute
        Dim result As Autodesk.Revit.IExternalCommand.Result
        result = Autodesk.Revit.IExternalCommand.Result.Failed

        Dim selectionObject As Autodesk.Revit.Selection
        Dim selection As Autodesk.Revit.ElementSet
        selectionObject = commandData.Application.ActiveDocument.Selection
        selection = selectionObject.Elements

        Debug.Write(selection.IsEmpty)

        'if one component is not selected then throw a wobbly
        If (selection.Size <> 1) Then
            message = "A single component or wall must be selected"
        Else
            Dim element As Autodesk.Revit.Element = Nothing
            Dim iter As IEnumerator
            iter = selection.ForwardIterator
            Do While iter.MoveNext
                element = iter.Current
            Loop

            If Not (TypeOf element Is Autodesk.Revit.Elements.FamilyInstance Or TypeOf element Is Autodesk.Revit.Elements.Wall) Then
                message = "A component or wall must be selected"
            Else
                Dim dialog As New TypeSelectorWindow
                dialog.Initialise(commandData.Application.ActiveDocument, element)
                dialog.ShowDialog()
                result = dialog.m_result
                message = dialog.m_resultMessage
            End If

        End If

    End Function

End Class
