Autodesk Revit API application: Version Checking

This sample uses Visual Studio .NET 2005 C# to displays the vertion information 
about Revit in a dialog. The information include  product name, version and build number.