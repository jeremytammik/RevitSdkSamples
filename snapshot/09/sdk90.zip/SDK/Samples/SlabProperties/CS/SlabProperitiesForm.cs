//
// (C) Copyright 1994-2005 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


/// <summary>
/// Show some properties of a slab in Revit Structure2, including Level, Type name, Span divection,
/// Material name, Thickness, and Young Modulus for each layer of the slab's materiral. 
/// </summary>

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Revit.SDK.Samples.SlabProperties.CS
{
	/// <summary>
	/// Summary description for SlabPropertiesForm.
	/// </summary>
	public class SlabPropertiesForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox layerGroupBox;
		private System.Windows.Forms.RichTextBox layerRichTextBox;
		private System.Windows.Forms.Label levelLabel;
		private System.Windows.Forms.Label typeNameLabel;
		private System.Windows.Forms.Label spanDirectionLabel;
		private System.Windows.Forms.TextBox levelTextBox;
		private System.Windows.Forms.TextBox typeNameTextBox;
		private System.Windows.Forms.TextBox spanDirectionTextBox;
		private System.Windows.Forms.Button closeButton;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		// To store the datas
		private SlabProperties m_dataBuffer;

		public SlabPropertiesForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// overload the constructor
		/// </summary>
		/// <param name="dataBuffer">To store the datas of a slab</param>
		public SlabPropertiesForm(SlabProperties dataBuffer)
		{
			InitializeComponent();
			m_dataBuffer = dataBuffer;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(null != components)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.layerGroupBox = new System.Windows.Forms.GroupBox();
			this.layerRichTextBox = new System.Windows.Forms.RichTextBox();
			this.levelLabel = new System.Windows.Forms.Label();
			this.levelTextBox = new System.Windows.Forms.TextBox();
			this.typeNameTextBox = new System.Windows.Forms.TextBox();
			this.spanDirectionTextBox = new System.Windows.Forms.TextBox();
			this.typeNameLabel = new System.Windows.Forms.Label();
			this.spanDirectionLabel = new System.Windows.Forms.Label();
			this.closeButton = new System.Windows.Forms.Button();
			this.layerGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// layerGroupBox
			// 
			this.layerGroupBox.Controls.Add(this.layerRichTextBox);
			this.layerGroupBox.Location = new System.Drawing.Point(22, 193);
			this.layerGroupBox.Name = "layerGroupBox";
			this.layerGroupBox.Size = new System.Drawing.Size(442, 286);
			this.layerGroupBox.TabIndex = 29;
			this.layerGroupBox.TabStop = false;
			this.layerGroupBox.Text = "Layers:";
			// 
			// layerRichTextBox
			// 
			this.layerRichTextBox.Location = new System.Drawing.Point(32, 32);
			this.layerRichTextBox.Name = "layerRichTextBox";
			this.layerRichTextBox.Size = new System.Drawing.Size(384, 232);
			this.layerRichTextBox.TabIndex = 2;
			this.layerRichTextBox.Text = "";
			// 
			// levelLabel
			// 
			this.levelLabel.Location = new System.Drawing.Point(31, 32);
			this.levelLabel.Name = "levelLabel";
			this.levelLabel.Size = new System.Drawing.Size(80, 23);
			this.levelLabel.TabIndex = 27;
			this.levelLabel.Text = "Level:";
			// 
			// levelTextBox
			// 
			this.levelTextBox.Location = new System.Drawing.Point(134, 33);
			this.levelTextBox.Name = "levelTextBox";
			this.levelTextBox.Size = new System.Drawing.Size(280, 20);
			this.levelTextBox.TabIndex = 24;
			this.levelTextBox.Text = "";
			// 
			// typeNameTextBox
			// 
			this.typeNameTextBox.Location = new System.Drawing.Point(134, 89);
			this.typeNameTextBox.Name = "typeNameTextBox";
			this.typeNameTextBox.Size = new System.Drawing.Size(280, 20);
			this.typeNameTextBox.TabIndex = 22;
			this.typeNameTextBox.Text = "";
			// 
			// spanDirectionTextBox
			// 
			this.spanDirectionTextBox.Location = new System.Drawing.Point(134, 145);
			this.spanDirectionTextBox.Name = "spanDirectionTextBox";
			this.spanDirectionTextBox.Size = new System.Drawing.Size(280, 20);
			this.spanDirectionTextBox.TabIndex = 23;
			this.spanDirectionTextBox.Text = "";
			// 
			// typeNameLabel
			// 
			this.typeNameLabel.Location = new System.Drawing.Point(30, 89);
			this.typeNameLabel.Name = "typeNameLabel";
			this.typeNameLabel.Size = new System.Drawing.Size(72, 23);
			this.typeNameLabel.TabIndex = 25;
			this.typeNameLabel.Text = "Type Name:";
			// 
			// spanDirectionLabel
			// 
			this.spanDirectionLabel.Location = new System.Drawing.Point(30, 145);
			this.spanDirectionLabel.Name = "spanDirectionLabel";
			this.spanDirectionLabel.Size = new System.Drawing.Size(88, 23);
			this.spanDirectionLabel.TabIndex = 26;
			this.spanDirectionLabel.Text = "Span Direction:";
			// 
			// closeButton
			// 
			this.closeButton.Location = new System.Drawing.Point(207, 511);
			this.closeButton.Name = "closeButton";
			this.closeButton.TabIndex = 28;
			this.closeButton.Text = "Close";
			this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
			// 
			// SlabPropertiesForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(486, 567);
			this.Controls.Add(this.layerGroupBox);
			this.Controls.Add(this.levelLabel);
			this.Controls.Add(this.levelTextBox);
			this.Controls.Add(this.typeNameTextBox);
			this.Controls.Add(this.spanDirectionTextBox);
			this.Controls.Add(this.typeNameLabel);
			this.Controls.Add(this.spanDirectionLabel);
			this.Controls.Add(this.closeButton);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SlabPropertiesForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Slab Properties";
			this.Load += new System.EventHandler(this.SlabPropertiesForm_Load);
			this.layerGroupBox.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Close the Form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void closeButton_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		/// <summary>
		/// Display the properties on the form when the form load
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void SlabPropertiesForm_Load(object sender, System.EventArgs e)
		{
			this.levelTextBox.Text = m_dataBuffer.Level;
			this.typeNameTextBox.Text = m_dataBuffer.TypeName;
			this.spanDirectionTextBox.Text = m_dataBuffer.SpanDirection;

			int numberOfLayers = m_dataBuffer.NumberOfLayers;

			this.layerRichTextBox.Text = "";

			for (int i=0 ; i < numberOfLayers ; i++)
			{
				// Get each layer's Material name and Young Modulus properties
				m_dataBuffer.SetLayer(i);	

				this.layerRichTextBox.Text += "Layer " + (i+1).ToString() + "\n";
				this.layerRichTextBox.Text += "Material name:  " + m_dataBuffer.LayerMaterialName + "\n";
				this.layerRichTextBox.Text += "Thickness: " + m_dataBuffer.LayerThickness + "\n";
				this.layerRichTextBox.Text += "YoungModulus X:  " + m_dataBuffer.LayerYoungModulusX + "\n";
				this.layerRichTextBox.Text += "YoungModulus Y:  " + m_dataBuffer.LayerYoungModulusY + "\n";
				this.layerRichTextBox.Text += "YoungModulus Z:  " + m_dataBuffer.LayerYoungModulusZ + "\n";
				this.layerRichTextBox.Text += "-----------------------------------------------------------" + "\n";
			}
		}
	}
}
