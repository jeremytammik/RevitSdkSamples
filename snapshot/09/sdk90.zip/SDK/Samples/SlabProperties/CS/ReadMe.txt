Autodesk Revit API application: SlabProperties

The function of the program is to show some main properies of each slab object via the API.

1. Open the SlabProperties project. Make sure the added RevitAPI under the References and have a right file path. 

2. Modify the Revit.ini file in your Revit installation directory. You may refer to the supplied  Revit.ini file.

3. Launch the Revit.exe, the Slab Properties command has be added in the External Commands item under the Tools menu.

4. Draw a slab object and select it, click the Slab Properties command. The Slab Properties dialog displays the main properties of the selected slab.