Autodesk Revit API application:CreateSimpleAreaReinforcement

This sample uses Visual studio .NET 2005 C#

This sample will provide the following functionality:
	Create an Area Reinforcement in a rectangular shape on the selected slab or wall. The boundary would be the same as the slab/wall boundaries. The application can verify the boundary of the selected slab/wall is rectangular.
	A dialog to the user asking for the following information:
	All the instance Parameters that are listed in the ��Construction�� Parameter Group:
	Layout Rule
	All the instance Parameters that are listed in the ��Structural�� Parameter Group:
	Estimated Reinforcement Volume (Read-Only)
	All the Layers are listed in the ��Layer�� Parameter Group. There are four layers. Each layer should include Top (Bottom) Major (Minor) Direction
