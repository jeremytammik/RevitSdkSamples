'
'	Revit API Sample Program: RevitCommands
'
'	Written by mh. July, 2005 
'
'	Last modified: Feb. 22, 2006 by mh. 
' 
'

A collection of small commands to show some function usage: 

Load Family        -  loads a family of the given family name. 
Load Family Symbol -  loads a family symbol/type of the given file and the symbol name.
Selection          -  shows the access to the current selection set.
Library Path       -   This sample goes through the list of library paths held in the Revit. 
                       If it has a certain key, it erases it.  If not, it adds a new path to the existing set. 
		       In the Revit UI, you can check the list in: 
                       Settings --> Options... --> [File Locations] Tab --> Libraries.  
Show Element Data  -  displays a geometry, location, parameter data of selected elements if any.  

This also includes some helper functions, which may become convenient for quick testing. 