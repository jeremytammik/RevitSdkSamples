'      .NET Sample
'
'      Copyright (c) 2006 by Autodesk, Inc.
'
'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.
'

'
'  ShowElementData - displays a few data of selected elements.   
'
Imports System

Imports Autodesk
Imports Autodesk.Revit
Imports Autodesk.Revit.Application
Imports Autodesk.Revit.Elements
Imports Autodesk.Revit.Geometry

'
' Show Element Data - show a few data of selected elements.
'

Public Class RvtCmd_ShowElementData

    Implements Revit.IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Revit.ElementSet) As Revit.IExternalCommand.Result Implements Revit.IExternalCommand.Execute

        Dim rvtApp As Autodesk.Revit.Application = commandData.Application

        '  get a list of selected elements. 
        Dim selSet As Revit.ElementSet = rvtApp.ActiveDocument.Selection.Elements

        '  how many did you get? 
        MsgBox("the number of element selected:" & selSet.Size)

        '  look at each of them.
        Dim elem As Revit.Element
        For Each elem In selSet

            '  show the type. 
            MsgBox(elem.GetType.ToString)

            '  location
            RvtUtils.ListLocation(elem)

            '  geometry
            RvtUtils.ListGeometry(rvtApp, elem)

            '  parameters
            RvtUtils.ListParameters(elem)

        Next

        ' finishing up.
        Return Autodesk.Revit.IExternalCommand.Result.Succeeded

    End Function

End Class

