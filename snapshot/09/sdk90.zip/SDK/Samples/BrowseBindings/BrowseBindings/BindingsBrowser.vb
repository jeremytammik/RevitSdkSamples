'     .NET Sample

'      Copyright (c) 2006 by Autodesk, Inc.

'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.
'
' BrowseBindings - This program demonstrates the usage of parameter binding map.
'

Option Explicit On 
Imports System.Runtime

Public Class BindingsBrowser
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents BindingsTree As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.BindingsTree = New System.Windows.Forms.TreeView
        Me.SuspendLayout()
        '
        'BindingsTree
        '
        Me.BindingsTree.ImageIndex = -1
        Me.BindingsTree.Indent = 38
        Me.BindingsTree.Location = New System.Drawing.Point(8, 8)
        Me.BindingsTree.Name = "BindingsTree"
        Me.BindingsTree.SelectedImageIndex = -1
        Me.BindingsTree.Size = New System.Drawing.Size(288, 328)
        Me.BindingsTree.TabIndex = 0
        '
        'BindingsBrowser
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 341)
        Me.Controls.Add(Me.BindingsTree)
        Me.Name = "BindingsBrowser"
        Me.Text = "BindingsBrowser"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private m_application As Autodesk.Revit.Application
    Private m_initialised As Boolean

    Public Sub Initialise(ByVal Application As Autodesk.Revit.Application)

        m_application = Application
        If Not (m_application Is Nothing) Then
            m_initialised = True
        End If

        LoadBindings()

    End Sub

    Public Property Initialised() As Boolean
        Get
            Initialised = m_initialised
        End Get
        Set(ByVal Value As Boolean)

        End Set
    End Property

    Public Property Document() As Autodesk.Revit.Document
        Get
            Document = m_application.ActiveDocument
        End Get
        Set(ByVal Value As Autodesk.Revit.Document)

        End Set
    End Property

    Public Property Application() As Autodesk.Revit.Application
        Get
            Application = m_application
        End Get
        Set(ByVal Value As Autodesk.Revit.Application)

        End Set
    End Property

    'Private Sub LoadBindings()

    '    Dim bindingsRoot As System.Windows.Forms.TreeNode
    '    bindingsRoot = Me.BindingsTree.Nodes.Add("Bindings")

    '    Dim bindingsMap As Autodesk.Revit.Parameters.BindingMap
    '    bindingsMap = Document.ParameterBindings

    '    Dim iterator As System.Collections.IEnumerator
    '    iterator = bindingsMap.ForwardIterator

    '    Do While (iterator.MoveNext)

    '        Dim binding As Autodesk.Revit.Parameters.Binding
    '        binding = iterator.Current

    '        Dim definition As Autodesk.Revit.Parameters.Definition
    '        Dim mapIterator As Autodesk.Revit.Collections.DefinitionBindingMapIterator
    '        mapIterator = iterator
    '        definition = mapIterator.Key

    '        Dim definitionNode As System.Windows.Forms.TreeNode
    '        definitionNode = bindingsRoot.Nodes.Add(definition.Name)

    '        If (TypeOf binding Is Autodesk.Revit.Parameters.ElementBinding) Then
    '            Dim elementBinding As Autodesk.Revit.Parameters.ElementBinding
    '            elementBinding = binding

    '            Dim categories As Autodesk.Revit.CategorySet
    '            categories = elementBinding.Categories

    '            Dim category As Autodesk.Revit.Category
    '            For Each category In categories
    '                definitionNode.Nodes.Add(category.Name)
    '            Next
    '        End If
    '    Loop

    'End Sub

    Private Sub LoadBindings_org()
        Dim bindingsRoot As System.Windows.Forms.TreeNode
        bindingsRoot = Me.BindingsTree.Nodes.Add("Bindings")

        Dim bindingsMap As Autodesk.Revit.Parameters.BindingMap
        bindingsMap = Document.ParameterBindings

        Dim iterator As Autodesk.Revit.Collections.DefinitionBindingMapIterator
        iterator = bindingsMap.ForwardIterator

        Do While (iterator.MoveNext)
            Dim elementBinding As Autodesk.Revit.Parameters.ElementBinding
            elementBinding = iterator.Current

            Dim definition As Autodesk.Revit.Parameters.Definition
            definition = iterator.Key

            Dim definitionNode As System.Windows.Forms.TreeNode
            definitionNode = bindingsRoot.Nodes.Add(definition.Name)

            If (Not elementBinding Is Nothing) Then
                Dim categories As Autodesk.Revit.CategorySet
                categories = elementBinding.Categories

                Dim category As Autodesk.Revit.Category
                For Each category In categories
                    definitionNode.Nodes.Add(category.Name)
                Next
            End If
        Loop
    End Sub

    Private Sub LoadBindings()
        Dim bindingsRoot As System.Windows.Forms.TreeNode
        bindingsRoot = Me.BindingsTree.Nodes.Add("Bindings")

        Dim bindingsMap As Autodesk.Revit.Parameters.BindingMap
        bindingsMap = Document.ParameterBindings

        Dim iterator As Autodesk.Revit.Collections.DefinitionBindingMapIterator
        iterator = bindingsMap.ForwardIterator

        Do While (iterator.MoveNext)
            Dim elementBinding As Autodesk.Revit.Parameters.ElementBinding
            elementBinding = iterator.Current

            ' get the name of the parameter 
            Dim definition As Autodesk.Revit.Parameters.Definition
            definition = iterator.Key

            Dim definitionNode As System.Windows.Forms.TreeNode = Nothing

            '  Note: the description of parameter binding is as follows:
            '  "a parameter definition is bound to elements within one or more categories."
            '  But this seems to return a one-to-one map.  
            '  The following for loop is a workaround. 

            '  do we have it in the node? 
            '  if yes, use the exisiting one. 
            Dim node As System.Windows.Forms.TreeNode
            For Each node In bindingsRoot.Nodes
                If (node.Text = definition.Name) Then
                    definitionNode = node
                End If
            Next

            ' if the new parameter, add a new node. 
            If (definitionNode Is Nothing) Then
                definitionNode = bindingsRoot.Nodes.Add(definition.Name)
            End If

            ' add the category name.  
            If (Not elementBinding Is Nothing) Then
                Dim categories As Autodesk.Revit.CategorySet
                categories = elementBinding.Categories

                Dim category As Autodesk.Revit.Category
                For Each category In categories
                    definitionNode.Nodes.Add(category.Name)
                Next
            End If
        Loop
    End Sub


    Private Sub Form_Load()

        If Not (Me.Initialised) Then
            Exit Sub
        End If

        LoadBindings()

    End Sub
End Class
