'
'	Revit API Sample Program: BrowseBindings 
'
'	Migrated by tn. Jan. 26, 2006 
'
'	Last modified: Feb. 18, 2006 by mh. 
' 
'

Subject: Parameter Bindings  

Classes: Autodesk.Revit.Parameters.ElementBinding, Autodesk.Revit.Parameters.BindingMap, Autodesk.Revit.Collections.DefinitionBindingMapIterator, Autodesk.Revit.Parameters.Definition.  

Description: This program demonstrates the usage of parameter binding map.

Usage: 

(1) add a few parameters to the project, and run the external command.   
It will show a tree view of a parameter to categories map.

For an example of defining new parameters and adding to new and existing elements within the project, please see FireRating sample. 

For more details on shared parameters please see the Revit help files.

Note: 
The description of parameter binding is as follows:
"a parameter definition is bound to elements within one or more categories."
But this seems to return a one-to-one map.  This program works around it by checking the name of parameter. 
