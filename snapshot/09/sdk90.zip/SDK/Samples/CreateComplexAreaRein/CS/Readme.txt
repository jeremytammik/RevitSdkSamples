Autodesk Revit API application:CreateComplexAreaReinforcement

This sample uses Visual studio .NET 2005 C#

This sample will provide the following functionality:
Make a slab reinforcement with all four layers, and with two rectangular curve loops, nested, so that we have a rectangular opening.
On the interior 4 curves, set the override flag and flip the hooks on the top 2 layers to ��up,�� so the bars can hook into some walls around that opening.?

