// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


namespace Revit.SDK.Samples.CreateComplexAreaRein.CS
{
	using System;
	using System.Collections.Generic;
	using System.Text;
	using System.Windows.Forms;

	using Autodesk.Revit;
	using Autodesk.Revit.Parameters;
	using Autodesk.Revit.Elements;
	using Autodesk.Revit.Geometry;
	using Autodesk.Revit.Symbols;

	using DocCreator = Autodesk.Revit.Creation.Document;

	
	public class CreateComplexAreaRein : IExternalCommand
	{
		private Document m_currentDoc;
		private static ExternalCommandData m_revit;
		private AreaReinData m_data;

		/// <summary>
		/// Application entry point implements IExternalCommand's method Execute
		/// </summary>
		/// <param name="revit">The revit object for the active instance of Autodesk Revit.</param>
		/// <param name="message">A message that can be set by the external command and displayed in case of error.</param>
		/// <param name="elements">A set of elements that can be displayed if an error occurs.</param>
		/// <returns>A value that signifies if your command was successful, failed or the user wishes to cancel.</returns>
		public IExternalCommand.Result Execute(ExternalCommandData revit, ref string message, ElementSet elements)
		{
			//initialize members
			m_revit = revit;
			m_currentDoc = revit.Application.ActiveDocument;
			m_data = new AreaReinData();

			try
			{
				//check precondition and prepare necessary data to create AreaReinforcement.
				Reference refer = null;
				CurveArray curves = null;
				Floor floor = InitFloor(ref refer, ref curves);
				InitAreaReinType();

				//ask for user's input
				AreaReinData dataOnFloor = new AreaReinData();
				dataOnFloor.AreaReinTypes = m_data.AreaReinTypes;
				CreateComplexAreaReinForm createForm = new CreateComplexAreaReinForm(dataOnFloor);
				if (createForm.ShowDialog() == DialogResult.OK)
				{
					//create
					AreaReinforcementType symbol = dataOnFloor.AreaReinType as AreaReinforcementType;
					DocCreator creator = m_revit.Application.ActiveDocument.Create;
					AreaReinforcement areaRein = creator.NewAreaReinforcement(symbol, floor, refer, curves);
					//set AreaReinforcement and it's AreaReinforcementCurves parameters
					dataOnFloor.FillIn(areaRein);
					return IExternalCommand.Result.Succeeded;
				}				
			}
			catch (ApplicationException appEx)
			{
				message = appEx.Message;
				return IExternalCommand.Result.Failed;
			}
			catch
			{
				message = "Unknow Errors.";
				return IExternalCommand.Result.Failed;
			}
			return IExternalCommand.Result.Cancelled;
		}

		/// <summary>
		/// ExternalCommandData
		/// </summary>
		public static ExternalCommandData CommandData
		{
			get
			{
				return m_revit;
			}
		}

		/// <summary>
		/// iterate all AreaReinforcementTypes in current project
		/// </summary>
		private void InitAreaReinType()
		{
			ElementIterator itor = m_currentDoc.Elements;
			itor.Reset();
			while (itor.MoveNext())
			{
				AreaReinforcementType symbol = itor.Current as AreaReinforcementType;
				if (null != symbol)
				{
					m_data.AreaReinTypes.Add(symbol);
				}
			}
			//no AreaReinForcementSymbol in current project
			if (m_data.AreaReinTypes.Count == 0)
			{
				string msg = "No Family of AreaReinForcement has been loaded in current project.";
				ApplicationException appEx = new ApplicationException(msg);
				throw appEx;
			}
		}

		/// <summary>
		/// initialize member data, judge simple precondition
		/// </summary>
		private Floor InitFloor(ref Reference refer, ref CurveArray curves)
		{
			ElementSet elems = m_currentDoc.Selection.Elements;
			//selected 0 or more than 1 element
			if (elems.Size != 1)
			{
				string msg = "Please selecte exactly one floor.";
				ApplicationException appEx = new ApplicationException(msg);
				throw appEx;
			}
			Floor floor = null;
			foreach (object o in elems)
			{
				//selected one floor
				floor = o as Floor;
				if (null == floor)
				{
					string msg = "Please selecte exactly one floor.";
					ApplicationException appEx = new ApplicationException(msg);
					throw appEx;	
				}
			}
			//check the shape is rectangular and get its edges
			GeomHelper helper = new GeomHelper();
			if (!helper.GetFloorGeom(floor, ref refer, ref curves))
			{
				ApplicationException appEx = new ApplicationException("Your selection is not a horizontal rectangular structural slab.");
				throw appEx;
			}

			return floor;
		}
	}
}
