Autodesk Revit API application: DeleteDimensions

This is a really minimal sample that add a command that given a selection deletes all the unpinned dimensions that are found in that selection.

To build the *.dll, edit project properties and make sure additional reference component include the RevitAPI.dll in Revit installation directory.
Then, paste the contents of Revit.ini into Revit.ini. Launch Revit, note the Tools -> External Commands menu.
