Autodesk Revit API application: Reinforcement

1. Create bar set in a selected concrete element(beam or column) that does not have any reinforcement.
2. Beam rebar should be three kinds: top rebar, bottom rebar and transverse rebar.
3. Column rebar should be two kinds: transverse rebar and vertical rebar