//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.


using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit.Geometry;

namespace Revit.SDK.Samples.Reinforcement.CS
{
   #region Struct Definition

   /// <summary>
   /// a struct to store the geometry information of the rebar
   /// </summary>
   public struct RebarGeometry
   {
      // Private members
      XYZ m_origin; //the origin of the plane that the rebar curves lie on
      XYZ m_normal; //the normal of the plane that the rebar curves lie on
      CurveArray m_curves; //the profile of the rebar
      int m_number;        //the number of the rebar
      double m_spacing;    //the spacing of the rebar                                                                               

      /// <summary>
      /// get and set the value of origin
      /// </summary>
      public XYZ Origin
      {
         get
         {
            return m_origin;
         }
         set
         {
            m_origin = value;
         }
      }

      /// <summary>
      /// get and set the value of the normal
      /// </summary>
      public XYZ Normal
      {
         get
         {
            return m_normal;
         }
         set
         {
            m_normal = value;
         }
      }

      /// <summary>
      /// get and set the value of curve array
      /// </summary>
      public CurveArray Curves
      {
         get
         {
            return m_curves;
         }
         set
         {
            m_curves = value;
         }
      }

      /// <summary>
      /// get and set the number of the rebar
      /// </summary>
      public int RebarNumber
      {
         get
         {
            return m_number;
         }
         set
         {
            m_number = value;
         }
      }

      /// <summary>
      /// get and set the value of the rebar spacing 
      /// </summary>
      public double RebarSpacing
      {
         get
         {
            return m_spacing;
         }
         set
         {
            m_spacing = value;
         }
      }

      /// <summary>
      /// consturctor
      /// </summary>
      /// <param name="origin">the origin information</param>
      /// <param name="normal">the normal information</param>
      /// <param name="curves">the profile of the rebars</param>
      /// <param name="number">the number of the rebar</param>
      /// <param name="spacing">the number of the rebar</param>
      public RebarGeometry(XYZ origin, XYZ normal, CurveArray curves, int number, double spacing)
      {
         // initialize the data members
         m_origin = origin;
         m_normal = normal;
         m_curves = curves;
         m_number = number;
         m_spacing = spacing;
      }
   }

   /// <summary>
   /// A struct to store the const data which support beam reinforcement creation
   /// </summary>
   public struct BeamRebarData
   {
      public const double TopEndOffset = 0.2; //offset value of the top end rebar
      public const double TopCenterOffset = 0.23; //offset value of the top center rebar

      public const double TransverseOffset = 0.125; //offset value of the transverse rebar
      public const double TransverseEndOffset = 1.2;//offset value of the end transverse rebar
      //the spacing value between end and center transvers rebar
      public const double TransverseSpaceBetween = 1;

      public const double BottomOffset = 0.271;//offset value of bottom rebar

      public const int BottomRebarNumber = 5; //number of bottom rebar
      public const int TopRebarNumber = 2; //number of top rebar
   }


   /// <summary>
   /// A struct to store the const data which support column reinforcement creation
   /// </summary>
   public struct ColumnRebarData
   {
      public const double TransverseOffset = 0.125; //offset value of transverse rebar
      public const double VerticalOffset = 0.234; // offset value of vertical rebar
   }

   #endregion

   #region Enum Definition
   /// <summary>
   /// Indicate location of top rebar
   /// </summary>
   public enum TopRebarLocation
   {
      Start,
      Center,
      End
   }

   /// <summary>
   /// Indicate location of transverse rebar
   /// </summary>
   public enum TransverseRebarLocation
   {
      Start,
      Center,
      End
   }

   /// <summary>
   /// Indicate location of vertical rebar
   /// </summary>
   public enum VerticalRebarLocation
   {
      North,
      East,
      South,
      West
   }

   /// <summary>
   /// Indicate the hook directions 
   /// </summary>
   public enum HookOrient
   {
      Orient0 = 0,
      Orient1 = 1,
      Orient2 = 2,
      Orient3 = 3
   }
   #endregion

   /// <summary>
   /// A comparer for XYZ, and give a method to sort all the XYZ points in a array
   /// </summary>
   public class XYZHeightComparer : IComparer<XYZ>
   {
      int IComparer<XYZ>.Compare(XYZ first, XYZ second)
      {
         // first compare z coordinate, then y coordinate, at last x coordinate
         if (GeomUtil.IsEqual(first.Z, second.Z))
         {
            if (GeomUtil.IsEqual(first.Y, second.Y))
            {
               if (GeomUtil.IsEqual(first.X, second.X))
               {
                  return 0;
               }
               return (first.X > second.X) ? 1 : -1;
            }
            return (first.Y > second.Y) ? 1 : -1;
         }
         return (first.Z > second.Z) ? 1 : -1;
      }
   }
}
