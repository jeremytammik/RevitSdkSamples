//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Windows.Forms;

using Autodesk.Revit;
using Autodesk.Revit.Elements;

namespace Revit.SDK.Samples.Materials2.CS
{
    /// <summary>
    /// external applications' only entry point class that supports the IExternalCommand interface
    /// </summary>
    public class Command : IExternalCommand
    {
        /// <summary>
        /// The method that is executed when Autodesk Revit calls your external API command.
        /// </summary>
        /// <param name="commandData">The ExternalCommandData object for the active
        /// instance of Autodesk Revit. </param>
        /// <param name="message">A message that can be set by the external command and
        /// displayed in case of error.</param>
        /// <param name="elements">A set of elements that can be displayed if an error occurs.
        /// </param>
        /// <returns>A value that signifies if your command was successful, failed or the user
        /// wishes to cancel.</returns>
        public IExternalCommand.Result Execute(ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            try
            {
                //Retrieves the current active project.
                Document doc = commandData.Application.ActiveDocument;

                // Generate a object for Revit materials management.
                MaterialsMgr materialsManager = new MaterialsMgr(doc);

                // Feed a MaterialsMgr to a dialog.
                using (MaterialsForm dlg = new MaterialsForm(materialsManager))
                {
                    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        // Done some action, ask revit to execute it.
                        return IExternalCommand.Result.Succeeded;
                    }
                    else
                    {
                        // Revit need to do nothing.
                        return IExternalCommand.Result.Cancelled;
                    }
                }                
            }
            catch (Exception e)
            {
                // Exception rised, report it by revit error reporting mechanism. 
                message = e.ToString();
                return IExternalCommand.Result.Failed;
            }
            
        }
    }
}
