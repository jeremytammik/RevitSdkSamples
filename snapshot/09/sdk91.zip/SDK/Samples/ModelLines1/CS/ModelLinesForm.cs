//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Revit.SDK.Samples.ModelLines1.CS
{
    /// <summary>
    /// The form which display some information to the user
    /// </summary>
    public partial class ModelLinesForm : Form
    {
        // Private members
        ModelLines m_dataBuffer;   // A reference of ModelLines.

        // Methods
        /// <summary>
        /// Constructor of ModelLinesForm
        /// </summary>
        /// <param name="dataBuffer">A reference of ModelLines class</param>
        public ModelLinesForm(ModelLines dataBuffer)
        {
            // Required for Windows Form Designer support
            InitializeComponent();

            //Get a reference of ModelLines
            m_dataBuffer = dataBuffer;

            // Initialize the information data grid view control
            InitializeInformationGrid();
        }


        /// <summary>
        /// Bind the DataSource of the information DataGridView
        /// </summary>
        void InitializeInformationGrid()
        {
            // In order to change column name, disable AutoGenerateColumns property
            informationDataGridView.AutoGenerateColumns = false;
            // Bind the DataSource to corresponding property.
            informationDataGridView.DataSource = m_dataBuffer.InformationMap;
            typeColumn.DataPropertyName = "TypeName";   // set data property name
            typeColumn.Width = informationDataGridView.Width * 3 / 5;   // set column width

            numberColumn.DataPropertyName = "Number";   // set data property name
            numberColumn.Width = informationDataGridView.Width * 2 / 5 - 2; // set column with
        }


        /// <summary>
        /// When the user click the create button, invoke method to create ReferencePlane
        /// </summary>
        private void createButton_Click(object sender, EventArgs e)
        {
            // Only invoke the CreateModelLines() method of ModelLines class
            try
            {
                m_dataBuffer.CreateModelLines();
            }
            catch (Exception ex)
            {
                // If some error occur during the creation, just show it
                MessageBox.Show(ex.Message, "Revit");
            }

            // Refresh the informationMap data
            m_dataBuffer.RefreshInformationMap();

            // Refresh the form display.
            this.Refresh();

        }

        /// <summary>
        /// When the user click the close button, just close the form
        /// </summary>
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}