//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.

using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;
using Autodesk.Revit.Elements;

namespace Revit.SDK.Samples.ModelLines1.CS
{
    /// <summary>
    /// The map class which store the data and display in informationDataGridView
    /// </summary>
    public class ModelCurveCounter
    {
        // Private members
        readonly String m_typeName; // type name
        int m_number;               // the number of corresponding type

        // Properties
        /// <summary>
        /// Indicate the type name, such ModelArc, ModelLine, etc
        /// </summary>
        public String TypeName
        {
            get
            {
                return m_typeName;
            }
        }

        /// <summary>
        /// Indicate the number of the corresponding type which name stored in type name
        /// </summary>
        public int Number
        {
            get
            {
                return m_number;
            }
            set
            {
                m_number = value;
            }
        }

        // Methods
        /// <summary>
        /// The constructor of ModelCurveCounter
        /// </summary>
        /// <param name="typeName">The type name</param>
        public ModelCurveCounter(String typeName)
        {
            m_typeName = typeName;
            m_number = 0;
        }

    }
}
