Autodesk Revit API application: ModelLines1

1. Draw some model lines in revit UI.
2. Get all model lines in revit and reports the number of each type.
3. Provide button to create one of each of the following in revit - Arc, Ellipse, Line, HermiteSpline and NurbSpline
4. All created model lines should be on a created sketch plane.

Note: 
Some model lines creation need the existing model line to support. Such as ModelEllipse, ModelHermiteSpline and ModelNurbSpline.