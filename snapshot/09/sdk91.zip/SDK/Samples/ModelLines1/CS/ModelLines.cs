//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.


using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Geometry;

namespace Revit.SDK.Samples.ModelLines1.CS
{
    /// <summary>
    /// The main deal class, which takes charge of showing the number of each model line type
    /// and creating one instance for each type using Revit API
    /// </summary>
    public class ModelLines
    {
        // Private members
        Autodesk.Revit.Application m_revit; // Store the reference of the application in revit
        Autodesk.Revit.Creation.Application m_createApp;// Store the create Application reference
        Autodesk.Revit.Creation.Document m_createDoc;   // Store the create Document reference
        SketchPlane m_workPlane;            // Store the work plane which place model curves on

        ModelCurveArray m_lineArray;        // Store the ModelLine references
        ModelCurveArray m_arcArray;         // Store the ModelArc references
        ModelCurveArray m_ellipseArray;     // Store the ModelEllipse references
        ModelCurveArray m_hermiteArray;     // Store the ModelHermiteSpline references
        ModelCurveArray m_nurbArray;        // Store the ModelNurbSpline references

        List<ModelCurveCounter> m_informationMap;   // Store the number of each model line type

        // Properties
        /// <summary>
        /// The type-number map, store the number of each model line type
        /// </summary>
        public List<ModelCurveCounter> InformationMap
        {
            get
            {
                return m_informationMap;
            }
        }

        // Methods
        /// <summary>
        /// The default constructor
        /// </summary>
        /// <param name="revit">The reference of the application in revit</param>
        public ModelLines(Autodesk.Revit.Application revit)
        {
            // Store the reference of the application for further use.
            m_revit = revit;
            // Get the create references
            m_createApp = m_revit.Create;       // Creation.Application
            m_createDoc = m_revit.ActiveDocument.Create;// Creation.Document

            // Construct all the ModelCurveArray instances for model lines
            m_lineArray = new ModelCurveArray();
            m_arcArray = new ModelCurveArray();
            m_ellipseArray = new ModelCurveArray();
            m_hermiteArray = new ModelCurveArray();
            m_nurbArray = new ModelCurveArray();

            // Construct the information list data
            m_informationMap = new List<ModelCurveCounter>();
        }


        /// <summary>
        /// This is the main deal method in this example.
        /// </summary>
        public void Run()
        {
            // Get all model lines in revit
            GetModelLines();

            // Initialize the InformationMap property for DataGridView display
            InitDisplayInformation();

            // Display the form and allow the user to create one of each model line in revit
            using (ModelLinesForm displayForm = new ModelLinesForm(this))
            {
                displayForm.ShowDialog();
            }
        }


        /// <summary>
        /// Get all model lines in current document of revit, and store them into the arrays
        /// </summary>
        void GetModelLines()
        {
            // Search all elements in current document and find all model lines
            ElementIterator iter = m_revit.ActiveDocument.Elements;
            iter.Reset();
            while (iter.MoveNext())
            {
                // Because the current work plane can not be gotten,
                // So I get every model lines in current project.
                // And I won't use SketchPlane property to judge which plane it is on

                // If the element is not a ModelCurve, just continue
                ModelCurve curve = iter.Current as ModelCurve;
                if (null == curve)
                {
                    continue;
                }

                // Get alll the ModelLines references
                String typeName = curve.GetType().Name;
                switch (typeName)
                {
                    case "ModelLine":   // Get all the ModelLine references
                        m_lineArray.Append(curve);
                        break;
                    case "ModelArc":    // Get all the ModelArc references
                        m_arcArray.Append(curve);
                        break;
                    case "ModelEllipse":// Get all the ModelEllipse references
                        m_ellipseArray.Append(curve);
                        break;
                    case "ModelHermiteSpline":  // Get all the ModelHermiteSpline references
                        m_hermiteArray.Append(curve);
                        break;
                    case "ModelNurbSpline": // Get all the ModelNurbSpline references
                        m_nurbArray.Append(curve);
                        break;
                    default:    // If not a model curve, just break
                        break;
                } 
            }
        }


        void InitDisplayInformation()
        {
            //// First add the type name into the m_information data map
            m_informationMap.Add(new ModelCurveCounter("ModelArc"));
            m_informationMap.Add(new ModelCurveCounter("ModelLine"));
            m_informationMap.Add(new ModelCurveCounter("ModelEllipse"));
            m_informationMap.Add(new ModelCurveCounter("ModelHermiteSpline"));
            m_informationMap.Add(new ModelCurveCounter("ModelNurbSpline"));

            // Use RefreshInformationMap to refresh the number of each model line type
            RefreshInformationMap();
        }



        /// <summary>
        /// Refresh the m_informationMap memeber, including the number of each model line type
        /// </summary>
        public void RefreshInformationMap()
        {
            // Search the model line types in the map, and refresh the number of each type
            foreach (ModelCurveCounter info in m_informationMap)
            {
                switch (info.TypeName)
                {
                    case "ModelArc":    // if the type is ModelAre
                        info.Number = m_arcArray.Size;  // refresh the number of arc
                        break;
                    case "ModelLine":   // if the type is ModelLine
                        info.Number = m_lineArray.Size; // refresh the number of line
                        break;
                    case "ModelEllipse":// If the type is ModelEllipse
                        info.Number = m_ellipseArray.Size;  // refresh the number of ellipse
                        break;
                    case "ModelHermiteSpline":  // If the type is ModelHermiteSpline
                        info.Number = m_hermiteArray.Size;  // refresh the number of HermiteSpline
                        break;
                    case "ModelNurbSpline":     // If the type is ModelNurbSpline
                        info.Number = m_nurbArray.Size;     // refresh the number of NurbSpline
                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Create one instance for each of the model lines in the created SketchPlane. 
        /// The model lines can be Arc, Line, Ellipse, HermiteSpline and NurbSpline
        /// </summary>
        public void CreateModelLines()
        {
            // Becase the current work plane can not be gotten,
            // it is hard to decide which sketch plane should place these model lines on.
            // So create a new sketch plane first and place all model lines on it.
           
            // First create a sketch plane
            if (null == m_workPlane)    // only create the work plane once
            {
                CreateSketchPlane();
            }

            // Create the line(ModelLine)
            CreateLine();           

            // Create the arc(ModelArc)
            CreateArc();

            // Create the other lines, including Ellipse, HermiteSpline and NurbSpline
            CreateOthers();      
        }


        /// <summary>
        /// Create a new sketch plane which all model lines are placed on.
        /// </summary>
        void CreateSketchPlane()
        {
            // NewSketchPlane() method need a Geometry.Plane reference
            // So first create it.
            XYZ normal = new XYZ(0, 0, 1);  // the normal vector
            XYZ origin = new XYZ(0, 0, 5);  // the origin point
            // create geometry plane
            Plane geometryPlane = m_createApp.NewPlane(ref normal, ref origin);
            if (null == geometryPlane)      // assert the creation is successful
            {
                throw new Exception("Create the geometry plane failed.");
            }
            // create sketch plane
            m_workPlane = m_createDoc.NewSketchPlane(geometryPlane);
            if (null == m_workPlane)        // assert the creation is successful
            {
                throw new Exception("Create the sketch plane failed.");
            }
        }


        /// <summary>
        /// Create the ModelLine
        /// </summary>
        void CreateLine()
        {
            // First assert the workPlane exist.
            if (null == m_workPlane)        
            {
                throw new Exception("The work plane has not been created.");
            }

            XYZ startPoint = new XYZ(0, 0, 0);  // the start point of the line
            XYZ endPoint = new XYZ(10, 10, 0);  // the end point of the line
            // create geometry line
            Line geometryLine = m_createApp.NewLine(ref startPoint, ref endPoint, true);
            if (null == geometryLine)       // assert the creation is successful
            {
                throw new Exception("Create the geometry line failed.");
            }
            // create the ModelLine
            ModelLine line = m_createDoc.NewModelCurve(geometryLine, m_workPlane) as ModelLine;
            if (null == line)               // assert the creation is successful
            {
                throw new Exception("Create the ModelLine failed.");
            }
            // Add the created ModelLine into the line array
            m_lineArray.Append(line);
        }


        /// <summary>
        /// Create the ModelArc
        /// </summary>
        void CreateArc()
        {
            // First assert the workPlane exist.
            if (null == m_workPlane)
            {
                throw new Exception("The work plane has not been created.");
            }

            XYZ startPoint = new XYZ(0, 0, 0);  // the start point of the arc
            XYZ endPoint = new XYZ(10, 5, 0);   // the end point of the arc
            XYZ thirdPoint = new XYZ(5, 10, 0); // the third point of the arc
            // create the geometry arc
            Arc geometryArc = m_createApp.NewArc(ref startPoint, ref endPoint, ref thirdPoint);
            if (null == geometryArc)            // assert the creation is successful
            {
                throw new Exception("Create the geometry arc failed.");
            }
            // create the ModelArc
            ModelArc arc = m_createDoc.NewModelCurve(geometryArc, m_workPlane) as ModelArc;
            if (null == arc)                    // assert the creation is successful
            {
                throw new Exception("Create the ModelArc failed.");
            }
            // Add the created ModelArc into the arc array
            m_arcArray.Append(arc);
        }


        /// <summary>
        /// Create the other lines, including Ellipse, HermiteSpline and NurbSpline
        /// </summary>
        void CreateOthers()
        {
            // First assert the workPlane exist.
            if (null == m_workPlane)
            {
                throw new Exception("The work plane has not been created.");
            }

            // Because the geometry of these lines can't be created by API,
            // use an existing geometry to create ModelEllipse, ModelHermiteSpline, ModelNurbSpline
            // and then move a bit to make the user see the creation distinctly

            // This method use NewModelCurveArray() method to create model lines
            CurveArray curves = m_createApp.NewCurveArray();// create a geometry curve array
            ModelCurve modelCurve = null;
            if (0 != m_ellipseArray.Size)   // If the array has data
            {
                modelCurve = m_ellipseArray.get_Item(0);
                curves.Append(modelCurve.GeometryCurve);    // add the geometry ellipse
            }
            if (0 != m_hermiteArray.Size)   // If the array has data
            {
                modelCurve = m_hermiteArray.get_Item(0);
                curves.Append(modelCurve.GeometryCurve);    // add the geometry HermiteSpline
            }
            if (0 != m_nurbArray.Size)      // If the array has data
            {
                modelCurve = m_nurbArray.get_Item(0);
                curves.Append(modelCurve.GeometryCurve);    // add the geometry NurbSpline
            }

            // If no curve can be copied from the existing model lines, give error information.
            if (0 == curves.Size)
            {
                throw new Exception("Please draw some ellipses, hermite and nurb splines " +
                            "before invoke the command, because the geometry curves of these " + 
                            "can't be created with Revit API.");
            }

            // Create other model lines
            ModelCurveArray modelCurves = m_createDoc.NewModelCurveArray(curves, m_workPlane);
            // assert the creation is successful
            if (null == modelCurves || curves.Size != modelCurves.Size) 
            {
                throw new Exception("Create the ModelCurveArray failed.");
            }
            // Offset the create model lines in order to differentiate the existing model lines
            XYZ offset = new XYZ(5, 0, 0);      // the offset direction
            foreach (ModelCurve m in modelCurves)
            {
                m_revit.ActiveDocument.Move(m, ref offset); // move the lines
            }
            // Add the created model lines into corresponding array
            foreach (ModelCurve m in modelCurves)
            {
                switch (m.GetType().Name)
                {
                    case "ModelEllipse":            // If the line is Ellipse
                        m_ellipseArray.Append(m);   // Add to Ellipse array
                        break;
                    case "ModelHermiteSpline":      // If the line is HermiteSpline
                        m_hermiteArray.Append(m);   // Add to HermiteSpline array
                        break;
                    case "ModelNurbSpline":         // If the line is NurbSpline
                        m_nurbArray.Append(m);      // Add to NurbSpline
                        break;
                    default:
                        break;
                }          
            }
        }
    }
}
