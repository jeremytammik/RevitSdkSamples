namespace Revit.SDK.Samples.ModelLines2.CS
{
    partial class PointUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.secondBracketLabel = new System.Windows.Forms.Label();
            this.secondCommaLabel = new System.Windows.Forms.Label();
            this.firstCommaLabel = new System.Windows.Forms.Label();
            this.zCoordinateTextBox = new System.Windows.Forms.TextBox();
            this.yCoordinateTextBox = new System.Windows.Forms.TextBox();
            this.xCoordinateTextBox = new System.Windows.Forms.TextBox();
            this.firstBracketLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // secondBracketLabel
            // 
            this.secondBracketLabel.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.secondBracketLabel.AutoSize = true;
            this.secondBracketLabel.Location = new System.Drawing.Point(203, 4);
            this.secondBracketLabel.Name = "secondBracketLabel";
            this.secondBracketLabel.Size = new System.Drawing.Size(10, 13);
            this.secondBracketLabel.TabIndex = 7;
            this.secondBracketLabel.Text = ")";
            // 
            // secondCommaLabel
            // 
            this.secondCommaLabel.AutoSize = true;
            this.secondCommaLabel.Location = new System.Drawing.Point(134, 7);
            this.secondCommaLabel.Name = "secondCommaLabel";
            this.secondCommaLabel.Size = new System.Drawing.Size(10, 13);
            this.secondCommaLabel.TabIndex = 5;
            this.secondCommaLabel.Text = ",";
            // 
            // firstCommaLabel
            // 
            this.firstCommaLabel.AutoSize = true;
            this.firstCommaLabel.Location = new System.Drawing.Point(66, 8);
            this.firstCommaLabel.Name = "firstCommaLabel";
            this.firstCommaLabel.Size = new System.Drawing.Size(10, 13);
            this.firstCommaLabel.TabIndex = 3;
            this.firstCommaLabel.Text = ",";
            // 
            // zCoordinateTextBox
            // 
            this.zCoordinateTextBox.Location = new System.Drawing.Point(152, 1);
            this.zCoordinateTextBox.Name = "zCoordinateTextBox";
            this.zCoordinateTextBox.Size = new System.Drawing.Size(45, 20);
            this.zCoordinateTextBox.TabIndex = 6;
            this.zCoordinateTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.CoordinateTextBox_Validating);
            // 
            // yCoordinateTextBox
            // 
            this.yCoordinateTextBox.Location = new System.Drawing.Point(84, 1);
            this.yCoordinateTextBox.Name = "yCoordinateTextBox";
            this.yCoordinateTextBox.Size = new System.Drawing.Size(45, 20);
            this.yCoordinateTextBox.TabIndex = 4;
            this.yCoordinateTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.CoordinateTextBox_Validating);
            // 
            // xCoordinateTextBox
            // 
            this.xCoordinateTextBox.Location = new System.Drawing.Point(17, 1);
            this.xCoordinateTextBox.Name = "xCoordinateTextBox";
            this.xCoordinateTextBox.Size = new System.Drawing.Size(45, 20);
            this.xCoordinateTextBox.TabIndex = 2;
            this.xCoordinateTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.CoordinateTextBox_Validating);
            // 
            // firstBracketLabel
            // 
            this.firstBracketLabel.AutoSize = true;
            this.firstBracketLabel.Location = new System.Drawing.Point(-1, 2);
            this.firstBracketLabel.Name = "firstBracketLabel";
            this.firstBracketLabel.Size = new System.Drawing.Size(10, 13);
            this.firstBracketLabel.TabIndex = 1;
            this.firstBracketLabel.Text = "(";
            // 
            // PointUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.secondBracketLabel);
            this.Controls.Add(this.secondCommaLabel);
            this.Controls.Add(this.firstCommaLabel);
            this.Controls.Add(this.zCoordinateTextBox);
            this.Controls.Add(this.yCoordinateTextBox);
            this.Controls.Add(this.xCoordinateTextBox);
            this.Controls.Add(this.firstBracketLabel);
            this.Name = "PointUserControl";
            this.Size = new System.Drawing.Size(213, 24);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label secondBracketLabel;
        private System.Windows.Forms.Label secondCommaLabel;
        private System.Windows.Forms.Label firstCommaLabel;
        private System.Windows.Forms.TextBox zCoordinateTextBox;
        private System.Windows.Forms.TextBox yCoordinateTextBox;
        private System.Windows.Forms.TextBox xCoordinateTextBox;
        private System.Windows.Forms.Label firstBracketLabel;
    }
}
