Autodesk Revit API application: ModelLines2

1. Draw some model lines in revit UI.
2. Get all model lines in revit and reports the number of each type.
3. Allow the user to specify some parameter to create model line:
	1) the model line shape
	2) which sketch plane places the model line on 
4. Provide button to create one specified model line in revit.


Note: 
Some model lines creation need the existing model line to support. Such as ModelEllipse, ModelHermiteSpline and ModelNurbSpline.