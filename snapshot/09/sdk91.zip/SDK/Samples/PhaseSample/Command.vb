Public Class Command

   Implements Autodesk.Revit.IExternalCommand

   'All Revit API commands must support this methof
   Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

      Dim application As Autodesk.Revit.Application = commandData.Application

      Dim phase As Autodesk.Revit.Elements.Phase

      'Create an instance of the dialog that will display the names of
      'the phases within the project
      Dim dialog As New PickPhase()

      'Iterate through the phases in the project and add them to the
      'check list
      For Each phase In application.ActiveDocument.Phases

         dialog.PhaseCheckedListBox.Items.Add(phase.Name)

      Next

      'Show the dialog to the user
      dialog.ShowDialog()

      'Loop through all the elements in the document and find those that
      'match the phases specified by the user in the dialog
      Dim iter As IEnumerator = application.ActiveDocument.Elements

      Do While iter.MoveNext()

         Dim element As Autodesk.Revit.Element = iter.Current

         'Check for created phase
         If (dialog.CreatedRadioButton.Checked = True) Then
            If Not (element.PhaseCreated Is Nothing) Then
               If dialog.PhaseCheckedListBox.CheckedItems.Contains(element.PhaseCreated.Name) Then
                  'put the element found into the elements set passed to this method
                  elements.Insert(element)
               End If
            End If

            'check for demolished phase
         ElseIf (dialog.DemolishedRadioButton.Checked = True) Then
            If Not (element.PhaseDemolished Is Nothing) Then
               If dialog.PhaseCheckedListBox.CheckedItems.Contains(element.PhaseDemolished.Name) Then
                  'put the element found into the elements set passed to this method
                  elements.Insert(element)
               End If
            End If
         End If

      Loop

      'If we have found any elements that we are interested in the set the
      'return message
      If elements.Size > 0 Then
         message = "Elements contained in the selected phases"
      End If

      'return cancel - this will cause the message and element set to appear
      'to the user
      Return Autodesk.Revit.IExternalCommand.Result.Cancelled

   End Function

End Class
