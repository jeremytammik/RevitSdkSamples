Autodesk Revit API application: AnalyticalSupportData_Info

This sample uses Visual Studio .NET 2005 C# to displays the element's surported information. The information include the element's id, element's type and 
whether the element be supported. If supported reporting the type of the support.

this sample mostly use AnalyticalSupportData class and AnalyticalSupportInfoArray class. 
And Both of them are below Autodesk.Revit.Structural Namespace.