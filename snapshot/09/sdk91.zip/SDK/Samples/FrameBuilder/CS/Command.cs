//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

namespace Revit.SDK.Samples.FrameBuilder.CS
{
	using System;
	using System.Text;
	using System.Windows.Forms;
	using System.Diagnostics;
	using System.Collections.Generic;

	using Autodesk.Revit;

	/// <summary>
	/// external applications' only entry point class that supports the IExternalCommand interface
	/// </summary>
	public class Command : IExternalCommand
	{
		/// <summary>
		/// overload this method to implement an external command within Revit
		/// </summary>
		/// <param name="commandData">an object that is passed to the external application 
		/// which contains data related to the command</param>
		/// <param name="message">a message that can be set by the external application 
		/// which will be displayed if a failure or cancellation is returned</param>
		/// <param name="elements">a set of elements which will be highlighted
		/// in case of failure or cancellation</param>
		/// <returns>Return the status of the external command</returns>
		public IExternalCommand.Result Execute(ExternalCommandData commandData,
			ref string message, ElementSet elements)
		{
			try
			{
				// try to initialize necessary data to create framing
				FrameData data = FrameData.CreateInstance(commandData);
				// display UI for user's input
				using (CreateFrameForm framingForm = new CreateFrameForm(data))
				{
					if (framingForm.ShowDialog() == DialogResult.OK)
					{
						// create framing
						FrameBuilder builder = new FrameBuilder(data);
						builder.CreateFraming();
					}
					else
					{
						// cancel the command
						return IExternalCommand.Result.Cancelled;
					}
				}
			}
			catch (ErrorMessageException appEx)
			{
				// not enough condition to create
				message = appEx.Message;
				return IExternalCommand.Result.Failed;
			}
			catch (Exception ex)
			{
				// unexpected error
				Debug.WriteLine(ex.ToString());
				return IExternalCommand.Result.Failed;
			}

			return Autodesk.Revit.IExternalCommand.Result.Succeeded;
		}
	}
}
