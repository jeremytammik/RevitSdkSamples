Autodesk Revit API application: FrameBuilder

1. User can input parameters to create a frame consist of column, beam and brace
2. Add levels if the number of floors is more than the number of levels in the Revit model
3. Have a user visible option to use the suspend updating function to increase the speed of the model creation
4. User can Duplicate type of column, beam and brace