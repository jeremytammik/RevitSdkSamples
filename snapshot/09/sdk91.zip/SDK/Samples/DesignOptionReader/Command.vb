Public Class Command

   Implements Autodesk.Revit.IExternalCommand

   ' Method required by all Revit external commands
   Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

      Dim application As Autodesk.Revit.Application = commandData.Application

      Dim iter As IEnumerator = application.ActiveDocument.Elements
      Dim element As Autodesk.Revit.Element
      Dim designOptions As New Autodesk.Revit.ElementSet()

      'iterate through all the elements, looking for design option elements
      Do While iter.MoveNext()

         element = iter.Current
         If TypeOf element Is Autodesk.Revit.Elements.DesignOption Then

            designOptions.Insert(element)

         End If

      Loop

      'if we found any design options then display them in a dialog
      If designOptions.Size > 0 Then
         Dim dialog As New DesignOptionsDialog()

         For Each element In designOptions

            dialog.DesignOptionsList.Items.Add(element.Name)

         Next

         dialog.ShowDialog()

      Else
         MsgBox("There are no design options in this document")
      End If


      Return Autodesk.Revit.IExternalCommand.Result.Succeeded

   End Function

End Class
