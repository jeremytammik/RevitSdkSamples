//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;


using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Enums;
using Autodesk.Revit.Parameters;


namespace Revit.SDK.Samples.Materials1.CS
{
    public struct ConversionValue
    {
        private int m_precision;   //precision of value show in PropertyGrid
        private string m_unitName; //unit'name shown in PropertyGrid
        private double m_ratio;    //ratio between value obtain by API 
                                   //and value show in PropertyGrid 
 
        public int Precision
        {
            get
            {
                return m_precision;
            }
            set
            {
                m_precision = value;
            }
        }

        public string UnitName
        {
            get
            {
                return m_unitName;
            }
            set
            {
                m_unitName = value;
            }
        }

        public double Ratio
        {
            get
            {
                return m_ratio;
            }
            set
            {
                m_ratio = value;
            }
        }
    }

    /// <summary>
    /// a class used to store information about conversion, and do converting operation
    /// can obtain these information by method "GetUnitValue"
    /// </summary>
    public class UnitConversion
    {
        private static readonly Dictionary<DisplayUnitType, ConversionValue> m_unitDictionary;
        //used to store DisplayUnitType and corresponding ConversionValue


        /// <summary>
        /// get conversionValue according to DisplayUnitType
        /// </summary>
        /// <param name="displayUnitType"></param>
        /// <param name="conversionValue"></param>
        /// <returns>if success return true, else return false</returns>
        public static bool GetUnitValue(DisplayUnitType displayUnitType,
            out ConversionValue conversionValue)
        {
            //try to get ConversionValue match displayUnitType in m_unitDictionary
            if (m_unitDictionary.TryGetValue(displayUnitType, out conversionValue))
            {
                return true;
            }
            //if not found, set precision = 0, ratio = 1, unitName = displayUnitType.ToString()
            //and return false
            else
            {
                conversionValue.Precision = 0;
                conversionValue.Ratio = 1;
                conversionValue.UnitName = displayUnitType.ToString();
                return false;
            }            
        }

        /// <summary>
        /// convert into string when StorageType is double or int,
        /// then return a string include value and type
        /// </summary>
        /// <param name="parameter">parameter of a Material</param>
        /// <param name="storageType">
        /// store StorageType of parameter,it is StorageType.Double or StorageType.Integer
        /// </param>
        /// <returns></returns>
        public static string ConvertFrom(Parameter parameter, StorageType storageType)
        {
            string displayText = null; // string included value and unit of parameter
                                       // will be shown in PropertyGrid
            DisplayUnitType unitType = parameter.DisplayUnitType;

            //get conversion value by method "GetUnitValue"
            ConversionValue conversionValue;
            GetUnitValue(unitType, out conversionValue);

            //if 0 == conversionValue.Ratio, set conversionValue.Ratio = 1
            if (0 == conversionValue.Ratio)
            {
                conversionValue.Ratio = 1;
            }

            if (StorageType.Double == storageType)
            {
                double value = parameter.AsDouble() / conversionValue.Ratio;

                //deal with precision by method"DealPrecision"
                double temp = DealPrecision(value, conversionValue.Precision);
                displayText = temp.ToString();
            }
            else
            {
                double value = (int)(parameter.AsInteger() / conversionValue.Ratio);

                //deal with precision by method"DealPrecision"
                double temp = DealPrecision(value, conversionValue.Precision);
                displayText = temp.ToString();
            }

            //add UnitType after value if necessary
            if (DisplayUnitType.Invalid != unitType && DisplayUnitType.General != unitType)
            {
                displayText += " " + conversionValue.UnitName;
            }
            return displayText;
        }

        /// <summary>
        /// convert a string into double or int,
        /// and then set it to parameter
        /// </summary>
        /// <param name="parameter">paramter of a Material</param>
        /// <param name="value">
        /// value will be set to parameter
        /// </param>
        /// <param name="storageType">
        /// store StorageType of parameter,it is StorageType.Double or StorageType.Integer
        /// </param>        
        public static void ConvertTo(Parameter parameter, Object value, StorageType storageType)
        {
            string stringValue = value as string;
            if (null == stringValue)
            {
                return;
            }
            
            // obtained from PropertyGrid
            DisplayUnitType unitType = parameter.DisplayUnitType;
            string unitTypeString = unitType.ToString();

            //get conversion value by class method "GetUnitValue"
            ConversionValue conversionValue;
            GetUnitValue(unitType, out conversionValue);

            //if failed Parsing from string,then not set
            double result;
            if (StorageType.Double == storageType)
            {
                //true if Parse successfully; otherwise, false.
                if (ParseFromString(parameter, stringValue, conversionValue, out result))
                {
                    parameter.Set(result * conversionValue.Ratio);
                }
            }
            else
            {
                //true if Parse successfully; otherwise, false.
                if (ParseFromString(parameter, stringValue, conversionValue, out result))
                {
                    parameter.Set((int)(result * conversionValue.Ratio));
                }
            }
        }

        /// <summary>
        /// deal with value according to precision
        /// </summary>
        /// <param name="value">original value will be dealed</param>
        /// <param name="precision">precision wanted to be set</param>
        /// <returns>return the dealed value</returns>
        public static double DealPrecision(double value, int precision)
        {
            //first make sure 0 =< precision <= 15
            if (precision < 0 && precision > 15)
            {
                return value;
            }

            //if >1 or < -1,just use Math.Round to deal with
            double newValue;
            if (value >= 1 || value <= -1 || 0 == value)
            {
                //Math.Round: returns the number with the specified precision
                //nearest the specified value.
                newValue = Math.Round(value, precision);
                return newValue;
            }

            //if -1 < value < 1, 
            //find fisrt number which is not "0"
            //compare it with precision, then select
            //min of them as final precision
            int firstNumberPos = 0;
            double temp = Math.Abs(value);
            for (firstNumberPos = 1; ; firstNumberPos++)
            {
                temp *= 10;
                if (temp >= 1)
                {
                    break;
                }
            }

            //Math.Round: returns the number with the specified precision
            //nearest the specified value.
            newValue = Math.Round(value, firstNumberPos > precision ? firstNumberPos : precision);
            return newValue;
        }

        /// <summary>
        /// try to parse string to double
        /// </summary>
        /// /// <param name="parameter">parameter of Material</param>
        /// <param name="value">input string</param>
        /// <param name="conversionValue">ConversionValue about value</param>
        /// <param name="result">the result of this method</param>
        /// <returns>successful return true; otherwise return false</returns>
        static bool ParseFromString(Parameter parameter, string value,
            ConversionValue conversionValue, out double result)
        {
            //try to get value from string "displayText". 
            string newValue = null;

            //check if contains string got by method "GetUnitValue"
            if (value.Contains(conversionValue.UnitName))
            {
                int index = value.IndexOf(conversionValue.UnitName);
                newValue = value.Substring(0, index);
            }
            //check if have string" " ,for there is string" " 
            //between value and unit when show in PropertyGrid
            else if (value.Contains(" "))
            {
                int index = value.IndexOf(" ");
                newValue = value.Substring(0, index);
            }
            //finally if displayText don't have unit name in it 
            //other situation, set newValue = displayText
            else
            {
                newValue = value;
            }

            //double.TryParse's return value:
            //true if s is converted successfully; otherwise, false.
            if (double.TryParse(newValue, out result))
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// add DisplayUnitType and corresponding ConversionValue 
        /// to Dictionary m_unitDictionary 
        /// </summary>
        static UnitConversion()
        {
            m_unitDictionary = new Dictionary<DisplayUnitType, ConversionValue>();
            foreach (DisplayUnitType displayUnitType in Enum.GetValues(typeof(DisplayUnitType)))
            {
                ConversionValue conversionValue = new ConversionValue();
                switch (displayUnitType)
                {
                    case DisplayUnitType.MegaPascals:
                        conversionValue.Precision = 6;
                        conversionValue.Ratio = 304800;
                        conversionValue.UnitName = "MPa";
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    case DisplayUnitType.KipsPerSquareInch:
                        conversionValue.Precision = 2;
                        conversionValue.Ratio = 2101522.0229577161;
                        conversionValue.UnitName = "ksi";
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    case DisplayUnitType.InvCelsius:
                        conversionValue.Precision = 8;
                        conversionValue.Ratio = 1;
                        conversionValue.UnitName = "1/��C";
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    case DisplayUnitType.InvFahrenheit:
                        conversionValue.Precision = 8;
                        conversionValue.Ratio = 1.8;
                        conversionValue.UnitName = "1/��F";
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    case DisplayUnitType.KilonewtonsPerCubicMeter:
                        conversionValue.Precision = 2;
                        conversionValue.Ratio = 92.90304;
                        conversionValue.UnitName = "kN/m" + (char)0x00B3;
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    case DisplayUnitType.PoundsForcePerCubicFoot:
                        conversionValue.Precision = 2;
                        conversionValue.Ratio = 14.593902937206364;
                        conversionValue.UnitName = "lb/ft" + (char)0x00B3;
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                    //others set default values as below
                    default:
                        conversionValue.Precision = 2;
                        conversionValue.Ratio = 1;
                        conversionValue.UnitName = " ";
                        m_unitDictionary.Add(displayUnitType, conversionValue);
                        break;
                }
            }
        }
    }
}
