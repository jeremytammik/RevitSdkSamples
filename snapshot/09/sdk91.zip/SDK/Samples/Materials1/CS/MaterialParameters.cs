//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.ComponentModel;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Enums;

namespace Revit.SDK.Samples.Materials1.CS
{
 
    /// <summary>
    /// used to instead of type bool. if catch a Exception, 
    /// can return BoolValue.Undefined
    /// </summary>
    public enum BoolValue 
    {
        False = 0, //equal to false
        True,      //equal to true
        Undefined  
    }

    /// <summary>
    /// used to describe Material's type
    /// </summary>
    public enum MaterialType
    {
        MaterialOther = 0,
        MaterialConcrete,
        MaterialSteel,
        MaterialGeneric,
        MaterialWood
    }
    
    
    /// <summary>
    /// base class which has a member Material
    /// and expose Material's parameters according 
    /// to Material's type
    /// </summary>
    public class MaterialParameters
    {
        private Material m_material; // reference to Material

        private const double m_ratio = 0.01; //conversion ratio of Smoothness and Transparency

        protected MaterialBehaviourType m_behavior; //if Behavior == Orthotropic,true, or false

     
        /// <summary>
        /// get parameter by Method "get_Parameter(BuiltInParameter )"
        /// and deal with it according to the type of Parameter's StorageType
        /// </summary>
        protected Object GetParameter(BuiltInParameter builtInParameter)
        {
            return GetParameter(builtInParameter, true);
        }

        /// <summary>
        /// get parameter by Method "get_Parameter(BuiltInParameter )"
        /// and deal with it according to the type of Parameter's StorageType
        /// </summary>
        protected Object GetParameter(BuiltInParameter builtInParameter, bool doConversion)
        {
           try
           {
               //obtain Material's parameter by method "get_Parameter"
               Parameter parameter = m_material.get_Parameter(builtInParameter);
               if (null == parameter)
               {
                   return null;
               }

               //deal with parameter according to 
               //it's StorageType and doConversion
               switch (parameter.StorageType)
               {
                   //if doConversion true, use method ConvertFrom
                   //else directly use method "AsDouble" of parameter 
                   case StorageType.Double:
                        if (doConversion)
                        {
                            return UnitConversion.ConvertFrom(parameter, StorageType.Double);
                        }
                        else
                        {
                            return parameter.AsDouble();
                        }
                    case StorageType.ElementId:
                        return parameter.AsElementId(); 

                    //if doConversion true, use method ConvertFrom
                    //else directly use method "AsInteger" of parameter
                    case StorageType.Integer:
                        if (doConversion)
                        {
                            return UnitConversion.ConvertFrom(parameter, StorageType.Integer);
                        }
                        else
                        {
                            return parameter.AsInteger();
                        }
                    case StorageType.None:
                        return parameter.AsValueString();
                    case StorageType.String:
                        return parameter.AsString();
                    default:
                        return null;
                }
            }
            catch (Exception )
            {
                return null;
            }
        }

        /// <summary>
        /// get parameter by Method "get_Parameter(BuiltInParameter )"
        /// and then set Parameter by Method "Set" or "SetValue"
        /// </summary>
        protected void SetParameter(BuiltInParameter builtInParameter, Object value)
        {
            SetParameter(builtInParameter, value,true);
        }

        /// <summary>
        /// get parameter by Method "get_Parameter(BuiltInParameter )"
        /// and then set Parameter by Method "Set" or "SetValue"
        /// </summary>
        protected void SetParameter(BuiltInParameter builtInParameter, Object value,
            bool doConversion)
        {
            try
            {
                //obtain Material's parameter by method "get_Parameter"
                Parameter parameter = m_material.get_Parameter(builtInParameter);
                if (null == parameter)
                {
                    return ;
                }

                //deal with parameter according to 
                //it's StorageType and doConversion
                switch (parameter.StorageType)
                {
                    case StorageType.Double:
                        //if doConversion true, use method ConvertTo
                        //otherwise directly use method "Set" of parameter
                        if (doConversion)
                        {
                            UnitConversion.ConvertTo(parameter, value, StorageType.Double);
                        }
                        else
                        {
                            parameter.Set((double)value);
                        }
                        break;                       
                    case StorageType.ElementId:
                        break;
                    case StorageType.Integer:
                        //if doConversion true, use method ConvertTo
                        //otherwise directly use method "Set" of parameter
                        if (doConversion)
                        {
                            UnitConversion.ConvertTo(parameter, value, StorageType.Integer);
                        }
                        else
                        {
                            parameter.Set((int)value);
                        }
                        break;
                    case StorageType.None:
                        parameter.SetValueString(value.ToString());
                        break;
                    case StorageType.String:
                        parameter.Set(value as string);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception )
            {
                return;
            }                       
        } 


        #region General        
        /// <summary>
        /// original StorageType : int
        /// </summary>
        [Category("General")]
        public System.Drawing.Color Color
        {
            get
            {
                try
                {
                    //first get integer value of RGB
                    int colorvalue = 
                        (int)GetParameter(BuiltInParameter.MATERIAL_PARAM_COLOR, false);
                    
                    //try to get R G B value
                    int red = colorvalue & 0xff;
                    int green = (colorvalue >> 8) & 0xff;
                    int blue = (colorvalue >> 16) & 0xff;

                    //use values got above to new a Color and return
                    System.Drawing.Color color = System.Drawing.Color.FromArgb(red,green,blue);
                    return color;                   
                }
                catch (Exception)
                {
                    return System.Drawing.Color.Empty;
                }
            }
            set
            {
                SetParameter(BuiltInParameter.MATERIAL_PARAM_COLOR, value.ToArgb(), false);
            }
        }

        /// <summary>
        /// original StorageType : double
        /// </summary> 
        [Category("General")]
        public string Shininess
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.MATERIAL_PARAM_SHININESS) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.MATERIAL_PARAM_SHININESS,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : double
        /// </summary>
        [Category("General")]
        public double Smoothness
        {
            get
            {
                try
                {
                    double smoothness = 
                        (double)GetParameter(BuiltInParameter.MATERIAL_PARAM_SMOOTHNESS,false);
                    return UnitConversion.DealPrecision(smoothness / m_ratio, 2);                  
                }                                
                catch (Exception)
                {
                    return double.NaN;
                }
            }
            set
            {
                SetParameter(BuiltInParameter.MATERIAL_PARAM_SMOOTHNESS,
                    value * m_ratio,false);
            }
        }

        /// <summary>
        /// original StorageType : bool
        /// </summary>
        [Category("General")]
        public BoolValue Glow
        {
            get
            {
                try
                {
                    int result = (int)GetParameter
                        (BuiltInParameter.MATERIAL_PARAM_GLOW, false);

                    //convert int into BoolValue
                    //if 0, return false
                    //otherwise, rerturn true
                    if (0 == result)
                    {
                        return BoolValue.False;
                    }
                    else
                    {
                        return BoolValue.True;
                    }
                }
                //if catch a Exception, return BoolValue.Undefined
                catch (Exception)
                {
                    return BoolValue.Undefined;
                }
            }
            set
            {
                //convert BoolValue into int value
                //if false, equal to 0
                //otherwise, equal to 1
                int result;
                if (BoolValue.True == value)
                {
                    result = 1;
                }
                else if (BoolValue.False == value)
                {
                    result = 0;
                }
                //if set BoolValue.Undefined, do nothing and return
                else
                {
                    return;
                }
                SetParameter(BuiltInParameter.MATERIAL_PARAM_GLOW,
                    result,false);
            }
        }

        /// <summary>
        /// original StorageType : double
        /// </summary>
        [Category("General")]
        public double Transparency
        {
            get
            {
                try
                {
                    double transparency = 
                        (double)GetParameter(BuiltInParameter.MATERIAL_PARAM_TRANSPARENCY,false);
                    return UnitConversion.DealPrecision(transparency / m_ratio,2);                   
                }
                //if catch a Exception ,return double.NaN
                catch (Exception)
                {
                    return double.NaN;
                }
            }
            set
            {
                SetParameter(BuiltInParameter.MATERIAL_PARAM_TRANSPARENCY,
                    value * m_ratio,false);
            }
        }
        #endregion

        #region ALL_MODEL
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [Category("Identity parameters")]
        public string Cost
        {
            get
            {
                string cost = GetParameter(BuiltInParameter.ALL_MODEL_COST) as string;
                if ("0" == cost)
                {
                    return "";
                }
                return cost;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_COST, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string Mark
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_MARK) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_MARK, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string Model
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_MODEL) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_MODEL, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string Manufacturer
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_MANUFACTURER) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_MANUFACTURER, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string Comments
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string URL
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_URL) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_URL, value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")]
        public string Description
        {
            get
            {
                return GetParameter(BuiltInParameter.ALL_MODEL_DESCRIPTION) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.ALL_MODEL_DESCRIPTION, value);
            }
        }
        #endregion

        /// <summary>
        /// original StorageType : string
        /// </summary>
        [Category("Identity parameters")] 
        public string Keynote
        {
            get
            {
                return GetParameter(BuiltInParameter.KEYNOTE_PARAM) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.KEYNOTE_PARAM, value);
            }

        }

        /// <summary>
        /// original StorageType : int
        /// </summary>
        public MaterialType MaterialType
        {
            get
            {
                try
                {
                    return (MaterialType)GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_TYPE,
                        false);
                }
                catch (Exception)
                {
                    return MaterialType.MaterialOther;
                }
            }
        }


        /// <summary>
        /// Material's constructor 
        /// </summary>
        /// <param name="material">a instance of Material's derived classes</param>
        public MaterialParameters(Material material)
        {
            m_material = material;
        }        
    }
}
