Autodesk Revit API application: Materials

1.	User can select a structure element
2.	Invoke external command
3.	all available materials in the current project is represent in a form.
4.	Application will change material to the structure element which is selected before this command be invoked.
