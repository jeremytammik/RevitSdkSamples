//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Enums;

namespace Revit.SDK.Samples.Materials1.CS
{

    /// <summary>
    /// derived class of MaterialParameters 
    /// </summary>
    public class MaterialWoodParameters : MaterialParameters
    {
        private MaterialWood m_materialWood;// reference to MaterialWood


        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string Bending 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_BENDING) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_BENDING, 
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string CompressionParallelToGrain 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_COMPRESSION_PARALLEL)
                    as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_COMPRESSION_PARALLEL,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string CompressionPerpendicularToGrain 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_COMPRESSION_PERPENDICULAR) 
                    as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_COMPRESSION_PERPENDICULAR,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        public string Grade 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_GRADE) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_GRADE,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string PoissonModulus 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearModulus 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearParallelToGrain 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_PARALLEL) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_PARALLEL,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearPerpendicularToGrain 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_PERPENDICULAR) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_PERPENDICULAR,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : string
        /// </summary>
        public string Species 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SPECIES) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SPECIES,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ThermalExpansionCoefficient 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string UnitWeight
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string YoungModulus 
        {
            get
            {
                return GetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD,
                    value);
            }
        }


        /// <summary>
        /// MaterialWoodParameters's constructor 
        /// </summary>
        /// <param name="materialWood">a instance of MaterialWood</param>
        public MaterialWoodParameters(MaterialWood materialWood)
            : base(materialWood)
        {
            m_materialWood = materialWood;
        }
    }
}
