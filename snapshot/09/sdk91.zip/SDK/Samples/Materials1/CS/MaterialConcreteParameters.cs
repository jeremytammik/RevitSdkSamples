//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Enums;

namespace Revit.SDK.Samples.Materials1.CS
{

    /// <summary>
    /// derived class of MaterialParameters 
    /// </summary>
    public class MaterialConcreteParameters : MaterialParameters
    {
        private MaterialConcrete m_materialConcrete;// reference to MaterialConcrete
        private bool m_isLightWeight;//if LightWeight == true, m_islightWeiht == true;otherwise false

        /// <summary>
        /// original StorageType : MaterialBehaviourType
        /// </summary>
        public MaterialBehaviourType Behavior
        {
            get
            {
                try
                {
                    MaterialBehaviourType materialBehaviourType = 
                        (MaterialBehaviourType)GetParameter
                        (BuiltInParameter.PHY_MATERIAL_PARAM_BEHAVIOR, false);

                    //reset m_behavior;
                    m_behavior = materialBehaviourType;
                    return materialBehaviourType;
                }
                //if catch a Exception ,return MaterialBehaviourType.Undefined   
                catch(Exception)
                {
                    return MaterialBehaviourType.Undefined;
                }
            }
            set
            {
                //if set MaterialBehaviourType.Undefined, do nothing and return
                if (MaterialBehaviourType.Undefined == value)
                {
                    return;
                }
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_BEHAVIOR, value, false);
            }
        }

        /// <summary>
        /// original StorageType : double
        /// </summary>
        public string ConcreteCompression
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_CONCRETE_COMPRESSION) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_CONCRETE_COMPRESSION,value);
            }
        }

        /// <summary>
        /// original StorageType : double
        /// </summary>
        public string DampingRatio
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_DAMPING_RATIO) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_DAMPING_RATIO, value);
            }
        }

        /// <summary>
        /// original StorageType : int
        /// </summary>
        public BoolValue LightWeight
        {
            get
            {
                try
                {
                    int result = (int)GetParameter
                        (BuiltInParameter.PHY_MATERIAL_PARAM_LIGHT_WEIGHT,false);

                    //convert int into BoolValue
                    //if 0, return BoolValue.False
                    //otherwise, return BoolValue.True
                    if (0 == result)
                    {
                        m_isLightWeight = false;
                        return BoolValue.False;
                    }
                    else
                    {
                        m_isLightWeight = true;
                        return BoolValue.True;
                    }
                }
                //if catch a Exception ,return BoolValue.Undefined
                catch (Exception)
                {
                    return BoolValue.Undefined;
                }
            }
        }

        #region PoissonModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string PoissonRatioX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string PoissonRatioY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD2,
                        value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string PoissonRatioZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD3,
                    value);
                }
            }
        }
        #endregion

        #region ShearModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string ShearModulusX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD1) as string;
            }
            set
            {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearModulusY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearModulusZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD3,
                    value);
                }
            }
        }
        #endregion

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearStrengthModification
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_STRENGTH_REDUCTION) as string;
            }
            set
            {
                //when property "LightWeiht" is True,can set;
                //otherwise do nothing
                if (m_isLightWeight)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_STRENGTH_REDUCTION,
                        value);
                }
            }
        }

        #region ThermalExpansionCoefficient
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string ThermalExpansionCoefficientX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ThermalExpansionCoefficientY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ThermalExpansionCoefficientZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF3,
                    value);
                }
            }
        }
        #endregion

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string UnitWeight
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT,
                    value);
            }
        }

        #region YoungModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string YoungModulusX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string YoungModulusY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string YoungModulusZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD3,
                    value);
                }
            }
        }
        #endregion


        /// <summary>
        /// MaterialConcreteParameters's constructor 
        /// </summary>
        /// <param name="materialConcrete">a instance of MaterialConcrete</param>
        public MaterialConcreteParameters(MaterialConcrete materialConcrete)
            : base(materialConcrete)
        {
            m_materialConcrete = materialConcrete;
        }
    }
}
