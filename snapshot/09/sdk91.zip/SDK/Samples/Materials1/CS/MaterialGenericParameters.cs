//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Enums;

namespace Revit.SDK.Samples.Materials1.CS
{

    /// <summary>
    /// derived class of MaterialParameters 
    /// </summary>
    public class MaterialGenericParameters : MaterialParameters
    {
        private MaterialGeneric m_materialGeneric;// reference to MaterialGeneric

        /// <summary>
        /// original StorageType : MaterialBehaviourType
        /// </summary>
        public MaterialBehaviourType Behavior
        {
            get
            {
                try
                {
                    MaterialBehaviourType materialBehaviourType = 
                        (MaterialBehaviourType)GetParameter
                        (BuiltInParameter.PHY_MATERIAL_PARAM_BEHAVIOR, false);

                    //reset m_behavior;
                    m_behavior = materialBehaviourType;
                    return materialBehaviourType;
                }
                //if catch a Exception ,return MaterialBehaviourType.Undefined   
                catch (Exception)
                {
                    return MaterialBehaviourType.Undefined;
                }
            }
            set
            {
                //if set MaterialBehaviourType.Undefined, do nothing and return
                if (MaterialBehaviourType.Undefined == value)
                {
                    return;
                }
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_BEHAVIOR, value, false);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string MinimumYieldStress
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_MINIMUM_YIELD_STRESS) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_MINIMUM_YIELD_STRESS,
                    value);
            }
        }

        #region PoissonModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string PoissonRatioX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string PoissonRatioY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD2,
                        value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string PoissonRatioZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_POISSON_MOD3,
                    value);
                }
            }
        }
        #endregion        

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ReductionFactor
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_REDUCTION_FACTOR) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_REDUCTION_FACTOR,
                    value);
            }
        }

        #region ShearModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string ShearModulusX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD1,
                value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearModulusY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ShearModulusZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_SHEAR_MOD3,
                    value);
                }
            }
        }
        #endregion

        #region ThermalExpansionCoefficient
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string ThermalExpansionCoefficientX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ThermalExpansionCoefficientY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string ThermalExpansionCoefficientZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_EXP_COEFF3,
                    value);
                }
            }
        }
        #endregion

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string UnitWeight
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_UNIT_WEIGHT,
                    value);
            }
        }

        #region YoungModulus
        /// <summary>
        /// original StorageType : Double
        /// </summary>
        [RefreshPropertiesAttribute(RefreshProperties.All)]
        public string YoungModulusX
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD1) as string;
            }
            set
            {
                SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD1,
                    value);
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string YoungModulusY
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD2) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD2,
                    value);
                }
            }
        }

        /// <summary>
        /// original StorageType : Double
        /// </summary>
        public string YoungModulusZ
        {
            get
            {
                return GetParameter
                    (BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD3) as string;
            }
            set
            {
                //when property "Behavior" is MaterialBehaviourType.Orthotropic,can set;
                //otherwise do nothing
                if (MaterialBehaviourType.Orthotropic == m_behavior)
                {
                    SetParameter(BuiltInParameter.PHY_MATERIAL_PARAM_YOUNG_MOD3,
                    value);
                }
            }
        }
        #endregion


        /// <summary>
        /// MaterialGenericParameters's constructor 
        /// </summary>
        /// <param name="materialGeneric">a instance of MaterialGeneric</param>
        public MaterialGenericParameters(MaterialGeneric materialGeneric)
            :base(materialGeneric)
        {
            m_materialGeneric = materialGeneric;
        }
    }
}
