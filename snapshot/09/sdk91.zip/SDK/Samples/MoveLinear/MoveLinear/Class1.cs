/*      .NET Sample

      Copyright (c) 2006 by Autodesk, Inc.

      Permission to use, copy, modify, and distribute this software
      for any purpose and without fee is hereby granted, provided
      that the above copyright notice appears in all copies and
      that both that copyright notice and the limited warranty and
      restricted rights notice below appear in all supporting
      documentation.

      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
      UNINTERRUPTED OR ERROR FREE.

      Use, duplication, or disclosure by the U.S. Government is subject to
      restrictions set forth in FAR 52.227-19 (Commercial Computer
      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
      (Rights in Technical Data and Computer Software), as applicable.


 MoveLinear - This class defines a command to move a linear objec,such as a structural beam.

*/

using System;
using System.Windows.Forms;
using Autodesk.Revit;

namespace MoveLinear
{
	/// <summary>
	/// This class is to define a command to move a linear object. 
	/// Bill Zhang, DevTech, Autodesk.
	/// </summary>
	public class Command : Autodesk.Revit.IExternalCommand
	{
		public Autodesk.Revit.IExternalCommand.Result Execute(ExternalCommandData cmdData, ref string msg, Autodesk.Revit.ElementSet eleSet)
		{
			IExternalCommand.Result res = IExternalCommand.Result.Succeeded;
			try
			{
				System.Collections.IEnumerator iter;
				Autodesk.Revit.Selection sel;
                sel = cmdData.Application.ActiveDocument.Selection;
		   
				Autodesk.Revit.ElementSet elemSet;
				elemSet = sel.Elements;
		   
				iter = elemSet.ForwardIterator();
		   
				iter.MoveNext();
				Autodesk.Revit.Element element;
		   
				element = (Autodesk.Revit.Element)iter.Current;
		   
				if( element != null )
				{
					Autodesk.Revit.LocationCurve lineLoc;
					lineLoc = (Autodesk.Revit.LocationCurve)element.Location;
		         
					Autodesk.Revit.Geometry.Line line;
					Autodesk.Revit.Geometry.XYZ newStart;
					Autodesk.Revit.Geometry.XYZ newEnd;
		      
					newStart = lineLoc.Curve.StartPoint;
					newEnd = lineLoc.Curve.EndPoint;
		      
					newStart.X = newStart.X + 100;
					newEnd.Y = newEnd.Y + 100;

                    line = cmdData.Application.Create.NewLineBound(ref newStart, ref newEnd);
					lineLoc.Curve = line;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "MoveLinear");
				res = IExternalCommand.Result.Failed;
			}
			finally
			{
			}
			return res;
		}
	}
}
