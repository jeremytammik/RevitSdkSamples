Autodesk Revit API application: Shared Coordinate Syatem

1. Show the projectlocation information and site informations for current project.
2. Users can set the values to change the location
3. In the Project Browser, open a 2D plan view of the project.Click View menu 
   and select View Properties,set the view orientation to True North
4. On the Tools menu, click Shared Coordinates and select Acquire Coordinates.
