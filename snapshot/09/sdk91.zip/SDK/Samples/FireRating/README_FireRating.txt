'
'	Revit API Sample Program: FireRating
'

Subject: add/retrieve/modify shared parameters. 

Description: 
This program define three commands: 

ApplyParameter - add a new shared parameter to revit and apply it to all doors. 
ExportFireRating - export fire rating values to an Excel file.  
ImportFireRating - import fire rating values from the Excel file and apply them to doors. 

Office 2002 or 2003 is required to run this sample. You may need to modify it acoording to your Office version. One included is runs with 2003. 

Note: There is a hard coded "path" in the code.  You will need to change it accordingly if you save the sample in a different location than "C:\Revit API\Samples\". Please look at MainModule.vb in the project. 

Note: This sample assumes that the Fire Rating parameter does not exist.  If it already does, the sample will add additional Fire Rating parameter.(s)

Sample Usage:
-------------

(1) Draw a few walls and place a couple of doors.  

(2) Execute the "Apply Fire Rating" command.  This will add a shared parameter to Revit and apply it to all the doors. 

Pick any level and select a door and look at the properties. 
You'll see a property names "Fire Rating" has been added to the door.  
It is not set to anything. Set it to a value, say 10

(3) Run the "Export Fire Rating" command.  This will launch Excel and extract all the fire ratings to excel. You should see the one that you changed in there.

Pick any door and set a new value in Excel under the fire rating column. (Take note of the level and the id. We are going to import it with the next command.) 
Save the excel file and close excel. 

(4) Run the "Import Fire Rating" command.  This will load the file and read the data from excel back to the model.

Bring up the element properties and note that the fire rating has changed.
Alternatively, go to the level of the door you changed and then use the [Tools] menu --> [Element Ids]  -->  [Select by Id] and enter the id of the door you changed.

