Autodesk Revit API application: FoundationSlab

1.	User open a building or draw the building.
2.	Invoke external command
3.	User can select floors which would be convert to octagonal slabs. 
4.      User can also select the foundation slab type.
4.	Application will create octagonal slabs for the selected floors at the base of the building.
