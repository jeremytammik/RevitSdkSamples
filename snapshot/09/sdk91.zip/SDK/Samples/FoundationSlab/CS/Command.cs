//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;

namespace Revit.SDK.Samples.FoundationSlab.CS
{
    /// <summary>
    /// The Entry point class that supports the IExternalCommand interface
    /// </summary>
    public class Command : IExternalCommand
    {
        /// <summary>
        /// Overload this method to implement an external command within Revit.
        /// </summary>
        /// <param name="commandData">
        /// An object that is passed to this external application, which contains data related to the command.
        /// </param>
        /// <param name="message">
        /// A message that can be set by this external application.
        /// The message will be displayed if a failure or cancellation is returned.
        /// </param>
        /// <param name="elements">
        /// A set of elements to which this external application can add elements that will be highlighted in case of failure or cancellation.
        /// </param>
        /// <returns>Return the status of the external command</returns>
        public IExternalCommand.Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                // Check commandData parameter.
                if (null == commandData)
                {
                    return IExternalCommand.Result.Failed;
                }

                SlabData revitDatas = null;
                try
                {
                    // The Datas for UI.
                    revitDatas = new SlabData(commandData.Application);
                }
                catch (NullReferenceException e)
                {
                    message = e.Message;
                    return IExternalCommand.Result.Cancelled;  // Data error.
                }
                // Display form.
                FoundationSlabForm displayForm = new FoundationSlabForm(revitDatas);
                using (displayForm)
                {
                    if (displayForm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        return IExternalCommand.Result.Succeeded; // Create foundation slabs successfully.
                    }
                }
                return IExternalCommand.Result.Cancelled;  // Cancel creation.
            }
            catch (Exception e)
            {
                message = e.Message;
                return IExternalCommand.Result.Failed; // Unknow error.
            }
        }

    }
}
