Option Explicit On 
Imports System
Imports Autodesk.Revit

Public Class Command1
    Implements Autodesk.Revit.IExternalCommand

Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute        'set the shared parameters filename
      commandData.Application.Options.SharedParametersFilename = "/RevitParameters.txt"

        'open the file
        Dim sharedParametersFile As Autodesk.Revit.Parameters.DefinitionFile
        Try
            sharedParametersFile = commandData.Application.OpenSharedParameterFile()
        Catch ex As Exception
            MsgBox("File ""RevitParameters.txt"" not found." & vbNewLine & vbTab & "Exiting function.")
            Exit Function
        End Try

        'get or create our group
        Dim sharedParameterGroup As Autodesk.Revit.Parameters.DefinitionGroup
        sharedParameterGroup = sharedParametersFile.Groups.Item("RevitParameters")
        If (sharedParameterGroup Is Nothing) Then
            sharedParameterGroup = sharedParametersFile.Groups.Create("RevitParameters")
        End If

        'get or create the parameter
        Dim sharedParameterDefinition As Autodesk.Revit.Parameters.Definition
        sharedParameterDefinition = sharedParameterGroup.Definitions.Item("APIParameter")
        If (sharedParameterDefinition Is Nothing) Then
            sharedParameterDefinition = sharedParameterGroup.Definitions.Create("APIParameter", Autodesk.Revit.Parameters.ParameterType.Text, True)
        End If

        'create a category set with the wall category in it
        Dim categories As Autodesk.Revit.CategorySet
        categories = commandData.Application.Create.NewCategorySet
        Dim wallCategory As Autodesk.Revit.Category
        wallCategory = commandData.Application.ActiveDocument.Settings.Categories.Item("Walls")

        categories.Insert(wallCategory)

        'create a new instance binding for the wall categories
        Dim instanceBinding As Autodesk.Revit.Parameters.InstanceBinding
        instanceBinding = commandData.Application.Create.NewInstanceBinding(categories)

        'add the binding
        commandData.Application.ActiveDocument.ParameterBindings.Insert(sharedParameterDefinition, instanceBinding)
    End Function
End Class
