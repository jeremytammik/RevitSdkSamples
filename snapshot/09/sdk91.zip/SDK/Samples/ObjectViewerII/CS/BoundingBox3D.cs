using System;
using System.Collections.Generic;
using System.Text;

namespace Revit.SDK.Samples.ObjectViewer.CS
{
	struct BoundingBox3D
	{
		private Vector m_max;
		private Vector m_min;

		public BoundingBox3D(Vector max, Vector min)
		{
			m_max = max;
			m_min = min;
		}

		public Vector Max
		{
			get 
			{
				return m_max; 
			}
		}


		public Vector Min
		{
			get
			{
				return m_min; 
			}
		}
	}
}
