//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

namespace Revit.SDK.Samples.ObjectViewer.CS
{
    using System;
    using System.Data;
    using Autodesk.Revit;
	using Autodesk.Revit.Parameters;

    public class Parameters
    {
        private Element m_element = null;
        private DataTable m_allParameters;
        string m_resultValue;

        /// <summary>
        /// All parameters of selected element.
        /// </summary>
        public DataTable AllParameters
        {
            get
            {
                return m_allParameters;
            }
        }

        public Parameters(Element element)
        {
            m_element = element;
            m_allParameters = GetParameterstable();
        }

        /// <summary>
        /// create a table to hold the parameters of the element
        /// </summary>
        /// <returns></returns>
        public DataTable Createtable()
        {
            //create a table named Parameterstable
            DataTable table = new DataTable("Parameterstable");

            //define the table's  first column
            DataColumn parameterColumn = new DataColumn();
            parameterColumn.DataType = System.Type.GetType("System.String");
            parameterColumn.ColumnName = "Parameter";
            parameterColumn.Caption = "Parameter";
            parameterColumn.ReadOnly = true;
            table.Columns.Add(parameterColumn);

            //define the table's  second column
            DataColumn valueColumns = new DataColumn();
            valueColumns.DataType = System.Type.GetType("System.String");
            valueColumns.ColumnName = "Value";
            valueColumns.Caption = "Value";
            valueColumns.ReadOnly = true;
            table.Columns.Add(valueColumns);

            return table;
        }

        /// <summary>
        /// add data into the table
        /// </summary>
        /// <param name="parameterName">the first column value </param>
        /// <param name="parameterValue">the second column value </param>
        /// <param name="table">the table to be added</param>
        void AddData2Table(string parameterName, string parameterValue, DataTable table)
        {
            // create a new row
            DataRow row = table.NewRow();
            row["Parameter"] = parameterName;
            row["Value"] = parameterValue;
            table.Rows.Add(row);
        }

        /// <summary>
        /// find out the parameters of the element and insert it into the table
        /// </summary>
        /// <returns></returns>
        DataTable GetParameterstable()
        {
            DataTable parametertable = Createtable();
            string getParameterName;
            string getParameterValue;
            Element e = m_element;

            ParameterSetIterator j;
            j = e.Parameters.ForwardIterator();
            j.Reset();

            bool jMoreAttribute;
            jMoreAttribute = j.MoveNext();

            //enum its parameters
            while (jMoreAttribute)
            {
                object oo = j.Current;
                Parameter attribute = oo as Parameter;
                if (null == attribute)
                {
                    jMoreAttribute = j.MoveNext();
                    continue;
                }
                //get the parameter name 
                getParameterName = attribute.Definition.Name.ToString();

                //find out the parameter's storage type
                switch (attribute.StorageType)
                {
                    //it is type of none
                    case Autodesk.Revit.Parameters.StorageType.None:
                        getParameterValue = " ";
                        AddData2Table(getParameterName, getParameterValue, parametertable);
                        break;
                    //it is type of double
                    case Autodesk.Revit.Parameters.StorageType.Double:
                        //covert the number into Metric
                        getParameterValue = ConvertUnit(attribute);
                        AddData2Table(getParameterName, getParameterValue, parametertable);
                        break;
                    //it is type of elementId
                    case Autodesk.Revit.Parameters.StorageType.ElementId:
                        Autodesk.Revit.Element ele = m_element;
                            if (attribute.AsElementId().Value == ele.Id.Value)
                            {
                                getParameterValue = ele.Name.ToString();
                                AddData2Table(getParameterName, getParameterValue, parametertable);
                            }
                        break;
                    //it is type of integer
                    case Autodesk.Revit.Parameters.StorageType.Integer:
                        //if it is a type of enum
						if (attribute.Definition.Name == "Bottom Release"
							|| attribute.Definition.Name == "Top Release"
							|| attribute.Definition.Name == "Start Release"
							|| attribute.Definition.Name == "End Release")
						{
							switch (attribute.AsInteger())
							{
								case 0:
									getParameterValue = "Fixed".ToString();
									break;
								case 1:
									getParameterValue = "Pinned".ToString();
									break;
								case 2:
									getParameterValue = "Bending Moment".ToString();
									break;
								case 3:
									getParameterValue = "User Defined".ToString();
									break;
								default:
									getParameterValue = attribute.AsDouble().ToString();
									break;
							}
						}
						//other integer
						else
						{
							getParameterValue = ConvertUnit(attribute);
							AddData2Table(getParameterName, getParameterValue, parametertable);
						}
						break;
					//it is a type of string 
					case Autodesk.Revit.Parameters.StorageType.String:
						getParameterValue = attribute.AsString();
						AddData2Table(getParameterName, getParameterValue, parametertable);
						break;
                    //other type
                    default:
                        getParameterValue = " ";
                        AddData2Table(getParameterName, getParameterValue, parametertable);
                        break;
                }
                //loop the parameters
                jMoreAttribute = j.MoveNext();
            }
            return parametertable;
        }

        /// <summary>
        /// convert the number into Metric number
        /// </summary>
        /// <param name="attribute"></param>
        /// <returns></returns>
        string ConvertUnit(Parameter attribute)
        {
			if (null != attribute)
			{
				switch (attribute.Definition.ParameterType)
				{
					// deal with different type parameters
					case ParameterType.Angle:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble() * 180 / Math.PI, 3));
						break;
					case ParameterType.Area:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble() * 9.29 / 100, 3));
						break;
					case ParameterType.AreaForce:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble(), 3));
						break;
					case ParameterType.Force:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble() * 304.8 / 453.6, 3));
						break;
					case ParameterType.Volume:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble() * 0.0283, 3));
						break;
					case ParameterType.LinearForce:
						m_resultValue = Convert.ToString(Math.Round(attribute.AsDouble() * 453.6 / 304.8, 3));
						break;
					case ParameterType.YesNo:
						// bool value
						if (attribute.AsInteger() == 0)
						{
							m_resultValue = "False".ToString();
						}
						else
						{
							m_resultValue = "True".ToString();
						}
						break;
					case ParameterType.Number:
						m_resultValue = Math.Round(attribute.AsDouble(), 3).ToString();
						break;
					case ParameterType.Length:
						m_resultValue = Math.Round((attribute.AsDouble() * 304.8), 3).ToString();
						break;
					default:
						m_resultValue = Math.Round(attribute.AsDouble(), 3).ToString();
						break;
				}
            }
            return m_resultValue;
        }
    }
}
