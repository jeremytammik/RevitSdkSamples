//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
using System.Windows.Forms;
using System.Diagnostics;


using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Enums;
using Autodesk.Revit.Parameters;


namespace Revit.SDK.Samples.ObjectViewer.CS
{
    /// <summary>
    /// a struct define conversion detail
    /// </summary>
    public struct ConversionValue
    {
        private string m_unitName; //unit'name shown in PropertyGrid
        private double m_ratio;    //ratio between value obtain by API 
                                   //and value show in PropertyGrid 
        
        public string UnitName
        {
            get
            {
                return m_unitName;
            }
            set
            {
                m_unitName = value;
            }
        }

        public double Ratio
        {
            get
            {
                return m_ratio;
            }
            set
            {
                m_ratio = value;
            }
        }

        public ConversionValue(double ratio, string unitName)
        {
            m_unitName = unitName;
            m_ratio = ratio;
        }
    }

    /// <summary>
    /// a class used to store information about conversion, and do converting operation
    /// can obtain these information by method "GetUnitValue"
    /// </summary>
    public class UnitConversion
    {       
        private static DataSet m_conversionDataSet; //used to store DisplayUnitType and corresponding ConversionValue
        private static DataTable m_conversionDataTable;//used to store DisplayUnitType and corresponding ConversionValue
        private static bool m_isValid;    //figure out whewher find XML file or that XML file is valid
        private const int m_defaultPrecision = 3;  //default precision for parameter

        /// <summary>
        /// Initialize this class
        /// </summary>
        /// <returns></returns>
        public static bool Initialize()
        {
            m_conversionDataSet = new DataSet();
            try
            {
                string filepath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                if (!filepath.EndsWith("\\"))
                {
                    filepath += "\\";
                    filepath += "ConversionData.xml";
                }
                m_conversionDataSet.ReadXml(filepath);
                //check whether is valid
                if (!IsValid())
                {
                    m_isValid = false;
                    return false;
                }
                m_isValid = true;
                return true;
            }
            catch(Exception e)
            {
                m_conversionDataSet = null;
                string errorText = "Get or Read file 'ConversionData.xml' failed: " + e.Message
                    + " So use default ConversionValue";
                MessageBox.Show(errorText);
                m_isValid = false;
                return false;
            }
        }

        /// <summary>
        /// convert into string when StorageType is double or int,
        /// then return a string include value and type
        /// </summary>
        /// <param name="parameter">parameter of Element</param>
        /// <returns></returns>
        public static Object ConvertFrom(Parameter parameter)
        {
            switch (parameter.StorageType)
            {
                case StorageType.Double:
                    return DoubleToString(parameter);
                case StorageType.ElementId:
                    return parameter.AsElementId().Value;
                case StorageType.Integer:
                    return DoubleToString(parameter);
                case StorageType.None:
                    return parameter.AsValueString();
                case StorageType.String:
                    return parameter.AsString();
                default:
                    return null;
            }
        }

        /// <summary>
        /// convert into string when StorageType is double or int,
        /// then return a string include value and type
        /// </summary>
        /// <param name="parameter">parameter of Element</param>
        /// <returns></returns>
        public static string DoubleToString(Parameter parameter)
        {
            string displayText = null; // string included value and unit of parameter
            // will be shown in PropertyGrid
            DisplayUnitType unitType = parameter.DisplayUnitType;

            //get conversion value by method "GetConversionValue"
            ConversionValue conversionValue = GetConversionValue(parameter);

            //if 0 == conversionValue.Ratio, set conversionValue.Ratio = 1
            if (0 == conversionValue.Ratio)
            {
                conversionValue.Ratio = 1;
            }

            if (StorageType.Double == parameter.StorageType)
            {
                double value = parameter.AsDouble();
                ValueConversion(parameter, true, conversionValue.Ratio, ref value);

                //deal with precision by method"DealPrecision"
                double temp = DealPrecision(value, m_defaultPrecision);
                displayText = temp.ToString();
            }
            else
            {
                double value = (int)(parameter.AsInteger());
                ValueConversion(parameter, true, conversionValue.Ratio, ref value);

                //deal with precision by method"DealPrecision"
                double temp = DealPrecision(value, m_defaultPrecision);
                displayText = temp.ToString();
            }

            //add UnitType after value if necessary
            if (DisplayUnitType.Invalid != unitType && DisplayUnitType.General != unitType)
            {
                displayText += " " + conversionValue.UnitName;
            }
            return displayText;
        }

        /// <summary>
        /// convert a string into double or int,
        /// and then set it to parameter
        /// </summary>
        /// <param name="parameter">paramter of a Material</param>
        /// <param name="value">
        /// value will be set to parameter
        /// </param>     
        public static void ConvertTo(Parameter parameter, Object value)
        {
            double newValue = 0;
            switch (parameter.StorageType)
            {
                case StorageType.Double:
                    if (StringToDouble(parameter, value as string, out newValue))
                    {
                        parameter.Set(newValue);
                    }
                    break;
                case StorageType.ElementId:
                    ElementId elementId = (ElementId)(value);
                    parameter.Set(ref elementId);
                    break;
                case StorageType.Integer:
                    if (StringToDouble(parameter, value as string, out newValue))
                    {
                        parameter.Set((int)newValue);
                    }
                    break;
                case StorageType.None:
                    parameter.SetValueString(value as string);
                    break;
                case StorageType.String:
                    parameter.Set(value as string);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// convert a string into double or int,
        /// and then set it to parameter
        /// </summary>
        /// <param name="parameter">paramter of a Material</param>
        /// <param name="value">
        /// value will be set to parameter
        /// </param>
        public static bool StringToDouble(Parameter parameter, string value,out double newValue)
        {
            newValue = 0;

            if (null == value)
            {
                return false;
            }

            //get conversion value by class method "GetConversionValue"
            ConversionValue conversionValue = GetConversionValue(parameter);

            //if 0 == conversionValue.Ratio, set conversionValue.Ratio = 1
            if (0 == conversionValue.Ratio)
            {
                conversionValue.Ratio = 1;
            }

            //if failed Parsing from string,then not set
            if (ParseFromString(parameter, value, conversionValue, out newValue))
            {
                ValueConversion(parameter, false, conversionValue.Ratio, ref newValue);
                return true;
            }
            return false;
        }

        /// <summary>
        /// try to parse string to double
        /// </summary>
        /// /// <param name="parameter">parameter of Material</param>
        /// <param name="value">input string</param>
        /// <param name="conversionValue">ConversionValue about value</param>
        /// <param name="result">the result of this method</param>
        /// <returns>successful return true; otherwise return false</returns>
        private static bool ParseFromString(Parameter parameter, string value,
            ConversionValue conversionValue, out double result)
        {
            //try to get value from string "displayText". 
            string newValue = null;

            //if nothing, set result = 0;
            if (value.Length == 0)
            {
                result = 0;
                return true;
            }

            //check if contain string got by method "GetConversionValue",
            //first make sure conversionValue.UnitName is not null
            else if (null != conversionValue.UnitName && "" != conversionValue.UnitName &&
                " " != conversionValue.UnitName && value.Contains(conversionValue.UnitName) )
            {
                int index = value.IndexOf(conversionValue.UnitName);
                newValue = value.Substring(0, index);
            }
            //check if have string" " ,for there is string" " 
            //between value and unit when show in PropertyGrid
            else if (value.Contains(" "))
            {
                int index = value.IndexOf(" ");
                newValue = value.Substring(0, index);
            }
            //finally if displayText don't have unit name in it 
            //other situation, set newValue = displayText
            else
            {
                newValue = value;
            }

            //double.TryParse's return value:
            //true if s is converted successfully; otherwise, false.
            if (double.TryParse(newValue, out result))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// deal with value according to precision
        /// </summary>
        /// <param name="value">original value will be dealed</param>
        /// <param name="precision">precision wanted to be set</param>
        /// <returns>return the dealed value</returns>
        private static double DealPrecision(double value, int precision)
        {
            //first make sure 0 =< precision <= 15
            if (precision < 0 && precision > 15)
            {
                return value;
            }

            //if >1 or < -1,just use Math.Round to deal with
            double newValue;
            if (value >= 1 || value <= -1 || 0 == value)
            {
                //Math.Round: returns the number with the specified precision
                //nearest the specified value.
                newValue = Math.Round(value, precision);
                return newValue;
            }

            //if -1 < value < 1, 
            //find fisrt number which is not "0"
            //compare it with precision, then select
            //min of them as final precision
            int firstNumberPos = 0;
            double temp = Math.Abs(value);
            for (firstNumberPos = 1; ; firstNumberPos++)
            {
                temp *= 10;
                if (temp >= 1)
                {
                    break;
                }
            }

            //Math.Round: returns the number with the specified precision
            //nearest the specified value.
            newValue = Math.Round(value, firstNumberPos > precision ? firstNumberPos : precision);
            return newValue;
        }

        /// <summary>
        /// deal with conversion of Temperature, for Temperature is not only Multi and divide
        /// </summary>
        /// <param name="paramter">paramter that need be deal with</param>
        /// <param name="isCalledByToString">whether is called by Method "DoubleToString"</param>
        /// <param name="ratio">the value used to convert</param>
        /// <param name="value">the value of parameter</param>
        /// <returns></returns>
        private static void ValueConversion(Parameter paramter, bool isCalledByToString,
            double ratio, ref double value)
        {
            //this method is called by Method "DoubleToString"
            if (isCalledByToString)
            {
                switch (paramter.DisplayUnitType)
                {
                    case DisplayUnitType.Kelvin:
                         break ;
                    case DisplayUnitType.Celsius:
                        value -= 273.15;
                        break ;
                    case DisplayUnitType.Fahrenheit:
                        value = ((value - 273.15) * 9 / 5) + 32;
                        break;
                    case DisplayUnitType.Rankine:
                        value = value * 9 / 5;
                        break;
                    default:
                        value /= ratio;
                        break;
                }
            }
            else
            {
                switch (paramter.DisplayUnitType)
                {
                    case DisplayUnitType.Kelvin:
                        break;
                    case DisplayUnitType.Celsius:
                        value += 273.15;
                        break;
                    case DisplayUnitType.Fahrenheit:
                        value = ((value - 32) * 5 / 9) + 273.15;
                        break;
                    case DisplayUnitType.Rankine:
                        value = value * 5 / 9;
                        break;
                    default:
                        value *= ratio;
                        break;
                }
            }
        }

        /// <summary>
        /// check if data in DataSet is valid 
        /// </summary>
        /// <returns></returns>
        private static bool IsValid()
        {
            //check whether XML file is correct
            //firstly, check whether have only one table
            if (1 != m_conversionDataSet.Tables.Count)
            {
                MessageBox.Show("the file is not correct");
                return false;
            }

            //then check whether the table have only four columns
            m_conversionDataTable = m_conversionDataSet.Tables[0];
            if (4 != m_conversionDataTable.Columns.Count)
            {
                MessageBox.Show("the file is not correct");
                return false;
            }
            return true;
        }

        /// <summary>
        /// find ConversionValue from m_conversionDataTable
        /// </summary>
        /// <param name="parameter">parameter that need to be deal with</param>
        /// <returns></returns>
        private static ConversionValue GetConversionValue(Parameter parameter)
        {
            //new a ConversionValue with default value
            ConversionValue conversionValue = new ConversionValue(1, "");
            GetConversionValue(parameter, ref conversionValue);
            return conversionValue;
        }

        /// <summary>
        /// find ConversionValue from m_conversionDataTable
        /// </summary>
        /// <param name="parameter">parameter that need to be deal with</param>
        /// <param name="conversionValue">ConversionValue found in m_conversionDataTable</param>
        /// <returns></returns>
        private static bool GetConversionValue(Parameter parameter, 
            ref ConversionValue conversionValue)
        {
            //get DisplayUntiType of parameter
            string displayUnitType = parameter.DisplayUnitType.ToString();

            //set filter expression then use it to search Rows in table
            string filterExpression = string.Format("DisplayUnitType = '{0}'", displayUnitType);

            //Array used to store search result
            DataRow[] foundRows;

            // Use the Select method to find all rows matching the filter.
            try
            {
                foundRows = m_conversionDataTable.Select(filterExpression);
            }
            catch
            {
                return false;
            }

            //if have no or more than one DataRows in result, return default value 
            if (1 != foundRows.Length)
            {
                return false;
            }

            //call method GetValueFromRow to get ConversionValue;
            return GetValueFromRow(foundRows[0],ref conversionValue);
        }


        /// <summary>
        /// find ConversionValue from a DataRow
        /// </summary>
        /// <param name="dataRow">DataRow that store ConversionValue</param>
        /// <param name="conversionValue">ConversionValue found in DataRow</param>
        /// <returns></returns>
        private static bool GetValueFromRow(DataRow dataRow,ref ConversionValue conversionValue)
        {
            //figure out whether this method deal successfully 
            bool isSuccess = true;
            //some temporary variable
            string temp;
            int precision;
            double ratio;

            try
            {
                //first, get ratio
                temp = dataRow["Ratio"] as string;
                if (null != temp)
                {
                    //if Parse successful,set value gotten;
                    //otherwise, use default value
                    if (double.TryParse(temp, out ratio))
                    {
                        conversionValue.Ratio = ratio;
                    }
                    else
                    {
                        isSuccess = false;
                    }
                }
                else
                {
                    isSuccess = false;
                }

                //then, get UnitName
                temp = dataRow["UnitName"] as string;
                if (null != temp)
                {
                    //if Parse successful,set value gotten;
                    //otherwise, use default value
                    conversionValue.UnitName = temp;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch
            {
                return false;
            }

            return isSuccess;
        }
    }
}
