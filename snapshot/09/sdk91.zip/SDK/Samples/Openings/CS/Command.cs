//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.

/// <summary>
/// Display how to get profile information of Opening and  draw it's profile
/// and show how to create X model line with biggest BoundingBox
/// </summary>

using System;
using System.Collections.Generic;
using System.Text;
using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Geometry;
using Autodesk.Revit.Structural;

namespace Revit.SDK.Samples.Openings.CS
{
    /// <summary>
    /// The entrance of this example, implement the Excute method of IExternalCommand
    /// </summary>
    public class Command : IExternalCommand
    {
        #region IExternalCommand Members

        //implement the method of IExternalCommand interface
        public IExternalCommand.Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                Application app = commandData.Application;
                bool haveOpening = false;

                //search Opening in Revit
                List<OpeningInfo> openingInfos = new List<OpeningInfo>();
                ElementIterator iter = app.ActiveDocument.Elements;
                iter.Reset();
                while (iter.MoveNext())
                {
                    Object obj = iter.Current;
                    if (obj is Opening)
                    {
                        haveOpening = true;
                        Opening opening = obj as Opening;
                        OpeningInfo openingInfo = new OpeningInfo(opening, app);
                        openingInfos.Add(openingInfo);
                    }
                }

                if (!haveOpening)
                {
                    message = "don't have opening in the project";
                    return IExternalCommand.Result.Cancelled;
                }

                //show dialogue
                using (OpeningForm openingForm = new OpeningForm(openingInfos))
                {
                    openingForm.ShowDialog();
                }
            }
            catch (Exception e)
            {
                message = e.ToString();
                return IExternalCommand.Result.Failed;
            }

            return IExternalCommand.Result.Succeeded;
        }
        #endregion
    }
}
