using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Symbols;
using Autodesk.Revit.Structural.Enums;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Geometry;
using Autodesk.Revit.Parameters;

namespace Revit.SDK.Samples.CreateWallsUnderBeams.CS
{
    public class CreateWallsUnderBeams : IExternalCommand
    {
        // Private Members
        ArrayList m_wallTypeCollection;         // Store all the wall types in current document
        ArrayList m_beamCollection;             // Store the selection of beams in Revit
        WallType m_selectedWallType;            // Store the selected wall type
        Level m_level;                          // Store the level which wall create on
        Boolean m_isStructural;                 // Indicate whether create structural walls
        String m_errorInformation;              // Store the error information
        const Double PRECISION = 0.0000000001;  // Define a precision of double data

        // Properties
        /// <summary>
        /// Inform all the wall types can be created in current document
        /// </summary>
        public ArrayList WallTypes
        {
            get
            {
                return m_wallTypeCollection;
            }
        }

        /// <summary>
        /// Inform the wall type selected by the user
        /// </summary>
        public Object SelectedWallType
        {
            set
            {
                m_selectedWallType = value as WallType;
            }
        }

        /// <summary>
        /// Inform whether the user want to create structual or architecture walls
        /// </summary>
        public Boolean IsSturctual
        {
            get
            {
                return m_isStructural;
            }
            set
            {
                m_isStructural = value;
            }
        }

        // Methods
        /// <summary>
        /// Default constructor of CreateWallsUnderBeams
        /// </summary>
        public CreateWallsUnderBeams()
        {
            m_wallTypeCollection = new ArrayList();
            m_beamCollection = new ArrayList();
            m_isStructural = true;
        }

        /// <summary>
        /// Implement the member of IExternalCommand Execute
        /// </summary>
        /// <param name="commandData"></param>
        /// <param name="message">
        ///  A message that can be set by the external command and displayed in case of error.
        /// </param>
        /// <param name="elements">A set of elements that can be displayed if an error occurs</param>
        /// <returns>
        ///  A value that signifies if your command was successful, failed or the user wishes to cancel.
        /// </returns>
        public IExternalCommand.Result Execute(ExternalCommandData commandData,
                                                    ref string message, ElementSet elements)
        {
            Autodesk.Revit.Application revit = commandData.Application;
            Document project = revit.ActiveDocument;

            // Find the selection of beams in Revit
            ElementSet selection = project.Selection.Elements;
            foreach (Autodesk.Revit.Element e in selection)
            {
                FamilyInstance m = e as FamilyInstance;
                if (null != m)
                {
                    if (StructuralType.Beam == m.StructuralType)
                    {
                        // Store all the beams the user selected in Revit
                        m_beamCollection.Add(e);
                    }
                }
            }
            if (0 == m_beamCollection.Count)
            {
                message = "Can not find any beams.";
                return IExternalCommand.Result.Failed;
            }

            // Make sure all the beams have horizontal analytical line
            if (!CheckBeamHorizontal())
            {
                message = m_errorInformation;
                return IExternalCommand.Result.Failed;
            }

            // Search all the wall types in the Revit
            foreach (WallType wallType in project.WallTypes)
            {
                if (null == wallType)
                {
                    continue;
                }
                m_wallTypeCollection.Add(wallType);
            }

            // Show the dialog for the user select the wall style
            CreateWallsUnderBeamsForm displayForm = new CreateWallsUnderBeamsForm(this);
            if (DialogResult.OK != displayForm.ShowDialog())
            {
                return IExternalCommand.Result.Failed;
            }

            // Create the walls which along and under the path of the beams.
            if (!BeginCreate(project))
            {
                message = m_errorInformation;
                return IExternalCommand.Result.Failed;
            }

            // If everything goes right, return succeeded.
            return IExternalCommand.Result.Succeeded;
        }

        /// <summary>
        /// Create the walls which along and under the path of the selected beams
        /// </summary>
        /// <param name="project"> A reference of current document</param>
        /// <returns>true if there is no error in process; otherwise, false.</returns>
        Boolean BeginCreate(Autodesk.Revit.Document project)
        {
            // Begin to create walls along and under each beam
            for (int i = 0; i < m_beamCollection.Count; i++)
            {
                // Get each selected beam.
                FamilyInstance m = m_beamCollection[i] as FamilyInstance;
                if (null == m)
                {
                    m_errorInformation = "The program should not go here.";
                    return false;
                }

                // Get the analytical model of the beam, 
                // the wall will be created using this model line as path.            
                AnalyticalModelFrame model = m.AnalyticalModel as AnalyticalModelFrame;
                if (null == model)
                {
                    m_errorInformation = "The beam should have analytical model frame.";
                    return false;
                }

                // Get the level using the beam's reference level
                ElementId levelId = m.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM).AsElementId();
                m_level = project.get_Element(ref levelId) as Level;
                if (null == m_level)
                {
                    m_errorInformation = "The program should not go here.";
                    return false;
                }
                
                Wall createdWall = project.Create.NewWall(model.Curve, m_selectedWallType,
                                                m_level, 10, 0, true, m_isStructural);
                if (null == createdWall)
                {
                    m_errorInformation = "Can not create the walls";
                    return false;
                }

                // Modify some parameters of the created wall to make it look better.
                Double offset = model.Curve.StartPoint.Z - m_level.Elevation;
                createdWall.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT).Set(ref levelId);
                createdWall.get_Parameter(BuiltInParameter.WALL_BASE_OFFSET).Set(offset - 3000 / 304.8);
                createdWall.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE).Set(ref levelId);
                createdWall.get_Parameter(BuiltInParameter.WALL_TOP_OFFSET).Set(offset);
            }
            return true;
        }


        /// <summary>
        /// Check whether all the beams have horizontal analytical line 
        /// </summary>
        /// <returns>true if each beam has horizontal analytical line; otherwise, false.</returns>
        Boolean CheckBeamHorizontal()
        {
            for (int i = 0; i < m_beamCollection.Count; i++)
            {
                // Get the analytical curve of each selected beam.
                // And check if Z coordinate of start point and end point of the curve are same.
                FamilyInstance m = m_beamCollection[i] as FamilyInstance;
                AnalyticalModelFrame model = m.AnalyticalModel as AnalyticalModelFrame;
                if (null == model)
                {
                    m_errorInformation = "The beam should have analytical model frame.";
                    return false;
                }
                else if ((PRECISION <= model.Curve.StartPoint.Z - model.Curve.EndPoint.Z)
                    || (-PRECISION >= model.Curve.StartPoint.Z - model.Curve.EndPoint.Z))
                {
                    m_errorInformation = "Please only select horizontal beams.";
                    return false;
                }
            }
            return true;
        }
    }
}
