Autodesk Revit API application: ReferencePlane

1.	Report all reference planes in current project, show its ID, bubble end, free end, and normal.
2.	Allow user to create a reference plane at the left face of the wall or at the bottom of slab which is selected first.