Autodesk Revit API application: SlabProperties

The function of the program is to show some main properies of each slab object via the API.

Firstly, please open the SlabProperties project. Make sure the added RevitAPI under the References have a righet file path. And please modify the Revit.ini file in your Revit installation directory. You may refer to the supplied  Revit.ini file.

Then, if you launch your Revit.exe, you will see the Slab Properties command in the External Commands item under the Tools menu.

Finally, if you draw a slab object and select it, when you select the Slab Properties command, you will see the Slab  Properties dialog. The dialog displays the main properties of the selected slab.