'      Copyright (c) 2006 by Autodesk, Inc.
'
'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.
'
Imports System

Imports Autodesk
Imports Autodesk.Revit
Imports Autodesk.Revit.Application
Imports Autodesk.Revit.Elements
Imports Autodesk.Revit.Geometry

Public Class RoomViewer
  Implements Autodesk.Revit.IExternalCommand

  Dim mViewer As RevitViewer.Wireframe

  Public Function Execute(ByVal commandData As ExternalCommandData, ByRef message As String, ByVal elements As ElementSet) As Revit.IExternalCommand.Result Implements IExternalCommand.Execute

    Dim iter As IEnumerator
    iter = commandData.Application.ActiveDocument.Elements

    Do While iter.MoveNext

      Dim element As Autodesk.Revit.Element
      element = iter.Current

      If (TypeOf element Is Autodesk.Revit.Elements.Room) Then
        DrawRoomOutline(element)
      End If
    Loop

    If Not (mViewer Is Nothing) Then
      mViewer.Fit()
      mViewer.Draw()
      mViewer.ShowModal()
    End If

    mViewer = Nothing

    Return Revit.IExternalCommand.Result.Succeeded

  End Function

    Private Sub DrawRoomOutline(ByVal room As Autodesk.Revit.Elements.Room)

        If mViewer Is Nothing Then
            mViewer = New RevitViewer.Wireframe()
        End If

        Dim boundaries As Autodesk.Revit.Rooms.BoundarySegmentArrayArray
        boundaries = room.Boundary
        Dim boundary As Autodesk.Revit.Rooms.BoundarySegmentArray

        For Each boundary In boundaries
            Dim segment As Autodesk.Revit.Rooms.BoundarySegment
            For Each segment In boundary

                DrawCurve(segment.Curve)

            Next
        Next

    End Sub

    Private Sub DrawCurve(ByVal curve As Autodesk.Revit.Geometry.Curve)

    mViewer.Add(curve.StartPoint.X, curve.StartPoint.Y, curve.StartPoint.Z, curve.EndPoint.X, curve.EndPoint.Y, curve.EndPoint.Z)

    End Sub

End Class