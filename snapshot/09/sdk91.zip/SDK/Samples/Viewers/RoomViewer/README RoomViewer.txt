'
'	Revit API Sample Program: Room Viewer 
'
'	Migrated by fw. Jan. 26, 2006 
'
'	Last modified: Feb. 6, 2006 by mh. 
' 
'

Subject: Room Boundary 

Classes: Autodesk.Revit.Elements.Room, Autodesk.Revit.Rooms.BoundarySegmentArrayArray

Description: This program demonstrates the usage of room boundary. This sample uses a helper program RevitViewer.  

Usage: 

(1) draw walls to form a room (four walls, for example), place a room tag. 
(2) run the external command.  
It will show an outline of a room on a viewer. 

