'
'	Revit API Sample Program: Analytical Viewer 
'
'	Migrated by tn. Mar. 1, 2006 
'
'	Last modified: Mar 1, 2006 by tn. 
' 
'

Subject: Analytical Model 

Classes: Autodesk.Revit.Structural.AnalyticalModel

Description: This program demonstrates the usage of a structural analytical model. This sample uses a helper program RevitViewer.
This samples works only with Revit Structure.   

Usage: 

(1) select one or more elements
(2) run the external command.  
It will show an analytical model of the element(s) in a viewer. 
