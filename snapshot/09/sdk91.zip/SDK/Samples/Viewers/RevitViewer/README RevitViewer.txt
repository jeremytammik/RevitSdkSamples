'
'	Revit API Sample Program: Revit Viewer (Helper program) 
'
'	Migrated by fw. Jan. 26, 2006 
'
'	Last modified: Feb. 6, 2006 by mh. 
' 
'

Subject: A simple program to help viewing a geometry information obtained through Revit API.  

Classes: no Revit API is used in this sample.  

Description: This is a helper program to be used by other viewer samples, such as ElementViewer and RoomViewer. 

Usage: see other viewer samples for the usage of this program. 

