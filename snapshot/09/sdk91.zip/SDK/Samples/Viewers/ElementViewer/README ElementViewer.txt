'
'	Revit API Sample Program: Element Viewer 
'
'	Migrated by fw. Jan. 26, 2006 
'
'	Last modified: Feb. 18, 2006 by mh. 
' 
'

Subject: Element Geometry 

Classes: Autodesk.Revit.Geometry.Element, Autodesk.Revit.Geometry.GeometryObject, 

Description: This program demonstrates the usage of element's geometry. This sample uses a helper program RevitViewer.  

Usage: 

(1) choose an element, and run the external command.  
It will show the element's geometry in a wireframe in a viewer. 

Note: 
Some element does not expose geometry, for example, curtain wall and dimension.
In case of a curtain wall, try selecting a whole wall by a window/box instead of a single pick. 
It will then select internal components and be able to display its geometry.
