Autodesk Revit API application: BoundaryConditions

1. Firstly, user should select a structure element.
2. Invoke external command.
3. If the selected element has boundary conditions the parameters of the boundary conditions (BC) are presented. And users are also allowed to set these parameters with other valid values.
4. If the selected element does not have a BC then create one.

The sample set the conversion between the internal value and display value fit to Imperial unit.
