namespace Revit.SDK.Samples.BoundaryConditions.CS
{
    partial class BoundaryConditionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bCLabel = new System.Windows.Forms.Label();
            this.hostLabel = new System.Windows.Forms.Label();
            this.bCPropertyGrid = new System.Windows.Forms.PropertyGrid();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.bCComboBox = new System.Windows.Forms.ComboBox();
            this.hostTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bCLabel
            // 
            this.bCLabel.AutoSize = true;
            this.bCLabel.Location = new System.Drawing.Point(131, 17);
            this.bCLabel.Name = "bCLabel";
            this.bCLabel.Size = new System.Drawing.Size(139, 17);
            this.bCLabel.TabIndex = 0;
            this.bCLabel.Text = "Boundary Conditions";
            // 
            // hostLabel
            // 
            this.hostLabel.AutoSize = true;
            this.hostLabel.Location = new System.Drawing.Point(10, 17);
            this.hostLabel.Name = "hostLabel";
            this.hostLabel.Size = new System.Drawing.Size(37, 17);
            this.hostLabel.TabIndex = 1;
            this.hostLabel.Text = "Host";
            // 
            // bCPropertyGrid
            // 
            this.bCPropertyGrid.Location = new System.Drawing.Point(13, 46);
            this.bCPropertyGrid.Name = "bCPropertyGrid";
            this.bCPropertyGrid.Size = new System.Drawing.Size(354, 290);
            this.bCPropertyGrid.TabIndex = 2;
            this.bCPropertyGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.bCPropertyGrid_PropertyValueChanged);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(159, 353);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(102, 30);
            this.okButton.TabIndex = 3;
            this.okButton.Text = "&OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(267, 353);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(102, 30);
            this.cancelButton.TabIndex = 4;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // bCComboBox
            // 
            this.bCComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bCComboBox.FormattingEnabled = true;
            this.bCComboBox.Location = new System.Drawing.Point(268, 10);
            this.bCComboBox.Name = "bCComboBox";
            this.bCComboBox.Size = new System.Drawing.Size(99, 24);
            this.bCComboBox.TabIndex = 1;
            this.bCComboBox.SelectedIndexChanged += new System.EventHandler(this.bCComboBox_SelectedIndexChanged);
            // 
            // hostTextBox
            // 
            this.hostTextBox.Location = new System.Drawing.Point(45, 12);
            this.hostTextBox.Name = "hostTextBox";
            this.hostTextBox.ReadOnly = true;
            this.hostTextBox.Size = new System.Drawing.Size(70, 22);
            this.hostTextBox.TabIndex = 6;
            this.hostTextBox.TabStop = false;
            // 
            // BoundaryConditionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(380, 394);
            this.Controls.Add(this.hostTextBox);
            this.Controls.Add(this.bCComboBox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.bCPropertyGrid);
            this.Controls.Add(this.hostLabel);
            this.Controls.Add(this.bCLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BoundaryConditionsForm";
            this.ShowInTaskbar = false;
            this.Text = "Boundary Conditions";
            this.Load += new System.EventHandler(this.BoundaryConditionsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bCLabel;
        private System.Windows.Forms.Label hostLabel;
        private System.Windows.Forms.PropertyGrid bCPropertyGrid;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ComboBox bCComboBox;
        private System.Windows.Forms.TextBox hostTextBox;
    }
}