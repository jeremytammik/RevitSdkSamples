Autodesk Revit API application: CreateBeamSystem

1.	User can select a number of beams that intersect end to end
2.	Invoke external command
3.	User can select layout method and beam type
4.	Application will create beam system
