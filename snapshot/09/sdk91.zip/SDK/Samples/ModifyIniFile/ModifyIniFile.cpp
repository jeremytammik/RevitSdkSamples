// ModifyIniFile.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ModifyIniFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
      // location of the Revit.ini file
		const CString iniFilename = "c:\\Program Files\\Autodesk Revit Building 9.1\\Program\\Revit.ini";
      
      // constants for you application
      const CString myClassName = "Test.Command";
      const CString myCommandName = "My Command";
      const CString myCommandDescription = "My Command Description";

      // Get the current command count if it exists. If it doesn't exist then 0 will be
      // returned
      UINT ecCount = GetPrivateProfileInt("ExternalCommands","ECCount",0,iniFilename);
      
      // increment the command count and use that number as the basis for our command
      // entries
      ecCount++;

      // WriteProfiteProfile only writes strings so format the number as a string
      CString ecCountString;
      ecCountString.Format("%u",ecCount);
      if (!WritePrivateProfileString("ExternalCommands","ECCount",ecCountString,iniFilename))
         return 1;

      // write our class name to the ini file
      CString classNameEntry;
      classNameEntry.Format("ECClassName%d",ecCount);
      if (!WritePrivateProfileString("ExternalCommands",classNameEntry,myClassName,iniFilename))
         return 1;

      // write our command name that will appear in the menu to the ini file
      CString commandNameEntry;
      commandNameEntry.Format("ECName%d",ecCount);
      if (!WritePrivateProfileString("ExternalCommands",commandNameEntry,myCommandName,iniFilename))
         return 1;

      // write our command description that will appear in the status bar to the ini file
      CString commandDescriptionEntry;
      commandDescriptionEntry.Format("ECDescription%d",ecCount);
      if (!WritePrivateProfileString("ExternalCommands",commandDescriptionEntry,myCommandDescription,iniFilename))
         return 1;
	}

	return nRetCode;
}


