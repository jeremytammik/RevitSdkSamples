Autodesk Revit API application: Journaling

1. This sample should show how an external application can be incorporated into the journaling mechanism.
2. This sample should provide functionality to add useful information into the journal file.


Issue:
1. Please run this sample in revit for the first time. It will ask the user for some data to create a wall, and then record the data into the revit journal.
2. Start Revit from the command line with the path to the journal file as a parameter. This sample can read the data in journal file and create a same wall in revit.