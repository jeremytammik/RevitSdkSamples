// ADDED BY AUTODESK

// DumpParameters.cpp : Implementation of CDumpParameters

#include "stdafx.h"
#include "DumpParameters.h"
#include "PropertiesDialog.h"

// CDumpParameters

// raw_execute is the implementation of the execture command. In this case the command will take a
// user selected element and display all the properties of the element within a simple dialog box.
STDMETHODIMP CDumpParameters::raw_Execute(RevitAPI::_Autodesk_Revit_ExternalCommandData * pCommandData, BSTR *pMessage, RevitAPI::_Autodesk_Revit_ElementSet * Elements, RevitAPI::Result * pRetVal)
{
   // AFX_MANAGE_STATE is vital at this point as it switches the MFC state data to that of this application.
   // This MUST be done before any MFC methods can be called. It must be done at each entry point within the application
   AFX_MANAGE_STATE(AfxGetStaticModuleState());

   RevitAPI::_Autodesk_Revit_ApplicationPtr pApplication = pCommandData->Application;
   
      // Set out default result to failure.
   *pRetVal = RevitAPI::Result_Failed;

   // Attach a bstr object to the message parameter that was passed to us.
   _bstr_t message(*pMessage,false);

   // The current selection can be retrive from the active document via the selection object
   RevitAPI::_Autodesk_Revit_ElementSetPtr selectionSet = pApplication->ActiveDocument->Selection->Elements;

   // we need to make sure that only one element is selected.
   if (selectionSet->Size == 1)
   {
      // we need to get the first and only element in the selection. Do this by getting an iterator
      // MoveNext and then get the current element.
      mscorlib::IEnumeratorPtr selectionIter = selectionSet->ForwardIterator();
      selectionIter->MoveNext();
      RevitAPI::_Autodesk_Revit_ElementPtr element = selectionIter->Current;


      // Next we will iterator through the parameters of the element. As we iterate we will
      // store the strings that are to be displayed for the parameters in the parameters StringArray
      CStringArray parameters;

      // Get an iterator to the parameters of the element.
      mscorlib::IEnumeratorPtr paramIter = element->Parameters->ForwardIterator();

      // loop through all the parameters
      while (paramIter->MoveNext())
      {
         RevitAPI::_Autodesk_Revit_ParameterPtr param = paramIter->Current;

         // We will make a string that has the following format,
         // name type value
         CString propertyLine;

         // The name of the parameter can be found from its definition
         propertyLine.Format(CString("%s\t"),(LPCTSTR)(param->Definition->Name));

         // Revit parameters can be one of 4 different internal storage types:
         // double, int, string and ElementId. Switch based on the storage type
         switch (param->StorageType)
         {
         case RevitAPI::Autodesk_Revit_Parameters_StorageType_Double :
            // append the type and value
            propertyLine.AppendFormat(CString("double\t%f"),param->AsDouble());
            break;
         case RevitAPI::Autodesk_Revit_Parameters_StorageType_ElementId :
            // For element ids we will try and retrieve the element from the document
            // if it can be found we will display its name
            {
               propertyLine.Append(CString("Element\t"));
               // using the element id value of the parameter, retrieve the element from the active
               // document
               RevitAPI::_Autodesk_Revit_ElementPtr element = pApplication->ActiveDocument->GetElement(&(param->AsElementId()));

               // if there is an element then display its name, otherwise display the fact that it is not set
               if (element)
                  propertyLine.AppendFormat(CString("%s"),(LPCTSTR)element->Name);
               else
                  propertyLine.Append(CString("Not set"));
            }
            break;
         case RevitAPI::Autodesk_Revit_Parameters_StorageType_Integer :
            // append the type and value
            propertyLine.AppendFormat(CString("int\t%d"),param->AsInteger());
            break;
         case RevitAPI::Autodesk_Revit_Parameters_StorageType_String :
            // append the type and value
            propertyLine.AppendFormat(CString("string\t%s"),(LPCTSTR)param->AsString());
            break;
         default:
            break;
         }

         // add the completed line to the string array
         parameters.Add(propertyLine);
      }

      // Create our dialog, passing it the parameters array for display.
      CPropertiesDialog dialog(parameters);
      dialog.DoModal();

      // return a succesful message to the API.
      *pRetVal = RevitAPI::Result_Succeeded;
   }
   else
      // if none or more than one element is selected then we set the message string to be out error
      // message. This will be displayed when we exit the command
      message = "Please select only one element";

   // release the b string back to the parameter that was passed to us.
   *pMessage = message.Detach();

   // return that the method functioned correctly.
   return ERROR_SUCCESS;
}

// END ADDED BY AUTODESK
