/*************************************************
 *
 *    Revit .Net Sample Program: HelloRevit
 * 
 *    March 15, 2005 by mh. 
 *    Last modified: Feb. 19, 2006 by mh. 
 * 
 *************************************************

Application: HelloRevit

Subject: Custom Command. 

Classes: Autodesk.Revit.IExternalCommand 

Description: This is *the* minimum sample to add a command to Revit. The program implements Revit.IExternalCommand.  
There is also a Form version of Hello Revit.  

Usage: 
(1) Check the refernce.  Re-reference RevitAPI.dll if needed.  You can find it under:
<your Revit install folder>\Program\. Normally, this will be:   
C:\Program Files\Autodesk Revit Building <version number>\Program

(2) rebuild the project.

(3) locate Revit.ini file in C:\Program Files\Autodesk Revit Building <version number>\Program folder. (or your install folder.)

(4) copy and save the original Revit.ini file. Append the following lines to the end of Revit.ini file: 

>>>>
[ExternalCommands]
ECCount=1
ECName1="Hello Revit!" 
ECDescription1="Shows a message box with Hello Revit!"
ECClassName1=HelloRevit.Command
ECAssembly1="C:\Revit API\Samples\HelloRevit\bin\HelloRevit.dll"
<<<<

Please adjust <the location of the sample> according to your environment. 

This file will be read at Revit startup, and add an item to [Tools] menu --> [External Tools].

(5) Start Revit Building. Select [Tools] --> [External Tools]. You will see a new command menu [Hello Revit!] there. Choose it to execute the command you just created.  


--------------------------------------------------------------------------------------
Additional Note: If you would like to add more than one command, use the format like the following: 

>>>>
[ExternalCommands]
ECCount=2
ECName1="Hello Revit!" 
ECDescription1="Shows a message box with Hello Revit!"
ECClassName1=HelloRevit.Command
ECAssembly1="C:\Revit API\Samples\HelloRevit\bin\HelloRevit.dll"
ECName2="How Are You?"
ECDescription2="Shows a message box with How Are You?"
ECClassName2=HelloRevit.Command2
ECAssembly2="C:\Revit API\Samples\HelloRevit\bin\HelloRevit.dll"
<<<<

where we assume you have created the second command class named "Command2"

ECCount - the total number of commands. 

ECName# - this appears as the menu item #.

ECDescription# - tool tip that appears when you place a cursor on the menu.

ECClassName# - the name of the assembly and the class name. 

ECAssembly# - the full path to the assembly.




