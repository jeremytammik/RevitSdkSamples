'
' (C) Copyright 1994-2005 by Autodesk, Inc. All rights reserved.
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.

'
' AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable. 

Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports Autodesk
Imports Autodesk.Revit
Imports Autodesk.Revit.Structural
Imports Autodesk.Revit.Elements

' With the selected floor, display the function of each of its structural layers
' in order from outside to inside in a dialog box
Public Class StructuralLayerFunction
    Implements IExternalCommand

    'Private data members
    Private m_slab As Autodesk.Revit.Elements.Floor 'Store the selected floor
    Private m_functions As ArrayList                'Store the function of each floor

    'Properties
    ' <summary>
    ' With the selected floor, export the function of each of its structural layers
    ' </summary>
    Public ReadOnly Property Functions() As ArrayList
        Get
            Functions = m_functions
        End Get
    End Property

    ' Public Methods
    ' <summary>
    ' Implement the member of IExternalCommand Execute
    ' </summary>
    ' <param name="revit">The revit object for the active instance of Autodesk Revit</param>
    ' <param name="message">A message that can be set by the external command and displayed in case of error</param>
    ' <param name="elements">A set of elements that can be displayed if an error occurs</param>
    ' <returns>A value that signifies if yout command was successful, failed or the user wishes to cancel</returns>

   Public Function Execute1(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements _
    As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements _
    Autodesk.Revit.IExternalCommand.Execute
      ' Get the selected element
      Dim revit As Autodesk.Revit.Application = commandData.Application
      Dim project As Autodesk.Revit.Document = revit.ActiveDocument
      Dim choices As Autodesk.Revit.Selection = project.Selection
      Dim collection As Autodesk.Revit.ElementSet = choices.Elements
      ' Only allow to select one floor, or else report the failure
      If Not (1 = collection.Size) Then
         message = "Please select a floor."
         Return IExternalCommand.Result.Failed
      End If
      For Each e As Autodesk.Revit.Element In collection
         ' Judge if the element is floor
         If TypeOf e Is Autodesk.Revit.Elements.Floor Then
            m_slab = e
         End If
         If Nothing Is m_slab Then
            message = "Please select a floor."
            Return IExternalCommand.Result.Failed
         End If
      Next

      ' Get the function of each of its structural layers
      For Each e As CompoundStructureLayer In m_slab.FloorType.CompoundStructure.Layers
         ' With the selected floor, judge if the function of each of its structural layers
         ' is exist, if it's not exist, there should be zero.
         If 0 = e.Function Then
            m_functions.Add("No function")
         Else
            m_functions.Add(e.Function.ToString())
         End If
      Next

      ' Display them in a form
      Dim displayForm As New StructuralLayerFunctionForm(Me)
      displayForm.ShowDialog()

      Return IExternalCommand.Result.Succeeded
   End Function

    ' Default constructor of StructuralLayerFunction
    Public Sub New()
        ' Construct the data members for the property
        m_functions = New ArrayList
    End Sub

End Class
