Autodesk Revit API application: AreaReinforcementParameters

This sample uses Visual studio .NET 2005 C# to show how to use API modify parameters of AreaReinforcement:

o       Turn layers on and off

o       Change their layout rules

o       Change hook type

o       Change hook type to None (invalidElementId).