//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable. 


namespace Revit.SDK.Samples.ObjectViewer.CS
{
	using System;
	using System.Collections.Generic;
	using System.Text;

	using Autodesk.Revit;
	using Autodesk.Revit.Elements;
	using Autodesk.Revit.Geometry;
	using Autodesk.Revit.Parameters;

	using RevitApplication = Autodesk.Revit.Application;
	using GeometryElement = Autodesk.Revit.Geometry.Element;
	using GeometryOptions = Autodesk.Revit.Geometry.Options;
	using GeometryInstance = Autodesk.Revit.Geometry.Instance;


    /// <summary>
    /// The GeometryDatafactory object is used to transform Revit geometry data
    /// to appropriate format for GDI. 
    /// </summary>
	class GeometryDataFactory
	{
		GraphicsData m_data;

		/// <summary>
		/// create 3D and 2D data of given GeometryElement
		/// </summary>
		/// <param name="geoElement"></param>
		/// <returns></returns>
		public GraphicsData CreateGraphicsData(GeometryElement geoElement)
		{
			m_data = new GraphicsData();
			Transform transform = new Transform();
			AddGeoElement(geoElement, transform);
			m_data.UpdataData();
			return m_data;
		}

		/// <summary>
		/// get the solids in a Geometric primitive
		/// </summary>
		/// <param name="geometry"></param>
		private void AddGeoElement(GeometryObject obj, Transform transform)
		{
			GeometryElement geometry = obj as GeometryElement;
			if (null == geometry)
			{
				return;
			}

			//get all geometric primitives contained in the GeometryElement
			GeometryObjectArray geometries = geometry.Objects;

			AddGeometryObjects(geometries, transform);
		}

		/// <summary>
		/// iterate GeometryObject in GeometryObjectArray and generate data accordingly
		/// </summary>
		/// <param name="objects"></param>
		/// <param name="transform"></param>
		private void AddGeometryObjects(GeometryObjectArray objects, Transform transform)
		{
			foreach (GeometryObject o in objects)
			{
				//if the type of the geometric primitive is Solid
				string geoType = o.GetType().Name;
				switch (geoType)
				{
					case "Solid":
						AddSolid(o, transform);
						break;
					case "Face":
						AddFace(o, transform);
						break;
					case "Mesh":
						AddMesh(o, transform);
						break;
					case "Curve":
					case "Line":
					case "Arc":
						AddCurve(o, transform);
						break;
					case "Profile":
						AddProfile(o, transform);
						break;
					case "Element":
						AddGeoElement(o, transform);
						break;
					case "Instance":
						AddInstance(o, transform);
						break;
					case "Edge":
						AddEdge(o, transform);
						break;
					default:
						break;
				}
			}
		}

		/// <summary>
		/// generate data of a Solid
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddSolid(GeometryObject obj, Transform transform)
		{
			Solid solid = obj as Solid;
			if (null == solid)
			{
				return;
			}

			//a solid has many faces
			FaceArray faces = solid.Faces;
			if (faces.Size == 0)
			{
				return;
			}

			foreach (Face face in faces)
			{
				AddFace(face, transform);
			}
		}

		/// <summary>
		/// generate data of a Face
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddFace(GeometryObject obj, Transform transform)
		{
			Face face = obj as Face;
			if (null == face)
			{
				return;
			}

			Mesh mesh = face.Triangulate();
			if (null == mesh)
			{
				return;
			}
			AddMesh(mesh, transform);
		}

		/// <summary>
		/// generate data of a Profile
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddProfile(GeometryObject obj, Transform transform)
		{
			Profile profile = obj as Profile;
			if (null == profile)
			{
				return;
			}

			foreach (Curve curve in profile.Curves)
			{
				AddCurve(curve, transform);
			}
		}

		/// <summary>
		/// generate data of a Mesh
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddMesh(GeometryObject obj, Transform transform)
		{
			Mesh mesh = obj as Mesh;
			if (null == mesh)
			{
				return;
			}
			
			//a face has a mesh, all meshes are made of triangles
			for (int i = 0; i < mesh.NumTriangles; i++)
			{
				MeshTriangle triangular = mesh.get_Triangle(i);
				XYZArray points = new XYZArray();
				try
				{	
					for (int n = 0; n < 3; n++)
					{
						XYZ point = triangular.get_Vertex(n);
						XYZ newPoint = GetBasis(point, transform);
						points.Append(ref newPoint);
					}
					XYZ iniPoint = points.get_Item(0);
					points.Append(ref iniPoint);
					m_data.InsertCurve(points);
				}
				catch
				{
				}
			}
		}

		/// <summary>
		/// generate data of a Curve
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddCurve(GeometryObject obj, Transform transform)
		{
			Curve curve = obj as Curve;
			if (null == curve)
			{
				return;
			}

			XYZArray points = curve.Tessellate();
			XYZArray result = new XYZArray();
			foreach (XYZ point in points)
			{
				XYZ newPoint = GetBasis(point, transform);
				result.Append(ref newPoint);
			}
			m_data.InsertCurve(result);
		}

		/// <summary>
		/// generate data of a Instance
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddInstance(GeometryObject obj, Transform transform)
		{
			GeometryInstance instance = obj as GeometryInstance;
			if (null == instance)
			{
				return;
			}

			Transform allTransform = AddTransform(transform, instance.Transform);	//get a transformation of the affine 3-space
			
			GeometryElement instanceGeometry = instance.SymbolGeometry;
			if (null == instanceGeometry)
			{
				return;
			}
			//get all geometric primitives contained in the GeometryElement
			GeometryObjectArray instanceGeometries = instanceGeometry.Objects;
			AddGeometryObjects(instanceGeometries, allTransform);
		}

		/// <summary>
		/// generate data of a Edge
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="transform"></param>
		private void AddEdge(GeometryObject obj, Transform transform)
		{
			Edge edge = obj as Edge;
			if (null == edge)
			{
				return;
			}

			XYZArray points = edge.Tessellate();
			XYZArray result = new XYZArray();
			foreach (XYZ point in points)
			{
				XYZ newPoint = GetBasis(point, transform);
				result.Append(ref newPoint);
			}
			m_data.InsertCurve(result);
		}

		/// <summary>
		/// get the coordinates from old coordinate system in the new coordinate system
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		/// <param name="transform"></param>
		private XYZ GetBasis(XYZ point, Transform transform)
		{
			double x = point.X;
			double y = point.Y;
			double z = point.Z;
			double x2;
			double y2;
			double z2;

			//transform basis of the old coordinate system in the new coordinate system
			XYZ b0 = transform.get_Basis(0);
			XYZ b1 = transform.get_Basis(1);
			XYZ b2 = transform.get_Basis(2);
			XYZ origin = transform.Origin;

			//transform the origin of the old coordinate system in the new coordinate system
			x2 = x * b0.X + y * b1.X + z * b2.X + origin.X;
			y2 = x * b0.Y + y * b1.Y + z * b2.Y + origin.Y;
			z2 = x * b0.Z + y * b1.Z + z * b2.Z + origin.Z;

			XYZ newPoint = new XYZ(x2, y2, z2);
			return newPoint;
		}

		/// <summary>
		/// Add 2 Transform Matrix
		/// </summary>
		/// <param name="tran1"></param>
		/// <param name="tran2"></param>
		/// <returns></returns>
		private Transform AddTransform(Transform tran1, Transform tran2)
		{
			Transform result = new Transform();
			result.Origin = MathUtil.AddXYZ(tran1.Origin, tran2.Origin);

			XYZ[] left = new XYZ[3];
			XYZ[] right = new XYZ[3];

			for (int i = 0; i < 3; i++)
			{
				left[i] = tran1.get_Basis(i);
				right[i] = tran2.get_Basis(i);
			}

			XYZ[] temp = MathUtil.MultiCross(left, right);

			for (int i = 0; i < 3; i++)
			{
				result.set_Basis(i, temp[i]);
			}

			return result;
		}

	}

}
