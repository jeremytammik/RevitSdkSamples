Autodesk Revit API application: Rooms

1. Display the information of all the rooms.
2. Create room tags and add them to the rooms which are lack of tags.
3. Reorder the number of all rooms by ascending order from ground floor to high floor, from left to right
4. Calculate the rooms area for each department and export the result to an Excel document. 

