The Hello World sample is availble in two languages, VB6 which uses COM access to the Autodesk Revit API and VB.NET which uses .NET framework access.

Both samples add a command to Autodesk Revit which, when executed displays a modal dialog with the words Hello World contained in it. This sample can be used as a basis for much larger projects.

