Module Main

   Sub Main()

      'Do Nothing

   End Sub

End Module
