Public Class Command

   ' All Autodesk Revit external commands must support this interface
   Implements Autodesk.Revit.IExternalCommand

   Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

      MsgBox("Hello World")

      Return Autodesk.Revit.IExternalCommand.Result.Succeeded

   End Function

End Class
