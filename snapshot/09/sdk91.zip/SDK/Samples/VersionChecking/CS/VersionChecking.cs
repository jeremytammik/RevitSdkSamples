//
// (C) Copyright 1994-2006 by Autodesk, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.

//
// AUTODESK PROVIDES THIS PROGRAM 'AS IS' AND WITH ALL ITS FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.

using System;
using System.Text;
using System.Collections.Generic;

using Autodesk.Revit;

namespace Revit.SDK.Samples.VersionChecking.CS
{   
    /// <summary>
    /// Get the product name, version and build number about Revit main program.
    /// </summary>
    public class VersionChecking: IExternalCommand
    {
        string m_productName = ""; // product name of Revit main program
        string m_version     = ""; // version number of Revit main program
        string m_buildNumber = ""; // build number of Revit main program

        // properties
        public string ProductName
        {
            get
            {
                return m_productName;
            }

        }

        public string ProductVersion
        {
            get
            {
                return m_version;
            }
        }

        public string BuildNumner
        {
            get
            {
                return m_buildNumber;
            }
        }


        ///<summary>
        /// Application entry point implements IExternalCommand's method Execute
        /// </summary>
        /// <param name="revit">
        /// Object for the active instance of Autodesk Revit 
        /// <param name="message">
        /// A message that can be set by the external command and displayed in case of error
        /// </param>
        /// <param name="elements">
        /// A set of elements that can be displayed if an error occurs
        /// </param>
        /// <returns>
        /// A value that signifies if yout command was successful, failed or the user wishes to cancel
        /// </returns>
        public IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData revit,
                                               ref string message,
                                               Autodesk.Revit.ElementSet elements)
        {
            // get currently executable application
            Application revitApplication = revit.Application;

            // get product name, version number and build number information
            // via corresponding Properties of Autodesk.Revit.Application class
            m_productName = revitApplication.VersionName;
            m_version     = revitApplication.VersionNumber;
            m_buildNumber = revitApplication.VersionBuild;

            //Show forms dialog which is a UI
            versionCheckingForm displayForm = new versionCheckingForm(this);
            displayForm.ShowDialog();
            
            return IExternalCommand.Result.Succeeded;
        }

    }
}
