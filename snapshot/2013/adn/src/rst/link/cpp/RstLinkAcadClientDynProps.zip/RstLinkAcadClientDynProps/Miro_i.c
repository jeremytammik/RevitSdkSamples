

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Tue Nov 15 12:27:54 2011
 */
/* Compiler settings for Miro.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IRevitID,0xA534D69F,0x802A,0x40cb,0xB6,0x2E,0x5D,0xAE,0x8C,0x70,0xFF,0x76);


MIDL_DEFINE_GUID(IID, IID_IForce,0xF648290E,0xEDB2,0x49aa,0xA4,0x37,0x69,0xB1,0x28,0x0D,0x9A,0x96);


MIDL_DEFINE_GUID(IID, IID_ISection,0x185408D6,0x1454,0x422f,0xB6,0x5F,0x58,0x5E,0xBE,0x11,0xD4,0xC7);


MIDL_DEFINE_GUID(IID, IID_IUsage,0x184F914F,0x6836,0x4b23,0x85,0x84,0xC8,0xEF,0x57,0x97,0x44,0x8D);


MIDL_DEFINE_GUID(IID, LIBID_AsdkMiroLib,0x57BA066C,0x86BA,0x4e21,0xB0,0x9B,0xE6,0x13,0x9B,0x36,0x62,0xA6);


MIDL_DEFINE_GUID(CLSID, CLSID_RevitID,0xB44BF477,0x78EF,0x4455,0xAB,0x16,0x69,0xFD,0xD5,0x66,0x84,0x84);


MIDL_DEFINE_GUID(CLSID, CLSID_Force,0x3E21B286,0xB799,0x4bce,0xB1,0x15,0xEB,0x06,0x28,0x7D,0x14,0x54);


MIDL_DEFINE_GUID(CLSID, CLSID_Section,0x0F88B0AA,0xBAE6,0x47f2,0xB8,0xD3,0xFB,0x8B,0x98,0xA1,0x57,0x47);


MIDL_DEFINE_GUID(CLSID, CLSID_Usage,0x61DF3C01,0x4BEB,0x48fe,0xA7,0xDE,0xCC,0x2F,0x54,0x92,0x02,0xFE);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



