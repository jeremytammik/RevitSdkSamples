================================================
           Webcast on Revit 2013 API 
          Autodesk Developer Network
================================================

This folder includes the following materials: 

* Recording - the recording of the webcast and the q_a.txt.
              Click on the wmv file to view the recording.
              Answers to questions asked using the Q&A Console 
              can be found in Revit2013API_Webcast_May_2012_QA.docx 
* Webcast   - Revit2013 API.pptx
            - The powerpoint slides used in the recording. 
* Code Samples - Code samples used for the demo. Please see
                 below for the notes about each samples. 

About Code Samples folder
-------------------------

This folder includes samples demonstrated in the webcast
presentation. Some samples that were not demonstrated during
the webcast but used in the presentation slides are also
included. 

----------
SourceCS
----------

If you prefer to use C# for all the samples, open the 
WebcastDemo.sln in this folder. 

------------------
SourceVB
------------------

If you prefer to use VB.Net for all the samples, open the 
WebcastDemo.sln in this folder. 

---------
Demo.rvt
---------

A sample revit file with a few simple elements that can be used to
try the functionality demonstrated by the sample code.
If you prefer, you may use any other Revit file.
 

Functionality demonstrated by the C# and VB.Net solutions
-----------------------------------------------------------

1) HelloWorldCmd         - A bare-bone example of an external command.

2) HelloWorldApp         - A bare-bone example of an external application.

3) CommandData           - Demonstrates the parameters of the execute method 
                           of the IExternalCommand interface.

4) SelectedElements      - Demonstrates the method to retrieve 
                           the selected elements.

5) FilteredElements      - Demonstrates the use of FilteredElementCollector to 
		           identify all Walls that exceed a certain length.

6) AllElements           - Demonstrates the use of FilteredElementCollector to 
		           retrieve all elements in the model.

7) ElementIdentification - Demonstrates the method to identify the type of the
                           element.

8) AllWalls              - Demonstrates the use of FilteredElementCollector to 
                           retrieve all walls in the model.

9) AllDoors              - Demonstrates the use of FilteredElementCollector to 
                           retrieve all doors in the model.

10) ElementCreation      - Demonstrates the use of Creation namespace and the
                           static creation method to create a wall.

11) ElementModification  - Demonstrates the use of ElementTransformUtils to 
                           rotate a wall.

12) BuiltInParameters    - Demonstrates the method to retrieve Built-In parameters


13) SharedParameter      - Demonstrates the creation of shared parameter and 
                           binding it to the Door type.


Release History
---------------

1.0    Original release

(C) Copyright 2010-2012 by Autodesk, Inc. 

Permission to use, copy, modify, and distribute this software in
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
UNINTERRUPTED OR ERROR FREE.