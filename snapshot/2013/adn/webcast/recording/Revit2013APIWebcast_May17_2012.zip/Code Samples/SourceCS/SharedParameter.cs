﻿#region Copyright
//
// Copyright (C) 2010-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
// Ported from old rac labs by Jeremy Tammik
// 
#endregion // Copyright

using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

#region Revit Namespaces

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Attributes;

#endregion

namespace IntroCs
{
/// <summary>
/// Create a new shared parameter, then set and 
/// retrieve its value.
/// In this example, we store a fire rating value 
/// on all doors.
/// Please also look at the FireRating Revit SDK sample.
/// </summary>
/// ' To View Per-doc shared parameters in Revit 2013
//'Ribbon-> Manage Tab -> Project Information

//' To view per-element shared parameter in Revit 2013
//' In the project browser -> Families --> Doors 
// --> Select any door type (say M_Single-Flush --> 0762 x 2032mm) 
//'Right-Click -> Type Properties

[Transaction(TransactionMode.Manual)]
[Regeneration(RegenerationOption.Manual)]
class SharedParameter : IExternalCommand
{
    const string kSharedParamsGroupAPI = "API Parameters";
    const string kSharedParamsDefFireRating = "API FireRating";
    const string kSharedParamsPath 
                               = "C:\\Temp\\SharedParams.txt";

    public Result Execute(
                            ExternalCommandData commandData,
                            ref string message,
                            ElementSet elements
                         )
    {
        UIDocument uidoc 
                    = commandData.Application.ActiveUIDocument;
        Application app = commandData.Application.Application; 
        Document doc = uidoc.Document;

        Transaction tr = new Transaction(doc);
        try
        {
            if (tr.Start("SharedParameterTransaction") != TransactionStatus.Started)
            {
                return Result.Failed;
            }
            // Get the current shared params definition file
            DefinitionFile sharedParamsFile = GetSharedParamsFile(app);
            if (null == sharedParamsFile)
            {
                message = "Error getting the shared params file.";
                return Result.Failed;
            }

            // Get or create the shared params group
            DefinitionGroup sharedParamsGroup
                                    = GetOrCreateSharedParamsGroup
                                        (
                                            sharedParamsFile,
                                            kSharedParamsGroupAPI
                                        );
            if (null == sharedParamsGroup)
            {
                message = "Error getting the shared params group.";
                return Result.Failed;
            }

            Category cat = doc.Settings.Categories.get_Item
                                    (
                                        BuiltInCategory.OST_Doors
                                    );

            // Visibility of the new parameter:
            // Category.AllowsBoundParameters property indicates
            // if a category can have shared or project parameters. 
            // If it is false, it may not be bound to shared 
            // parameters using the BindingMap. 
            // Please note that non-user-visible parameters can 
            // still be bound to these categories. 
            bool visible = cat.AllowsBoundParameters;

            // Get or create the shared params definition
            Definition fireRatingParamDef
                            = GetOrCreateSharedParamsDefinition
                            (
                                sharedParamsGroup,
                                ParameterType.Number,
                                kSharedParamsDefFireRating,
                                visible
                            );
            if (null == fireRatingParamDef)
            {
                message = "Error in creating shared parameter.";
                return Result.Failed;
            }

            // Create the category set for binding and add the 
            // category we are interested in, doors or walls or 
            // whatever:
            CategorySet catSet = app.Create.NewCategorySet();
            try
            {
                catSet.Insert(cat);
            }
            catch (Exception)
            {
                message = string.Format
                (
                    "Error adding '{0}' category to parameters binding set.",
                    cat.Name
                );
                return Result.Failed;
            }

            // Bind the param
            Binding binding = app.Create.NewInstanceBinding
                                                (
                                                    catSet
                                                );

            // We could check if already bound, but looks like
            // Insert will just ignore it in such case
            doc.ParameterBindings.Insert(
                                            fireRatingParamDef,
                                            binding
                                        );

            tr.Commit();

            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            // If there are something wrong, give error information and return failed
            if ((tr != null) && tr.HasStarted() && !tr.HasEnded())
            {
                tr.RollBack();
            }

            message = ex.Message;
            return Autodesk.Revit.UI.Result.Failed;
        }
    }

    /// <summary>
    /// Helper to get shared parameters file.
    /// </summary>
    public static DefinitionFile GetSharedParamsFile(Application app)
    {
        // Get current shared params file name
        string sharedParamsFileName;
        try
        {
            sharedParamsFileName = app.SharedParametersFilename;
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                                "Get shared params file",
                                "No shared params file set:" 
                                + ex.Message
                           );
            return null;
        }

        if (0 == sharedParamsFileName.Length ||
                !System.IO.File.Exists(sharedParamsFileName))
        {
            StreamWriter stream;
            stream = new StreamWriter(kSharedParamsPath);
            stream.Close();
            app.SharedParametersFilename = kSharedParamsPath;
            sharedParamsFileName = app.SharedParametersFilename;
        }

        // Get the current file object and return it
        DefinitionFile sharedParametersFile;
        try
        {
            sharedParametersFile = app.OpenSharedParameterFile();
        }
        catch (Exception ex)
        {
            TaskDialog.Show(
                "Get shared params file", 
                "Cannnot open shared params file:" + ex.Message);
            sharedParametersFile = null;
        }
        return sharedParametersFile;
    }

    public static DefinitionGroup GetOrCreateSharedParamsGroup
                        (
                            DefinitionFile sharedParametersFile,
                            string groupName
                        )
    {
        DefinitionGroup g 
            = sharedParametersFile.Groups.get_Item(groupName);
        if (null == g)
        {
            try
            {
                g = sharedParametersFile.Groups.Create(groupName);
            }
            catch (Exception)
            {
                g = null;
            }
        }
        return g;
    }

    public static Definition GetOrCreateSharedParamsDefinition
                                (
                                    DefinitionGroup defGroup,
                                    ParameterType defType,
                                    string defName,
                                    bool visible
                                )
    {
        Definition definition 
                    = defGroup.Definitions.get_Item(defName);
        if (null == definition)
        {
            try
            {
                definition 
                    = defGroup.Definitions.Create(
                                                    defName, 
                                                    defType, 
                                                    visible
                                                 );
            }
            catch (Exception)
            {
                definition = null;
            }
        }
        return definition;
    }
}

} // namespace
