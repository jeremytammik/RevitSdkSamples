﻿#Region "Copyright"
'
' Copyright (C) 2010-2012 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'
' Ported from old rac labs by Jeremy Tammik
' 
#End Region

Imports System.Collections.Generic
Imports System.Linq
Imports System.IO

#Region "Revit Namespaces"

Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.UI.Selection
Imports Autodesk.Revit.Attributes

#End Region


<Transaction(TransactionMode.Manual)> _
<Regeneration(RegenerationOption.Manual)> _
Class SharedParameter
    Implements Autodesk.Revit.UI.IExternalCommand

    Const kSharedParamsGroupAPI As String = "API Parameters"
    Const kSharedParamsDefFireRating As String = "API FireRating"
    Const kSharedParamsPath As String = "C:\Temp\SharedParams.txt"

    Public Function Execute( _
      ByVal commandData As Autodesk.Revit.UI.ExternalCommandData, _
      ByRef message As String, _
      ByVal elements As Autodesk.Revit.DB.ElementSet) _
      As Autodesk.Revit.UI.Result _
      Implements Autodesk.Revit.UI.IExternalCommand.Execute

        Dim uidoc As UIDocument = commandData.Application.ActiveUIDocument
        Dim app As Application = commandData.Application.Application
        Dim doc As Document = uidoc.Document

        Dim tr As New Transaction(doc)
        Try
            If tr.Start("SharedParameterTransaction") <> TransactionStatus.Started Then
                Return Result.Failed
            End If
            ' Get the current shared params definition file
            Dim sharedParamsFile As DefinitionFile = GetSharedParamsFile(app)
            If sharedParamsFile Is Nothing Then
                message = "Error getting the shared params file."
                Return Result.Failed
            End If

            ' Get or create the shared params group
            Dim sharedParamsGroup As DefinitionGroup = GetOrCreateSharedParamsGroup(sharedParamsFile, kSharedParamsGroupAPI)
            If sharedParamsGroup Is Nothing Then
                message = "Error getting the shared params group."
                Return Result.Failed
            End If

            Dim cat As Category = doc.Settings.Categories.Item(BuiltInCategory.OST_Doors)

            ' Visibility of the new parameter:
            ' Category.AllowsBoundParameters property indicates
            ' if a category can have shared or project parameters. 
            ' If it is false, it may not be bound to shared 
            ' parameters using the BindingMap. 
            ' Please note that non-user-visible parameters can 
            ' still be bound to these categories. 
            Dim visible As Boolean = cat.AllowsBoundParameters

            ' Get or create the shared params definition
            Dim fireRatingParamDef As Definition = GetOrCreateSharedParamsDefinition(sharedParamsGroup, ParameterType.Number, kSharedParamsDefFireRating, visible)
            If fireRatingParamDef Is Nothing Then
                message = "Error in creating shared parameter."
                Return Result.Failed
            End If

            ' Create the category set for binding and add the 
            ' category we are interested in, doors or walls or 
            ' whatever:
            Dim catSet As CategorySet = app.Create.NewCategorySet()
            Try
                catSet.Insert(cat)
            Catch generatedExceptionName As Exception
                message = String.Format("Error adding '{0}' category to parameters binding set.", cat.Name)
                Return Result.Failed
            End Try

            ' Bind the param
            Dim binding As Binding = app.Create.NewInstanceBinding(catSet)

            ' We could check if already bound, but looks like
            ' Insert will just ignore it in such case
            doc.ParameterBindings.Insert(fireRatingParamDef, binding)

            tr.Commit()

            Return Result.Succeeded
        Catch ex As Exception
            ' If there are something wrong, give error information and return failed
            If (tr IsNot Nothing) AndAlso tr.HasStarted() AndAlso Not tr.HasEnded() Then
                tr.RollBack()
            End If

            message = ex.Message
            Return Autodesk.Revit.UI.Result.Failed
        End Try
    End Function

    ''' <summary>
    ''' Helper to get shared parameters file.
    ''' </summary>
    Public Shared Function GetSharedParamsFile(ByVal app As Application) As DefinitionFile
        ' Get current shared params file name
        Dim sharedParamsFileName As String
        Try
            sharedParamsFileName = app.SharedParametersFilename
        Catch ex As Exception
            TaskDialog.Show("Get shared params file", "No shared params file set:" & ex.Message)
            Return Nothing
        End Try

        If 0 = sharedParamsFileName.Length OrElse Not System.IO.File.Exists(sharedParamsFileName) Then
            Dim stream As StreamWriter
            stream = New StreamWriter(kSharedParamsPath)
            stream.Close()
            app.SharedParametersFilename = kSharedParamsPath
            sharedParamsFileName = app.SharedParametersFilename
        End If

        ' Get the current file object and return it
        Dim sharedParametersFile As DefinitionFile
        Try
            sharedParametersFile = app.OpenSharedParameterFile()
        Catch ex As Exception
            TaskDialog.Show("Get shared params file", "Cannnot open shared params file:" & ex.Message)
            sharedParametersFile = Nothing
        End Try
        Return sharedParametersFile
    End Function

    Public Shared Function GetOrCreateSharedParamsGroup(ByVal sharedParametersFile As DefinitionFile, ByVal groupName As String) As DefinitionGroup
        Dim g As DefinitionGroup = sharedParametersFile.Groups.Item(groupName)
        If g Is Nothing Then
            Try
                g = sharedParametersFile.Groups.Create(groupName)
            Catch generatedExceptionName As Exception
                g = Nothing
            End Try
        End If
        Return g
    End Function

    Public Shared Function GetOrCreateSharedParamsDefinition(ByVal defGroup As DefinitionGroup, ByVal defType As ParameterType, ByVal defName As String, ByVal visible As Boolean) As Definition
        Dim definition As Definition = defGroup.Definitions.Item(defName)
        If definition Is Nothing Then
            Try
                definition = defGroup.Definitions.Create(defName, defType, visible)
            Catch generatedExceptionName As Exception
                definition = Nothing
            End Try
        End If
        Return definition
    End Function
End Class

