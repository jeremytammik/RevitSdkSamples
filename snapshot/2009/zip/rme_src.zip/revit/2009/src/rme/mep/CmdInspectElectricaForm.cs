#region Header
// Revit MEP API sample application
//
// Copyright (C) 2007-2008 by Jeremy Tammik, Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  
// AUTODESK, INC. DOES NOT WARRANT THAT THE OPERATION OF THE 
// PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject
// to restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Revit;
#endregion // Namespaces

namespace mep
{
  public partial class CmdInspectElectricaForm : Form
  {
      private string _pnlNameToFind;
      private List<string> keys;
      IDictionary<string, List<Element>> _map;
    public CmdInspectElectricaForm( IDictionary<string, List<Element>> map )
    {
      InitializeComponent();
      //
      // we could implement sorting on the tree view itself, 
      // but since we already worked out sorting algorithms
      // for our dictionaries and maps in the main command
      // for printing to the debug output window, we may as 
      // well reuse those and leave the tree view unsorted:
      //
      _map = map;
      keys = new List<string>( map.Keys );



      List<string> rootPanels =  keys.FindAll(FindUnassigned);
      foreach (string rootPanel in rootPanels)
      {
          PopulateRootPanelNodes(rootPanel);

      }

      //keys.Sort( new CmdInspectElectrical.PanelSystemComparer() );
      //foreach( string panelAndSystem in keys )
      //{
      //  string[] pair = panelAndSystem.Split( ':' );
      //  Debug.Assert( 2 == pair.GetLength( 0 ), "expected string in the form panel:system" );
      //  string panelName = pair[0];
      //  string systemName = pair[1];
      //  tn = tv.Nodes.ContainsKey( panelName )
      //    ? tv.Nodes.Find( panelName, false )[0]
      //    : tv.Nodes.Add( panelName, panelName );
      //  tn = tn.Nodes.ContainsKey( systemName )
      //    ? tn.Nodes.Find( systemName, false )[0]
      //    : tn.Nodes.Add( systemName, systemName );
      //  List<Element> elements = map[panelAndSystem];
      //  List<string> a = new List<string>( elements.Count );
      //  foreach( Element e in elements )
      //  {
      //    a.Add( Util.BrowserDescription( e ) );
      //  }
      //  a.Sort();
      //  foreach( string s in a )
      //  {
      //    tn.Nodes.Add( s );
      //  }
      //}
    }

      private void PopulateRootPanelNodes(string panelAndSystem)
      {
          string[] pair = panelAndSystem.Split(':');
          Debug.Assert(2 == pair.GetLength(0), "expected string in the form panel:system");
          string unassigned = pair[0];
          string panelName = pair[1];


          PopulatePanelSystemNodes(tv.Nodes, panelName);
          
      }

      private void PopulatePanelSystemNodes(TreeNodeCollection tnc, string panelName)
      {
          TreeNode tn = tnc.Add(panelName, panelName);
          _pnlNameToFind = panelName;
          List<string> systemsForPanel = keys.FindAll(FindPanelBasedOnName);
          systemsForPanel.Sort(new CmdInspectElectrical.PanelSystemComparer());
          foreach (string panelAndSystem in systemsForPanel)
          {
              string[] pair = panelAndSystem.Split(':');
              Debug.Assert(2 == pair.GetLength(0), "expected string in the form panel:system");
              //string panelName = pair[0];
              string systemName = pair[1];

              TreeNode systemNode = tn.Nodes.Add(systemName);
              PopulateSystemNodes(systemNode, panelAndSystem);
          }
      }

      private void PopulateSystemNodes(TreeNode tn, string panelAndSystem)
      {
          List<Element> elements = _map[panelAndSystem];
          foreach (Element e in elements)
          {
              if (e.Category.Name == "Electrical Equipment")
              {
                  PopulatePanelSystemNodes(tn.Nodes, e.Name);
                  System.Drawing.Font oldFont = this.Font;
                  tn.NodeFont = new System.Drawing.Font(oldFont, System.Drawing.FontStyle.Bold);
                  oldFont.Dispose();
              }
              else
              {
                  tn.Nodes.Add(Util.BrowserDescription(e));
              }
          }
      }


      private bool FindUnassigned(string str)
      {
          string[] pnl = str.Split(':');
          Debug.Assert(2 == pnl.GetLength(0), "expected string in the form panel:system");
          return string.Compare(pnl[0], "unassigned", true) == 0;
      }

      private bool FindPanelBasedOnName(string strToCheck)
      {
          string[] pnlToCheck = strToCheck.Split(':');
          Debug.Assert(2 == pnlToCheck.GetLength(0), "expected string in the form panel:system");
          return string.Compare(pnlToCheck[0], _pnlNameToFind, true) == 0;
      }
  }
}
