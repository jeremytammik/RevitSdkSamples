using System;
using System.Collections.Generic;
using System.Text;

namespace mep
{
    class PanelTreeNodeHelperList : List<PanelTreeNodeHelper>
    {
        public PanelTreeNodeHelperList(List<Autodesk.Revit.Element> list)
        {
            foreach (Autodesk.Revit.Element elem in list)
            {
                this.Add(new PanelTreeNodeHelper(elem));
            }
        }

        internal void SetNode(Autodesk.Revit.Element e, System.Windows.Forms.TreeNode tn)
        {
            foreach (PanelTreeNodeHelper ptnh in this)
            {
                if (ptnh.Element == e)
                {
                    ptnh.TreeNode = tn;
                    return;
                }
            }
        }

    }
}
