using System;
using System.Collections.Generic;
using System.Text;

namespace mep
{
    class PanelTreeNodeHelper
    {
        public override string ToString()
        {
            return _element.Name ;
        }

        System.Windows.Forms.TreeNode _tn;

        public System.Windows.Forms.TreeNode TreeNode
        {
            get { return _tn; }
            set { _tn = value; }
        }
        string _en;

        //public PanelTreeNodeHelper(System.Windows.Forms.TreeNode tn, string equipmentName)
        //{
        //    _tn = tn;
        //    _en = equipmentName;
        //}

        Autodesk.Revit.Element _element;

        public Autodesk.Revit.Element Element
        {
            get { return _element; }
            set { _element = value; }
        }

        public PanelTreeNodeHelper(Autodesk.Revit.Element elem)
        {
            _element = elem;
        }

        public static int CompareByName(PanelTreeNodeHelper x, PanelTreeNodeHelper y)
        {
            return string.Compare(x.ToString(), y.ToString());
        }
    }
}
