using System;
using System.Collections.Generic;
using System.Text;

namespace VanWassenhove.DomainObjects
{
    public class Person
    {
        private int id;
        private string name;
        private DateTime birthday;
        private double score;

        public Person(int id, string name, DateTime birthday, double score)
        {
            this.id = id;
            this.name = name;
            this.birthday = birthday;
            this.score = score;
        }

        public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public DateTime Birthday
        {
            get { return this.birthday; }
            set { this.birthday = value; }
        }

        public double Score
        {
            get { return this.score; }
            set { this.score = value; }
        }

    }
}
