using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using VanWassenhove.Util;
using VanWassenhove.DomainObjects;

namespace VanWassenhove.Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.ColumnId.DataPropertyName = "Id";
            this.ColumnName.DataPropertyName = "Name";
            this.ColumnBirthday.DataPropertyName = "Birthday";
            this.ColumnScore.DataPropertyName = "Score";

            List<Person> list = new List<Person>();
            list.Add(new Person(1, "Tim", new DateTime(1980, 4, 30), 100.1));
            list.Add(new Person(2, "Amy", new DateTime(1983, 1, 1), 200.2));
            list.Add(new Person(3, "Sarah", new DateTime(1984, 1, 24), 300.3));
            list.Add(new Person(4, "Mike", new DateTime(1988, 3, 21), 400.4));
            
            SortableBindingList<Person> persons = new SortableBindingList<Person>(list);

            this.dataGridView1.DataSource = persons;
        }
    }
}