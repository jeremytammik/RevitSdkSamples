#region Header
// Revit MEP API sample application
//
// Copyright (C) 2007 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  
// AUTODESK, INC. DOES NOT WARRANT THAT THE OPERATION OF THE 
// PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject
// to restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Collections;
using System.Diagnostics;
using WinForms = System.Windows.Forms;
using Autodesk.Revit;
using Autodesk.Revit.Collections; // Map
using Autodesk.Revit.Elements;
using Autodesk.Revit.Enums;
using Autodesk.Revit.Parameters;
#endregion // Namespaces

namespace mep
{
  class Util
  {
    #region Exceptions
    public class ParameterException : Exception
    {
      public ParameterException( string parameterName, string description, Element elem )
        :
      base( string.Format( "'{0}' parameter not defined for {1} {2}", parameterName, description, elem.Id.Value.ToString() ) )
      {
      }
    }

    public class RoomParameterException : Exception
    {
      public RoomParameterException( string parameterName, Room room )
        :
      base( string.Format( "'{0}' parameter not defined for room {1}", parameterName, room.Number ) )
      {
      }
    }

    public class TerminalParameterException : ParameterException
    {
      public TerminalParameterException( string parameterName, FamilyInstance terminal )
        :
      base( parameterName, "terminal", terminal )
      {
      }
    }
    #endregion // Exceptions

    #region Formatting Utility
    public static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    public static string DotOrColon( int n )
    {
      return 0 == n ? "." : ":";
    }

    public static string IdList( IEnumerable elements )
    {
      string s = string.Empty;
      foreach( Element e in elements )
      {
        if( 0 < s.Length )
        {
          s += ", ";
        }
        s += e.Id.Value.ToString();
      }
      return s;
    }

    public static string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    public static string ElementDescription( Element e )
    {
      string description = ( null == e.Category )
        ? e.GetType().Name
        : e.Category.Name;
      if( null != e.Name )
      {
        description += " '" + e.Name + "'";
      }
      return description;
    }

    public static string ElementDescription( Element e, bool includeId )
    {
      string description = ElementDescription( e );
      if( includeId )
      {
        description += " " + e.Id.Value.ToString();
      }
      return description;
    }
    #endregion // Formatting Utility

    #region Message
    const string _caption = "Revit MEP API Sample";

    /// <summary>
    /// MessageBox wrapper for informational message.
    /// </summary>
    /// <param name="msg"></param>
    public static void InfoMsg( string msg )
    {
      WinForms.MessageBox.Show( msg, _caption, WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information );
    }

    /// <summary>
    /// MessageBox wrapper for error message.
    /// </summary>
    /// <param name="msg"></param>
    public static void ErrorMsg( string msg )
    {
      WinForms.MessageBox.Show( msg, _caption, WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Error );
    }

    /// <summary>
    /// MessageBox wrapper for question message.
    /// </summary>
    public static bool QuestionMsg( string msg )
    {
      return WinForms.DialogResult.Yes
        == WinForms.MessageBox.Show( msg, _caption, WinForms.MessageBoxButtons.YesNo, WinForms.MessageBoxIcon.Question );
    }
    #endregion // Message

    #region Parameter Access
    /// <summary>
    /// Helper to get a specific parameter by name.
    /// </summary>
    static Parameter GetParameterFromName( Element elem, string name )
    {
      foreach( Parameter p in elem.Parameters )
      {
        if( p.Definition.Name == name )
        {
          return p;
        }
      }
      return null;
    }

    public static Definition GetParameterDefinitionFromName( Element elem, string name )
    {
      Parameter p = GetParameterFromName( elem, name );
      return ( null == p ) ? null : p.Definition;
    }

    public static double GetParameterValueFromName( Element elem, string name )
    {
      Parameter p = GetParameterFromName( elem, name );
      if( null == p )
      {
        throw new ParameterException( name, "element", elem );
      }
      return p.AsDouble();
    }

      public static string GetStringParameterValueFromName(Element elem, string name)
      {
          Parameter p = GetParameterFromName(elem, name);
          if (null == p)
          {
              throw new ParameterException(name, "element", elem);
          }
          return p.AsString();
      }

    static void DumpParameters( Element elem )
    {
      foreach( Parameter p in elem.Parameters )
      {
        Debug.WriteLine( p.Definition.ParameterType + " " + p.Definition.Name );
      }
    }

    public static double GetRoomParameterValue( Room room, BuiltInParameter bip, string name )
    {
      Parameter p = room.get_Parameter( bip );
      if( null == p )
      {
        throw new RoomParameterException( name, room );
      }
      return p.AsDouble();
    }

    public static Parameter GetRoomParameter( Room room, string name )
    {
      Parameter p = GetParameterFromName( room, name );
      if( null == p )
      {
        throw new RoomParameterException( name, room );
      }
      return p;
    }

    public static double GetRoomParameterValue( Room room, string name )
    {
      Parameter p = GetRoomParameter( room, name );
      return p.AsDouble();
    }

    public static bool IsSupplyAir( FamilyInstance terminal )
    {
      Parameter p = terminal.get_Parameter( Bip.SystemType );
      if( null == p )
      {
        throw new TerminalParameterException( Bip.SystemType.ToString(), terminal );
      }
      return ParameterValue.SupplyAir == p.AsString();
    }

    public static Parameter GetTerminalFlowParameter( FamilyInstance terminal )
    {
      //
      // the built-in parameter "Flow" is read-only:
      //
      //Parameter p = terminal.get_Parameter( _bipFlow );
      //
      // The parameter we are interested in is not the BuiltInParameter... 
      //
      Definition d = Util.GetParameterDefinitionFromName( terminal, ParameterName.Flow );
      Parameter p = terminal.get_Parameter( d );
      if( null == p )
      {
        throw new Util.TerminalParameterException( ParameterName.Flow, terminal );
      }
      return p;
    }
    #endregion // Parameter Access

    #region Element Access
    private static ElementSet GetSupplyAirTerminals2008( Application app )
    {
      ElementSet es = app.Create.NewElementSet();
      //using( ProgressForm progressForm = new ProgressForm() )
      {
        //progressForm.Show();
        //progressForm.HideProgressBar();

        Document doc = app.ActiveDocument;
        Category categoryAirTerminal = doc.Settings.Categories.get_Item( BuiltInCategory.OST_DuctTerminal );
        ElementIterator it = doc.get_Elements( typeof( FamilyInstance ) );
        int elementCount = 0;

        while( it.MoveNext() )
        {
          ++elementCount;
          if( 482 == elementCount ) // kludge to avoid crash in MoveNext()
          {
            break;
          }
          ////progressForm.SetText( string.Format( "Finding Supply Air Terminals\n{0} Elements Checked", elementCount ) );

          FamilyInstance terminal = it.Current as FamilyInstance;
          if( null != terminal.Category
            && categoryAirTerminal == terminal.Category
            && Util.IsSupplyAir( terminal ) )
          {
            es.Insert( terminal );
          }
          ////DumpParameters( terminal );
        }
        ////progressForm.Hide();
        ////progressForm.Dispose();
      }
      return es;
    }

    private static ElementSet GetSupplyAirTerminals2009( Application app )
    {
      Document doc = app.ActiveDocument;
      Autodesk.Revit.Creation.Application a = app.Create;
      CategoryFilter categoryFilter = a.Filter.NewCategoryFilter( BuiltInCategory.OST_DuctTerminal );
      ParameterFilter parameterFilter = a.Filter.NewParameterFilter( Bip.SystemType, CriteriaFilterType.Equal, ParameterValue.SupplyAir );
      TypeFilter typeFilter = a.Filter.NewTypeFilter( typeof( FamilyInstance ) );
      LogicAndFilter andFilter = a.Filter.NewLogicAndFilter( typeFilter, categoryFilter );
      LogicAndFilter and2Filter = a.Filter.NewLogicAndFilter( parameterFilter, andFilter );
      ElementIterator it = doc.get_Elements( and2Filter );
      ElementSet es = a.NewElementSet();
      while( it.MoveNext() )
      {
        es.Insert( it.Current as Element );
      }
      return es;
    }

    public static ElementSet GetSupplyAirTerminals( Application app )
    {
      return Const.UseRevitApiFilters
        ? GetSupplyAirTerminals2009( app )
        : GetSupplyAirTerminals2008( app );
    }

    /// <summary>
    /// Call the ElementIterator MoveNext() method.
    /// This is wrapped in a try/catch clause, because in Revit 2009 beta 1 and 3,
    /// MoveNext() can throw an exception if run on an RME model inside RAC.
    /// If this exception is caught, we abort the iteration ... we don't really 
    /// have any other choice at the moment ... cf. 
    /// SPR #147425 [ElementIterator returns null element, MoveNext() crashes].
    /// </summary>
    /// <param name="it">Iterator to move to next item</param>
    /// <returns>The same as MoveNext(), or false if a NullReferenceException exception is thrown</returns>
    public static bool TryMoveNext( ref ElementIterator it )
    {
      try
      {
        return it.MoveNext();
      }
      catch( System.NullReferenceException )
      {
        return false;
      }
    }
    #endregion // Element Access
  }
}
