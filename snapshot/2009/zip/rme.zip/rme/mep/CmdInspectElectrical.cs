using System;
using System.Collections;
using System.Diagnostics;
using Autodesk.Revit;
using Autodesk.Revit.Collections; // Map
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.MEP;

namespace mep
{
    class CmdInspectElectrical : IExternalCommand
    {
        public IExternalCommand.Result Execute(
          ExternalCommandData commandData,
          ref String message,
          ElementSet elements)
        {
            try
            {
                ElementSet elecEqpmSet = GetElectricalEquipment(commandData.Application);
                foreach (FamilyInstance elecEqip in elecEqpmSet)
                {
                    System.Diagnostics.Debug.WriteLine(elecEqip.Name);
                    MEPModel mepModel = elecEqip.MEPModel;
                    DoSomethingWithMEPModel(mepModel);
                    
                }
                return IExternalCommand.Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return IExternalCommand.Result.Failed;
            }
        }

        private static void DoSomethingWithMEPModel(MEPModel mepModel)
        {
            if (mepModel.ElectricalSystems == null)
            {
                Debug.WriteLine("\tnull");
                return;
            }
            foreach (ElectricalSystem elecSyst in mepModel.ElectricalSystems)
            {
                Debug.WriteLine(string.Format("\t{0}",elecSyst.Name));
            }
        }

        private static ElementSet GetElectricalEquipment(Application app)
        {
            Document doc = app.ActiveDocument;
            Autodesk.Revit.Creation.Application a = app.Create;
            CategoryFilter categoryFilter = a.Filter.NewCategoryFilter(BuiltInCategory.OST_ElectricalEquipment);
            TypeFilter typeFilter = a.Filter.NewTypeFilter(typeof(FamilyInstance));
            LogicAndFilter andFilter = a.Filter.NewLogicAndFilter(typeFilter, categoryFilter);
            ElementIterator it = doc.get_Elements(andFilter);
            ElementSet es = a.NewElementSet();
            while (it.MoveNext())
            {
                es.Insert(it.Current as Element);
            }
            return es;
        }
    }
}
