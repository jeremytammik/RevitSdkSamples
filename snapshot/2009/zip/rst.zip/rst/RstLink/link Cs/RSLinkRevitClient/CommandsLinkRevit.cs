#region Header
// RstLink
//
// Copyright (C) 2007-2008 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

//INSTANT C# NOTE: Formerly VB.NET project-level imports:
using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;

using RSLink;

#region Imports

using System.IO;
using System.Xml.Serialization;
//Imports System.Runtime.Serialization.Formatters.Binary
using System.Runtime.Serialization.Formatters.Soap;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Symbols;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Geometry;

using RSLink;

#endregion

// Import inctremental changes from the RSLink intermediate XML file
namespace RSLinkRevitClient
{
  public class RSLinkImport : IExternalCommand
  {

    public IExternalCommand.Result Execute(ExternalCommandData commandData, ref string msg, ElementSet els)
    {

      Autodesk.Revit.Application app = commandData.Application;

      Hashtable _RSelems = null;

      // De-serialize the result file 
      OpenFileDialog dlg = new OpenFileDialog();
      try
      {
        // Select File to Open
        dlg.Filter = "RS Link xml files (*.xml)|*.xml";
        dlg.Title = "RS Link - Revit IMPORT from AutoCAD";
        if (dlg.ShowDialog() == DialogResult.OK)
        {
          FileStream fs = new FileStream(dlg.FileName, FileMode.Open);
          SoapFormatter sf = new SoapFormatter();
          sf.AssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Simple;
          sf.Binder = new RSLink.RsLinkBinder();
          _RSelems = sf.Deserialize(fs) as Hashtable;
          fs.Close();
        }
        else
        {
          MessageBox.Show("Command cancelled!");
          return IExternalCommand.Result.Failed;
        }

      }
      catch (Exception ex)
      {
        MessageBox.Show("Error when deserializing: " + ex.Message);
        return IExternalCommand.Result.Failed;
      }

      if (_RSelems.Count == 0)
      {
        MessageBox.Show("No elements found in the result file!");
        return IExternalCommand.Result.Cancelled;
      }

      // KIS: one big TRY block - would be better to be more specific..
      try
      {

        StreamWriter log = new StreamWriter(dlg.FileName + ".log");
        int iModified = 0;

        // Itearate all results
        IDictionaryEnumerator iter = _RSelems.GetEnumerator();
        while (iter.MoveNext())
        {
          RSMember m = iter.Value as RSMember;

          //ADD NEW elements 
          //================
          if (m.revitId == 0)
          {
            // In 8.1 API there are no ways to create new Families with Location as Curve, but Point only.
            // This has been addressed in 9.0 API - see eg CreateBeamsColumnsBraces sample in the SDK

            // Bonus: add new elements....

            //MODIFY NEW Sizes (Types)
            //=======================
          }
          else
          {
            Autodesk.Revit.ElementId id = new Autodesk.Revit.ElementId();
            id.Value = m.revitId;
            Autodesk.Revit.Elements.FamilyInstance fi = app.ActiveDocument.get_Element(ref id) as FamilyInstance;

            // Check if the Type has changed (in theory we'd need to check Family as well)
            string newType = m._type;
            if (!(fi.Symbol.Name.Equals(newType)))
            {

              log.WriteLine("Member Id=" + m.revitId + ": Type changed from " + fi.Symbol.Name + " to " + newType);

              string catName = null;
              if (m._usage.Equals("Column"))
              {
                catName = "Structural Columns";
              }
              else
              {
                catName = "Structural Framing";
              }

              Autodesk.Revit.Symbols.FamilySymbol newSymb = GetFamilySymbol(app.ActiveDocument, catName, newType);
              if (newSymb == null)
              {
                log.WriteLine("  ERROR: Could not find the new Symbol loaded in RVT!");
              }
              else
              {
                try
                {
                  fi.Symbol = newSymb;
                  log.WriteLine("  Symbol SUSSESSFULLY changed!");
                  iModified += 1;
                }
                catch (Exception ex)
                {
                  log.WriteLine("  ERROR: Could not change to the new Symbol ?!");
                }
              }

            }
          }

        }
        MessageBox.Show("Successfully MODIFIED Types for " + iModified + " structural members!");
        log.Close();

      }
      catch (Exception ex)
      {
        MessageBox.Show("Error when processing: " + ex.Message);
        return IExternalCommand.Result.Failed;
      }
      finally
      {
      }

      return IExternalCommand.Result.Succeeded;
    }

    //Helper to get specified Type for a Category
    //   (in theory, we can have non-unique solution, ie the same Type name for more than one family from this category!)
    public static Autodesk.Revit.Symbols.FamilySymbol GetFamilySymbol(Document doc, string catName, string typeName)
    {

      // todo: use 2009 element filtering

      ElementIterator iter = doc.Elements;
      while (iter.MoveNext())
      {
        Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;

        // We got a Family
        if (elem is Autodesk.Revit.Elements.Family)
        {
          Autodesk.Revit.Elements.Family fam = elem as Family;
          // If we have a match on Category name, loop all its types for the other match
          try
          {
            // we CANNOT use this, since Category is not implemented for Family objects :-( !
            //If fam.Category.Name.Equals(catName) Then
            //INSTANT C# NOTE: Commented this declaration since looping variables in 'foreach' loops are declared in the 'foreach' header in C#
            //			  Symbols.FamilySymbol sym = null;
            foreach (Autodesk.Revit.Symbols.FamilySymbol sym in fam.Symbols)
            {
              if (sym.Name.Equals(typeName))
              {
                if (sym.Category.Name.Equals(catName)) // must use it here - slightly more inefficient
                {
                  return sym;
                }
              }
            }
            //End If
          }
          catch
          {
          }
        }

      }

      // if here - haven't got it!
      return null;

    }

  }


  // Export all structural elements to the RSLink intermediate file
  // (only Columns and Framing implemented - skeleton code in place for others)
  public class RSLinkExport : IExternalCommand
  {

    public IExternalCommand.Result Execute(ExternalCommandData commandData, ref string msg, ElementSet els)
    {


      Autodesk.Revit.Application app = commandData.Application;
      Settings setting = app.ActiveDocument.Settings;
      // From RS3, we can make sure it works in all locales, so use localized category names:
      Autodesk.Revit.Category catStruColums = setting.Categories.get_Item(BuiltInCategory.OST_StructuralColumns);
      Autodesk.Revit.Category catStruFraming = setting.Categories.get_Item(BuiltInCategory.OST_StructuralFraming);
      Autodesk.Revit.Category catStruFoundation = setting.Categories.get_Item(BuiltInCategory.OST_StructuralFoundation);

      // No Dictionary was available in VB.NET 2003, so used untyped collection. If doing again in 2005 - better use Dictionary
      Hashtable _RSElems = new Hashtable();
      //alternatively
      //Dim _RSarray As New ArrayList

      // LOOP all elements and add to the collection
      ElementIterator iter = app.ActiveDocument.Elements;
      while (iter.MoveNext())
      {
        Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;

        // Strucural WALL
        if (elem is Wall)
        {
          Wall w = elem as Wall;
          try
          {
            AnalyticalModelWall anaWall = w.AnalyticalModel as AnalyticalModelWall;
            if (anaWall != null)
            {
              if (anaWall.Curves.Size > 0)
              {

                //ToDo WALL

              }
            }
          }
          catch
          {
          }

          // Strucural FLOOR
        }
        else if (elem is Autodesk.Revit.Elements.Floor)
        {
          Autodesk.Revit.Elements.Floor f = elem as Floor;
          try
          {
            AnalyticalModelFloor anaFloor = f.AnalyticalModel as AnalyticalModelFloor;
            if (anaFloor != null)
            {
              if (anaFloor.Curves.Size > 0)
              {

                //ToDo FLOOR

              }
            }
          }
          catch
          {
          }

          // Strucural CONTINUOUS FOOTING
        }
        else if (elem is Autodesk.Revit.Elements.ContFooting)
        {
          Autodesk.Revit.Elements.ContFooting cf = elem as Autodesk.Revit.Elements.ContFooting;
          try
          {
            AnalyticalModel3D ana3D = cf.AnalyticalModel as AnalyticalModel3D;
            if (ana3D != null)
            {
              if (ana3D.Curves.Size > 0)
              {

                //ToDo CONT.FOOTING

              }
            }
          }
          catch
          {
          }

          // One of Strucural Standard Families
        }
        else if (elem is Autodesk.Revit.Elements.FamilyInstance)
        {
          try
          {
            Autodesk.Revit.Elements.FamilyInstance fi = elem as FamilyInstance;
            //INSTANT C# NOTE: The following VB 'Select Case' included range-type or non-constant 'Case' expressions and was converted to C# 'if-else' logic:
            //			  Select Case fi.Category.Name

            // From RS3, better use local-independent design
            // Case "Structural Columns", "Structural Framing"
            //ORIGINAL LINE: Case catStruColums.Name, catStruFraming.Name
            if ((fi.Category.Name == catStruColums.Name) || (fi.Category.Name == catStruFraming.Name))
            {
              try
              {
                AnalyticalModelFrame anaFrame = fi.AnalyticalModel as AnalyticalModelFrame;
                if (anaFrame != null)
                {

                  // Create MEMBER in neutral format and add it to the collection
                  RSMember member = CreateRSMember(fi, anaFrame);
                  if (member != null)
                  {
                    _RSElems.Add(member, member);
                  }

                }
              }
              catch
              {
              }

              //Case "Structural Foundations"
            }
            //ORIGINAL LINE: Case catStruFoundation.Name
            else if (fi.Category.Name == catStruFoundation.Name)
            {
              try
              {
                AnalyticalModelLocation anaLoc = fi.AnalyticalModel as AnalyticalModelLocation;
                if (anaLoc != null)
                {

                  //ToDo FOUNDATION...also change hard-coded category name

                }
              }
              catch
              {
              }

            }
          }
          catch
          {
          }

          //ToDo: all LOADS!
        }
        else if (elem is Autodesk.Revit.Elements.PointLoad)
        {
          //...
        }
        else if (elem is Autodesk.Revit.Elements.LineLoad)
        {
          //...
        }
        else if (elem is Autodesk.Revit.Elements.AreaLoad)
        {
          //...
        }

      }

      // Serialize the members to a file
      if (_RSElems.Count > 0)
      {

        // Select File to Save
        SaveFileDialog dlg = new SaveFileDialog();
        dlg.Filter = "RS Link xml files (*.xml)|*.xml";
        dlg.Title = "RS Link - Revit EXPORT to AutoCAD";
        dlg.FileName = "RSLinkRevitToAcad.xml";
        if (dlg.ShowDialog() == DialogResult.OK)
        {

          //SOAP (would be faster if BINARY, but just to make it readable)
          FileStream fs = new FileStream(dlg.FileName, FileMode.Create);
          SoapFormatter sf = new SoapFormatter();
          sf.AssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Simple;
          sf.Binder = new RSLink.RsLinkBinder();
          sf.Serialize(fs, _RSElems);
          fs.Close();
          MessageBox.Show("Successfully exported " + _RSElems.Count + " structural elements!");

        }
        else
        {
          MessageBox.Show("Command cancelled!");
          return IExternalCommand.Result.Cancelled;
        }

        //' NOTE: - (de)serialization works fine but all assemblies MUST be in the same folder as revit.EXE!
        //'       The same is true later when deserializing in AutoCAD - must put them in same folder with acad.EXE.

        //           SEE: Serialize the Collection to a file
        //           http://www.codeproject.com/soap/Serialization_Samples.asp
        //           Serialization(Headaches)
        //           http://www.dotnet4all.com/dotnet-code/2004/12/serialization-headaches.html
        //Try
        //    Dim fsTest As New FileStream("c:\temp\_RSLinkExport.xml", FileMode.Open)
        //    Dim sfTest As New SoapFormatter
        //    Dim elemsTest As Hashtable = sfTest.Deserialize(fsTest)
        //    fsTest.Close()
        //    MsgBox("Num.of DeSer = " & elemsTest.Count)
        //Catch ex As Exception
        //    MsgBox("Error in DeSer: " & ex.Message)
        //End Try

      }
      else
      {
        MessageBox.Show("No Structural Elements found in this model!");
      }

      return IExternalCommand.Result.Succeeded;
    }

    public RSMember CreateRSMember(Autodesk.Revit.Elements.FamilyInstance fi, AnalyticalModelFrame anaFrame)
    {
      try
      {
        int id = fi.Id.Value;
        Line line = anaFrame.Curve as Line;
        string type = fi.Symbol.Name;
        string usage = null;
        if (fi.Category.Name == "Structural Columns")
        {
          usage = "Column";
        }
        else
        {
          // This doesn't work any longer in structure 3! (was OK in 2?)
          //usage = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_TEXT_PARAM).AsString
          // Now must get the integer enumeration and map the name
          //124334  6	Other
          //124340  3	Girder
          //124349  5	Purlin
          //134865  6	Other
          //129463  7	Vertical Bracing
          //124337  3	Girder
          //124331  6	Other
          //124346  8	Horizontal Bracing
          //124343  4	Joist
          //129409  9	Kicker Bracing
          try
          {
            switch (fi.get_Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_PARAM).AsInteger())
            {
              case 3:
                usage = "Girder";
                break;
              case 4:
                usage = "Joist";
                break;
              case 5:
                usage = "Purlin";
                break;
              case 6:
                usage = "Other";
                break;
              case 7:
                usage = "Vertical Bracing";
                break;
              case 8:
                usage = "Horizontal Bracing";
                break;
              case 9:
                usage = "Kicker Bracing";
                break;
              default:
                usage = "Unknown";
                break;
            }
          }
          catch (Exception ex)
          {
            usage = "Parameter Fails";
          }

          //Dim p1 As Parameter = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_TEXT_PARAM)
          //If Not p1 Is Nothing Then
          //    MsgBox(p1.StorageType.ToString)
          //End If

          //Dim p2 As Parameter = fi.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_PARAM)
          //If Not p2 Is Nothing Then
          //    MsgBox(p2.StorageType.ToString)
          //End If
        }

        RSMember m = new RSMember(id, usage, type, new RSLine(new RSPoint(line.get_EndPoint(0).X, line.get_EndPoint(0).Y, line.get_EndPoint(0).Z), new RSPoint(line.get_EndPoint(1).X, line.get_EndPoint(1).Y, line.get_EndPoint(1).Z)));

        return m;
      }
      catch (Exception ex)
      {
        return null;
      }
    }

  }

} //end of root namespace