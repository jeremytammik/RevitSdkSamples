using System;
using System.Collections.Generic;
using System.Text;

namespace Be.TimVanWassenhove.TypedListDemo.BusinessObjects
{
    /// <summary>
    /// This class represents an Address
    /// </summary>
    public class Address
    {
        #region Fields

        private int id;
        private string street;
        private int postalCode;
        private string municipality;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="street"></param>
        /// <param name="postalCode"></param>
        /// <param name="municipality"></param>
        public Address(int id, string street, int postalCode, string municipality)
        {
            this.id = id;
            this.street = street;
            this.postalCode = postalCode;
            this.municipality = municipality;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the identification of the Address
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Gets and sets the street
        /// </summary>
        public string Street
        {
            get { return street; }
            set { street = value; }
        }

        /// <summary>
        /// Gets and sets the postalcode
        /// </summary>
        public int PostalCode
        {
            get { return postalCode; }
            set { postalCode = value; }
        }

        /// <summary>
        /// Gets and sets the municipality
        /// </summary>
        public string Municipality
        {
            get { return municipality; }
            set { municipality = value; }
        }

        #endregion
    }
}
