using System;
using System.Collections.Generic;
using System.Text;

namespace Be.TimVanWassenhove.TypedListDemo.BusinessObjects
{
    /// <summary>
    /// This class represents an Appointment
    /// </summary>
    public class Appointment
    {
        #region Fields

        private int id;
        private Patient patient;
        private DateTimeRange dateTimeRange;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="patient"></param>
        /// <param name="dateTimeRange"></param>
        public Appointment(int id, Patient patient, DateTimeRange dateTimeRange)
        {
            this.id = id;
            this.patient = patient;
            this.dateTimeRange = dateTimeRange;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the identification of the Appointment
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Gets and sets the identification of the involved patient
        /// </summary>
        public Patient Patient
        {
            get { return patient; }
            set { patient = value; }
        }

        /// <summary>
        /// Gets and sets the Range when the appointment takes place
        /// </summary>
        public DateTimeRange DateTimeRange
        {
            get { return dateTimeRange; }
            set { dateTimeRange = value; }
        }

        #endregion
    }
}
