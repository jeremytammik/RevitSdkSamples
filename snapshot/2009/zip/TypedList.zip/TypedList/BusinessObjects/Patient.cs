using System;
using System.Collections.Generic;
using System.Text;

namespace Be.TimVanWassenhove.TypedListDemo.BusinessObjects
{
    /// <summary>
    /// This class represents a Patient
    /// </summary>
    public class Patient
    {
        #region Fields

        private int id;
        private string name;
        private Address address;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="address"></param>
        public Patient(int id, string name, Address address)
        {
            this.id = id;
            this.name = name;
            this.address = address;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the idenfication of the Patient
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Gets and sets the name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets and sets the address
        /// </summary>
        public Address Address
        {
            get { return address; }
            set { address = value; }
        }

        #endregion
    }
}
