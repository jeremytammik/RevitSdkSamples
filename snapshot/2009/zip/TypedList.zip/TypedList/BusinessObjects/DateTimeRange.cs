using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Be.TimVanWassenhove.TypedListDemo.BusinessObjects
{
    /// <summary>
    /// This class represents a Range of DateTime
    /// </summary>
    public class DateTimeRange
    {
        #region Fields

        private DateTime start;
        private DateTime end;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        public DateTimeRange(DateTime start, DateTime end)
        {
            this.start = start;
            this.end = end;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets and sets the Start of the range
        /// </summary>
        public DateTime Start
        {
            get { return start; }
            set { start = value; }
        }

        /// <summary>
        /// Gets and sets the End of the range
        /// </summary>
        public DateTime End
        {
            get { return end; }
            set { end = value; }
        }

        #endregion
    }
}
