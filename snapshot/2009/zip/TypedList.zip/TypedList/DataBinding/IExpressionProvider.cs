using System;
using System.Collections.Generic;
using System.Text;

namespace Be.TimVanWassenhove.DataBinding
{
    /// <summary>
    /// This interface represents the behaviour an Expression Provider has to implement
    /// </summary>
    public interface IExpressionProvider<ComponentType, PropertyType>
    {
        /// <summary>
        /// Gets the name of the property
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Returns the value of the expression for the given component
        /// </summary>
        /// <param name="component"></param>
        /// <returns></returns>
        PropertyType GetValue(ComponentType component);
    }
}
