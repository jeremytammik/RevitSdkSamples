using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Reflection;

namespace Be.TimVanWassenhove.DataBinding
{
    /// <summary>
    /// This class represents a SortableBindingList that provides the possibility to provide additional PropertyDescriptors
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class TypedBindingList<T> : SortableBindingList<T>, ITypedList
    {
        #region Fields

        private IEnumerable<PropertyDescriptor> propertyDescriptors;

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor
        /// </summary>
        public TypedBindingList()
            :this(new PropertyDescriptor[0])
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="propertyDescriptors"></param>
        public TypedBindingList(IEnumerable<PropertyDescriptor> propertyDescriptors)
            : base()
        {
            if (propertyDescriptors == null)
            {
                throw new ArgumentNullException("propertyDescriptors");
            }

            this.propertyDescriptors = propertyDescriptors;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="propertyDescriptors"></param>
        /// <param name="elements"></param>
        public TypedBindingList(IEnumerable<PropertyDescriptor> propertyDescriptors, IEnumerable<T> elements)
            : base(elements)
        {
            if (propertyDescriptors == null)
            {
                throw new ArgumentNullException("propertyDescriptors");
            }

            this.propertyDescriptors = propertyDescriptors;
        }

        #endregion

        #region ITypedList Members

        /// <summary>
        /// <see cref="ITypedList.GetItemProperties"/>
        /// </summary>
        public PropertyDescriptorCollection GetItemProperties(PropertyDescriptor[] listAccessors)
        {
            PropertyDescriptorCollection propertyDescriptors = new PropertyDescriptorCollection(listAccessors);

            // add the regular property descriptors Appointment has
            foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(typeof(T)))
            {
                propertyDescriptors.Add(propertyDescriptor);
            }

            // add the additional propertydescriptors
            foreach (PropertyDescriptor propertyDescriptor in this.propertyDescriptors)
            {
                propertyDescriptors.Add(propertyDescriptor);
            }

            return propertyDescriptors;
        }

        /// <summary>
        /// <see cref="ITypedList.GetListName"/>
        /// </summary>
        public string GetListName(PropertyDescriptor[] listAccessors)
        {
            return MethodBase.GetCurrentMethod().DeclaringType.FullName;
        }

        #endregion
    }
}
