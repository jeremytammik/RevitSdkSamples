using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Reflection;

namespace Be.TimVanWassenhove.DataBinding
{
    /// <summary>
    /// This class represents a PropertyDescriptor for Expressions
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ExpressionDescriptor<TComponent, TProperty> : PropertyDescriptor
    {
        #region Fields

        private IExpressionProvider<TComponent, TProperty> expressionProvider;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="expressionProvider"></param>
        public ExpressionDescriptor(IExpressionProvider<TComponent, TProperty> expressionProvider)
            : base(expressionProvider.Name, null)
        {
            if (expressionProvider == null)
            {
                throw new ArgumentNullException("expressionProvider");
            }

            this.expressionProvider = expressionProvider;
        }

        #endregion

        #region Overriden Methods

        /// <summary>
        /// <see cref="PropertyDescriptor.ComponentType"/>
        /// </summary>
        public override Type ComponentType
        {
            get { return typeof(TComponent); }
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.PropertyType"/>
        /// </summary>
        public override Type PropertyType
        {
            get { return typeof(TProperty); }
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.GetValue"/>
        /// </summary>
        public override object GetValue(object component)
        {
            return this.expressionProvider.GetValue((TComponent)component);
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.IsReadOnly"/>
        /// </summary>
        public override bool IsReadOnly
        {
            get { return true; }
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.SetValue"/>
        /// </summary>
        public override void SetValue(object component, object value)
        {
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.CanResetValue"/>
        /// </summary>
        public override bool CanResetValue(object component)
        {
            return false;
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.ResetValue"/>
        /// </summary>
        public override void ResetValue(object component)
        {
        }

        /// <summary>
        /// <see cref="PropertyDescriptor.ShouldSerializeValue"/>
        /// </summary>
        public override bool ShouldSerializeValue(object component)
        {
            return false;
        }

        #endregion
    }
}
