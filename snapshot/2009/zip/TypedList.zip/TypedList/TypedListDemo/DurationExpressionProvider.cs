using System;
using System.Collections.Generic;
using System.Text;
using Be.TimVanWassenhove.TypedListDemo.BusinessObjects;
using Be.TimVanWassenhove.DataBinding;

namespace Be.TimVanWassenhove.TypedListDemo
{
    public class DurationExpressionProvider : IExpressionProvider<Appointment, TimeSpan>
    {
        #region IExpressionProvider<Appointment,TimeSpan> Members

        public string Name
        {
            get { return "|Duration"; }
        }

        public TimeSpan GetValue(Appointment component)
        {
            return component.DateTimeRange.End - component.DateTimeRange.Start;
        }

        #endregion
    }
}
