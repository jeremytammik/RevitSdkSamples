using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Be.TimVanWassenhove.DataBinding;
using Be.TimVanWassenhove.TypedListDemo.BusinessObjects;

namespace Be.TimVanWassenhove.TypedListDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<PropertyDescriptor> propertyDescriptors = new List<PropertyDescriptor>();

            // create the subpropertydescriptors
            string[] propertyNames = new string[] { "Patient.Name", "Patient.Address.Municipality", "DateTimeRange.Start", "DateTimeRange.End" };
            propertyDescriptors.AddRange(Array.ConvertAll<string, SubPropertyDescriptor<Appointment>>(propertyNames, delegate(string propertyName) { return new SubPropertyDescriptor<Appointment>(propertyName); }));

            // add an expressiondescriptor
            IExpressionProvider<Appointment, TimeSpan> expressionProvider = new DurationExpressionProvider();
            ExpressionDescriptor<Appointment, TimeSpan> durationDescriptor = new ExpressionDescriptor<Appointment, TimeSpan>(expressionProvider);
            propertyDescriptors.Add(durationDescriptor);

            TypedBindingList<Appointment> appointments = new TypedBindingList<Appointment>(propertyDescriptors);

            Patient patient = new Patient(1, "Tim", new Address(1, "MyStreet", 1820, "Melsbroek"));
            Patient patient2 = new Patient(2, "John", new Address(2, "His Street", 3000, "Leuven"));

            appointments.Add(new Appointment(1, patient, new DateTimeRange(new DateTime(2007, 5, 3, 15, 0, 0), new DateTime(2007, 5, 3, 16, 0, 0))));
            appointments.Add(new Appointment(2, patient2, new DateTimeRange(new DateTime(2007, 5, 4, 15, 0, 0), new DateTime(2007, 5, 4, 16, 0, 0))));
            appointments.Add(new Appointment(3, patient, new DateTimeRange(new DateTime(2007, 5, 5, 15, 0, 0), new DateTime(2007, 5, 5, 16, 0, 0))));
            appointments.Add(new Appointment(4, patient, new DateTimeRange(new DateTime(2007, 5, 6, 15, 0, 0), new DateTime(2007, 5, 6, 16, 0, 0))));
            appointments.Add(new Appointment(5, patient2, new DateTimeRange(new DateTime(2007, 5, 7, 15, 0, 0), new DateTime(2007, 5, 7, 16, 0, 0))));
            appointments.Add(new Appointment(6, patient, new DateTimeRange(new DateTime(2007, 5, 7, 17, 0, 0), new DateTime(2007, 5, 7, 17, 15, 0))));

            this.dataGridView1.AutoGenerateColumns = false;
            this.ColumnId.DataPropertyName = "Id";
            this.ColumnPatient.DataPropertyName = "Patient.Name";
            this.ColumnMunicipality.DataPropertyName = "Patient.Address.Municipality";
            this.ColumnStart.DataPropertyName = "DateTimeRange.Start";
            this.ColumnEnd.DataPropertyName = "DateTimeRange.End";
            this.ColumnDuration.DataPropertyName = "|Duration";

            this.bindingSource1.DataSource = appointments;
        }
    }
}