using System;
using System.Collections;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Utility;
using Autodesk.Revit.Elements;

using Autodesk.Revit.Symbols;



using System.Windows.Forms;
//  Utils from standard RevitAPI class (some will be reused here)

public class RBUtils
{

    //  Helper to get all geometrical elements
    static ElementSet GetAllModelElements(Autodesk.Revit.Application revitApp)
    {
        ElementSet elems = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            //  This single line would probably work if all system families were exposed as HostObjects, but they are not yet
            // If TypeOf elem Is FamilyInstance Or TypeOf elem Is HostObject Then
            if (!((elem is Symbol)
                        || (elem is FamilyBase)))
            {
                if (!(elem.Category == null))
                {
                    Autodesk.Revit .Geometry.Options opt = revitApp.Create.NewGeometryOptions();
                    opt.DetailLevel = Autodesk.Revit .Geometry.Options.DetailLevels.Medium;
                    Autodesk.Revit .Geometry.Element geo = elem.get_Geometry(opt);
                    if (!(geo == null))
                    {
                        elems.Insert(elem);
                    }
                }
            }
        }
        return elems;
    }

    //  Helper to get all Walls
    static ElementSet GetAllWalls(Autodesk.Revit.Application revitApp)
    {
        ElementSet elems = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            //  For Wall (one of the Host objects), there is a specific class!
            if ((elem is Wall))
            {
                elems.Insert(elem);
            }
        }
        return elems;
    }

    public static ElementSet GetAllStandardFamilyInstancesForACategory(Autodesk.Revit.Application revitApp, string catName)
    {
        ElementSet elems = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Element elem = (Element)iter.Current;
            if (elem is FamilyInstance)
            {
                try
                {
                    if (elem.Category.Name.Equals(catName))
                    {
                        elems.Insert(elem);
                    }
                }
                catch
                {
                    
                }
            }
        }
        return elems;
    }

    //    Helper to get specified Type for specified Family as FamilySymbol object
    //   (in theory, we should also check for the correct *Category Name*)
public static FamilySymbol GetFamilySymbol(Document doc, string familyName, string typeName)
{
    ElementIterator iter = doc.Elements;
    while (iter.MoveNext())
    {
        Element elem = (Element) iter.Current;
        if (elem is Family)
        {
            Family fam = (Family) elem;
            if (fam.Name.Equals(familyName))
            {
             
                foreach (FamilySymbol sym in fam.Symbols)
                {
                    if (sym.Name.Equals(typeName))
                    {
                        return sym;
                    }
                }             
            }
        }
    }
    return null;
}

 
public static StorageType GetParamStorageType(Parameter param)
{
    switch (param.StorageType)
    {
        case StorageType.None:
            return StorageType.None;

        case StorageType.Integer:
            return StorageType.Integer;

        case StorageType.Double:
            return StorageType.Double;

        case StorageType.String:
            return StorageType.String;

        case StorageType.ElementId:
            return StorageType.ElementId;
    }
    return StorageType.None;
}

 
public static string GetParamAsString(Parameter param)
{
    switch (param.StorageType)
    {
        case StorageType.None:
            return "?NONE?";

        case StorageType.Integer:
            return param.AsInteger().ToString();

        case StorageType.Double:
            return param.AsDouble().ToString();

        case StorageType.String:
            return param.AsString();

        case StorageType.ElementId:
            return param.AsElementId().Value.ToString();
    }
    return "?ELSE?";
}
    //Helper to get *specific* parameter by name
 public static Parameter GetElemParam(Autodesk.Revit .Element elem, string name)
{
    ParameterSet parameters = elem.Parameters;
   
        foreach (Parameter parameter in parameters)
        {
            if (parameter.Definition.Name == name)
            {
                return parameter;
            }
        }
   
    return null;
}

    // Helpers for the Shared Parameters:
    // -------------------------------------
    // Shared Params FILE
    public static DefinitionFile GetSharedParamsFile(Autodesk.Revit.Application revitApp)
{
    DefinitionFile sharedParametersFile;
    try
    {
        string sharedParamsFileName = revitApp.Options.SharedParametersFilename;
    }
    catch 
    {
      
        MessageBox.Show("No Shared params file set !?");      
        return null;
      
    }
    try
    {
        sharedParametersFile = revitApp.OpenSharedParameterFile();
    }
    catch 
    {
        
        MessageBox.Show("Cannnot open Shared Params file !?");
        sharedParametersFile = null;        
    }
    return sharedParametersFile;
}

     // Shared Params GROUP
public static DefinitionGroup GetOrCreateSharedParamsGroup(DefinitionFile sharedParametersFile, string groupName)
{
    DefinitionGroup msProjectGroup = sharedParametersFile.Groups.get_Item(groupName);
    if (msProjectGroup == null)
    {
        try
        {
            msProjectGroup = sharedParametersFile.Groups.Create(groupName);
        }
        catch 
        {           
            msProjectGroup = null;           
        }
    }
    return msProjectGroup;
}

        //' Shared Params DEFINITION
    public static Definition GetOrCreateSharedParamsDefinition(DefinitionGroup defGroup, ParameterType defType, string defName, bool visible)
{
    Definition definition = defGroup.Definitions.get_Item(defName);
    if (definition == null)
    {
        try
        {
            definition = defGroup.Definitions.Create(defName, defType, visible);
        }
        catch
        {
            
            definition = null;
            
        }
    }
    return definition;
}

     //' Get GUID for a given shared param name
    public static Guid SharedParamGUID(Autodesk.Revit.Application revitApp, string defGroup, string defName)
{
    Guid guid = Guid.Empty;
    try
    {
        ExternalDefinition externalDefinition = (ExternalDefinition) revitApp.OpenSharedParameterFile().Groups.get_Item(defGroup).Definitions.get_Item(defName);
        guid = externalDefinition.GUID;
    }
    catch 
    {
        
    }
    return guid;
}

     //' Helper to get all Groups
    public static ElementSet GetAllGroups(Autodesk.Revit.Application revitApp)
{
    ElementSet elems = revitApp.Create.NewElementSet();
    IEnumerator iter = revitApp.ActiveDocument.Elements;
    while (iter.MoveNext())
    {
        Element elem = (Element) iter.Current;
        if (elem is Group)
        {
            elems.Insert(elem);
        }
    }
    return elems;
}

 

 
    //' Helper to get all Group Types
    public static ElementSet GetAllGroupTypes(Autodesk.Revit.Application revitApp)
{
    ElementSet elems = revitApp.Create.NewElementSet();
    IEnumerator iter = revitApp.ActiveDocument.Elements;
    while (iter.MoveNext())
    {
        Element elem = (Element) iter.Current;
        if (elem is GroupType)
        {
            elems.Insert(elem);
        }
    }
    return elems;
}

 

//     ' Helper to get all *Model* Group Types
    public static ElementSet GetAllModelGroupTypes(Autodesk.Revit.Application revitApp)
{
    ElementSet elems = revitApp.Create.NewElementSet();
    IEnumerator iter = revitApp.ActiveDocument.Elements;
    while (iter.MoveNext())
    {
        Element elem = (Element) iter.Current;
        if (elem is GroupType)
        {
            GroupType gt = (GroupType) elem;
            try
            {
                if (gt.get_Parameter(BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM).AsString().Equals("Model Group"))
                {
                    elems.Insert(elem);
                }
            }
            catch 
            {
                
            }
        }
    }
    return elems;
}

 

 



 

 

 


 

 

 

 


 

 


    ////  Helper to get all Standard Family Instances for a given Category
    //public static ElementSet GetAllStandardFamilyInstancesForACategory(Autodesk.Revit.Application revitApp, string catName) {
    //    ElementSet elems = revitApp.Create.NewElementSet;
    //    IEnumerator iter = revitApp.ActiveDocument.Elements;
    //    while (iter.MoveNext()) {
    //        Revit.Element elem = iter.Current;
    //        //  First check for the class, then for specific category name
    //        if ((elem.GetType() == FamilyInstance)) {
    //            try {
    //                if (elem.Category.Name.Equals(catName)) {
    //                    elems.Insert(elem);
    //                }
    //            }
    //            catch (System.Exception End) {
    //                try {
    //                }
    //                return elems;
    //            }
    //            // Helper to get specified Type for specified Family as FamilySymbol object
    //            //    (in theory, we should also check for the correct *Category Name*)
    //            ((FamilySymbol)(GetFamilySymbol(((Revit.Document)(doc)), ((string)(familyName)), ((string)(typeName)))));
    //            ElementIterator iter = doc.Elements;
    //            while (iter.MoveNext()) {
    //                Revit.Element elem = iter.Current;
    //                //  We got a Family
    //                if ((elem.GetType() == Family)) {
    //                    Family fam = elem;
    //                    //  If we have a match on family name, loop all its types for the other match
    //                    if (fam.Name.Equals(familyName)) {
                            
    //                        foreach (FamilySymbol sym in fam.Symbols) {
    //                            if (sym.Name.Equals(typeName)) {
    //                                return sym;
    //                            }
    //                        }
    //                    }
    //                }
    //            }
    //            //  if here - haven't got it!
    //            return null;
    //        }
    //        // Helper to return Parameter's StorageType
    //        ((Parameters.StorageType)(GetParamStorageType(((Parameter)(param)))));
    //        switch (param.StorageType) {
    //            case StorageType.Double:
    //                return StorageType.Double;
    //                break;
    //            case StorageType.Integer:
    //                return StorageType.Integer;
    //                break;
    //            case StorageType.String:
    //                return StorageType.String;
    //                break;
    //            case StorageType.ElementId:
    //                return StorageType.ElementId;
    //                break;
    //            case StorageType.None:
    //                return StorageType.None;
    //                break;
    //            default:
    //                return null;
    //                break;
    //        }
    //        // Helper to return Parameter as string
    //        ((string)(GetParamAsString(((Parameter)(param)))));
    //        string str;
    //        switch (param.StorageType) {
    //            case StorageType.Double:
    //                str = param.AsDouble.ToString();
    //                break;
    //            case StorageType.Integer:
    //                str = param.AsInteger.ToString();
    //                break;
    //            case StorageType.String:
    //                str = param.AsString;
    //                break;
    //            case StorageType.ElementId:
    //                str = param.AsElementId.Value.ToString();
    //                break;
    //            case StorageType.None:
    //                str = "?NONE?";
    //                break;
    //            default:
    //                str = "?ELSE?";
    //                break;
    //        }
    //        return str;
    //        // Helper to get *specific* parameter by name
    //        ((Parameter)(GetElemParam(((Revit.Element)(elem)), ((string)(name)))));
    //        Autodesk.Revit.ParameterSet parameters = elem.Parameters;
            
    //        foreach (Autodesk.Revit.Parameter parameter in parameters) {
    //            if ((parameter.Definition.Name == name)) {
    //                return parameter;
    //            }
    //        }
    //        return null;
    //        //  Helpers for the Shared Parameters:
    //        // -------------------------------------
    //        //  Shared Params FILE
    //        ((Parameters.DefinitionFile)(GetSharedParamsFile(((Revit.Application)(revitApp)))));
    //        //  Get current shared params file name 
    //        string sharedParamsFileName;
    //        try {
    //            sharedParamsFileName = revitApp.Options.SharedParametersFilename;
    //        }
    //        catch (System.Exception MsgBox) {
    //            "No Shared params file set !?";
    //            return null;
    //        }
    //        //  Get the current file object and return it
    //        Autodesk.Revit.Parameters.DefinitionFile sharedParametersFile;
    //        try {
    //            sharedParametersFile = revitApp.OpenSharedParameterFile;
    //        }
    //        catch (System.Exception MsgBox) {
    //            "Cannnot open Shared Params file !?";
    //            sharedParametersFile = null;
    //        }
    //        return sharedParametersFile;
    //        //  Shared Params GROUP
    //        ((Parameters.DefinitionGroup)(GetOrCreateSharedParamsGroup(((Parameters.DefinitionFile)(sharedParametersFile)), ((string)(groupName)))));
    //        Autodesk.Revit.Parameters.DefinitionGroup msProjectGroup;
    //        msProjectGroup = sharedParametersFile.Groups.Item[groupName];
    //        if ((msProjectGroup == null)) {
    //            try {
    //                msProjectGroup = sharedParametersFile.Groups.Create(groupName);
    //            }
    //            catch (System.Exception msProjectGroup) {
    //                null;
    //            }
    //        }
    //        return msProjectGroup;
    //        //  Shared Params DEFINITION
    //        ((Parameters.Definition)(GetOrCreateSharedParamsDefinition(((Parameters.DefinitionGroup)(defGroup)), ((Parameters.ParameterType)(defType)), ((string)(defName)), ((bool)(visible)))));
    //        Parameters.Definition definition = defGroup.Definitions.Item[defName];
    //        if ((definition == null)) {
    //            try {
    //                //  NOTE: Although Integer type, the 3rd arg must be Boolean "False" to make it invisible in UI!?
    //                definition = defGroup.Definitions.Create(defName, defType, visible);
    //            }
    //            catch (System.Exception definition) {
    //                null;
    //            }
    //        }
    //        return definition;
    //        //  Get GUID for a given shared param name
    //        ((Guid)(SharedParamGUID(((Revit.Application)(revitApp)), ((string)(defGroup)), ((string)(defName)))));
    //        Guid guid = guid.Empty;
    //        try {
    //            Autodesk.Revit.Parameters.DefinitionFile file = revitApp.OpenSharedParameterFile;
    //            Autodesk.Revit.Parameters.DefinitionGroup group = file.Groups.Item[defGroup];
    //            Autodesk.Revit.Parameters.Definition definition = group.Definitions.Item[defName];
    //            Autodesk.Revit.Parameters.ExternalDefinition externalDefinition = definition;
    //            guid = externalDefinition.GUID;
    //        }
    //        catch (System.Exception End) {
    //            try {
    //                return guid;
    //            }
    //            //  Helper to get all Groups
    //            ((ElementSet)(GetAllGroups(((Revit.Application)(revitApp)))));
    //            ElementSet elems = revitApp.Create.NewElementSet;
    //            IEnumerator iter = revitApp.ActiveDocument.Elements;
    //            while (iter.MoveNext()) {
    //                Revit.Element elem = iter.Current;
    //                if ((elem.GetType() == Group)) {
    //                    elems.Insert(elem);
    //                }
    //            }
    //            return elems;
    //        }
    //        //  Helper to get all Group Types
    //        ((ElementSet)(GetAllGroupTypes(((Revit.Application)(revitApp)))));
    //        ElementSet elems = revitApp.Create.NewElementSet;
    //        IEnumerator iter = revitApp.ActiveDocument.Elements;
    //        while (iter.MoveNext()) {
    //            Revit.Element elem = iter.Current;
    //            if ((elem.GetType() == GroupType)) {
    //                elems.Insert(elem);
    //            }
    //        }
    //        return elems;
    //        //  Helper to get all *Model* Group Types
    //        ((ElementSet)(GetAllModelGroupTypes(((Revit.Application)(revitApp)))));
    //        ElementSet elems = revitApp.Create.NewElementSet;
    //        IEnumerator iter = revitApp.ActiveDocument.Elements;
    //        while (iter.MoveNext()) {
    //            Revit.Element elem = iter.Current;
    //            if ((elem.GetType() == GroupType)) {
    //                //  Need additional check for the group type
    //                GroupType gt = elem;
    //                try {
    //                    // If gt.Parameter(Parameters.BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM).AsString.Equals(gsGroupTypeModel) Then
    //                    if (gt.Parameter(Parameters.BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM).AsString.Equals("Model Group")) {
    //                        elems.Insert(elem);
    //                    }
    //                }
    //                catch (System.Exception End) {
    //                    try {
    //                    }
    //                    return elems;
    //                }
    //            }
    //        }
    //    }
    //}
}

