using System;
using System.Collections;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Utility;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Symbols;

using System.Windows.Forms;

// Revit Structure utilities
public class RSutils
{

    public static ElementSet GetAllLoadNatures(Autodesk.Revit.Application revitApp)
    {
        ElementSet natures = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is LoadNature)
            {
                natures.Insert(elem);
            }
        }
        return natures;
    }

    public static ElementSet GetAllLoadCases(Autodesk.Revit.Application revitApp)
    {
        ElementSet cases = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is LoadCase)
            {
                cases.Insert(elem);
            }
        }
        return cases;
    }

    public static ElementSet GetAllLoadCombinations(Autodesk.Revit.Application revitApp)
    {
        ElementSet combinations = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is LoadCombination)
            {
                combinations.Insert(elem);
            }
        }
        return combinations;
    }

    public static ElementSet GetAllLoadUsages(Autodesk.Revit.Application revitApp)
    {
        ElementSet usages = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is LoadUsage)
            {
                usages.Insert(elem);
            }
        }
        return usages;
    }

    public static ElementSet GetAllLoads(Autodesk.Revit.Application revitApp)
    {
        ElementSet loads = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is LoadBase)
            {
                loads.Insert(elem);
            }
        }
        return loads;
    }

    //  More efficient if we loop only once and sort at the time
    public static void GetAllSpecificLoads(Autodesk.Revit.Application revitApp, ref ElementSet pointLoads, ref ElementSet lineLoads, ref ElementSet areaLoads)
    {
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is PointLoad)
            {
                pointLoads.Insert(elem);
            }
            else if (elem is LineLoad)
            {
                lineLoads.Insert(elem);
            }
            else if (elem is AreaLoad)
            {
                areaLoads.Insert(elem);
            }
        }
    }

    public static ElementSet GetAllLoadSymbols(Autodesk.Revit.Application revitApp)
    {

        ElementSet symbols = revitApp.Create.NewElementSet();
        // Revit 2009 added new classes to represent Load symbols, such as LoadTypeBase, PointLoadType,LineLoadType and AreaLoadType.
        // to find out all load types, we can compare the class instead of comparing Category.

        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while ((iter.MoveNext()))
        {
            LoadTypeBase loadType = iter.Current as LoadTypeBase;
            if (loadType is LoadTypeBase)
            {
                symbols.Insert(loadType);                                    
            }
        }

        return symbols;

    }

    public static ElementSet GetPointLoadSymbols(Autodesk.Revit.Application revitApp)
    {

        ElementSet symbols = revitApp.Create.NewElementSet();

        ElementIterator iter = revitApp.ActiveDocument.get_Elements(typeof(PointLoadType));
        while ((iter.MoveNext()))
        {
            Element elem = iter.Current as Element;
            if (elem is PointLoadType)
            {
                symbols.Insert(elem);              
            }
        }

        return symbols;

    }

    // Helper to get all STRUCTURAL Walls
    public static ElementSet GetAllStructuralWalls(Autodesk.Revit.Application revitApp)
    {
        ElementSet elems = revitApp.Create.NewElementSet();

        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while ((iter.MoveNext()))
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            // For Wall (one of the Host objects), there is a specific class!
            if (elem is Wall)
            {
                Wall w = elem as Wall ;

                //' We could check if the Wall is anything but Non-bearing in one of the two following ways:...

                // this works only in 8.1, not in 9/9.1!
                //If Not w.Parameter(BuiltInParameter.WALL_STRUCTURAL_USAGE_TEXT_PARAM).AsString.Equals("Non-bearing") Then
                // '...
                //End If
                //'OR better

                // this works both in 8.1 and 9/9.1!
                //If Not w.Parameter(BuiltInParameter.WALL_STRUCTURAL_USAGE_PARAM).AsInteger = 0 Then
                // '...
                //End If

                //... but it's more generic and precise to make sure that Analytical Model exists (in theory, one
                // can set the wall to bearing and still uncheck Analytical)
                AnalyticalModel anaMod;
                try
                {
                    anaMod = w.AnalyticalModel;
                    if ((anaMod != null))
                    {
                        elems.Insert(elem);
                    }
                }
                catch
                {
                }
            }
        }

        return elems;

    }

    // Helper to get all STRUCTURAL Floors
    public static ElementSet GetAllStructuralFloors(Autodesk.Revit.Application revitApp)
    {

        ElementSet elems = revitApp.Create.NewElementSet();

        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while ((iter.MoveNext()))
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is Floor)
            {
                Floor f = elem as Floor ;
                AnalyticalModel anaMod;
                try
                {
                    anaMod = f.AnalyticalModel;
                    if ((anaMod != null))
                    {
                        // For floors, looks like we need to have additional check: for non-Structural Floors
                        // anaMod is NOT Nothing, but it IS empty!
                        AnalyticalModelFloor floorAnaMod = anaMod as AnalyticalModelFloor;
                        if (floorAnaMod.Curves.Size > 0)
                        {
                            elems.Insert(elem);
                        }
                    }
                }
                catch
                {
                }
            }
        }
        return elems;
    }

    //  Helper to get all STRUCTURAL ContinuousFootings
    public static ElementSet GetAllStructuralContinuousFootings(Autodesk.Revit.Application revitApp)
    {
        ElementSet elems = revitApp.Create.NewElementSet();
        IEnumerator iter = revitApp.ActiveDocument.Elements;
        while (iter.MoveNext())
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit.Element;
            if (elem is ContFooting)
            {
                ContFooting cf = elem as ContFooting ;
                AnalyticalModel anaMod;
                try
                {
                    anaMod = cf.AnalyticalModel;
                    if (!(anaMod == null))
                    {
                        elems.Insert(elem);
                    }
                }
                catch
                {
                }
            }
        }
        return elems;
    }
}