using System;
using System.Collections;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Utility;
using Autodesk.Revit.Elements;

using System.Windows.Forms;


//  List all STRUCTURAL elements in the model
//  -----------------------------------------
// Structural COLUMNS and FRAMING elements
public class Lab2_1 : IExternalCommand
{
    public Autodesk.Revit.IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData commandData, ref string message, Autodesk.Revit.ElementSet elements) {
        Autodesk.Revit.Application app = commandData.Application;
        //  Get all Structural COLUMNS - we can use generic utility
        //  In 8.1 we had to hard-code the category name which then works only in specific locale (EN or DE or IT etc)...
        // Dim columns As ElementSet = RBUtils.GetAllStandardFamilyInstancesForACategory(app, "Structural Columns")
        // ...but from 9.0 there is new category enum, so this should work in ANY locale:
        Category catStructuralColumns = app.ActiveDocument.Settings.Categories.get_Item(BuiltInCategory.OST_StructuralColumns);
        ElementSet columns = RBUtils.GetAllStandardFamilyInstancesForACategory(app, catStructuralColumns.Name);
        string sMsg = "There are " + columns.Size + " Structural COLUMNS elements:" + "\r\n";
        
        // " Struct.Usage=" & col.StructuralUsage.ToString & _ ' only beam and brace allow strctural usage in 2008
        foreach (FamilyInstance col in columns) 
        {
            sMsg = (sMsg + ("  Id="  + col.Id.Value.ToString() 
                         + " Type=" + col.Symbol.Name
                         + " Struct.Type=" + col.StructuralType.ToString()
                         + " Analytical Type="  + col.AnalyticalModel.GetType().Name 
                         + "\r\n"));
        }
        MessageBox.Show(sMsg);
        //  Get all Structural FRAMING elements - again the same
        Category catStructuralFraming = app.ActiveDocument.Settings.Categories.get_Item(BuiltInCategory.OST_StructuralFraming);
        ElementSet frmEls = RBUtils.GetAllStandardFamilyInstancesForACategory(app, catStructuralFraming.Name);
        sMsg = "There are "  + frmEls.Size + " Structural FRAMING elements:" + "\r\n";
        
        foreach (FamilyInstance frmEl in frmEls) {
            //  INSTANCE_STRUCT_USAGE_TEXT_PARAM works only in 8.1 and not in 9!...
            // sMsg += "  Id=" & frmEl.Id.Value.ToString & " Type=" & frmEl.Symbol.Name & _
            //         " Struct.Usage=" & RBUtils.GetParamAsString(frmEl.Parameter(BuiltInParameter.INSTANCE_STRUCT_USAGE_TEXT_PARAM)) & _
            //          " Analytical Type=" & frmEl.AnalyticalModel.GetType.Name & vbCrLf
            //  ..so better use dedicated class' property StructuralUsage which works in both. Also check StructuralType
            sMsg = (sMsg + ("  Id=" + frmEl.Id.Value.ToString()
                         + " Type=" + frmEl.Symbol.Name 
                         + " Struct.Usage=" + frmEl.StructuralUsage.ToString()
                         + " Struct.Type=" + frmEl.StructuralType.ToString()
                         + " Analytical Type=" + frmEl.AnalyticalModel.GetType().Name
                         + "\r\n"));
        }
        MessageBox.Show(sMsg);
        return IExternalCommand.Result.Succeeded;
    }
}

//  Structural FOUNDATION elements and any standard family in alternative way
public class Lab2_2 : IExternalCommand
{

    public Autodesk.Revit.IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData commandData, ref string message, Autodesk.Revit.ElementSet elements) 
    {
        Autodesk.Revit.Application app = commandData.Application;
        //  Get all standard Structural FOUNDATION elements - again the same. Note that this:
        //    a)  excludes "Wall Foundation" System Type under "Structural Foundations" category in the Browser - these belong to *Continuous Footing* system family, see next Lab
        //    b)  excludes "Foundation Slab" System Type under "Structural Foundations" category in the Browser - these are internally implemented as Revit *Floor* system family, see next Lab
        Category catStructuralFoundation = app.ActiveDocument.Settings.Categories.get_Item(BuiltInCategory.OST_StructuralFoundation);
        ElementSet struFnds = RBUtils.GetAllStandardFamilyInstancesForACategory(app, catStructuralFoundation.Name);
        string sMsg = "There are "  + struFnds.Size + " Structural FOUNDATION (standard families only) elements :" + "\r\n";
        
        //  " Struct.Usage=" & found.StructuralUsage.ToString & _only Beam and Brace support Structural Usage!
        foreach (FamilyInstance found in struFnds) 
        {
            sMsg = (sMsg + "  Id=" + found.Id.Value.ToString()
                         + " Type=" + found.Symbol.Name 
                         + " Struct.Type=" + found.StructuralType.ToString()
                         + " Analytical Type=" + found.AnalyticalModel.GetType().Name
                         + "\r\n");
        }
        MessageBox.Show(sMsg);
        //  NOTE: All of the previous 3 are *standard* Family Instances, so we could alternatively get them by using something like:
        sMsg = ("ALL Structural FAMILY INSTANCES (generic check):" + "\r\n");
        IEnumerator iter = app.ActiveDocument.Elements;
        string categoryName;
        int i = 0;
        while (iter.MoveNext()) 
        {
            Autodesk.Revit.Element elem = iter.Current as Autodesk.Revit .Element ;
            if ((elem is FamilyInstance)) {
                FamilyInstance fi = elem as FamilyInstance;
                AnalyticalModel anaMod = fi.AnalyticalModel;
                if (!(anaMod == null)) {
                    i++;
                    categoryName = "?";
                    try {
                        categoryName = fi.Category.Name;
                    }
                    catch 
                    {
                    }
                        
                    sMsg = (sMsg
                                 + i + ": Category="+ categoryName
                                 + "  Struct.Type="+ fi.StructuralType.ToString()
                                 + "  Id= "+ fi.Id.Value.ToString()
                                 + "\r\n");                                                                                     
                }
            }
        }
        MessageBox.Show(sMsg);  

        return IExternalCommand.Result.Succeeded;
    }
}

//  Structural System Families: WALL, FLOOR, CONTINUOUS FOOTING
public class Lab2_3 : IExternalCommand
{

    public Autodesk.Revit.IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData commandData, ref string message, Autodesk.Revit.ElementSet elements) {
        Autodesk.Revit.Application app = commandData.Application;
        //  Get all Structural WALLS elements - dedicated helper that checks for all Walls of Structural usage
        ElementSet struWalls = RSutils.GetAllStructuralWalls(app);
        string sMsg = ("There are " 
                    + (struWalls.Size + (" Structural WALLS elements:" + "\r\n")));        
        foreach (Wall w in struWalls) {
            //  WALL_STRUCTURAL_USAGE_TEXT_PARAM works only in 8.1 and not from 9!...
            // sMsg += "  Id=" & w.Id.Value.ToString & " Type=" & w.WallType.Name & _
            //         " Struct.Usage=" & RBUtils.GetParamAsString(w.Parameter(BuiltInParameter.WALL_STRUCTURAL_USAGE_TEXT_PARAM)) & _
            //         " Analytical Type=" & w.AnalyticalModel.GetType.Name & vbCrLf
            //  ..so better use dedicated class' property StructuralUsage which works in both
            sMsg = (sMsg + ("  Id=" 
                        + (w.Id.Value.ToString() + (" Type=" 
                        + (w.WallType.Name + (" Struct.Usage=" 
                        + (w.StructuralUsage.ToString() + (" Analytical Type=" 
                        + (w.AnalyticalModel.GetType().Name + "\r\n")))))))));
        }
        MessageBox.Show(sMsg);
        //  Get all Structural FLOOR elements - dedicated helper that checks for all Floors of Structural usage
        // NOTE: From RS3, these include not only standard Floors, but also "Foundation Slab" instances from "Structural Foundations" category
        ElementSet struFloors = RSutils.GetAllStructuralFloors(app);
        sMsg = ("There are " 
                    + (struFloors.Size + (" Structural FLOOR elements:" + "\r\n")));
        
        foreach (Floor fl in struFloors) {
            sMsg = (sMsg + ("  Id=" 
                        + (fl.Id.Value.ToString() + ("  Category=" 
                        + (fl.Category.Name + ("  Type=" 
                        + (fl.FloorType.Name + ("  Analytical Type=" 
                        + (fl.AnalyticalModel.GetType().Name + "\r\n")))))))));
        }
        MessageBox.Show(sMsg);
        //  Get all Structural CONTINUOUS FOOTING elements - dedicated helper
        // NOTE: From RS3, these are "Wall Foundation" instances from "Structural Foundations" category
        ElementSet contFootings = RSutils.GetAllStructuralContinuousFootings(app);
        sMsg = ("There are " 
                    + (contFootings.Size + (" Structural CONTINUOUS FOOTING (or Wall Foundations) elements:" + "\r\n")));
        
        foreach (ContFooting cf in contFootings) {
            sMsg = (sMsg + ("  Id=" 
                        + (cf.Id.Value.ToString() + (" Type=" 
                        + (cf.FootingType.Name + (" Analytical Type=" 
                        + (cf.AnalyticalModel.GetType().Name + "\r\n")))))));
        }
        MessageBox.Show(sMsg);
        return IExternalCommand.Result.Succeeded;
    }
}
// 'Some Built-in params that seem relevant for structural elements:
// FLOOR_PARAM_IS_STRUCTURAL     
// INSTANCE_STRUCT_USAGE_TEXT_PARAM     
// INSTANCE_STRUCT_USAGE_PARAM     
// INSTANCE_STRUCT_INSERTION_PARAM     
// INSTANCE_STRUCT_SETBACK1_PARAM     
// INSTANCE_STRUCT_SETBACK0_PARAM     
// STRUCTURAL_BOTTOM_RELEASE_MZ     
// STRUCTURAL_BOTTOM_RELEASE_MY     
// STRUCTURAL_BOTTOM_RELEASE_MX     
// STRUCTURAL_BOTTOM_RELEASE_FZ     
// STRUCTURAL_BOTTOM_RELEASE_FY     
// STRUCTURAL_BOTTOM_RELEASE_FX     
// STRUCTURAL_TOP_RELEASE_MZ     
// STRUCTURAL_TOP_RELEASE_MY     
// STRUCTURAL_TOP_RELEASE_MX     
// STRUCTURAL_TOP_RELEASE_FZ     
// STRUCTURAL_TOP_RELEASE_FY     
// STRUCTURAL_TOP_RELEASE_FX     
// STRUCTURAL_BOTTOM_RELEASE_TYPE     
// STRUCTURAL_TOP_RELEASE_TYPE     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_COLUMN_BOTTOM     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_COLUMN_TOP     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_WALL_BOTTOM     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_WALL_TOP     
// STRUCTURAL_MATERIAL_TYPE     
// STRUCTURAL_CAMBER     
// STRUCTURAL_NUMBER_OF_STUDS     
// STRUCTURAL_END_RELEASE_MZ     
// STRUCTURAL_END_RELEASE_MY     
// STRUCTURAL_END_RELEASE_MX     
// STRUCTURAL_END_RELEASE_FZ     
// STRUCTURAL_END_RELEASE_FY     
// STRUCTURAL_END_RELEASE_FX     
// STRUCTURAL_START_RELEASE_MZ     
// STRUCTURAL_START_RELEASE_MY     
// STRUCTURAL_START_RELEASE_MX     
// STRUCTURAL_START_RELEASE_FZ     
// STRUCTURAL_START_RELEASE_FY     
// STRUCTURAL_START_RELEASE_FX     
// STRUCTURAL_END_RELEASE_TYPE     
// STRUCTURAL_START_RELEASE_TYPE     
// STRUCTURAL_WALL_BOTTOM_PROJECTION_PLANE     
// STRUCTURAL_WALL_TOP_PROJECTION_PLANE     
// STRUCTURAL_WALL_PROJECTION_SURFACE     
// STRUCTURAL_COLUMN_ANALYTICAL_OFFSET     
// STRUCTURAL_ANALYTICAL_PROJECT_FLOOR_PLANE     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_BOTTOM     
// STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE     
// STRUCTURAL_BRACE_REPRESENTATION     
// STRUCTURAL_CONNECTION_TYPE     
// STRUCTURAL_MOMENT_CONN_END     
// STRUCTURAL_MOMENT_CONN_START     
// STRUCTURAL_STICK_SYMBOL_ON_TOP     
// STRUCTURAL_BEAM_END_SUPPORT     
// STRUCTURAL_BEAM_START_SUPPORT     

