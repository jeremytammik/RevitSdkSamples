
using System;
using System.Collections;
using System.Reflection;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.Parameters;
using Autodesk.Revit.Structural;
using Autodesk.Revit.Utility;
using Autodesk.Revit.Elements;

using System.Windows.Forms;

public class BuiltInParamsChecker : IExternalCommand
{

    public Autodesk.Revit.IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData commandData, ref string message, Autodesk.Revit.ElementSet elements)
    {
        Autodesk.Revit.Document doc = commandData.Application.ActiveDocument;
        // ' Test: list all BuiltInParameter enums
        // Dim fis() As FieldInfo = GetType(BuiltInParameter).GetFields
        // ' Loop over the fields.
        // Dim msg As String = "Revit BuiltInParameters:" & vbCrLf
        // For Each fi As FieldInfo In fis
        //     ' See if this is a literal value (set at compile time).
        //     If fi.IsLiteral Then
        //         msg += fi.Name & " = " & CType(fi.GetValue(Nothing), Integer) & vbCrLf
        //     End If
        // Next fi
        // MessageBox.Show(msg)
        //  Get the single selected element
        ElementSet ss = doc.Selection.Elements;
        if (!(ss.Size == 1))
        {
            MessageBox.Show("You must pre-select a single element!");
            return IExternalCommand.Result.Cancelled;
        }
        ElementSetIterator iter = ss.ForwardIterator();
        iter.MoveNext();
        Element elem = iter.Current as Element;
        //  Takes some time, so change cursor
        Cursor oldCursor = Cursor.Current;
        Cursor.Current = Cursors.WaitCursor;
        ArrayList ParamEnums = new ArrayList();
        ArrayList ParamTypes = new ArrayList();
        ArrayList ParamValues = new ArrayList();
        //  Loop all fields for built-in params using .NET Reflection
        FieldInfo[] fis = typeof(BuiltInParameter).GetFields();
        foreach (FieldInfo fi in fis)
        {
            //  See if this is an enum (a literal value set at compile time)
            if (fi.IsLiteral)
            {
                try
                {
                    int enumInt = ((int)(fi.GetValue(null)));
                    BuiltInParameter enumBip = (BuiltInParameter)enumInt;
                    Parameter param = elem.get_Parameter(enumBip);
                    switch (param.StorageType)
                    {
                        case StorageType.Double:
                            ParamValues.Add(param.AsDouble().ToString());
                            ParamEnums.Add(fi.Name);
                            ParamTypes.Add("Double");
                            break;
                        case StorageType.Integer:
                            ParamValues.Add(param.AsInteger().ToString());
                            ParamEnums.Add(fi.Name);
                            ParamTypes.Add("Integer");
                            break;
                        case StorageType.String:
                            ParamValues.Add(param.AsString());
                            ParamEnums.Add(fi.Name);
                            ParamTypes.Add("String");
                            break;
                        case StorageType.ElementId:
                            ParamValues.Add(param.AsElementId().Value.ToString());
                            ParamEnums.Add(fi.Name);
                            ParamTypes.Add("Id");
                            break;
                        case StorageType.None:
                            //  nothing
                            break;
                    }
                    
                }
                catch 
                {
                }
            }
            // isLiteral
        }
        //  looping field infos
        //  Revert the cursor
        Cursor.Current = oldCursor;
        // KIS for now - in future may display in an user-friendly form...
        string msg = ("Number of valid Params  = "
                    + (ParamEnums.Count + (", "
                    + (ParamTypes.Count + (", " + ParamValues.Count)))));
        MessageBox.Show(msg);
        msg = "Valid Params for this element: ";
        int iNum = ParamValues.Count;
        for (int i = 0; (i
                    <= (iNum - 1)); i++)
        {
            msg = (msg + ("\r\n" + ("  "
                        + (ParamEnums[i] + (", "
                        + (ParamTypes[i] + (": " + ParamValues[i])))))));
        }
        MessageBox.Show(msg);
        return IExternalCommand.Result.Succeeded;
    }
}

