Public Class BuiltInParamsChecker
    Implements IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

        Dim doc As Revit.Document = commandData.Application.ActiveDocument

        '' Test: list all BuiltInParameter enums
        'Dim fis() As FieldInfo = GetType(BuiltInParameter).GetFields
        '' Loop over the fields.
        'Dim msg As String = "Revit BuiltInParameters:" & vbCrLf
        'For Each fi As FieldInfo In fis
        '    ' See if this is a literal value (set at compile time).
        '    If fi.IsLiteral Then
        '        msg += fi.Name & " = " & CType(fi.GetValue(Nothing), Integer) & vbCrLf
        '    End If
        'Next fi
        'MsgBox(msg)

        ' Get the single selected element
        Dim ss As ElementSet = doc.Selection.Elements
        If Not ss.Size = 1 Then
            MsgBox("You must pre-select a single element!")
            Return IExternalCommand.Result.Cancelled
        End If
        Dim iter As ElementSetIterator = ss.ForwardIterator
        iter.MoveNext()
        Dim elem As Revit.Element = iter.Current

        ' Takes some time, so change cursor
        Dim oldCursor As Cursor = Cursor.Current
        Cursor.Current = Cursors.WaitCursor

        Dim ParamEnums As New ArrayList
        Dim ParamTypes As New ArrayList
        Dim ParamValues As New ArrayList

        ' Loop all fields for built-in params using .NET Reflection
        Dim fis() As FieldInfo = GetType(BuiltInParameter).GetFields
        For Each fi As FieldInfo In fis
            ' See if this is an enum (a literal value set at compile time)
            If fi.IsLiteral Then
                Try
                    Dim enumInt As Integer = CType(fi.GetValue(Nothing), Integer)
                    Dim enumBip As BuiltInParameter = enumInt
                    Dim param As Parameter = elem.Parameter(enumBip)
                    Select Case param.StorageType

                        Case StorageType.Double
                            ParamValues.Add(param.AsDouble.ToString)
                            ParamEnums.Add(fi.Name)
                            ParamTypes.Add("Double")

                        Case StorageType.Integer
                            ParamValues.Add(param.AsInteger.ToString)
                            ParamEnums.Add(fi.Name)
                            ParamTypes.Add("Integer")

                        Case StorageType.String
                            ParamValues.Add(param.AsString)
                            ParamEnums.Add(fi.Name)
                            ParamTypes.Add("String")

                        Case StorageType.ElementId
                            ParamValues.Add(param.AsElementId.Value.ToString)
                            ParamEnums.Add(fi.Name)
                            ParamTypes.Add("Id")

                        Case StorageType.None
                            ' nothing
                        Case Else
                            ' nothing
                    End Select

                Catch ex As Exception
                End Try

            End If 'isLiteral
        Next fi ' looping field infos

        ' Revert the cursor
        Cursor.Current = oldCursor

        'KIS for now - in future may display in an user-friendly form...
        Dim msg As String = "Number of valid Params  = " & ParamEnums.Count & ", " & ParamTypes.Count & ", " & ParamValues.Count
        MsgBox(msg)

        msg = "Valid Params for this element: "
        Dim iNum As Integer = ParamValues.Count
        For i As Integer = 0 To iNum - 1
            msg += vbCrLf & "  " & ParamEnums(i) & ", " & ParamTypes(i) & ": " & ParamValues(i)
        Next
        MsgBox(msg)

        Return IExternalCommand.Result.Succeeded
    End Function
End Class