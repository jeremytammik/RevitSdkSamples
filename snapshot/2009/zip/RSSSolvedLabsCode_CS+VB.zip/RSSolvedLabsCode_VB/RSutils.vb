
'Revit Structure utilities
Public Class RSutils

    Public Shared Function GetAllLoadNatures(ByVal revitApp As Revit.Application) As ElementSet

        Dim natures As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is LoadNature Then
                natures.Insert(elem)
            End If
        Loop

        Return natures

    End Function

    Public Shared Function GetAllLoadCases(ByVal revitApp As Revit.Application) As ElementSet

        Dim cases As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is LoadCase Then
                cases.Insert(elem)
            End If
        Loop

        Return cases

    End Function

    Public Shared Function GetAllLoadCombinations(ByVal revitApp As Revit.Application) As ElementSet

        Dim combinations As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is LoadCombination Then
                combinations.Insert(elem)
            End If
        Loop

        Return combinations

    End Function

    Public Shared Function GetAllLoadUsages(ByVal revitApp As Revit.Application) As ElementSet

        Dim usages As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is LoadUsage Then
                usages.Insert(elem)
            End If
        Loop

        Return usages

    End Function

    Public Shared Function GetAllLoads(ByVal revitApp As Revit.Application) As ElementSet

        Dim loads As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is LoadBase Then
                loads.Insert(elem)
            End If
        Loop

        Return loads

    End Function

    ' More efficient if we loop only once and sort at the time
    Public Shared Sub GetAllSpecificLoads(ByVal revitApp As Revit.Application, _
                                          ByRef pointLoads As ElementSet, _
                                          ByRef lineLoads As ElementSet, _
                                          ByRef areaLoads As ElementSet)

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is PointLoad Then
                pointLoads.Insert(elem)
            ElseIf TypeOf elem Is LineLoad Then
                lineLoads.Insert(elem)
            ElseIf TypeOf elem Is AreaLoad Then
                areaLoads.Insert(elem)
            End If
        Loop


    End Sub


    Public Shared Function GetAllLoadSymbols(ByVal revitApp As Revit.Application) As ElementSet

        Dim symbols As ElementSet = revitApp.Create.NewElementSet
        'Revit 2009 added new classes to represent Load symbols, such as LoadTypeBase, PointLoadType,LineLoadType and AreaLoadType.
        'to find out all load types, we can compare the class instead of comparing Category.
        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim loadType As LoadTypeBase = iter.Current
            If TypeOf loadType Is LoadTypeBase Then
                symbols.Insert(loadType)
            End If
            
        Loop

        Return symbols

    End Function

    Public Shared Function GetPointLoadSymbols(ByVal revitApp As Revit.Application) As ElementSet

        Dim symbols As ElementSet = revitApp.Create.NewElementSet
        'Revit 2009 added new classes to represent Load symbols, such as LoadTypeBase, PointLoadType.
        'to find out point load types, we can compare the class PointLoadType instead of comparing Category.
        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements(GetType(PointLoadType))
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is PointLoadType Then
                symbols.Insert(elem)
            End If
        Loop

        Return symbols

    End Function

    ' Helper to get all STRUCTURAL Walls
    Shared Function GetAllStructuralWalls(ByVal revitApp As Revit.Application) As ElementSet

        Dim elems As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            ' For Wall (one of the Host objects), there is a specific class!
            If TypeOf elem Is Wall Then
                Dim w As Wall = elem

                '' We could check if the Wall is anything but Non-bearing in one of the two following ways:...

                ' this works only in 8.1, not in 9/9.1!
                'If Not w.Parameter(BuiltInParameter.WALL_STRUCTURAL_USAGE_TEXT_PARAM).AsString.Equals("Non-bearing") Then
                '    '...
                'End If
                ''OR better

                ' this works both in 8.1 and 9/9.1!
                'If Not w.Parameter(BuiltInParameter.WALL_STRUCTURAL_USAGE_PARAM).AsInteger = 0 Then
                '    '...
                'End If

                '... but it's more generic and precise to make sure that Analytical Model exists (in theory, one
                '    can set the wall to bearing and still uncheck Analytical)
                Dim anaMod As AnalyticalModel
                Try
                    anaMod = w.AnalyticalModel
                    If Not anaMod Is Nothing Then
                        elems.Insert(elem)
                    End If
                Catch
                End Try
            End If
        Loop

        Return elems

    End Function

    ' Helper to get all STRUCTURAL Floors
    Shared Function GetAllStructuralFloors(ByVal revitApp As Revit.Application) As ElementSet

        Dim elems As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is Floor Then
                Dim f As Floor = elem
                Dim anaMod As AnalyticalModel
                Try
                    anaMod = f.AnalyticalModel
                    If Not anaMod Is Nothing Then
                        ' For floors, looks like we need to have additional check: for non-Structural Floors
                        '    anaMod is NOT Nothing, but it IS empty!
                        Dim floorAnaMod As AnalyticalModelFloor = anaMod
                        If floorAnaMod.Curves.Size > 0 Then
                            elems.Insert(elem)
                        End If
                    End If
                Catch
                End Try
            End If
        Loop

        Return elems

    End Function

    ' Helper to get all STRUCTURAL ContinuousFootings
    Shared Function GetAllStructuralContinuousFootings(ByVal revitApp As Revit.Application) As ElementSet

        Dim elems As ElementSet = revitApp.Create.NewElementSet

        Dim iter As IEnumerator = revitApp.ActiveDocument.Elements
        Do While (iter.MoveNext())
            Dim elem As Revit.Element = iter.Current
            If TypeOf elem Is ContFooting Then
                Dim cf As ContFooting = elem
                Dim anaMod As AnalyticalModel
                Try
                    anaMod = cf.AnalyticalModel
                    If Not anaMod Is Nothing Then
                        elems.Insert(elem)
                    End If
                Catch
                End Try
            End If
        Loop

        Return elems

    End Function

End Class
