#Region "Header"
' Revit API .NET Labs
'
' Copyright (C) 2006-2008 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software
' for any purpose and without fee is hereby granted, provided
' that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
#End Region

#Region "Namespaces"
Imports System.Enum
Imports Autodesk.Revit
Imports Autodesk.Revit.Geometry
Imports Autodesk.Revit.Structural.Enums
Imports Autodesk.Revit.Geometry.XYZ
Imports Labs
#End Region

Namespace Labs

#Region "Lab2_0_CreateLittleHouse"
''' <summary>
''' Create some sample elements.
''' We create a simple building consisting of four walls, 
''' a door, two windows, a floor, a roof, a room and a room tag.
''' </summary>
Public Class Lab2_0_CreateLittleHouse
    Implements IExternalCommand


    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

        Try
            Dim waitCursor As New Labs.WaitCursor
            Dim app As Application = commandData.Application
            Dim doc As Document = app.ActiveDocument
            Dim creApp As Autodesk.Revit.Creation.Application = app.Create
            Dim creDoc As Autodesk.Revit.Creation.Document = doc.Create
            '
            ' determine the four corners of the rectangular house:
            '
            Dim width As Double = 7 * LabConstants.MeterToFeet
            Dim depth As Double = 4 * LabConstants.MeterToFeet

                Dim corners As List(Of Geometry.XYZ) = New List(Of Geometry.XYZ)(4)
                corners.Add(New Geometry.XYZ(0, 0, 0))
                corners.Add(New Geometry.XYZ(width, 0, 0))
                corners.Add(New Geometry.XYZ(width, depth, 0))
                corners.Add(New Geometry.XYZ(0, depth, 0))
            '
            'determine the levels where the walls will be located:
            '
            Dim levelBottom As Level = Nothing
            Dim levelTop As Level = Nothing
            If Not LabUtils.GetBottomAndTopLevels(app, levelBottom, levelTop) Then
                message = "Unable to determine wall bottom and top levels"
                Return IExternalCommand.Result.Failed
            End If
            Debug.Print(String.Format("Drawing walls on '{0}' up to '{1}'", levelBottom.Name, levelTop.Name))
            '
            ' Create the walls
            '   
            Dim topLevelParam As BuiltInParameter = BuiltInParameter.WALL_HEIGHT_TYPE
            Dim topLevelId As ElementId = levelTop.Id
            Dim walls As List(Of Wall) = New List(Of Wall)(4)
            Dim i As Integer
            For i = 0 To 4 - 1 Step +1
                Dim line As Line = creApp.NewLineBound(corners(i), corners(IIf(3 = i, 0, i + 1)))

                Dim wall As Wall = creDoc.NewWall(line, levelBottom, False)
                Dim param As Parameter = wall.Parameter(topLevelParam)
                param.Set(topLevelId)
                walls.Add(wall)
            Next
            '
            ' Add door and windows to the first wall:
            '
            Dim doorSymbols As List(Of Element) = LabUtils.GetAllFamilySymbols(app, BuiltInCategory.OST_Doors)
            Dim windowSymbols As List(Of Element) = LabUtils.GetAllFamilySymbols(app, BuiltInCategory.OST_Windows)
            Debug.Assert(0 < doorSymbols.Count, "expected at least one door symbol to be loaded into project")
            Debug.Assert(0 < windowSymbols.Count, "expected at least one window symbol to be loaded into project")
            Dim door As FamilySymbol = CType(doorSymbols(0), FamilySymbol)
            Dim window As FamilySymbol = CType(windowSymbols(0), FamilySymbol)
                Dim midpoint As Geometry.XYZ = LabUtils.Midpoint(corners(0), corners(1))
                Dim p As Geometry.XYZ = LabUtils.Midpoint(corners(0), midpoint)
                Dim q As Geometry.XYZ = LabUtils.Midpoint(midpoint, corners(1))
            'double h = 1 * LabConstants.MeterToFeet;
            Dim h As Double = levelBottom.Elevation + 0.3 * (levelTop.Elevation - levelBottom.Elevation)
            p.Z = h
            q.Z = h
            Dim inst As FamilyInstance = creDoc.NewFamilyInstance(midpoint, door, walls(0), levelBottom, StructuralType.NonStructural)
            inst = creDoc.NewFamilyInstance(p, window, walls(0), levelBottom, StructuralType.NonStructural)
            inst = creDoc.NewFamilyInstance(q, window, walls(0), levelBottom, StructuralType.NonStructural)
            '
            ' determine wall thickness and grow the profile out by half the wall thickness, 
            ' so the floor and roof do not stop halfway through the wall:
            '
            Dim thickness As Double = walls(0).WallType.CompoundStructure.Layers.Item(0).Thickness
            Dim w As Double = 0.5 * thickness
            corners(0).X -= w
            corners(0).Y -= w
            corners(1).X += w
            corners(1).Y -= w
            corners(2).X += w
            corners(2).Y += w
            corners(3).X -= w
            corners(3).Y += w
            Dim profile As New CurveArray()
            For i = 0 To 4 - 1 Step +1
                Dim line As Line = creApp.NewLineBound(corners(i), corners(IIf(3 = i, 0, i + 1)))
                profile.Append(line)
            Next
            '
            'add a floor, a roof, a room and a room tag:
            '
            'todo: make a nicer roof, with a slope
            ' 
            Dim structural As Boolean = False
            Dim floor As Floor = creDoc.NewFloor(profile, structural)
            Dim roofTypes As List(Of Element) = LabUtils.GetAllTypes(app, GetType(RoofType), BuiltInCategory.OST_Roofs)
            Debug.Assert(0 < roofTypes.Count, "expected at least one roof type to be loaded into project")
            Dim roofType As RoofType = CType(roofTypes(0), RoofType)
            Dim roof As FootPrintRoof = creDoc.NewFootPrintRoof(profile, levelTop, roofType, New ElementIdSet())
            Dim room As Room = creDoc.NewRoom(levelBottom, New Autodesk.Revit.Geometry.UV(0.5 * width, 0.5 * depth))
            Dim roomTag As RoomTag = creDoc.NewRoomTag(room, New Autodesk.Revit.Geometry.UV(0.5 * width, 0.7 * depth), Nothing)
            'LabUtils.InfoMsg( "Little house was created successfully." );
            Return IExternalCommand.Result.Succeeded

        Catch ex As Exception
            message = ex.Message
            Return IExternalCommand.Result.Failed
        End Try
    End Function
End Class


#End Region

#Region "Lab2_1_Elements"
''' <summary>
''' List all document elements.
''' </summary>
Public Class Lab2_1_Elements
    Implements IExternalCommand

    Public Function Execute( _
        ByVal commandData As Autodesk.Revit.ExternalCommandData, _
        ByRef message As String, _
        ByVal elements As Autodesk.Revit.ElementSet) _
    As Autodesk.Revit.IExternalCommand.Result _
    Implements Autodesk.Revit.IExternalCommand.Execute

        ' Typical .NET error-checking (should be done everywhere, but will be omitted
        ' for clarity in some of the following labs unless we expect exceptions)
        Dim sw As StreamWriter
        Try
            sw = New StreamWriter(gsFilePathLab2_1)
        Catch e As Exception
            MsgBox("Cannot open " & gsFilePathLab2_1 & "; Exception=" & e.Message)
            Return IExternalCommand.Result.Failed
        End Try

        ' *ALL* elements are bundled together and accessible via Document's ElementIterator
        Dim sLine As String
        Dim elem As Revit.Element
        Dim iter As ElementIterator = commandData.Application.ActiveDocument.Elements
        Do While (iter.MoveNext)

            ' current Element
            elem = iter.Current

            ' Element Id
            sLine = "Id=" & elem.Id.Value.ToString

            ' Element class (System.Type)
            sLine += "; Class=" & elem.GetType.Name

            ' Element Category (not implemented for all classes!)
            Dim sCatName As String
            Try
                sCatName = elem.Category.Name
            Catch
                sCatName = ""
            End Try
            sLine += "; Category=" & sCatName

            ' Element Name (different meaning for different classes, but mostly implemented "logically")
            ' Later, we'll see that more precise info on elements can be obtained in class-specific ways...
            Dim sName As String
            Try
                sName = elem.Name
            Catch
                sName = ""
            End Try
            sLine += "; Name=" & sName

            ' write the Line
            sw.WriteLine(sLine)

        Loop

        sw.Close()
        MsgBox("Elements list has been created in " & gsFilePathLab2_1 & "!")
        Return IExternalCommand.Result.Succeeded

    End Function
End Class

#End Region

#Region "Lab2_2_ModelElements"
''' <summary>
''' List all model elements.
''' </summary>
Public Class Lab2_2_ModelElements
    Implements IExternalCommand

    Public Function Execute( _
        ByVal commandData As ExternalCommandData, _
        ByRef message As String, _
        ByVal elements As ElementSet) _
    As Autodesk.Revit.IExternalCommand.Result _
    Implements Autodesk.Revit.IExternalCommand.Execute

        ' Call the utility
        Dim modelElems As ElementSet = LabUtils.GetAllModelElements(commandData.Application)

        ' List all elems
        Dim sMsg As String = "There are " & modelElems.Size & " model elements:"
        Dim elem As Revit.Element
        For Each elem In modelElems
            sMsg += vbCrLf & "  Category=" & elem.Category.Name & "; Id=" & elem.Id.Value.ToString
        Next
        MsgBox(sMsg)

        Return IExternalCommand.Result.Succeeded

    End Function
End Class

#End Region

#Region "Lab2_3_AllWallsAndFamilyInstances"
''' <summary>
''' List all walls and family instances.
''' </summary>
Public Class Lab2_3_AllWallsAndFamilyInstances
    Implements IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.ElementSet) As Autodesk.Revit.IExternalCommand.Result Implements Autodesk.Revit.IExternalCommand.Execute

        Dim app As Revit.Application = commandData.Application

        ' get all Walls
        Dim walls As List(Of Element) = LabUtils.GetAllWalls(app)
        Dim wall As Wall
        Dim sMsg As String = "All Walls in the model:"
        For Each wall In walls
            sMsg += vbCrLf & "  Id=" & wall.Id.Value.ToString & "; Kind=" & wall.WallType.Kind.ToString & "; Type=" & wall.WallType.Name
        Next
        MsgBox(sMsg)

        ' get all Doors (you can change it to eg Furniture or Windows...)

        'NOTE: Before 9.0, one had to hard-code the name which wouldn't work in other locales!
        'Dim catName As String = "Doors"
        ' From 9.0, there is enumeration which should work with ALL locales
        Dim catName As String = app.ActiveDocument.Settings.Categories.Item(BuiltInCategory.OST_Doors).Name

        Dim familyInstances As List(Of Revit.Element) = LabUtils.GetAllStandardFamilyInstancesForACategory(app, catName)
        Dim inst As FamilyInstance
        sMsg = "All " & catName & " instances in the model:"
        For Each inst In familyInstances
            ' For FamilyInstances, Element's Name property returns Type name. More on this later...
            sMsg += vbCrLf & "  Id=" & inst.Id.Value.ToString & "; Type=" & inst.Name
        Next
        MsgBox(sMsg)

        Return IExternalCommand.Result.Succeeded

    End Function
End Class

#End Region

#Region "Lab2_4_AddColumnsAndMoveWall"
''' <summary>
''' Insert new family instances (columns) and move a wall.
''' note: the column can be seen in 3D view by setting argument to StructuralType.Column,
''' but cannot by StructuralType.NonStructural, the latter is only visible in plan view.
''' This is a temporary problem, NewFamilyInstance identifies the nonstructural instance
''' as an annotation instance, so it only shows it in plan view.
''' </summary>
Public Class Lab2_4_AddColumnsAndMoveWall
    Implements IExternalCommand
    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef msg As String, ByVal els As ElementSet) As IExternalCommand.Result Implements IExternalCommand.Execute

        Dim doc As Revit.Document = commandData.Application.ActiveDocument
        Dim ss As ElementSet = doc.Selection.Elements

        ' must have single element only
        If Not ss.Size = 1 Then
            MsgBox("You must pre-select a single element!")
            Return IExternalCommand.Result.Cancelled
        End If

        ' must be a wall
        Dim iter As ElementSetIterator = ss.ForwardIterator
        iter.MoveNext()
        Dim elem As Revit.Element = iter.Current
        If Not TypeOf elem Is Wall Then
            MsgBox("Selected element is NOT a wall!")
            Return IExternalCommand.Result.Cancelled
        End If
        Dim wall As Wall = elem

        ' wall must be constrained to a Level at the top (more on Parameters later...)
        Dim topLev As Level = Nothing
        Try
            topLev = doc.Element(wall.Parameter(Parameters.BuiltInParameter.WALL_HEIGHT_TYPE).AsElementId)
        Catch
            topLev = Nothing
        End Try
        If topLev Is Nothing Then
            MsgBox("Selected Wall is NOT constrained to a Level at the Top!")
            Return IExternalCommand.Result.Cancelled
        End If

        ' get the bottom Level as well (this should never fail)
        Dim botLev As Level = Nothing
        Try
            botLev = doc.Element(wall.Parameter(Parameters.BuiltInParameter.WALL_BASE_CONSTRAINT).AsElementId)
        Catch
            botLev = Nothing
        End Try
        If botLev Is Nothing Then
            MsgBox("Selected Wall is NOT constrained to a Level at the Bottom?!")
            Return IExternalCommand.Result.Cancelled
        End If

        ' Calculate the location points for the 3 columns (assuming straight wall)
        Dim locations As New XYZArray()

        Dim locCurve As LocationCurve = wall.Location
            Dim ptStart As Geometry.XYZ = locCurve.Curve.EndPoint(0)
            Dim ptEnd As Geometry.XYZ = locCurve.Curve.EndPoint(1)
            Dim ptMid As New Geometry.XYZ((ptStart.X + ptEnd.X) / 2, (ptStart.Y + ptEnd.Y) / 2, (ptStart.Z + ptEnd.Z) / 2)

        locations.Append(ptStart)
        locations.Append(ptMid)
        locations.Append(ptEnd)

        Dim sMsg As String = "Locations for the new Columns (ALWAYS reported 'raw', in inches!) are:"
        sMsg += vbCrLf & "  Start:" & ptStart.X & ", " & ptStart.Y & ", " & ptStart.Z
        sMsg += vbCrLf & "  Mid  :" & ptMid.X & ", " & ptMid.Y & ", " & ptMid.Z
        sMsg += vbCrLf & "  End  :" & ptEnd.X & ", " & ptEnd.Y & ", " & ptEnd.Z
        MsgBox(sMsg)

        ' Get the family type for the new instances.
        ' If needed, change the names to match a column type available in the model
        Dim sFamilyName As String = "M_Wood Timber Column"
        Dim sTypeName As String = "191 x 292mm"
        Dim symbol As FamilySymbol = LabUtils.GetFamilySymbol(doc, sFamilyName, sTypeName)
        If symbol Is Nothing Then
            MsgBox("Cannot find Family=" & sFamilyName & " Type=" & sTypeName & " in the current model - load it first!")
            Return IExternalCommand.Result.Cancelled
        End If

        ' Insert columns as family instances
            Dim pt As Geometry.XYZ
        For Each pt In locations
            Try
                ' Note: Currently there is a problem.  If we set the type as NonStructural, it is treated as Annotation instance, and it shows only in plan view.
                'Dim column As FamilyInstance = doc.Create.NewFamilyInstance(pt, symbol, botLev, Structural.Enums.StructuralType.NonStuctural)
                Dim column As FamilyInstance = doc.Create.NewFamilyInstance(pt, symbol, botLev, Structural.Enums.StructuralType.Column)
                Dim paramTopLevel As Parameter = column.Parameter(Parameters.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)
                paramTopLevel.Set(topLev.Id)
            Catch e As Exception
                MsgBox("Failed to create or adjust this column!?")
            End Try
        Next

        ' Move the wall so the columns are surely visible. For simplicity,
        ' move the wall "perpendicularly" to the location curve by its length
            Dim wallPerpAxis As New Geometry.XYZ(-0.1 * (ptEnd.Y - ptStart.Y), 0.1 * (ptEnd.X - ptStart.X), 0)
        If Not CType(wall.Location.Move(wallPerpAxis), Boolean) Then
            MsgBox("Failed to Move the wall!?")
        End If
        Return IExternalCommand.Result.Succeeded

    End Function
End Class

#End Region

#Region "Lab2_5_Categories"
''' <summary>
''' List all built-in categories and the entire category tree.
''' Some of the results:
''' - not all built-in categories have a corresponding document category.
''' - not all document categories have a corresponding built-in category.
''' There are 598 built-in categories.
''' 397 of them have associated document categories.
''' 190 of these are top level parents.
''' These lead to 423 top-level and children categories.
''' </summary>
Public Class Lab2_5_Categories
    Implements IExternalCommand

    Dim _doc As Document
    Const _indentDepth As Integer = 2
    Dim _bicForCategory As Hashtable

    ''' <summary>
    ''' Check whether the given category is one of the built-in ones.
    ''' This implementation is slow in 2008, and very very very slow in 2009,
    ''' so it has been replaced by the _bicForCategory hash table solution below.
    ''' </summary>
    ''' <param name="c"></param>
    ''' <returns>True if the given category is one of the built-in ones.</returns>
    Private Function IsBuiltInCategory1(ByVal c As Category) As Boolean

        Dim rc As Boolean = False
        Dim a As BuiltInCategory
        For Each a In System.Enum.GetValues(GetType(BuiltInCategory))
            Dim c2 As Category = _doc.Settings.Categories.Item(a)
            If c.Equals(c2) = True Then
                rc = True
                Exit For
            End If
        Next
        Return rc
    End Function

    ''' <summary>
    ''' Check whether the given category is one of the built-in ones.
    ''' </summary>
    ''' <param name="c"></param>
    ''' <returns>True if the given category is one of the built-in ones.</returns>
    Private Function IsBuiltInCategory(ByVal c As Category) As Boolean
        Return _bicForCategory.ContainsKey(c)
    End Function

    Private Function ListCategoryAndSubCategories(ByVal c As Category, ByVal level As Integer) As Integer

        Dim n As Integer = 1
        Dim indent As String = New String(" ", level * _indentDepth)
        Dim subCat As Category
        For Each subCat In c.SubCategories
            n += ListCategoryAndSubCategories(subCat, level + 1)
        Next
        Return n

    End Function

    Public Function Execute(ByVal commandData As Autodesk.Revit.ExternalCommandData, ByRef msg As String, ByVal els As ElementSet) As IExternalCommand.Result Implements IExternalCommand.Execute

        Dim waitCursor As New Labs.WaitCursor
        Dim app As Application = commandData.Application
        _doc = app.ActiveDocument
        Dim categories As Categories = _doc.Settings.Categories
        Dim bics As Array = System.Enum.GetValues(GetType(BuiltInCategory))
        _bicForCategory = New Hashtable(bics.GetLength(0))
        '_categoryForBic = new Hashtable( bics.GetLength( 0 ) );
        Dim bic As BuiltInCategory
        Dim c As Category
        For Each bic In bics
            c = categories.Item(bic)
            If c Is Nothing Then
                Debug.WriteLine(String.Format("Built-in category '{0}' has a null category.", bic.ToString()))
            Else
                '_categoryForBic.Add( bic, c );
                _bicForCategory.Add(c, bic)
            End If
        Next
        '
        ' list and count all the built-in categoreies:
        '
        Dim nBuiltInCategories As Integer = 0
        Dim nDocumentCategories As Integer = 0
        Dim indent As String = New String(" "c, _indentDepth)
        Dim topLevelCategories As CategorySet = app.Create.NewCategorySet()
        Debug.WriteLine("\nBuilt-in categories:")
        Dim a As BuiltInCategory
        For Each a In System.Enum.GetValues(GetType(BuiltInCategory))
            c = categories.Item(a)
            If Not (c Is Nothing) Then
                nDocumentCategories = nDocumentCategories + 1
                If c.Parent Is Nothing Then
                    topLevelCategories.Insert(c)
                End If
            End If

            Dim tempStr As String = ""
            If Not c Is Nothing Then
                tempStr = ": " + c.Name
            End If
            Debug.WriteLine(indent + a.ToString() + tempStr)
            nBuiltInCategories = nBuiltInCategories + 1
        Next
        Debug.WriteLine(String.Format("There are {0} built-in categories. {1} of them have associated document categories. {2} are top level parents.", nBuiltInCategories, nDocumentCategories, topLevelCategories.Size))
        '
        ' list the entire category hierarchy:
        '
        Dim nPrinted As Integer = 0
        Debug.WriteLine("\nDocument categories:")
        For Each c In topLevelCategories
            nPrinted += ListCategoryAndSubCategories(c, 1)
        Next
        Debug.WriteLine(String.Format("{0} top-level and children categories printed.", nPrinted))
        Return IExternalCommand.Result.Succeeded

    End Function
End Class
#End Region

End Namespace

