#
# chkasm.py - parse and check validity of Revit_SDK_Samples.xlsx EC info
#
# Copyright (C) 2007-2008 Jeremy Tammik, Autodesk Inc.
#
# History:
#
# 2007-08-28 initial implementation
# 2007-08-29 updated for improved versions of Revit_SDK_Samples.xlsx
# 2008-01-02 updated for Revit 2009 alpha 2 SDK
# 2008-03-12 updated for Revit 2009 beta 3 SDK
#
# CheckAsm.exe source code is 
# C:\a\src\revit\CheckAsm\CheckAsm\Program.cs
#
import os

def main():
    f = open( 'C:/a/lib/revit/2009/SDK/Samples/RvtSamples/py/Revit_SDK_Samples.txt' )
    lines = f.readlines()
    f.close()
    exePath = 'C:/j/bin/CheckAsm.exe'
    sdkRoot = 'C:/a/lib/revit/2009/SDK/Samples/'
    failed = succeeded = 0
    for line in lines[1:]:
        a = line.split( '\t' )
        assert( 14 == len( a ) )
        key = a[0]
        className = a[3]
        assemblyPath = a[4]
        typ = a[8]
        if 'exe' != typ:
            args = [exePath, sdkRoot + assemblyPath, className]
            if 'app' == typ: args.append( '-a' )
            rc = os.spawnv( os.P_WAIT, exePath, args )
            if 0 == rc:
                succeeded = succeeded + 1
            else:
                print key, 'returned error code', rc
                failed = failed + 1
    print failed, 'failed,', succeeded, 'succeeded.'

if __name__ == '__main__':
    main()
