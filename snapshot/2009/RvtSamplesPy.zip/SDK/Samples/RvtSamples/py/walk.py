#
# walk.py - determine source file number and size of Revit SDK samples
#
# Copyright (C) 2007 Jeremy Tammik, Autodesk Inc.
#
# History:
#
# 2007-08-29 initial implementation
#
import os
from os.path import join, getsize

debug = False
filter = 'SlabShapeEditing' # set it to empty string '' for no filter

def ext( s ):
    n = len( s )
    return s[-3:]

sdkroot = 'C:/a/lib/revit/2009/SDK/Samples'
n = len( sdkroot ) + 1
nFilesTotal = nBytesTotal = 0

print '%6s %7s  %s' % ('files', 'bytes', 'project')
print '%6s %7s  %s' % ('-----', '-----', '-------')

for root, dirs, files in os.walk( sdkroot ):
    if debug: print files
    srcfiles = [name for name in files if ext( name) in ['.cs', '.vb' ]]
    if debug: print srcfiles
    nfiles = len( srcfiles )
    nbytes = sum( getsize( join( root, name ) ) for name in srcfiles )
    if 0 < nbytes:
        subdir = root[n:]
        if subdir.startswith( filter ):
            if debug: print subdir, 'consumes', nbytes, 'bytes in', len( srcfiles ), 'cs or vb source files'
            print '%6s %7s  %s' % (len( srcfiles ), nbytes, subdir)
            nFilesTotal += nfiles
            nBytesTotal += nbytes
    # don't visit certain subdirectories
    for a in ['bin', 'obj', 'Properties', 'My Project']:
        if a in dirs:
            dirs.remove( a )

print '%6s %7s  %s' % ('-----', '-----', '-------')
print '%6s %7s  %s' % (nFilesTotal, nBytesTotal, 'Total')
