﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.Concrete
{
   /// <summary>
   /// Base class for internal forces in different structural elements
   /// </summary>
   abstract class InternalForcesBase
   {
      /// <summary>
      /// Creates default InternalForcesBase
      /// </summary>
      protected InternalForcesBase() { }

      /// <summary>
      /// Get or set number of the related load case
      /// </summary>
      int RelatedCaseId
      {
         get { return relatedCaseId; }
         set { relatedCaseId = value; }
      }

      /// <summary>
      /// Get or set number of the related point
      /// </summary>
      int RelatedPointId
      {
         get { return relatedPointId; }
         set { relatedPointId = value; }
      }

      private int relatedCaseId;
      private int relatedPointId;
   }
}
