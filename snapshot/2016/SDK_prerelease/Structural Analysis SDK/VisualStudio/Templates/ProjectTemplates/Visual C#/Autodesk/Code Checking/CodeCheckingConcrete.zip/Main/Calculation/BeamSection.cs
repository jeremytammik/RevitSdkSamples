﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Engineering;
using Autodesk.CodeChecking.Concrete;
using $safeprojectname$.Engine;
using $safeprojectname$.Concrete;
using $safeprojectname$.Utility;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's section of a beam element.
   /// </summary>
   class BeamSection : LinearSection
   {
      /// <summary>
      /// Initializes a new instance of user's section object of beam element.  
      /// </summary>
      /// <param name="sectionDataBase">Instance of base section object with predefined parameters to copy.</param>
      public BeamSection(SectionDataBase sectionDataBase)
         : base(sectionDataBase)
      {
         Width = 0.0;
         Height = 0.0;
         Geometry = new Geometry();
         ///<WIZARD OPTION="$RC_BEAM_GEOMETRY_T_SECTION">
         IsTSection = false;
         ///</WIZARD>

         ListInternalForces = new List<InternalForcesBase>();
         MinStiffness = 0.0;
      }

      ///<WIZARD OPTION="$RC_BEAM_GEOMETRY_T_SECTION">
      /// <summary>
      /// gets and sets flag for T-shape section.
      /// </summary>
      public bool IsTSection { get; set; }
      ///</WIZARD>
   }
}
