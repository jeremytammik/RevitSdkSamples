﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.Utility;

namespace $safeprojectname$.Main
{
   /// <summary>
   /// Container for RC linear element results data
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("ResultLinearElement", "$guid13$")]
   public class ResultLinearElement : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
   {
      ///<WIZARD OPTION="$RC_RESULTS_PRESENTATION_TEMPLATE">
      
      /// <summary>
      /// Collection of values representing element results in raw format
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(Unit = Autodesk.Revit.DB.UnitType.UT_Length, DisplayUnit = Autodesk.Revit.DB.DisplayUnitType.DUT_METERS)]
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.Attributes.ListValue(Name = "ValuesInPoints", LocalizableValue = false, Level = Autodesk.Revit.DB.ExtensibleStorage.Framework.Documentation.DetailLevel.General, Localizable = false)]
      public List<Double> ValuesInPointsData { get; set; }

      /// <summary>
      /// Gets results in point formatted as a list of ResultInPointLinear elements
      /// </summary>
      /// <returns>List of ResultInPointLinear</returns>
      public List<ResultInPointLinear> GetResultsInPointsCollection()
      {
         IEnumerable<ResultTypeLinear> linearResultTypes = Enum.GetValues(typeof(ResultTypeLinear)).OfType<ResultTypeLinear>();

         int numberOfResultTypes  = linearResultTypes.Count(),
             numberOfPoints = ValuesInPointsData.Count / numberOfResultTypes;

         List<ResultInPointLinear> resultsInPoints = new List<ResultInPointLinear>();
         for (int ptId = 0; ptId < numberOfPoints; ptId++)
         {
            resultsInPoints.Add(new ResultInPointLinear(ValuesInPointsData.GetRange(ptId * numberOfResultTypes, numberOfResultTypes)));
         }

         return resultsInPoints;
      }
      ///</WIZARD>

      /// <summary>
      /// Creates default ResultLinearElement
      /// </summary>
      public ResultLinearElement()
      {
         ///<WIZARD OPTION="$RC_RESULTS_PRESENTATION_TEMPLATE">
         ValuesInPointsData = new List<double>();
         ///</WIZARD>
      }

   }
}
