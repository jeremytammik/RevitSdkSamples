﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.Engine
{
   /// <summary>
   /// Base interface for calculation scenario.
   /// </summary>
   public interface ICalculationScenario
   {
      /// <structural_toolkit_2015>

      /// <summary>
      /// Gets list of calculation objects cref="ICalculationObject".
      /// </summary>
      /// <param name="category">Category of the element.</param>
      /// <param name="material">Material of the element.</param>
      /// <returns>List of calculation objects.</returns>
      List<ICalculationObject> CalculationScenarioList(Autodesk.Revit.DB.BuiltInCategory category, Autodesk.Revit.DB.StructuralAssetClass material);

      /// </structural_toolkit_2015>
   }
}
