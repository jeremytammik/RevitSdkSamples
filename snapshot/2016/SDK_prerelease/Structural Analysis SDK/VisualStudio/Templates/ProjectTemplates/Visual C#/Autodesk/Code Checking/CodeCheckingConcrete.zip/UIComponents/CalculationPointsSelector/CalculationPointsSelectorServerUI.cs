﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.UIComponents.CalculationPointsSelector
{
#pragma warning disable 1591
   class CalculationPointsSelectorServerUI : Autodesk.Revit.UI.ExtensibleStorage.Framework.IServerUI
   {
      #region IServerUI Members

      public System.Collections.IList GetDataSource(string key, Autodesk.Revit.DB.Document document, Autodesk.Revit.DB.DisplayUnitType unitType)
      {
         return null;
      }

      public void LayoutInitialized(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.LayoutInitializedEventArgs e)
      {
         onChange(e);
      }

      public void ValueChanged(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.ValueChangedEventArgs e)
      {
         onChange(e);
      }

      private void onChange(Autodesk.Revit.UI.ExtensibleStorage.Framework.SchemaEditorEventArgs e)
      {
         CalculationPointsSelectorSchema pointsSelectorSchema = new CalculationPointsSelectorSchema();
         pointsSelectorSchema.SetProperties(e.Entity as Autodesk.Revit.DB.ExtensibleStorage.Entity);

         CalculationPointsSelectorSchema.DivisionType divisionType = pointsSelectorSchema.ElementDivisionType;
         bool isUniformDistance = divisionType == CalculationPointsSelectorSchema.DivisionType.Points,
              isUserSegmentDistance = divisionType == CalculationPointsSelectorSchema.DivisionType.Segments;

         e.Editor.SetAttribute("UniformDistribution", Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.FieldUIAttribute.PropertyIsVisible, isUniformDistance, Autodesk.Revit.DB.DisplayUnitType.DUT_UNDEFINED);
         e.Editor.SetAttribute("UserSegmentDivision", Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.FieldUIAttribute.PropertyIsVisible, isUserSegmentDistance, Autodesk.Revit.DB.DisplayUnitType.DUT_UNDEFINED);
      }

      #endregion

      #region IResource Members

      public string GetResource(string key, string context)
      {
         String txt = null;
         if (context == "CalculationPointsSelector")
         {
            if (key == "Points" || key == "Segments")
            {
               txt = $safeprojectname$.Properties.Resources.ResourceManager.GetString(key);
            }
         }

         return txt != null ? txt : key;
      }

      public Uri GetResourceImage(string key, string context)
      {
         return null;
      }



      #endregion

 
   }
}
