﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$.Main
{
   /// <summary>
   /// Container for code Calculation parameters 
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("CalculationParam", "$guid8$")]
   public class CalculationParameter : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
   {
      ///<WIZARD OPTION="$RC_UICALCPOINTSELECTION">
      /// <summary>
      /// Calculation points selection component
      /// </summary>
      [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.SchemaProperty(FieldName = "CalcPointSelector")]
      [$safeprojectname$.UIComponents.CalculationPointsSelector.CalculationPointsSelector(Category = "CalcPointSelector")]
      public $safeprojectname$.UIComponents.CalculationPointsSelector.CalculationPointsSelectorSchema CalculationPointsSelector { get; set; }
      ///</WIZARD>

      /// <summary>
      /// Creates default CalculationParameter
      /// </summary>
      public CalculationParameter()
      {
         ///<WIZARD OPTION="$RC_UICALCPOINTSELECTION">
         CalculationPointsSelector = new $safeprojectname$.UIComponents.CalculationPointsSelector.CalculationPointsSelectorSchema();
         CalculationPointsSelector.ElementDivisionType = $safeprojectname$.UIComponents.CalculationPointsSelector.CalculationPointsSelectorSchema.DivisionType.Points;
         CalculationPointsSelector.UniformDistribution = 11;
         ///</WIZARD>
      }
   }
}
