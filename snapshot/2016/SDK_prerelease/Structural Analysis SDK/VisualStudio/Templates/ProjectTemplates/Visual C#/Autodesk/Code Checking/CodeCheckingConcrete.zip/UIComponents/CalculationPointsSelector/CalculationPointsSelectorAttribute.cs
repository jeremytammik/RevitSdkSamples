﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.UIComponents.CalculationPointsSelector
{
#pragma warning disable 1591
   public class CalculationPointsSelectorAttribute : Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes.SubSchemaEmbeddedControlAttribute
   {
      public CalculationPointsSelectorAttribute()
      {
         ServerUI = typeof(CalculationPointsSelectorServerUI);
      }
   }
}
