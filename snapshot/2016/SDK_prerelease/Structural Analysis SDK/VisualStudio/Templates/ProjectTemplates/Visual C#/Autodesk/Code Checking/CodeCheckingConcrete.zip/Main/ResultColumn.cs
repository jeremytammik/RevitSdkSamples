﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.Utility;


namespace $safeprojectname$.Main
{
   /// <summary>
   /// Container for RC column results data
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("ResultColumn", "$guid12$")]
   public class ResultColumn : ResultLinearElement
   {
      /// <summary>
      /// Creates default ResultColumn
      /// </summary>
      public ResultColumn()
         : base()
      {

      }
   }
}
