﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using $safeprojectname$.Utility;


namespace $safeprojectname$.Main
{
   /// <summary>
   /// Container for RC beam results data
   /// </summary>
   [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("ResultBeam", "$guid11$")]
   public class ResultBeam : ResultLinearElement
   {
      /// <summary>
      /// Creates default ResultBeam
      /// </summary>
      public ResultBeam()
         : base()
      {

      }
   }
}