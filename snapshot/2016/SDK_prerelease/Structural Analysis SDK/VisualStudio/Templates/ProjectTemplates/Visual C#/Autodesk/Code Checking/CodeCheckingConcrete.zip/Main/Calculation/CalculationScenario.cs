﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $safeprojectname$.Engine;
using Autodesk.Revit.DB;

namespace $safeprojectname$.Main.Calculation
{
   /// <summary>
   /// Represents user's calculation scenario.
   /// </summary>
   public class CalculationScenario : ICalculationScenario
   {

      #region ICalculationScenario Members

      /// <summary>
      /// Creates list of cref="ICalculationObject".
      /// </summary>
      /// <param name="category">Category of the element.</param>
      /// <param name="material">Material of the element.</param>
      /// <returns>List of cref="ICalculationObject".</returns>
      public List<ICalculationObject> CalculationScenarioList(Autodesk.Revit.DB.BuiltInCategory category, Autodesk.Revit.DB.StructuralAssetClass material)
      {
         List<ICalculationObject> scenario = new List<ICalculationObject>();

         /// <structural_toolkit_2015>
         switch (material)
         {
            case StructuralAssetClass.Concrete:
               switch (category)
               {
                  ///<WIZARD OPTION="$RC_BEAM;$RC_COLUMN">
                  ///<WIZARD OPTION="$RC_BEAM">
                  case BuiltInCategory.OST_BeamAnalytical:
                  ///</WIZARD>
                  ///<WIZARD OPTION="$RC_COLUMN">
                  case BuiltInCategory.OST_ColumnAnalytical:
                  ///</WIZARD>
                     {
                        PrepareSectionData calcObj = new PrepareSectionData();
                        calcObj.Type = CalculationObjectType.Section;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                              ///<WIZARD OPTION="$RC_BEAM">
                              BuiltInCategory.OST_BeamAnalytical, 
                              ///</WIZARD>
                              ///<WIZARD OPTION="$RC_COLUMN">
                              BuiltInCategory.OST_ColumnAnalytical, 
                              ///</WIZARD>
                           };
                        scenario.Add(calcObj);
                     }
                     {
                        ModifyElementForces calcObj = new ModifyElementForces();
                        calcObj.Type = CalculationObjectType.Element;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                              ///<WIZARD OPTION="$RC_BEAM">
                              BuiltInCategory.OST_BeamAnalytical, 
                              ///</WIZARD>
                              ///<WIZARD OPTION="$RC_COLUMN">
                              BuiltInCategory.OST_ColumnAnalytical, 
                              ///</WIZARD>
                           };
                        scenario.Add(calcObj);
                     }
                     {
                        CalculateSection calcObj = new CalculateSection();
                        calcObj.Type = CalculationObjectType.Section;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                              ///<WIZARD OPTION="$RC_BEAM">
                              BuiltInCategory.OST_BeamAnalytical, 
                              ///</WIZARD>
                              ///<WIZARD OPTION="$RC_COLUMN">
                              BuiltInCategory.OST_ColumnAnalytical, 
                              ///</WIZARD>
                           };
                        scenario.Add(calcObj);
                     }
                     {
                        FillResultData calcObj = new FillResultData();
                        calcObj.Type = CalculationObjectType.Element;
                        calcObj.ErrorResponse = ErrorResponse.RunOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                              ///<WIZARD OPTION="$RC_BEAM">
                              BuiltInCategory.OST_BeamAnalytical, 
                              ///</WIZARD>
                              ///<WIZARD OPTION="$RC_COLUMN">
                              BuiltInCategory.OST_ColumnAnalytical, 
                              ///</WIZARD>
                           };
                        scenario.Add(calcObj);
                     }
                     break;
                  ///</WIZARD>
                  
                  ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
                  ///<WIZARD OPTION="$RC_FLOOR">
                  case Autodesk.Revit.DB.BuiltInCategory.OST_FloorAnalytical:
                  ///</WIZARD>
                  ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">
                  case Autodesk.Revit.DB.BuiltInCategory.OST_FoundationSlabAnalytical:
                  ///</WIZARD>
                  ///<WIZARD OPTION="$RC_WALL">
                  case Autodesk.Revit.DB.BuiltInCategory.OST_WallAnalytical:
                  ///</WIZARD>
                     {
                        PrepareSectionData calcObj = new PrepareSectionData();
                        calcObj.Type = CalculationObjectType.Section;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                           ///<WIZARD OPTION="$RC_FLOOR">
                           BuiltInCategory.OST_FloorAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">
                           BuiltInCategory.OST_FoundationSlabAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_WALL">
                           BuiltInCategory.OST_WallAnalytical 
                           ///</WIZARD>
                        };
                        scenario.Add(calcObj);
                     }
                     {
                        ModifyElementForces calcObj = new ModifyElementForces();
                        calcObj.Type = CalculationObjectType.Element;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                           ///<WIZARD OPTION="$RC_FLOOR">
                           BuiltInCategory.OST_FloorAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">
                           BuiltInCategory.OST_FoundationSlabAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_WALL">
                           BuiltInCategory.OST_WallAnalytical 
                           ///</WIZARD>
                        };
                        scenario.Add(calcObj);
                     }
                     {
                        CalculateSection calcObj = new CalculateSection();
                        calcObj.Type = CalculationObjectType.Section;
                        calcObj.ErrorResponse = ErrorResponse.SkipOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                           ///<WIZARD OPTION="$RC_FLOOR">
                           BuiltInCategory.OST_FloorAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">
                           BuiltInCategory.OST_FoundationSlabAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_WALL">
                           BuiltInCategory.OST_WallAnalytical 
                           ///</WIZARD>
                        };
                        scenario.Add(calcObj);
                     }
                     {
                        FillResultData calcObj = new FillResultData();
                        calcObj.Type = CalculationObjectType.Element;
                        calcObj.ErrorResponse = ErrorResponse.RunOnError;
                        calcObj.Categories = new List<BuiltInCategory>() { 
                           ///<WIZARD OPTION="$RC_FLOOR">
                           BuiltInCategory.OST_FloorAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">
                           BuiltInCategory.OST_FoundationSlabAnalytical, 
                           ///</WIZARD>
                           ///<WIZARD OPTION="$RC_WALL">
                           BuiltInCategory.OST_WallAnalytical 
                           ///</WIZARD>
                        };
                        scenario.Add(calcObj);
                     }
                     break;
                  ///</WIZARD>
               }
               break;
         }
         /// </structural_toolkit_2015>

         return scenario;
      }

      #endregion
   }
}
