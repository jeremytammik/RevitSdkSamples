﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("LoadCombination", "$guid1$")]
    public class LoadCombination: Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public LoadCombination()
        {
        }
		
		public LoadCombination(Document document)
        {
        }

        public LoadCombination(Entity entity,Document document)
            : base(entity,document)
        {
        }
    }
}
