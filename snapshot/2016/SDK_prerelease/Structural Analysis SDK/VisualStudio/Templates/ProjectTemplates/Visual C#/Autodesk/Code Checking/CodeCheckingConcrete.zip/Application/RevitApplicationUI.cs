﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
   class RevitApplicationUI : Autodesk.Revit.UI.IExternalApplication
   {
      #region IExternalApplication Members

      public Autodesk.Revit.UI.Result OnShutdown(Autodesk.Revit.UI.UIControlledApplication application)
      {
         return Autodesk.Revit.UI.Result.Succeeded;
      }

      public Autodesk.Revit.UI.Result OnStartup(Autodesk.Revit.UI.UIControlledApplication application)
      {
         Server.ServerUI server = new Server.ServerUI();
         Autodesk.Revit.UI.CodeChecking.ServiceUI.BindUIServerWithDBServer(Server.Server.ID, server);
         return Autodesk.Revit.UI.Result.Succeeded;
      }

      #endregion
   }
}
