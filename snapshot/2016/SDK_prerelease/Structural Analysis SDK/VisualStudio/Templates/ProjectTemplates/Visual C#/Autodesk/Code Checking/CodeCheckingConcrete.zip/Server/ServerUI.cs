﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.ExtensibleStorage.Framework.Attributes;
using Autodesk.Revit.UI.ExtensibleStorage.Framework;
using Autodesk.Revit.UI.ExtensibleStorage;
using $safeprojectname$.ConcreteTypes;
using $safeprojectname$.Properties;
using $safeprojectname$.Main;

#pragma warning disable 1591

namespace $safeprojectname$.Server
{
   [Autodesk.Revit.DB.CodeChecking.Attributes.CalculationParamsStructure(typeof(CalculationParameter))]
   ///<WIZARD OPTION="$RC_BEAM">
   [Autodesk.Revit.DB.CodeChecking.Attributes.LabelStructure(typeof(LabelBeam), BuiltInCategory.OST_BeamAnalytical, Autodesk.Revit.DB.StructuralAssetClass.Concrete)]
   ///</WIZARD>
   ///<WIZARD OPTION="$RC_COLUMN">
   [Autodesk.Revit.DB.CodeChecking.Attributes.LabelStructure(typeof(LabelColumn), BuiltInCategory.OST_ColumnAnalytical, Autodesk.Revit.DB.StructuralAssetClass.Concrete)]
   ///</WIZARD>
   ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
   /// <structural_toolkit_2015>
   ///</WIZARD>
   ///<WIZARD OPTION="$RC_FLOOR">
   [Autodesk.Revit.DB.CodeChecking.Attributes.LabelStructure(typeof(LabelFloor), BuiltInCategory.OST_FloorAnalytical, Autodesk.Revit.DB.StructuralAssetClass.Concrete)]
   ///</WIZARD> 
   ///<WIZARD OPTION="$RC_FOUNDATION_SLAB">  
   [Autodesk.Revit.DB.CodeChecking.Attributes.LabelStructure(typeof(LabelFloor), BuiltInCategory.OST_FoundationSlabAnalytical, Autodesk.Revit.DB.StructuralAssetClass.Concrete)]
   ///</WIZARD>
   ///<WIZARD OPTION="$RC_WALL">  
   [Autodesk.Revit.DB.CodeChecking.Attributes.LabelStructure(typeof(LabelWall), BuiltInCategory.OST_WallAnalytical, Autodesk.Revit.DB.StructuralAssetClass.Concrete)]
   ///</WIZARD>  
   ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL"> 
   /// </structural_toolkit_2015>
   ///</WIZARD> 
   public class ServerUI : Autodesk.Revit.UI.CodeChecking.MultiStructureServer
   {
      #region ICodeCheckingServerUI Members
      public override string GetResource(string key, string context)
      {
         string txt = "";
         string resname = "";
         if (context != null)
         {
            switch (context)
            {
               default:
                  break;
               ///<WIZARD OPTION="$RC_COLUMN">
               case "ColumnLabel":
                  {
                     switch (key)
                     {
                        case "FX":
                        case "FY":
                        case "FZ":
                        case "MX":
                        case "MY":
                        case "MZ":
                           resname = "Column" + key;
                           break;
                     }
                     break;
                  }
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_BEAM">
               case "BeamLabel":
                  {
                     switch (key)
                     {
                        case "FX":
                        case "FY":
                        case "FZ":
                        case "MX":
                        case "MY":
                        case "MZ":
                           resname = "Beam" + key;
                           break;
                     }
                     break;
                  }
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
               /// <structural_toolkit_2015>
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB">
               case "FloorLabel":
                  switch (key)
                     {
                        default:
                           break;
                        case "FX":
                           resname = "FloorF";
                           break;
                        case "MY":
                           resname = "FloorM";
                           break;
                        case "FZ":
                           resname = "FloorQ";
                           break;
                     }
                     break;
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_WALL">
               case "WallLabel":
                     switch (key)
                     {
                        default:
                           break;
                        case "FX":
                           resname = "WallF";
                           break;
                        case "MY":
                           resname = "WallM";
                           break;
                        case "FZ":
                           resname = "WallQ";
                           break;
                     }
                     break;
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
               /// </structural_toolkit_2015>
               ///</WIZARD>
            }
         }

         if (!string.IsNullOrEmpty(resname))
            txt = Resources.ResourceManager.GetString(resname);

         if (string.IsNullOrEmpty(txt))
            txt = Resources.ResourceManager.GetString(key);

         if (!string.IsNullOrEmpty(txt))
            return txt;

         return key;
      }

      public override Uri GetResourceImage(string key, string context)
      {
         String contextKey = "";
         if(context != null)
         {
            switch (context)
            {
               default:
                  break;
               ///<WIZARD OPTION="$RC_COLUMN">
               case "ColumnLabel":
                  {
                     switch (key)
                     {
                        case "FX":
                           contextKey = "CFX_32";
                           break;
                        case "FY":
                           contextKey = "CFY_32";
                           break;
                        case "FZ":
                           contextKey = "CFZ_32";
                           break;
                        case "MX":
                           contextKey = "CMX_32";
                           break;
                        case "MY":
                           contextKey = "CMY_32";
                           break;
                        case "MZ":
                           contextKey = "CMZ_32";
                           break;
                        ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
                        case "DirectionY":
                           contextKey = "buckling_Y";
                           break;
                        case "DirectionZ":
                           contextKey = "buckling_Z";
                           break;
                        ///</WIZARD>
                     }
                     break;
                  }
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_BEAM">
               case "BeamLabel":
                  {
                     switch (key)
                     {
                        case "FX":
                           contextKey = "BFX_32";
                           break;
                        case "FY":
                           contextKey = "BFY_32";
                           break;
                        case "FZ":
                           contextKey = "BFZ_32";
                           break;
                        case "MX":
                           contextKey = "BMX_32";
                           break;
                        case "MY":
                           contextKey = "BMY_32";
                           break;
                        case "MZ":
                           contextKey = "BMZ_32";
                           break;
                     }
                     break;
                  }
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
               /// <structural_toolkit_2015>
               ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB">
               case "FloorLabel":
                  {
                     switch (key)
                     { 
                        case "FX":
                        case "MY":
                           contextKey = "F" + key + "_32";
                           break;
                        default:
                           contextKey = null;
                           break;
                     }
                     break;
                  }
               ///</WIZARD>
               ///<WIZARD OPTION="$RC_WALL">
               case "WallLabel":
                  {
                     switch (key)
                     { 
                        case "FX":
                        case "FY":
                        case "MY":
                           contextKey = "W" + key + "_32";
                           break;
                        default:
                           contextKey = null;
                           break;
                     }
                     break;
                  }
               ///</WIZARD>
               /// </structural_toolkit_2015>
               ///</WIZARD>
            }
         }

         if (contextKey == "")
         {
            switch (key)
            {
               case "WithSlabBeamInteraction":
                  contextKey = "BWithSlabBeamInteraction";
                  break;
               case "WithoutSlabBeamInteraction":
                  contextKey = "BWithoutSlabBeamInteraction";
                  break;
               default:
                  contextKey = context != null ? context + key : key;
                  break;
            }
         }

         String currAssemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().ToString();
         return contextKey==null ? null : new Uri("pack://application:,,,/" + currAssemblyName + ";component/UIComponents/ICons/" + contextKey + ".png");
      }

      public override void LayoutInitialized(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.LayoutInitializedEventArgs e)
      {
         onChange(e);

         base.LayoutInitialized(sender, e);
      }

      public override void ValueChanged(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.ValueChangedEventArgs e)
      {
         onChange(e);
      }

      private void onChange(Autodesk.Revit.UI.ExtensibleStorage.Framework.SchemaEditorEventArgs e)
      {
         ///<WIZARD OPTION="$RC_COLUMN">
         ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
         String elementTypeName = e.Editor.GetEntity().Schema.SchemaName;
         if (elementTypeName == "LabelColumn")
         {
            LabelColumn obj = new LabelColumn();
            obj.SetProperties(e.Entity as Autodesk.Revit.DB.ExtensibleStorage.Entity, e.Document);
         
            e.Editor.SetAttribute("LengthCoefficientY", FieldUIAttribute.PropertyIsEnabled, obj.BucklingDirectionY, DisplayUnitType.DUT_UNDEFINED);
            e.Editor.SetAttribute("ColumnStructureTypeY", FieldUIAttribute.PropertyIsEnabled, obj.BucklingDirectionY, DisplayUnitType.DUT_UNDEFINED);
            e.Editor.SetAttribute("LengthCoefficientZ", FieldUIAttribute.PropertyIsEnabled, obj.BucklingDirectionZ, DisplayUnitType.DUT_UNDEFINED);
            e.Editor.SetAttribute("ColumnStructureTypeZ", FieldUIAttribute.PropertyIsEnabled, obj.BucklingDirectionZ, DisplayUnitType.DUT_UNDEFINED);
         }
         ///</WIZARD>
         ///</WIZARD>
      }

     public override Layout BuildLabelLayout(Schema schema, Document document)
     {
        Layout layout = null;

        ///<WIZARD OPTION="$RC_BEAM">
        if (schema.SchemaName == "LabelBeam")
        {
           layout = Layout.Build(typeof(LabelBeam), this);
        }
        ///</WIZARD>

        ///<WIZARD OPTION="$RC_COLUMN">
        if (schema.SchemaName == "LabelColumn")
        {
           layout = Layout.Build(typeof(LabelColumn), this);
           ///<WIZARD OPTION="$RC_COLUMN_BUCKLING">
           if (layout != null)
           {
              Autodesk.Revit.UI.ExtensibleStorage.Framework.Category category = layout.GetCategory("Buckling");
              String currAssemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName().ToString();
              Image image = new Image() { Source = new Uri("pack://application:,,,/" + currAssemblyName + ";component/UIComponents/ICons/" + "buckling.png"), Index = 1 };
              category.Controls.Add(image);
              layout.SortIndexBased();
           }
           ///</WIZARD>
        }
        ///</WIZARD>

        ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB;$RC_WALL">
        /// <structural_toolkit_2015>
        ///<WIZARD OPTION="$RC_WALL">
        if (schema.SchemaName == "LabelWall")
        {
           layout = Layout.Build(typeof(LabelWall), this);
        }
        ///</WIZARD>
        ///<WIZARD OPTION="$RC_FLOOR;$RC_FOUNDATION_SLAB">
        if (schema.SchemaName == "LabelFloor")
        {
           layout = Layout.Build(typeof(LabelFloor), this);
        }
        ///</WIZARD>
        /// </structural_toolkit_2015>
        ///</WIZARD>

        return layout;
     }

      public override System.Collections.IList GetDataSource(string key, Autodesk.Revit.DB.Document document, Autodesk.Revit.DB.DisplayUnitType unitType)
      {
         return base.GetDataSource(key, document, unitType);
      }

      #endregion
   }
}
