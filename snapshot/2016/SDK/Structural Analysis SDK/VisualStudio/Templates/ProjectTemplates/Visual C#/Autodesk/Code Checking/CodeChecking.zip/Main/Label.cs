﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    /// <summary>
    /// Represents labels.
    /// </summary>
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("Label", "$guid2$")]
    public class Label : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public Label()
        {
        }
		
		public Label(Document document)
        {
        }

        public Label(Entity entity,Document document)
            : base(entity,document)
        {
        }
    }
}
