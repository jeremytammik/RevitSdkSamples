﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("Result", "$guid3$")]
    public class Result : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public Result()
        {
        }
		
		public Result(Document document)
        {
        }

        public Result(Entity entity,Document document)
            : base(entity,document)
        {
        }
    }
}
