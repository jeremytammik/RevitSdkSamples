﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.CodeChecking;
using Autodesk.Revit.DB.CodeChecking.Documentation;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    [Autodesk.Revit.DB.CodeChecking.Attributes.ServerVersion(1)]
	///<WIZARD OPTION="$CC_SERVER_DECLARATION">
	public class Server:Autodesk.Revit.DB.CodeChecking.Documentation.Server<CalculationParameter,Label,Result>
    ///</WIZARD>  
	///<WIZARD OPTION="$CC_MULTISERVER_DECLARATION">
    ///<CODE>
	///[Autodesk.Revit.DB.CodeChecking.Attributes.CalculationParamsStructure(typeof(CalculationParameter))]
///$serverattributes$
	///public class Server : Autodesk.Revit.DB.CodeChecking.Documentation.MultiStructureServer
	///</CODE>
    ///</WIZARD> 
    {
        public static readonly Guid ID = new Guid("$guid6$");
        #region ICodeCheckingServer Members

        public override void Verify(Autodesk.Revit.DB.CodeChecking.ServiceData data)
        {
            Autodesk.Revit.DB.CodeChecking.Storage.StorageService service = Autodesk.Revit.DB.CodeChecking.Storage.StorageService.GetStorageService();
            Autodesk.Revit.DB.CodeChecking.Storage.StorageDocument storageDocument = service.GetStorageDocument(data.Document);

            
            foreach (Element element in data.Selection)
            {
                Autodesk.Revit.DB.CodeChecking.Storage.Label ccLabel = storageDocument.LabelsManager.GetLabel(element);

                if (ccLabel != null)
                {
                    Label myLabel = ccLabel.GetEntity<Label>(data.Document);

		    if(myLabel != null)
		    {
                        CalculationParameter  myParams = storageDocument.CalculationParamsManager.CalculationParams.GetEntity<CalculationParameter>(data.Document);

                        Result myResult = new Result();

                      	storageDocument.ResultsManager.SetResult(myResult.GetEntity(), element);
		   }
                }
            }
        }

        public override IList<BuiltInCategory> GetSupportedCategories(StructuralAssetClass material)
        {
            return new List<BuiltInCategory>() { $supportedcategories$ };
        }

        public override IList<Autodesk.Revit.DB.StructuralAssetClass> GetSupportedMaterials()
        {
            return new List<Autodesk.Revit.DB.StructuralAssetClass>(){ $supportedmaterials$ };
        }

		public override bool LoadCasesAndCombinationsSupport()
        {
            return $loadcombinations$;
        }

        public override bool ResultBuilderPackagesAsInputData()
        {
            return  $resultpackagesasinputdata$;
        }

        public override Autodesk.Revit.DB.ResultsBuilder.UnitsSystem GetOutputPackageUnitSystem()
        {
            return $rbunitssystem$;
        }	

        #endregion

        #region IExternalServer Members

        public override string GetDescription()
        {
            return "$addindescription$";
        }

        public override string GetName()
        {
            return "$addinname$";
        }

        public override Guid GetServerId()
        {
            return ID;
        }

        public override string GetVendorId()
        {
            return "$vendorname$";
        }

        #endregion

        #region ICodeCheckingServerDocumentation Members     

        public override string GetResource(string key, string context)
        {
            string txt = $safeprojectname$.Properties.Resources.ResourceManager.GetString(key);

            if(!string.IsNullOrEmpty(txt))
                return txt;

           return key;
        }

        #endregion
    }
}
