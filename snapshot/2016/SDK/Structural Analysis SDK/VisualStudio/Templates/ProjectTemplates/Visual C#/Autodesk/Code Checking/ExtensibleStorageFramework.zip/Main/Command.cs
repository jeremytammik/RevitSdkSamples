﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage; 
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using System.Windows.Media;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Automatic)]
    [Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)]

    public class Command: IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData commandData,
            ref string message, Autodesk.Revit.DB.ElementSet elements)
        {

            ServerUI serverUI = new ServerUI();

            Schema schemaClassInstance = new Schema();

            Autodesk.Revit.UI.ExtensibleStorage.Framework.Layout layout = Autodesk.Revit.UI.ExtensibleStorage.Framework.Layout.Build(typeof(Schema),serverUI);

            Autodesk.Revit.UI.ExtensibleStorage.Framework.ILayoutControl layoutControl = Autodesk.Revit.UI.ExtensibleStorage.Framework.Layout.BuildControl(serverUI, commandData.Application.ActiveUIDocument.Document, layout, schemaClassInstance);

            MainWindow window = new MainWindow();
            window.dockPanel.Children.Add(layoutControl as System.Windows.UIElement);

            window.ShowAndAssignParent();

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }
}