﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("Schema", "$guid1$")]
    public class Schema : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public Schema()
        {
        }

        public Schema(Document document)
        {
        }

        public Schema(Entity entity, Document document)
            : base(entity, document)
        {
        }
    }
}
