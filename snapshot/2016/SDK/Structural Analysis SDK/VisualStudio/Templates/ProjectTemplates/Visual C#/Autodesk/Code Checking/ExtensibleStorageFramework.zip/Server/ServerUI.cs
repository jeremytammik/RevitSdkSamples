﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    class ServerUI:Autodesk.Revit.UI.ExtensibleStorage.Framework.IServerUI
    {
        public System.Collections.IList GetDataSource(string key, Autodesk.Revit.DB.Document document, Autodesk.Revit.DB.DisplayUnitType unitType)
        {
            return null;
        }

        public void LayoutInitialized(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.LayoutInitializedEventArgs e)
        {
        }

        public void ValueChanged(object sender, Autodesk.Revit.UI.ExtensibleStorage.Framework.ValueChangedEventArgs e)
        {
        }

        public string GetResource(string key, string context)
        {
            string txt = $safeprojectname$.Resources.Texts.ResourceManager.GetString(key);

            if (!string.IsNullOrEmpty(txt))
                return txt;

            return key;
        }

        public Uri GetResourceImage(string key, string context)
        {
            return null;
        }
    }
}
