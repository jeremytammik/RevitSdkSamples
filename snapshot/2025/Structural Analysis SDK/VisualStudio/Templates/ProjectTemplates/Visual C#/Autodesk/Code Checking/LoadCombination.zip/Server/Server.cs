﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.CodeChecking;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.CodeChecking.Storage.LoadCombination;
using Autodesk.Revit.DB.CodeChecking.LoadCombination;
using Autodesk.Revit.DB.Structure;

namespace $safeprojectname$
{
    public class Server:Autodesk.Revit.DB.CodeChecking.LoadCombination.Server<LoadCombination>
    {
        public static readonly Guid ID = new Guid("$guid6$");
        #region ICodeCheckingServer Members

 public override List<LoadCombinationPreview> GeneratePreview(Autodesk.Revit.DB.CodeChecking.LoadCombination.ServiceData data)
        {
            LoadCombinationManager manager = LoadCombinationManager.GetManager(data.Document);

            LoadCombination loadCombination = manager.LoadCombinationParams.GetEntity<LoadCombination>(data.Document);
            
            if (loadCombination != null)
            {
                List<LoadCombinationPreview> combinations = new List<LoadCombinationPreview>();

		LoadCaseArray cases = manager.LoadCombinationParams.GetLoadCasesArray(ID);

                return combinations;
            }

            return null;
        }  

        #endregion

         #region IExternalServer Members

        public override string GetDescription()
        {
            return "$addindescription$";
        }

        public override string GetName()
        {
            return "$addinname$";
        }

        public override Guid GetServerId()
        {
            return ID;
        }

        public override string GetVendorId()
        {
            return "$vendorname$";
        }

        #endregion
    }
}
