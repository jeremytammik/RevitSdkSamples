﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    class ServerDocument:Autodesk.Revit.DB.ExtensibleStorage.Framework.IResource
    {
        public string GetResource(string key, string context)
        {
            string txt = $safeprojectname$.Resources.Texts.ResourceManager.GetString(key);

            if (!string.IsNullOrEmpty(txt))
                return txt;

            return key;
        }

        public Uri GetResourceImage(string key, string context)
        {
            return null;
        }
    }
}
