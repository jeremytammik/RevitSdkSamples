﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $safeprojectname$
{
	///<WIZARD OPTION="$CC_SERVER_DECLARATION">
    public class ServerUI : Autodesk.Revit.UI.CodeChecking.Server<CalculationParameter,Label>
    ///</WIZARD>  
	///<WIZARD OPTION="$CC_MULTISERVER_DECLARATION">
    ///<CODE>
	///[Autodesk.Revit.DB.CodeChecking.Attributes.CalculationParamsStructure(typeof(CalculationParameter))]
///$serveruiattributes$
	///public class ServerUI : Autodesk.Revit.UI.CodeChecking.MultiStructureServer
	///</CODE>
    ///</WIZARD>
    {
        #region ICodeCheckingServerUI Members

        public override string GetResource(string key, string context)
        {
            string txt = $safeprojectname$.Properties.Resources.ResourceManager.GetString(key);

            if(!string.IsNullOrEmpty(txt))
                return txt;

           return key;
        }

        public override Uri GetResourceImage(string key, string context)
        {
           return new Uri(@"pack://application:,,,/$safeprojectname$;component/"+key);
        }

        #endregion
    }
}
