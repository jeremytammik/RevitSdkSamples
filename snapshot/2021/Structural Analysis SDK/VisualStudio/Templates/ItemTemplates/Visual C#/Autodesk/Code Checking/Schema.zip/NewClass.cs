﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.DB;

namespace $rootnamespace$
{
    [Autodesk.Revit.DB.ExtensibleStorage.Framework.Attributes.Schema("$safeitemname$","$guid1$")]
    public class $safeitemname$ : Autodesk.Revit.DB.ExtensibleStorage.Framework.SchemaClass
    {
        public $safeitemname$()
        {
        }

        public $safeitemname$(Document document)
        {
        }

        public $safeitemname$(Entity entity, Document document)
            : base(entity, document)
        {
        }
    }
}
